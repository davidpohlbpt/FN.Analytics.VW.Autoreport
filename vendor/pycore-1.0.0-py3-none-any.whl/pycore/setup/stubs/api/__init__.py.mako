from pycore.api.web.app import app
from pycore import easy

# app.include_router(...)
# easy.hook_repo.hook_in_source(...)