from pycore.api.cli.commands import app

@app.command()
def my_command():
    print("Hello World! ${project_folder} is up and running.")