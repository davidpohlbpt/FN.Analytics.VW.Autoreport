from ${project_folder}.api.cli.commands import app
app()
