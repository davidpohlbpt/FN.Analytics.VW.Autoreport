# This gives you access to all integration testing fixtures from the pycore docs
from pycore.testing.integration import *