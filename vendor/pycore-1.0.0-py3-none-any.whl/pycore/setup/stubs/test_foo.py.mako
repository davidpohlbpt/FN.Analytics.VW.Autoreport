def test_bar():
    
    # Arrange

    a = 1
    b = 1
    exp_result = 2

    # Act

    act_result = a + b

    # Assert

    assert act_result == exp_result
