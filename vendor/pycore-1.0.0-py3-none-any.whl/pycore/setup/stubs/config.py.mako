from pydantic_settings import BaseSettings


class ProjectSettings(BaseSettings):
    pass


settings = ProjectSettings()
