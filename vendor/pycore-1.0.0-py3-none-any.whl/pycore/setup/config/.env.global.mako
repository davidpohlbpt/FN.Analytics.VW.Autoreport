app_name = "${serviceName}"
app_db_name = "***" # TODO if needed