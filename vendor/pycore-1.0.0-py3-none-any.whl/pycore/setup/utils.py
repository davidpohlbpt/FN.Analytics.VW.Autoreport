import logging
import os
import pathlib
import platform
import re

import toml
import typer

RES_DIR = pathlib.Path(os.path.dirname(os.path.realpath(__file__)))
ROOT_DIR = pathlib.Path()
DEPLOYMENT_DIR = ROOT_DIR / "deployment"
ALEMBIC_DIR = DEPLOYMENT_DIR / "alembic"


def create_files():
    # Select the project name from the pyproject.toml file
    try:
        project_def = toml.load("pyproject.toml")
        name = project_def["tool"]["poetry"]["name"]
        name = name.lower()  # e.g. PyCore to pycore
        name = name.replace("-", "_")  # e.g. py-core to py_core
        name = re.sub(r"\W", "", name)  # e.g. py!core to pycore
    except FileNotFoundError:
        logging.critical(
            msg="A file 'pyproject.toml' created by poetry must exist in the root directory."
        )
        raise typer.Exit()
    except toml.TomlDecodeError:
        logging.critical(
            msg="The file 'pyproject.toml' is malformed. Only use poetry commands to modify this file."
        )
        raise typer.Exit()

    if not typer.confirm(f"Confirm project folder '{name}/'"):
        return

    if typer.confirm("Create config files"):
        create_config_files(project_folder=name)

    if typer.confirm("Create testing files"):
        create_testing_files(project_folder=name)

    if typer.confirm("Create alembic files"):
        create_alembic_files(project_folder=name)

    if typer.confirm("Create 'main.py' files"):
        create_main_files(project_folder=name)

    if typer.confirm("Create pipeline files"):
        create_pipeline_files(project_folder=name)

    if typer.confirm("Create test data script"):
        create_test_data_script(project_folder=name)


def create_pipeline_files(project_folder: str):
    version = ".".join(platform.python_version().split(".")[0:2])
    if not typer.confirm(f"Confirm Python version '{version}'"):
        return

    # Create required files
    copy_file(
        RES_DIR / "pipelines" / "build.yml",
        ROOT_DIR / "deployment" / "pipelines" / "build.yml",
        tokens={"serviceName": project_folder, "pythonVersion": version},
    )
    copy_file(
        RES_DIR / "pipelines" / "deploy.yml",
        ROOT_DIR / "deployment" / "pipelines" / "deploy.yml",
        tokens={"serviceName": project_folder},
    )
    copy_file(
        RES_DIR / "pipelines" / "variables.yml",
        ROOT_DIR / "deployment" / "pipelines" / "variables.yml",
    )

    copy_file(
        RES_DIR / "config" / ".dockerignore",
        ROOT_DIR / ".dockerignore",
    )


def create_config_files(project_folder: str):
    copy_file(
        RES_DIR / "config" / ".gitignore",
        ROOT_DIR / ".gitignore",
    )

    copy_file(
        RES_DIR / "config" / ".env.global.mako",
        ROOT_DIR / ".env.global",
        params={"serviceName": project_folder},
    )

    copy_file(
        RES_DIR / "config" / ".env",
        ROOT_DIR / ".env",
    )

    copy_file(
        RES_DIR / "config" / "launch.json",
        ROOT_DIR / ".vscode" / "launch.json",
        params={"serviceName": project_folder},
    )


def create_main_files(project_folder: str):
    # Create required files
    copy_file(
        RES_DIR / "stubs" / "api" / "__main__.py.mako",
        ROOT_DIR / project_folder / "__main__.py",
        params={"project_folder": project_folder},
    )
    copy_file(
        RES_DIR / "stubs" / "api" / "commands.py.mako",
        ROOT_DIR / project_folder / "api" / "cli" / "commands.py",
        params={"project_folder": project_folder},
    )
    copy_file(
        RES_DIR / "stubs" / "api" / "__init__.py.mako",
        ROOT_DIR / project_folder / "api" / "web" / "__init__.py",
    )


def create_testing_files(project_folder: str):
    copy_file(
        RES_DIR / "config" / "settings.json",
        ROOT_DIR / ".vscode" / "settings.json",
        params={"serviceName": project_folder},
    )

    copy_file(
        RES_DIR / "stubs" / "integration_conftest.py.mako",
        ROOT_DIR / "tests" / "integration" / "conftest.py",
    )

    copy_file(
        RES_DIR / "stubs" / "unit_conftest.py.mako",
        ROOT_DIR / "tests" / "unit" / "conftest.py",
    )

    copy_file(
        RES_DIR / "stubs" / "test_foo.py.mako",
        ROOT_DIR / "tests" / "unit" / "test_foo.py",
    )


def create_alembic_files(project_folder: str):
    # Create required files
    copy_file(RES_DIR / "alembic" / "alembic.ini", ROOT_DIR / "alembic.ini")
    copy_file(RES_DIR / "alembic" / "script.py.mako", ALEMBIC_DIR / "script.py.mako")
    copy_file(
        RES_DIR / "alembic" / "env.py.mako",
        ALEMBIC_DIR / "env.py",
        params={"project_folder": project_folder},
    )

    # Create empty version directory
    (ALEMBIC_DIR / "versions").mkdir(exist_ok=True)


def has_all_alembic_files():
    return all(
        [
            (ROOT_DIR / "alembic.ini").is_file(),
            (ALEMBIC_DIR / "script.py.mako").is_file(),
            (ALEMBIC_DIR / "env.py").is_file(),
        ]
    )


def create_test_data_script(project_folder: str):
    # Create required files
    copy_file(
        RES_DIR / "stubs" / "test.py.mako",
        ROOT_DIR / "deployment" / "data" / "test.py",
        params={"project_folder": project_folder},
    )


def copy_file(
    source: pathlib.Path,
    target: pathlib.Path,
    params: dict[str, str] | None = None,
    tokens: dict[str, str] | None = None,
):
    params = params or {}
    tokens = tokens or {}
    exists = target.is_file()
    if exists and not typer.confirm(f"Override '{target.name}'"):
        typer.echo(f"-> Skipping '{target}'.")
        return

    # Ensure directory exists
    target.parent.mkdir(exist_ok=True, parents=True)

    with open(source, encoding="utf-8") as f:
        content = f.read()

    for param, value in params.items():
        content = content.replace("${" + param + "}", value)

    for param, value in tokens.items():
        content = content.replace("__" + param + "__", value)

    with open(target, "w+") as f:
        f.write(content)

    param_str = ",".join([k + "=" + v for k, v in params.items()])
    action = "Overriden" if exists else "Created"
    typer.echo(f"-> {action} {target}{' with params ' + param_str if params else ''}.")
