import sqlalchemy as sa

from pycore.repository.services.rdp import (
    INC_TABLE,
    INC_TAG_TABLE,
    OCC_TABLE,
    INC_RESOLUTION_TABLE,
    INC_HISTORY_TABLE,
    INC_EVENT_TYPE_TABLE,
    GROUP_INFORMATION_TABLE,
    DATA_TRANSFER_TABLE,
)


def add_rdp_tabs_to_meta(meta: sa.MetaData):
    inc = get_incident_tab(meta)
    inc_tag = get_incident_tag_tab(meta)
    occ = get_occurence_tab(meta)
    inc_res = get_incident_resolution_tab(meta)
    inc_his = get_incident_history_tab(meta)
    inc_event_type = get_incident_event_type_tab(meta)
    inc_group = get_group_information_tab(meta)
    data_transfer = get_data_transfer_tab(meta)
    return {
        INC_TABLE: inc,
        INC_TAG_TABLE: inc_tag,
        OCC_TABLE: occ,
        INC_RESOLUTION_TABLE: inc_res,
        INC_HISTORY_TABLE: inc_his,
        INC_EVENT_TYPE_TABLE: inc_event_type,
        GROUP_INFORMATION_TABLE: inc_group,
        DATA_TRANSFER_TABLE: data_transfer,
    }


def get_incident_tab(meta: sa.MetaData) -> sa.Table:

    return sa.Table(
        INC_TABLE,
        meta,
        sa.Column("IncidentID", sa.Integer, primary_key=True),
        sa.Column("ScenarioID", sa.Integer, primary_key=True),
        sa.Column("RuleID", sa.String(100), nullable=False),
        sa.Column("BusinessRuleID", sa.String(100), nullable=False),
        sa.Column("Identifier", sa.JSON),
        sa.Column("Loads", sa.JSON),
        sa.Column("ReportingUnitID", sa.Integer),
        sa.Column("Status", sa.String),
        sa.Column("Created", sa.DateTime),
        sa.Column("Dimension", sa.String(100)),
        sa.Column("AssignedUser", sa.String(500)),
        sa.Column("EntityID", sa.Integer),
        sa.Column("BulkInsertSessionID", sa.Integer),
        sa.Column("TransferInProgress", sa.Boolean),
    )


def get_incident_tag_tab(meta: sa.MetaData) -> sa.Table:

    return sa.Table(
        INC_TAG_TABLE,
        meta,
        sa.Column("IncidentTagID", sa.Integer, primary_key=True),
        sa.Column("IncidentID", sa.Integer),
        sa.Column("ScenarioID", sa.Integer),
        sa.Column("TagPropertiesID", sa.Integer),
        sa.Column("ChangedOn", sa.DateTime),
        sa.Column("ChangedBy", sa.String),
    )


def get_occurence_tab(meta: sa.MetaData) -> sa.Table:
    return sa.Table(
        OCC_TABLE,
        meta,
        sa.Column("OccurenceID", sa.Integer, primary_key=True),
        sa.Column("ScenarioID", sa.Integer, primary_key=True),
        sa.Column("IncidentID", sa.Integer),
        sa.Column("RuleID", sa.String(100), nullable=False),
        sa.Column("BusinessRuleID", sa.String(100), nullable=False),
        sa.Column("LoadID", sa.Integer),
        sa.Column("ReportingUnitID", sa.Integer),
        sa.Column("Fields", sa.JSON),
        sa.Column("EntityID", sa.Integer),
        sa.Column("TransferInProgress", sa.Boolean),
    )


def get_incident_resolution_tab(meta: sa.MetaData) -> sa.Table:
    return sa.Table(
        INC_RESOLUTION_TABLE,
        meta,
        sa.Column("Id", sa.Integer, primary_key=True),
        sa.Column("IncidentID", sa.Integer, nullable=False),
        sa.Column("ScenarioID", sa.Integer, nullable=False),
        sa.Column("LoadId", sa.Integer, nullable=False),
        sa.Column("UserId", sa.String(250)),
        sa.Column("CreatedBy", sa.String),
        sa.Column("CreatedOn", sa.DateTime),
    )


def get_incident_history_tab(meta: sa.MetaData) -> sa.Table:
    return sa.Table(
        INC_HISTORY_TABLE,
        meta,
        sa.Column("IncidentHistoryID", sa.Integer, primary_key=True),
        sa.Column("IncidentID", sa.Integer, nullable=False),
        sa.Column("ScenarioID", sa.Integer, nullable=False),
        sa.Column("EventTypeID", sa.Integer),
        sa.Column("DateTime", sa.DateTime),
        sa.Column("UserId", sa.String(450)),
        sa.Column("LoadID", sa.Integer),
        sa.Column("RuleID", sa.String(100)),
        sa.Column("Comment", sa.String),
        sa.Column("HideUntil", sa.DateTime),
    )


def get_incident_event_type_tab(meta: sa.MetaData) -> sa.Table:
    return sa.Table(
        INC_EVENT_TYPE_TABLE,
        meta,
        sa.Column("EventTypeID", sa.Integer, primary_key=True),
        sa.Column("EventName", sa.String(50)),
        sa.Column("TranslationKey", sa.String(200)),
    )


def get_group_information_tab(meta: sa.MetaData) -> sa.Table:
    return sa.Table(
        GROUP_INFORMATION_TABLE,
        meta,
        sa.Column("GroupInformationID", sa.Integer, primary_key=True),
        sa.Column("GroupingDimensionID", sa.Integer, nullable=False),
        sa.Column("GroupID", sa.String),
        sa.Column("ScenarioID", sa.Integer, nullable=False),
        sa.Column("Description", sa.String),
        sa.Column("TagPropertiesID", sa.Integer),
        sa.Column("ChangedOn", sa.DateTime),
        sa.Column("ChangedBy", sa.String),
    )


def get_data_transfer_tab(meta: sa.MetaData) -> sa.Table:
    return sa.Table(
        DATA_TRANSFER_TABLE,
        meta,
        sa.Column("Id", sa.Integer, primary_key=True),
        sa.Column("OccurrenceId", sa.Integer),
        sa.Column("ScenarioId", sa.Integer),
        sa.Column("Identifier", sa.String),
        sa.Column("Table", sa.String),
        sa.Column("Field", sa.String),
        sa.Column("BeforeValue", sa.String),
        sa.Column("AfterValue", sa.String),
        sa.Column("TransactionDate", sa.DateTime),
        sa.Column("TransactionOwner", sa.String),
        sa.Column("Transferred", sa.Boolean),
        sa.Column("TransactionId", sa.String),
    )
