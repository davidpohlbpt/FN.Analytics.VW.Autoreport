import os

import dotenv
import pytest

from pycore.resources.http import AdminHttpSession

AZ_KV_URL = "https://fntest-kv6.vault.azure.net"
TEST_BASE_URL = "https://test.factorynavigator.de"


@pytest.fixture
def vault_conn_str():
    """Returns the connection string to the Azure Key Vault of the test environment."""
    dotenv.load_dotenv()
    return os.environ["key_vault_conn_str"]


@pytest.fixture()
def vault(vault_conn_str):
    """Returns a `AzureKeyVault` resource based on the Azure Key Vault of the test environment."""
    from pycore.resources.azure import AzureKeyVault

    return AzureKeyVault(url=AZ_KV_URL, conn_str=vault_conn_str)


@pytest.fixture()
def http_session(vault):
    """Returns a `AdminHttpSession` resource based on the test environment."""
    http_secret = vault.get_secret("IdentityClientAdmin")
    return AdminHttpSession(base_url=TEST_BASE_URL, http_secret=http_secret)
