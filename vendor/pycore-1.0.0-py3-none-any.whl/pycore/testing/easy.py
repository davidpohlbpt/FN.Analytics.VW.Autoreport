import pytest

from pycore.enum import EnvironmentType, ServiceType
from pycore.repository.data import DataRepository
from pycore.repository.hooks import HookRepository
from pycore.repository.services.batch import BatchRepository
from pycore.repository.services.masterdata import MasterDataRepository
from pycore.repository.services.monitoring import MonitoringRepository
from pycore.repository.services.rdp import ReportDataProviderRepository
from pycore.repository.services.rules_mgmt import RulesMgmtRepository
from pycore.repository.services.tracker import TrackerRepository
from pycore.resources.abc import BlobStorage, HttpSession, Vault
from pycore.resources.odbc import OdbcDatabase
from pycore.resources.openai.openai import OpenAiSession


@pytest.fixture(autouse=True)
def easy_test(
    monkeypatch: pytest.MonkeyPatch,
    database: OdbcDatabase,
    rdp_db: OdbcDatabase,
    md_db: OdbcDatabase,
    batch_api_db: OdbcDatabase,
    storage: BlobStorage,
    vault: Vault,
    http_session: HttpSession,
    openai: OpenAiSession,
):
    from pycore import easy

    monkeypatch.setattr(easy, "openai", openai)
    monkeypatch.setattr(easy.database, "res", database)
    monkeypatch.setattr(easy.rdp_db, "res", rdp_db)
    monkeypatch.setattr(easy.md_db, "res", md_db)
    monkeypatch.setattr(easy.batch_api_db, "res", batch_api_db)
    monkeypatch.setattr(easy.storage, "res", storage)
    monkeypatch.setattr(easy.vault, "res", vault)
    monkeypatch.setattr(easy.http_session, "res", http_session)
    monkeypatch.setattr(easy, "data_repo", DataRepository(easy.database))
    monkeypatch.setattr(
        easy, "tracker", TrackerRepository(easy.http_session, env=EnvironmentType.LOCAL)
    )
    monkeypatch.setattr(
        easy,
        "monitoring_service",
        MonitoringRepository(easy.http_session, env=EnvironmentType.LOCAL),
    )
    monkeypatch.setattr(
        easy,
        "batch_service",
        BatchRepository(
            database=easy.batch_api_db,
            http_session=easy.http_session,
            env=EnvironmentType.LOCAL,
        ),
    )
    monkeypatch.setattr(
        easy,
        "rules_mgmt",
        RulesMgmtRepository(easy.http_session, env=EnvironmentType.LOCAL),
    )
    monkeypatch.setattr(
        easy, "rdp_repo", ReportDataProviderRepository(database=easy.rdp_db)
    )
    monkeypatch.setattr(easy, "md_repo", MasterDataRepository(database=easy.md_db))
    monkeypatch.setattr(easy, "hook_repo", HookRepository())

    services = {
        ServiceType.TRACKER: easy.tracker,
        ServiceType.MONITORING: easy.monitoring_service,
        ServiceType.BATCH: easy.batch_service,
        ServiceType.RULES_MGMT: easy.rules_mgmt,
    }
    monkeypatch.setattr(easy, "services", services)

    return easy


@pytest.fixture
def hook_repo(easy_test) -> HookRepository:
    """Returns a `HookRepository` repository.

    Returns:
        HookRepository: hook repository object.
    """
    return easy_test.hook_repo
