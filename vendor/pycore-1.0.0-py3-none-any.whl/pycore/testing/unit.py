import os

import pytest
import requests_mock
import sqlalchemy as sa

from pycore.enum import EnvironmentType, ResourceType
from pycore.repository.services.rdp import (
    DATA_TRANSFER_TABLE,
    GROUP_INFORMATION_TABLE,
    INC_EVENT_TYPE_TABLE,
    INC_HISTORY_TABLE,
    INC_RESOLUTION_TABLE,
    INC_TABLE,
    INC_TAG_TABLE,
    OCC_TABLE,
    ReportDataProviderRepository,
)
from pycore.resources.openai.openai import OpenAiSession
from pycore.testing.easy import easy_test, hook_repo  # fixtures

os.environ["resource_type"] = ResourceType.MEMORY.value
os.environ["environment"] = EnvironmentType.LOCAL.value

from pycore import (
    BlobStorage,
    DataRepository,
    DeclarativeBase,
    EnvVault,
    HttpSession,
    NoAuthHttpSession,
    OdbcDatabase,
    SqliteDatabase,
    TempFileStorage,
    Vault,
)


@pytest.fixture
def base_url(requests_mock: requests_mock.mocker.Mocker) -> str:
    """Returns the base URL used for mocked FN services.

    Requests to this base URL can be mocked using the library [requests-mock](https://requests-mock.readthedocs.io/en/latest/).
    See [StackOverflow](https://stackoverflow.com/questions/57663308/how-to-mock-requests-using-pytest) for an usage example.
    A simple GET to this base url is already mocked with this fixture.


    Args:
        requests_mock (requests_mock.mocker.Mocker): fixture provided by the library requests-mock (must be installed)

    Returns:
        str: constant base url 'http://test'
    """
    requests_mock.real_http = True
    url = "http://test"
    requests_mock.get(url)
    return url


@pytest.fixture
def database() -> OdbcDatabase:
    """Returns a `OdbcDatabase` resource based on an in-menory SQLite database resource.

    Returns:
        DatabaseResource: _description_
    """
    return SqliteDatabase(base=DeclarativeBase)


@pytest.fixture
def rdp_db() -> OdbcDatabase:
    """Returns a `OdbcDatabase` resource based on an in-menory SQLite database resource.

    Returns:
        DatabaseResource: _description_
    """
    return SqliteDatabase()


@pytest.fixture
def md_db() -> OdbcDatabase:
    """Returns a `OdbcDatabase` resource based on an in-menory SQLite database resource.

    Returns:
        DatabaseResource: _description_
    """
    return SqliteDatabase()


@pytest.fixture
def batch_api_db() -> OdbcDatabase:
    """Returns a `OdbcDatabase` resource based on an in-menory SQLite database resource.

    Returns:
        DatabaseResource: _description_
    """
    return SqliteDatabase()


@pytest.fixture
def data_repo(database: SqliteDatabase) -> DataRepository:
    """Returns a `DataRepository` based on a given database resource fixture.

    Args:
        database (OdbcDatabase): database resource used in the repository.

    Returns:
        DataRepository: repository object.
    """
    return DataRepository(database=database)


@pytest.fixture
def rdp_repo(rdp_db: SqliteDatabase) -> ReportDataProviderRepository:
    """Returns a `ReportDataProviderRepository` based on a given database resource fixture.

    Args:
        database (OdbcDatabase): database resource used in the repository.

    Returns:
        ReportDataProviderRepository: repository object.
    """
    return ReportDataProviderRepository(database=rdp_db)


@pytest.fixture
def vault() -> Vault:
    """Returns a `Vault` resource based on environment variables for secret storage.

    Returns:
        Vault: vault object.
    """
    return EnvVault()


@pytest.fixture
def storage() -> BlobStorage:
    """Returns a `BlobStorage` resource based on a temporary local directory.

    Returns:
        BlobStorage: blob storage object.
    """
    return TempFileStorage()


@pytest.fixture
def http_session(base_url: str) -> HttpSession:
    """Returns a `HttpSession` resource based on a simple session without authentication involved.

    This can be used to test calls to other services.
    These calls must be mocked using [requests-mock](https://requests-mock.readthedocs.io/en/latest/).
    See [StackOverflow](https://stackoverflow.com/questions/57663308/how-to-mock-requests-using-pytest) for an usage example.

    Args:
        base_url (str): service base URL.

    Returns:
        HttpSession: session object.
    """
    return NoAuthHttpSession(base_url=base_url)


@pytest.fixture
def db_scope(database: OdbcDatabase) -> sa.orm.session.Session:
    """Returns a transactional session scope based on the provided database fixture.

    The session is closed after test execution and all changes are committed.
    If committing the changes fails, the test fails as well.

    Args:
        database (OdbcDatabase): database resource with connection information.

    Yields:
        sa.orm.session.Session: transactional session scope.
    """
    # Closes connection after test execution
    with database.session_scope() as db:
        yield db


@pytest.fixture
def test_client() -> "TestClient":
    """Returns a test client that can be used to send HTTP request to this service."""

    from fastapi.testclient import TestClient

    from pycore.api.web.app import app

    return TestClient(app)


@pytest.fixture
def openai() -> OpenAiSession:
    # Cannot be used adequately in tests
    # get_completion() must be mocked individually per use case
    return OpenAiSession(
        base_url="",
        api_key=None,
        deployment_name=None,
    )


@pytest.fixture(autouse=True)
def inc_table(rdp_db):
    class Incident(rdp_db.base):
        __tablename__ = INC_TABLE
        __table_args__ = {"extend_existing": True}
        IncidentID = sa.Column(sa.Integer, primary_key=True)
        ScenarioID = sa.Column(sa.Integer, primary_key=True)
        RuleID = sa.Column(sa.String(100), nullable=False)
        BusinessRuleID = sa.Column(sa.String(100), nullable=False)
        Identifier = sa.Column(sa.JSON)
        Loads = sa.Column(sa.JSON)
        ReportingUnitID = sa.Column(sa.Integer)
        Status = sa.Column(sa.String)
        Created = sa.Column(sa.DateTime)
        Dimension = sa.Column(sa.String(100))
        AssignedUser = sa.Column(sa.String(500))
        EntityID = sa.Column(sa.Integer)
        BulkInsertSessionID = sa.Column(sa.Integer)
        TransferInProgress = sa.Column(sa.Boolean)

    rdp_db.create_all_tables()
    return Incident


@pytest.fixture(autouse=True)
def inc_tag_table(rdp_db):
    class IncidentTag(rdp_db.base):
        __tablename__ = INC_TAG_TABLE
        __table_args__ = {"extend_existing": True}
        IncidentTagID = sa.Column(sa.Integer, primary_key=True)
        IncidentID = sa.Column(sa.Integer, primary_key=False)
        ScenarioID = sa.Column(sa.Integer, primary_key=False)
        TagPropertiesID = sa.Column(sa.Integer)
        ChangedOn = sa.Column(sa.DateTime)
        ChangedBy = sa.Column(sa.String)

    rdp_db.create_all_tables()
    return IncidentTag


@pytest.fixture(autouse=True)
def occ_table(rdp_db):
    class Occurence(rdp_db.base):
        __tablename__ = OCC_TABLE
        __table_args__ = {"extend_existing": True}
        OccurenceID = sa.Column(sa.Integer, primary_key=True)
        ScenarioID = sa.Column(sa.Integer, primary_key=True)
        IncidentID = sa.Column(sa.Integer, primary_key=False)
        RuleID = sa.Column(sa.String(100), nullable=False)
        BusinessRuleID = sa.Column(sa.String(100), nullable=False)
        LoadID = sa.Column(sa.Integer, nullable=False)
        ReportingUnitID = sa.Column(sa.Integer, nullable=False)
        Fields = sa.Column(sa.JSON)
        EntityID = sa.Column(sa.Integer, nullable=False)
        TransferInProgress = sa.Column(sa.Boolean)

    rdp_db.create_all_tables()
    return Occurence


@pytest.fixture(autouse=True)
def inc_resolution_table(rdp_db):
    class IncidentResolution(rdp_db.base):
        __tablename__ = INC_RESOLUTION_TABLE
        __table_args__ = {"extend_existing": True}
        Id = sa.Column(sa.Integer, primary_key=True)
        IncidentID = sa.Column(sa.Integer, nullable=False)
        ScenarioID = sa.Column(sa.Integer, nullable=False)
        LoadId = sa.Column(sa.Integer, nullable=False)
        UserId = sa.Column(sa.String(250))
        CreatedBy = sa.Column(sa.String)
        CreatedOn = sa.Column(sa.DateTime)

    rdp_db.create_all_tables()
    return IncidentResolution


@pytest.fixture(autouse=True)
def inc_hist_table(rdp_db):
    class IncidentHistory(rdp_db.base):
        __tablename__ = INC_HISTORY_TABLE
        __table_args__ = {"extend_existing": True}
        IncidentHistoryID = sa.Column(sa.Integer, primary_key=True)
        IncidentID = sa.Column(sa.Integer, nullable=False)
        ScenarioID = sa.Column(sa.Integer, nullable=False)
        EventTypeID = sa.Column(sa.Integer)
        DateTime = sa.Column(sa.DateTime)
        UserId = sa.Column(sa.String(450))
        LoadID = sa.Column(sa.Integer)
        RuleID = sa.Column(sa.String(100))
        Comment = sa.Column(sa.String)
        HideUntil = sa.Column(sa.DateTime)

    rdp_db.create_all_tables()
    return IncidentHistory


@pytest.fixture(autouse=True)
def inc_event_type_table(rdp_db):
    class IncidentEventType(rdp_db.base):
        __tablename__ = INC_EVENT_TYPE_TABLE
        __table_args__ = {"extend_existing": True}
        EventTypeID = sa.Column(sa.Integer, primary_key=True)
        EventName = sa.Column(sa.String(50))
        TranslationKey = sa.Column(sa.String(200))

    rdp_db.create_all_tables()
    return IncidentEventType


@pytest.fixture(autouse=True)
def group_information_table(rdp_db):
    class GroupInformation(rdp_db.base):
        __tablename__ = GROUP_INFORMATION_TABLE
        __table_args__ = {"extend_existing": True}
        GroupInformationID = sa.Column(sa.Integer, primary_key=True)
        GroupingDimensionID = sa.Column(sa.Integer, nullable=False)
        GroupID = sa.Column(sa.String)
        ScenarioID = sa.Column(sa.Integer, nullable=False)
        Description = sa.Column(sa.String)
        TagPropertiesID = sa.Column(sa.Integer)
        ChangedOn = sa.Column(sa.DateTime)
        ChangedBy = sa.Column(sa.String)

    rdp_db.create_all_tables()
    return GroupInformation


@pytest.fixture(autouse=True)
def data_transfer_table(rdp_db):
    class DataTransfer(rdp_db.base):
        __tablename__ = DATA_TRANSFER_TABLE
        __table_args__ = {"extend_existing": True}
        Id = sa.Column("Id", sa.Integer, primary_key=True)
        OccurrenceId = sa.Column("OccurrenceId", sa.Integer)
        ScenarioId = sa.Column("ScenarioId", sa.Integer)
        Identifier = sa.Column("Identifier", sa.String)
        Table = sa.Column("Table", sa.String)
        Field = sa.Column("Field", sa.String)
        BeforeValue = sa.Column("BeforeValue", sa.String)
        AfterValue = sa.Column("AfterValue", sa.String)
        TransactionDate = sa.Column("TransactionDate", sa.DateTime)
        TransactionOwner = sa.Column("TransactionOwner", sa.String)
        Transferred = sa.Column("Transferred", sa.Boolean)
        TransactionId = sa.Column("TransactionId", sa.String)

    rdp_db.create_all_tables()
    return DataTransfer
