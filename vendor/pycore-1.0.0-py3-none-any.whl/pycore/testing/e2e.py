import os

import pytest

from pycore import OdbcDatabase, SqlServerDatabase
from pycore.config import settings
from pycore.enum import EnvironmentType
from pycore.resources.abc import SecretValue
from pycore.resources.http import AdminHttpSession, NoAuthHttpSession
from pycore.resources.openai import OpenAiSettings
from pycore.resources.openai.openai import OpenAiSession
from pycore.testing.azure import (  # used as fixture
    TEST_BASE_URL,
    http_session,
    vault,
    vault_conn_str,
)
from pycore.testing.easy import easy_test, hook_repo  # auto-use fixture


@pytest.fixture
def database(vault) -> OdbcDatabase:
    """Returns a `OdbcDatabase` resource based either on a local or an Azure SQL Server database.

    If this code is executed either in or as in a Kubernetes cluster, an Azure SQL Server database running on the test system is used.
    If this code is executed locally, or in a docker-compose file a local SQL Server database is used.

    Returns:
        DatabaseResource: SQL Server database bound to this app's database
    """
    if settings.e2e_test:
        db_secret = vault.get_secret("Database-GenericDBConnectionString")
        return SqlServerDatabase(conn_secret=db_secret, db_name=settings.app_db_name)
    else:
        conn_str = os.environ.get("local_sqlserver_conn_str")
        return SqlServerDatabase(
            conn_secret=SecretValue(conn_str), db_name=settings.app_db_name
        )


@pytest.fixture
def rdp_db(vault) -> OdbcDatabase:
    """Returns a `OdbcDatabase` resource based on an Azure SQL Server database resource.

    Returns:
        DatabaseResource: Azure SQL Server database bound to the ReportDB of the test environment
    """
    db_secret = vault.get_secret("Database-GenericDBConnectionString")
    return SqlServerDatabase(conn_secret=db_secret, db_name="ReportDB")

@pytest.fixture
def md_db(vault) -> OdbcDatabase:
    """Returns a `OdbcDatabase` resource based on an Azure SQL Server database resource.

    Returns:
        DatabaseResource: Azure SQL Server database bound to the MasterDataDB of the test environment
    """
    db_secret = vault.get_secret("Database-GenericDBConnectionString")
    return SqlServerDatabase(conn_secret=db_secret, db_name="MasterDataDB")


@pytest.fixture
def batch_api_db(vault) -> OdbcDatabase:
    """Returns a `OdbcDatabase` resource based on an Azure SQL Server database resource.

    Returns:
        DatabaseResource: Azure SQL Server database bound to the BatchApiDB of the test environment
    """
    db_secret = vault.get_secret("Database-GenericDBConnectionString")
    return SqlServerDatabase(conn_secret=db_secret, db_name="BatchApiDB")


@pytest.fixture
def storage(vault):
    """Returns a `Storage` resource based on an Azure Blob Storage resource.

    Returns:
        StorageResource: Azure Blob Storage bound to the test environment
    """
    from pycore.resources.azure.storage import AzureBlobStorage

    conn_secret = vault.get_secret("AppSettings-StorageAccountConnString")
    return AzureBlobStorage(conn_secret=conn_secret)


@pytest.fixture
def openai(vault) -> OpenAiSession:
    settings = OpenAiSettings()
    # Requires the secret to be present in the key vault fntest-kv6
    api_key = vault.get_secret(settings.secret_name)
    return OpenAiSession(
        base_url=settings.base_url,
        deployment_name=settings.deployment_name,
        api_key=api_key,
    )


@pytest.fixture
def test_client(vault):
    """Returns a `TestClient` resource based on the FastAPI app.

    If this code is executed either in or as in a Kubernetes cluster, requests are routed through the API Gateway to the actually deployed service.
    If this code is executed in a docker-compose file, the requests are routed directly to the service.

    Returns:
        TestClient: TestClient bound to this app's API
    """
    if settings.e2e_test:
        http_secret = vault.get_secret("IdentityClientAdmin")
        session = AdminHttpSession(base_url=TEST_BASE_URL, http_secret=http_secret)
        session.base_url = f"{TEST_BASE_URL}/adminapigw/{settings.root_path}"
        return session
    else:
        from fastapi.testclient import TestClient

        from pycore.api.web.app import app

        return TestClient(app)
