import os

import pytest
import requests_mock
import sqlalchemy as sa

from pycore import DeclarativeBase, OdbcDatabase, SecretValue, SqlServerDatabase
from pycore.config import settings
from pycore.repository.data import DataRepository
from pycore.repository.services.masterdata import MasterDataRepository
from pycore.repository.services.rdp import (
    GROUP_INFORMATION_TABLE,
    INC_EVENT_TYPE_TABLE,
    INC_HISTORY_TABLE,
    INC_RESOLUTION_TABLE,
    INC_TABLE,
    INC_TAG_TABLE,
    OCC_TABLE,
    ReportDataProviderRepository,
)
from pycore.resources.abc import BlobStorage, HttpSession, Vault
from pycore.resources.env import EnvVault
from pycore.resources.http import NoAuthHttpSession
from pycore.resources.openai.openai import OpenAiSession
from pycore.testing.azure import http_session, vault, vault_conn_str  # used as fixture
from pycore.testing.easy import easy_test, hook_repo
from pycore.testing.rdp import add_rdp_tabs_to_meta  # fixtures

LOCAL_SQLSERVER_CONN_STR = "Driver={ODBC Driver 17 for SQL Server};Server=127.0.0.1;database=DuplicateCheckDb;uid=sa;pwd=TestPassword99;"
LOCAL_STORAGE_CONN_STR = "DefaultEndpointsProtocol=http;AccountName=devstoreaccount1;AccountKey=Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==;BlobEndpoint=http://azure_storage:10000/devstoreaccount1;"


@pytest.fixture
def base_url(requests_mock: requests_mock.mocker.Mocker) -> str:
    """Returns the base URL used for mocked FN services.

    Requests to this base URL can be mocked using the library [requests-mock](https://requests-mock.readthedocs.io/en/latest/).
    See [StackOverflow](https://stackoverflow.com/questions/57663308/how-to-mock-requests-using-pytest) for an usage example.
    A simple GET to this base url is already mocked with this fixture.


    Args:
        requests_mock (requests_mock.mocker.Mocker): fixture provided by the library requests-mock (must be installed)

    Returns:
        str: constant base url 'https://test'
    """
    requests_mock.real_http = True
    url = "https://test"
    requests_mock.get(url)
    return url


@pytest.fixture
def database() -> OdbcDatabase:
    """Returns a `OdbcDatabase` resource based on a local SQL Server database resource.

    This can be used either by providing a connection string in the environment variable `local_sqlserver_conn_str`
    or by executing the corresponding docker-compose file.

    Returns:
        DatabaseResource: SQL Server database bound to this app's database
    """
    conn_str = os.environ.get("local_sqlserver_conn_str") or LOCAL_SQLSERVER_CONN_STR
    db_name = (
        os.environ.get("local_sqlserver_db_name") or settings.app_db_name or "master"
    )

    secret = SecretValue(conn_str)
    database = SqlServerDatabase(
        conn_secret=secret, db_name=db_name, base=DeclarativeBase
    )
    return database


@pytest.fixture
def rdp_db(database: SqlServerDatabase) -> OdbcDatabase:
    """Returns a `OdbcDatabase` resource based on a local SQL Server database resource.

    This can be used either by providing a connection string in the environment variable `local_sqlserver_conn_str`
    or by executing the corresponding docker-compose file.

    Returns:
        DatabaseResource: SQL Server database bound to the ReportDB
    """
    return SqlServerDatabase(conn_secret=database.conn_secret, db_name="ReportDB")


@pytest.fixture
def md_db(database: SqlServerDatabase) -> OdbcDatabase:
    """Returns a `OdbcDatabase` resource based on a local SQL Server database resource.

    This can be used either by providing a connection string in the environment variable `local_sqlserver_conn_str`
    or by executing the corresponding docker-compose file.

    Returns:
        DatabaseResource: SQL Server database bound to the MasterDataDB
    """
    return SqlServerDatabase(conn_secret=database.conn_secret, db_name="MasterDataDB")


@pytest.fixture
def batch_api_db(database) -> OdbcDatabase:
    """Returns a `OdbcDatabase` resource based on a local SQL Server database resource.

    This can be used either by providing a connection string in the environment variable `local_sqlserver_conn_str`
    or by executing the corresponding docker-compose file.

    Returns:
        DatabaseResource: SQL Server database bound to the BatchApiDB
    """
    return SqlServerDatabase(conn_secret=database.conn_secret, db_name="BatchApiDB")


@pytest.fixture
def data_repo(database: OdbcDatabase) -> DataRepository:
    """Returns a `DataRepository` based on a given database resource fixture.

    Args:
        database (OdbcDatabase): database resource used in the repository.

    Returns:
        DataRepository: repository object.
    """
    return DataRepository(database=database)


@pytest.fixture
def rdp_repo(rdp_db: OdbcDatabase) -> ReportDataProviderRepository:
    """Returns a `ReportDataProviderRepository` based on a given database resource fixture.

    Args:
        database (OdbcDatabase): database resource used in the repository.

    Returns:
        ReportDataProviderRepository: repository object.
    """
    return ReportDataProviderRepository(database=rdp_db)


@pytest.fixture
def md_repo(md_db: OdbcDatabase) -> MasterDataRepository:
    """Returns a `MasterDataRepository` based on a given database resource fixture.

    Args:
        database (OdbcDatabase): database resource used in the repository.

    Returns:
        MasterDataRepository: repository object.
    """
    return MasterDataRepository(database=md_db)


@pytest.fixture
def vault() -> Vault:
    """Returns a `Vault` resource based on environment variables for secret storage.

    Returns:
        Vault: vault object.
    """
    return EnvVault()


@pytest.fixture
def storage() -> BlobStorage:
    """Returns a `Storage` resource based on an emulated Azure Blob Storage instance.

    This only works under the following conditions:

    1. The corresponding Docker Compose file is executed, which sets up the local Azure Blob Storage emulator.

    OR

    2. The environment variable `local_storage_conn_str` is defined in the `.env` file with the following value:

       local_storage_conn_str = "DefaultEndpointsProtocol=http;AccountName=devstoreaccount1;AccountKey=Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==;BlobEndpoint=http://azure_storage:10000/devstoreaccount1;"

       Additionally, the "Start Azure Blob Storage" task must be run to create the local storage in Docker Desktop.
    """
    from pycore.resources.azure import AzureBlobStorage

    storage_conn_str = (
        os.environ.get("local_storage_conn_str") or LOCAL_STORAGE_CONN_STR
    )
    conn_secret = SecretValue(storage_conn_str)
    return AzureBlobStorage(conn_secret=conn_secret)


@pytest.fixture
def http_session(base_url: str) -> HttpSession:
    """Returns a `HttpSession` resource based on a simple session without authentication involved.

    This can be used to test calls to other services.
    These calls must be mocked using [requests-mock](https://requests-mock.readthedocs.io/en/latest/).
    See [StackOverflow](https://stackoverflow.com/questions/57663308/how-to-mock-requests-using-pytest) for an usage example.

    Args:
        base_url (str): service base URL.

    Returns:
        HttpSession: session object.
    """
    return NoAuthHttpSession(base_url=base_url)


@pytest.fixture
def db_scope(database: SqlServerDatabase) -> sa.orm.session.Session:
    """Returns a transactional session scope based on the provided database fixture.

    The session is closed after test execution and all changes are committed.
    If committing the changes fails, the test fails as well.

    Args:
        database (OdbcDatabase): database resource with connection information.

    Yields:
        sa.orm.session.Session: transactional session scope.
    """
    # Closes connection after test execution
    with database.session_scope() as db:
        yield db


@pytest.fixture
def test_client():
    """Returns a `TestClient` resource based on the FastAPI app.

    This can be used to send HTTP requests to this app's API.
    """
    from fastapi.testclient import TestClient

    from pycore.api.web.app import app

    return TestClient(app)


@pytest.fixture
def openai() -> OpenAiSession:
    # Cannot be used adequately in tests
    # get_completion() must be mocked individually per use case
    return OpenAiSession(
        base_url="",
        api_key=None,
        deployment_name=None,
    )


@pytest.fixture
def rdp_models(rdp_db):

    rdp_tables = add_rdp_tabs_to_meta(rdp_db.base.metadata)

    rdp_db.drop_all_tables()
    rdp_db.create_all_tables()
    return rdp_tables
