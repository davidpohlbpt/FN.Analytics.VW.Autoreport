import functools
import inspect
from collections.abc import Callable
from typing import Any


class Dependency:
    def __init__(self, func: Callable):
        self.func = func

    def resolve(self):
        return self.func()


class Scope(Dependency):
    def resolve(self):
        with self.func() as scope:
            return scope


def inject(func):
    """Decorator to inject dependencies into function arguments."""

    @functools.wraps(func)
    def _wrapper(*args, **kwargs):
        _inject(func, args, kwargs)
        return func(*args, **kwargs)

    return _wrapper


def _get_default_args(func) -> dict[tuple[int, str], Any]:
    sig = inspect.signature(func)
    defaults = {}

    for i, (k, v) in enumerate(sig.parameters.items()):
        if v.default is not inspect.Parameter.empty:
            defaults[(i, k)] = v.default

    return defaults


def _inject(func, args, kwargs):
    deps = {
        k: v for k, v in _get_default_args(func).items() if isinstance(v, Dependency)
    }

    # Replace dependency with actual value if not overriden by caller

    for (i, k), v in deps.items():
        if i < len(args) and args[i] is None:
            args[i] = v.resolve()
        elif i >= len(args) and k not in kwargs:
            kwargs[k] = v.resolve()
