import typing
from collections.abc import Callable, Iterable
from typing import Any


def merge_args_into_kwargs(
    fn: Callable, args: list[Any], kwargs: dict[str, Any]
) -> dict[str, Any]:
    """Merges positional arguments into keyword arguments.

    Args:
        fn: The function to be called.
        args: The positional arguments of the function.
        kwargs: The keyword arguments of the function.

    Returns:
        dict[str, Any]: The merged arguments.
    """
    kwargs = kwargs.copy()  # prevent modification of original dict

    if len(args) > len(fn.__code__.co_varnames):
        raise ValueError("Too many arguments.")

    for idx, arg_val in enumerate(args):
        arg_name = fn.__code__.co_varnames[idx]
        kwargs[arg_name] = arg_val

    return kwargs


def check_full_annotation(fn: Callable) -> None:
    """Checks if a function has full type annotations.

    Args:
        fn: The function to check.

    Raises:
        ValueError: If the function does not have full type annotations.
    """
    if (fn.__code__.co_argcount + 1) != len(fn.__annotations__):
        raise ValueError(
            f"The function {fn.__name__} does not have full type annotations, "
            "including the return value."
        )


def has_argument(fn: Callable, arg_name: str) -> bool:
    """Checks if a function has a given argument.

    Args:
        fn: The function to check.
        arg_name: The name of the argument.

    Returns:
        bool: Whether the function has the argument.
    """
    return arg_name in fn.__annotations__


def get_arg_type(
    fn: Callable, arg_name: str, base_type: Any = None, origin: bool = True
) -> Any:
    """Gets the type annotation of an argument of a function.

    Args:
        fn: The function to check.
        arg_name: The name of the argument.

    Returns:
        Any: The type annotation of the argument.
    """
    if not has_argument(fn, arg_name):
        raise ValueError(f"Invalid argument: {arg_name}.")

    arg_type = fn.__annotations__.get(arg_name)

    if origin:
        arg_type = typing.get_origin(arg_type) or arg_type

    if base_type is not None and not issubclass(arg_type, base_type):
        raise ValueError(
            f"Invalid annotation for argument: {arg_name}. Should inherit from {base_type}."
        )
    return arg_type


def get_arg(fn: Callable, arg_name: str, args, kwargs):
    """Gets the value of an argument of a function to be called.

    Args:
        fn: The function to check.
        arg_name: The name of the argument.
        args: The positional arguments of the function call.
        kwargs: The keyword arguments of the function call.

    Returns:
        Any: The value of the argument.
    """
    if not has_argument(fn, arg_name):
        raise ValueError(f"Invalid argument: {arg_name}.")

    if arg_name in kwargs:
        return kwargs[arg_name]

    arg_idx = fn.__code__.co_varnames.index(arg_name)
    return args[arg_idx]


def check_return_value(fn: Callable, result: Any) -> None:
    """Checks the return value of a function against its annotation.

    Args:
        fn: The function to check.
        result: The return value of the function.

    Raises:
        ValueError: If the return value does not match the annotation.
    """
    if "return" not in fn.__annotations__:
        raise ValueError("Missing annotation for return value.")
    check_argument("return", fn.__annotations__.get("return"), result)


def check_arguments(
    fn: Callable,
    args: list[Any],
    kwargs: dict[str, Any],
    ignore: Iterable[str] = [],
) -> None:
    """Checks the arguments of a function against its annotations.

    Args:
        fn: The function to check.
        args: The positional arguments of the function.
        kwargs: The keyword arguments of the function.
        ignore: The names of arguments to ignore.

    Raises:
        ValueError: If the arguments do not match the annotations.
    """
    kwargs = kwargs.copy()  # prevent modification of original dict

    if len(args) > len(fn.__code__.co_varnames):
        raise ValueError("Too many arguments.")

    for idx, arg_val in enumerate(args):
        arg_name = fn.__code__.co_varnames[idx]
        kwargs[arg_name] = arg_val

    kwargs = {k: v for k, v in kwargs.items() if k not in ignore}

    for arg_name, arg_val in kwargs.items():
        if arg_name not in fn.__annotations__:
            raise ValueError(f"Invalid argument: {arg_name}.")

        arg_type = fn.__annotations__.get(arg_name)
        check_argument(arg_name, arg_type, arg_val)


def check_argument(arg_name: str, arg_type: Any, arg_val: Any) -> None:
    """Checks an argument against its annotation.

    Args:
        arg_name: The name of the argument.
        arg_type: The annotation of the argument.
        arg_val: The value of the argument.

    Raises:
        ValueError: If the argument does not have an annotation.
        ValueError: If the argument does not match the annotation.
    """
    if arg_type is None:
        raise ValueError(f"Missing annotation for argument: {arg_name}.")

    if not isinstance(arg_val, arg_type):
        raise ValueError(f"Invalid type for argument: {arg_name}.")
