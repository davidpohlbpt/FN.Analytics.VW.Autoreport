import contextvars
import logging
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from typing import Any

MAX_BATCH_SIZE = 500


def get_batches(requests: list[dict[str, Any]], batch_size: int):

    for i in range(0, len(requests), batch_size):
        yield requests[i : i + batch_size]


def parallelize_func_error_handling(
    func: Callable, payload: dict[str, Any]
) -> str | None:
    try:
        return func(**payload)
    except Exception:
        logging.error(f"Request failed with payload: {payload}")
        return None


def parallelize_func(
    func_to_be_parallelized: Callable,
    requests: list[dict[str, Any]],
    func_save_response: Callable | None = None,
    batch_size: int = 50,
    max_workers: int | None = None,
    memory_saver: bool = False,
) -> list[str]:
    """
    Parallelizes function calls.

    Args:
        func_to_be_parallelized: The function to execute in parallel
        requests: List of request payloads (dicts) to process
        func_save_response: Optional callback to save responses after each batch
        batch_size: Number of requests per batch (default: 50)
        max_workers: Maximum concurrent worker threads (default: batch_size)
        memory_saver: If True, do not accumulate results in memory. Relies on
            func_save_response for persistence and returns an empty list.
            Use this for large workloads where holding all responses in memory
            would cause excessive memory consumption. (default: False)

    Returns:
        List of tuples containing (request, response) pairs.
        Returns empty list when memory_saver=True.
    """

    if batch_size > MAX_BATCH_SIZE:
        raise ValueError(
            f"Batch size {batch_size} exceeds the maximum allowed requests {MAX_BATCH_SIZE}."
        )

    if memory_saver and func_save_response is None:
        raise ValueError(
            "memory_saver=True requires func_save_response to be provided. "
            "Without it, all results would be discarded."
        )

    effective_max_workers = max_workers if max_workers is not None else batch_size

    def helper_wrapper_func(payload: dict[str, Any]) -> str | None:

        return parallelize_func_error_handling(func_to_be_parallelized, payload)

    batches = get_batches(requests, batch_size)
    response_batches = []

    for batch in batches:
        responses = []
        with ThreadPoolExecutor(max_workers=effective_max_workers) as executor:
            futures = [
                executor.submit(
                    contextvars.copy_context().run, helper_wrapper_func, payload
                )
                for payload in batch
            ]
            responses = [f.result() for f in futures]

        results_zip = list(zip(batch, responses))
        if func_save_response:
            func_save_response(results_zip)

        if not memory_saver:
            response_batches.extend(results_zip)

    return response_batches
