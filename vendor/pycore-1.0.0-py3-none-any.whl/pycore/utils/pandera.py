import pandera.pandas as pa
import sqlalchemy as sa

_TYPE_MAP = {
    "int": sa.Integer,
    "int16": sa.Integer,
    "int32": sa.Integer,
    "int64": sa.Integer,
    "Int": sa.Integer,
    "Int16": sa.Integer,
    "Int32": sa.Integer,
    "Int64": sa.Integer,
    "float": sa.Float,
    "float16": sa.Float,
    "float32": sa.Float,
    "float64": sa.Float,
    "Float": sa.Float,
    "Float16": sa.Float,
    "Float32": sa.Float,
    "Float64": sa.Float,
    "str": sa.String,
    "object": sa.JSON,
    "bool": sa.Boolean,
    "boolean": sa.Boolean,
    "datetime64[ns]": sa.DateTime,
    "datetime64[s]": sa.DateTime,
    "datetime64[ms]": sa.DateTime,
    "datetime64[us]": sa.DateTime,
    "date": sa.Date,
    "category": sa.Enum,
    "<class 'dict'>": sa.JSON,
    "<class 'list'>": sa.JSON,
}


def df_model_to_db_table(
    df_model: pa.DataFrameModel,
    base: sa.orm.DeclarativeMeta,
    table: str | None = None,
    schema: str | None = None,
) -> sa.Table:
    df_schema = df_model.to_schema()

    if not df_schema.unique:
        raise ValueError(
            f"DataFrameModel {df_model} must have at least one unique "
            "column to be converted to a database table."
        )

    autoinc_key = None
    if hasattr(df_model.Config, "metadata"):
        autoinc_key = df_model.Config.metadata.get("autoincrement")
        if autoinc_key and autoinc_key not in df_schema.columns:
            raise ValueError(
                f"Autoincrement key {autoinc_key} not found in DataFrameModel {df_model}."
            )

    columns = []
    for name, df_col in df_schema.columns.items():
        if autoinc_key is None:
            is_key = name in df_schema.unique
        else:
            is_key = name == autoinc_key
        db_col = df_col_to_db_col(
            df_col,
            is_key=is_key,
            autoincrement=autoinc_key is not None,
        )
        columns.append(db_col)

    if not table:
        table = str(df_model)

    table = sa.Table(
        table,
        base.metadata,
        *columns,
        schema=schema,
        info={"model": str(df_model)},
        extend_existing=True,
    )

    return table


def df_col_to_db_col(
    df_col: pa.Column, is_key: bool = False, autoincrement: bool = False
) -> sa.Column:
    is_nullable = True  # default
    if is_key or not df_col.nullable:
        is_nullable = False

    if not is_key and not df_col.properties.get("required", False):
        is_nullable = True

    type_ = _TYPE_MAP.get(str(df_col.dtype))

    if type_ is None:
        raise ValueError(
            f"Type {df_col.dtype} not supported for conversion to sqlalchemy column."
        )

    if is_key and type_ == sa.String:
        type_ = sa.String(255)

    str_checks = [
        c for c in df_col.properties.get("checks", []) if c.name == "str_length"
    ]

    if type_ == sa.String and str_checks:
        str_len = str_checks[0].statistics.get("max_value")
        if str_len:
            type_ = sa.String(str_len)

    if type_ == sa.Enum:
        type_ = sa.Enum(*df_col.dtype.categories)

    return sa.Column(
        df_col.name,
        type_,
        nullable=is_nullable,
        primary_key=is_key,
        autoincrement=autoincrement if is_key else False,
    )
