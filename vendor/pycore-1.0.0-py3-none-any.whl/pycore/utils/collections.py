try:
    # Running the web service behind PyCore requires additional libraries
    import fastapi
except ImportError as e:
    raise ImportError(
        "Please install optional webapi dependencies with 'poetry install --extras webapi'"
    ) from e

import collections
import datetime as dt
import json
from collections.abc import Generator, Hashable, Iterable, Sequence
from typing import Any

import pandas as pd
import pydantic
from fastapi.encoders import jsonable_encoder


def create_json_from_str(v: str | dict | Any) -> dict | None:
    if v is None:
        return {}
    elif isinstance(v, str):
        return json.loads(v)
    else:
        return v


def is_jsonable(obj: object) -> bool:
    """Returns whether an object can be converted to a JSON.

    Args:
        obj (object): Object in question

    Returns:
        bool: True if conversion is possible, False else.
    """
    try:
        json.dumps(obj)
        return True
    except TypeError:
        pass
    return False


def remove_duplicates(seq: Iterable[Hashable]) -> list[Hashable]:
    """Removes duplicate elements from an iterable.

    Args:
        seq (Iterable[Hashable]): Iterable with potentially duplicate elements.

    Returns:
        list[Hashable]: Duplicate-free sequence of elements.
    """
    seen = set()
    seen_add = seen.add
    return [x for x in seq if not (x in seen or seen_add(x))]


# Turns a value into a list if it isn't one yet
def maybe_make_list(obj):
    if obj is not None and not isinstance(obj, (tuple, list)):
        return [obj]
    return obj


def recursive_update(d, u):
    for k, v in u.items():
        if isinstance(v, collections.abc.Mapping):
            d[k] = recursive_update(d.get(k, {}), v)
        else:
            d[k] = v
    return d


def get_nested_dict(flat_list: list[tuple[str, Any]]):
    nested_dict = {}
    for key, value in flat_list:
        key_seq = key.split(".")
        nested_dict = _add_to_nested_dict(nested_dict, key_seq, value)

    return nested_dict


def _add_to_nested_dict(dict_: dict[str, Any], key_seq: list[str], value: Any):
    key = key_seq[0]
    if len(key_seq) == 1:
        dict_[key] = value
    else:
        sub_dict = dict_[key] if key in dict_ else {}
        dict_[key] = _add_to_nested_dict(sub_dict, key_seq[1:], value)

    return dict_


def get_flat_list_from_model(obj: pydantic.BaseModel):
    flat_list = _get_flat_key_seq(obj)
    flat_list = [(".".join(key_seq), value) for key_seq, value in flat_list]
    return flat_list


def _get_flat_key_seq(obj: pydantic.BaseModel):
    flat_list = []
    for key, value in obj:
        if isinstance(value, pydantic.BaseModel):
            sub_list = _get_flat_key_seq(value)
            flat_list += [((key, *sub_key), val) for sub_key, val in sub_list]
        else:
            flat_list.append(((key,), value))

    return flat_list


_PRIMITIVE = (int, str, bool, float, type(None))


def has_complex_type(value, date_is_complex: bool = True):
    if type(value) in _PRIMITIVE:
        return False
    elif isinstance(value, dt.date) and not date_is_complex:
        return False
    else:
        return True


def to_json_type(value, complex_as_str: bool = True):
    is_complex = has_complex_type(value)

    if is_complex:
        value = jsonable_encoder(value)

    if is_complex and complex_as_str:
        return json.dumps(value)
    else:
        return value


def merge_chunks(partial_results: list[Any]) -> Any | None:
    if len(partial_results) == 0:
        return None

    # peek to obtain the type of the result
    first_result = partial_results[0]

    # make sure all results are of the same type
    if not all(type(result) is type(first_result) for result in partial_results):
        raise ValueError("All partial results must be of the same type.")

    if isinstance(first_result, pd.DataFrame):
        return pd.concat(partial_results, ignore_index=True)
    elif isinstance(first_result, list):
        return [item for sublist in partial_results for item in sublist]
    else:
        raise ValueError(f"Unsupported result type for merging: {first_result}")


def split_in_chunks(obj: Iterable, chunk_size: int) -> Generator:
    if not isinstance(obj, Sequence) and not isinstance(obj, pd.DataFrame):
        raise ValueError("Object to be chunked must be iterable.")

    for i in range(0, len(obj), chunk_size):
        yield obj[i : i + chunk_size]
