import requests
from requests.adapters import HTTPAdapter
from urllib3.util import Retry


class RetryRequest(Retry):
    BACKOFF_MAX = 10


def requests_retry_session(
    retries: int = 1,
    backoff_factor: float = 0.3,
    status_forcelist: tuple[int] = (500, 502, 504),
    pool_maxsize: int = 10,
    session: requests.Session | None = None,
) -> requests.Session:
    """Provides a session with included retry mechanism.

    Reference: https://www.peterbe.com/plog/best-practice-with-retries-with-requests

    Args:
        retries (int, optional): Number of retries. Defaults to 3.
        backoff_factor (float, optional): Time between requests. Defaults to 0.3.
        status_forcelist (tuple[int], optional): Response status codes after which requests are retried. Defaults to (500, 502, 504).
        session (requests.Session, optional): Http session object. Defaults to None.

    Returns:
        requests.Session: Http session object
    """
    session = session or requests.Session()
    retry = RetryRequest(
        total=retries,
        read=retries,
        connect=retries,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
    )
    adapter = HTTPAdapter(max_retries=retry, pool_maxsize=pool_maxsize)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session
