import warnings
from functools import wraps


def deprecated_function(func):
    warnings.warn(func.__name__ + " is deprecated. Please remove its usage.")

    @wraps(func)
    def func_with_warning(*args, **kwargs):
        return func(*args, **kwargs)

    return func_with_warning


def deprecated_method(func):
    @wraps(func)
    def meth_with_warning(self, *args, **kwargs):
        warnings.warn(
            func.__name__ + " is deprecated. Please remove its usage.", stacklevel=0
        )
        return self.func(*args, **kwargs)

    return meth_with_warning
