import enum
import logging
import re
from collections.abc import Iterable
from typing import Any

import numpy as np
import pandas as pd
from fastapi.encoders import jsonable_encoder
from pandas.testing import assert_frame_equal


def set_combined_key(df: pd.DataFrame, key_columns: list[str], key_name: str):
    df = df.reset_index()
    df[key_columns] = df[key_columns].astype(str)
    df[key_name] = df[key_columns].agg("-".join, axis=1)
    df = df.set_index(key_name)
    return df


# Turns a value into a list if it isn't one yet
def maybe_make_list(obj):
    if obj is not None and not isinstance(obj, (tuple, list)):
        return [obj]
    return obj


def get_dict_from_cols(
    df: pd.DataFrame, cols: list[str], exclude_nulls: bool = True
) -> pd.Series:
    """Returns a series of dictionaries containing the values in a set of columns.

    Args:
        df (pd.DataFrame): Data frame containing the columns.
        cols (list[str]): Names of the columns to be condensed in the dictionary.
        exclude_nulls (bool, optional): Indicates whether keys with null values are added to the dictionary. Defaults to True.

    Raises:
        ValueError: Raised if one of the given columns is not contained in the data frame.

    Returns:
        pd.Series: Series with the same length as the data frame containing the given columns as dictionaries.
    """
    for col in cols:
        if col not in df.columns:
            raise ValueError(f"The column '{col}' is not part of the dataframe.")

    result = df[cols].to_dict(orient="records")
    if exclude_nulls:
        result = [{k: v for k, v in x.items() if not pd.isna(v)} for x in result]
    return pd.Series(result)


def get_cols_from_dict(
    s: pd.Series, cols: list[str], missing_as_na: bool = False
) -> pd.DataFrame:
    """Returns a data frame from a series containing dictionaries.

    Args:
        s (pd.Series): Series containing the dictionaries.
        cols (list[str]): Column names whose values are extracted from the dictionary.
        missing_as_na (bool, optional): Indicates whether columns which were found in none of the dictionaries should be added with all-None values. Defaults to False.

    Raises:
        ValueError: Raised if not `missing_as_na` and a column was not part of any dictionary.

    Returns:
        pd.DataFrame: Data frame containing exactly the given columns an the respective values from the dictionaries.
    """

    df = pd.DataFrame(data=list(s))

    for col in cols:
        if col in df.columns:
            continue
        if missing_as_na:
            df[col] = None
        else:
            raise ValueError(f"The column '{col}' is not part of the dictionary.")

    return df[cols]


def get_col_from_dict(s: pd.Series, col: str) -> pd.Series:
    """Returns a series from a series containing dictionaries.

    Args:
        s (pd.Series): Series containing the dictionaries.
        col (str): Column name whose value is extracted from the dictionary.

    Raises:
        ValueError: Raised if column was not part of any dictionary.

    Returns:
        pd.Series: Series containing the extracted values from the dictionaries.
    """
    return get_cols_from_dict(s, [col], missing_as_na=False)[col]


class JoinType(str, enum.Enum):
    INNER = "inner"
    LEFT = "left"
    SEMI = "semi"
    ANTI = "anti"


def join(
    left: pd.DataFrame,
    right: pd.DataFrame,
    type: JoinType,
    on: str | Iterable[str] | None = None,
    left_on: str | Iterable[str] | None = None,
    right_on: str | Iterable[str] | None = None,
):
    if on:
        left_on = on
        right_on = on

    left_on = maybe_make_list(left_on)
    right_on = maybe_make_list(right_on)

    if type == JoinType.INNER:
        return left.merge(right, how="inner", left_on=left_on, right_on=right_on)
    elif type == JoinType.LEFT:
        return left.merge(right, how="left", left_on=left_on, right_on=right_on)
    elif type == JoinType.SEMI:
        return semi_join(left=left, right=right, left_on=left_on, right_on=right_on)
    elif type == JoinType.ANTI:
        return anti_join(left=left, right=right, left_on=left_on, right_on=right_on)
    else:
        raise ValueError(f"Invalid join type: {type}")


def semi_join(
    left: pd.DataFrame,
    right: pd.DataFrame,
    on: str | Iterable[str] | None = None,
    left_on: str | Iterable[str] | None = None,
    right_on: str | Iterable[str] | None = None,
) -> pd.DataFrame:
    """Performs a filtering join that returns all rows from `left` _with_ a match in `right`.

    Please provide either `on` or both `left_on` and `right_on`

    Args:
        left (pandas.DataFrame): data frame to be filtered.
        right (pandas.DataFrame): data frame to be matched.
        on (Union[str, Iterable[str], None], optional): Columns used for matching. Can be a string or a list of strings.
        left_on (Union[str, Iterable[str], None], optional): Columns used for matching in the left data frame. Can be a string or a list of strings.
        right_on (Union[str, Iterable[str], None], optional): Columns used for matching in the right data frame. Can be a string or a list of strings.

    Returns:
        pd.DataFrame: Filtered data frame.
    """
    return _filter_join(left, right, True, on=on, left_on=left_on, right_on=right_on)


def anti_join(
    left: pd.DataFrame,
    right: pd.DataFrame,
    on: str | Iterable[str] | None = None,
    left_on: str | Iterable[str] | None = None,
    right_on: str | Iterable[str] | None = None,
) -> pd.DataFrame:
    """Performs a filtering join that returns all rows from `left` _without_ a match in `right`.

    Please provide either `on` or both `left_on` and `right_on`

    Args:
        left (pandas.DataFrame): data frame to be filtered.
        right (pandas.DataFrame): data frame to be matched.
        on (Union[str, Iterable[str], None], optional): Columns used for matching. Can be a string or a list of strings.
        left_on (Union[str, Iterable[str], None], optional): Columns used for matching in the left data frame. Can be a string or a list of strings.
        right_on (Union[str, Iterable[str], None], optional): Columns used for matching in the right data frame. Can be a string or a list of strings.

    Returns:
        pd.DataFrame: Filtered data frame.
    """
    return _filter_join(left, right, False, on=on, left_on=left_on, right_on=right_on)


def _filter_join(
    left: pd.DataFrame,
    right: pd.DataFrame,
    semi: bool,
    on=None,
    left_on=None,
    right_on=None,
):
    if on and (left_on or right_on):
        raise ValueError("You must provide either 'on' _or_ 'left_on' and 'right_on")
    elif any([left_on, right_on]) and not all([left_on, right_on]):
        raise ValueError("You must provide _both_ 'left_on' and 'right_on")
    elif not any([on, left_on, right_on]):
        raise ValueError("You must provide columns to join on.")

    if on:
        left_on = on
        right_on = on

    left_on = maybe_make_list(left_on)
    right_on = maybe_make_list(right_on)

    missing_left_cols = set(left_on).difference(left.columns)
    if missing_left_cols:
        raise ValueError(
            f"Join columns {'.'.join(missing_left_cols)} are not present in left data frame."
        )

    missing_right_cols = set(right_on).difference(right.columns)
    if missing_right_cols:
        raise ValueError(
            f"Join columns {'.'.join(missing_right_cols)} are not present in right data frame."
        )

    right = right[right_on].drop_duplicates()

    left = left.merge(
        right, how="left", left_on=left_on, right_on=right_on, indicator="_merge"
    )

    if semi:
        left = left.loc[left["_merge"] == "both"]
    else:
        left = left.loc[left["_merge"] == "left_only"]

    left = left.drop(columns=["_merge"])

    return left


def map_regex(
    pattern_map: dict[re.Pattern | str, Any],
    values: pd.Series,
    default: Any = None,
):
    values = values.copy()
    had_match = False
    for pattern, sub in pattern_map.items():
        if not isinstance(pattern, re.Pattern):
            pattern = re.compile(pattern)

        match = values.str.fullmatch(pattern)
        match = match.fillna(False)
        values.loc[match] = sub

        if any(had_match & match):
            logging.warning(f"The regex {pattern.pattern} matches multiple rows.")
        had_match = had_match | match

    values.loc[~had_match] = default

    return values


def assert_equals(left: pd.DataFrame, right: pd.DataFrame, index: str):
    left = left.set_index(index).sort_index()
    right = right.set_index(index).sort_index()

    assert (
        left.shape == right.shape
    ), f"Shape is different ({left.shape} vs. {right.shape})."
    assert (left.index == right.index).all(), "Index is different."
    assert_frame_equal(
        left, right
    ), f"Data is different\n{left.compare(right).to_string()}"


def df_to_jsonable_dict(df: pd.DataFrame):
    """Converts a data frame to a JSON-serializable dictionary.

    Args:
        df (pd.DataFrame): Data frame to be converted.

    Returns:
        dict: JSON-serializable dictionary.
    """
    with pd.option_context("future.no_silent_downcasting", True):
        df = df.fillna(np.nan).replace([np.nan], [None])
    df = df.to_dict(orient="records")
    df = jsonable_encoder(df)
    return df
