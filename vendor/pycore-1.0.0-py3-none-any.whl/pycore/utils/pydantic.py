import enum
from typing import Any, Optional

import pydantic
from humps import camelize
from pydantic import ConfigDict


def to_camel(string):
    return camelize(string)


class CamelModel(pydantic.BaseModel):
    """Model that outputs its attributes in camelCase.

    Useful if the model is exchanged with other Factory Navigator services which require JSON data with camelCase keys.
    This way, the Python naming conventions can be kept and the keys are only converted if the model is exported (i.e. shared via HTTP).
    """

    model_config = ConfigDict(
        alias_generator=to_camel, populate_by_name=True, coerce_numbers_to_str=True
    )


class CaseInsensitiveEnum(str, enum.Enum):
    """Enum type which allows API users to use case-insensitive values.

    This is particularly useful for pydantic models referencing enums.
    """

    @classmethod
    def _missing_(cls, value) -> None | Any:

        candidates = [item for item in cls if item.lower() == value.lower()]

        if len(candidates) == 0:
            return None
        elif len(candidates) == 1:
            return candidates[0]
        else:
            raise ValueError(f"Value '{value}' is ambiguous: {candidates}")


class MakeOptional(pydantic.BaseModel):

    @classmethod
    def __pydantic_init_subclass__(cls, **kwargs: Any) -> None:
        super().__pydantic_init_subclass__(**kwargs)

        for field in cls.model_fields.values():
            if field.is_required():
                field.default = None

        cls.model_rebuild(force=True)


def translate_to_alias(name: str, model_cls) -> str:
    """Translates a field name to its alias.

    Args:
        name (str): Field name (as it can be used in Python).
        model_cls (pydantic.main.ModelMetaclass): Model class.

    Raises:
        ValueError: If the field name is not found in the model.

    Returns:
        str: Alias of the field.
    """
    if name not in model_cls.model_fields:
        raise ValueError(f"Field '{name}' not found in model '{model_cls.__name__}'.")

    alias = model_cls.model_fields[name].alias

    if alias is None:
        alias = name  # use standard if no alias exists

    return alias
