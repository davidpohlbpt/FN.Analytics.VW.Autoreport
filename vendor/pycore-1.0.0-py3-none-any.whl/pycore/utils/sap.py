import datetime as dt

import numpy as np
import pandas as pd
import pandera.pandas as pa


def _is_string_like_dtype(series: pd.Series) -> bool:
    """Check if a series has string-like dtype.

    In pandas 2.0, is_string_dtype returns False for object columns containing
    None values. This helper also accepts object dtype columns, which is the
    typical dtype for mixed string/null data read from databases.
    """
    return pd.api.types.is_string_dtype(series) or pd.api.types.is_object_dtype(series)


@pa.engines.pandas_engine.Engine.register_dtype
@pa.dtypes.immutable
class XFlag(pa.engines.pandas_engine.BOOL):
    """Represents SAP XFlag data type.

    XFlag is a single character field that can be either "X" or empty.
    Using this type will coerce the values to boolean (True/False).
    """

    def coerce(self, series: pd.Series) -> pd.Series:
        if len(series) == 0:
            return pd.Series(dtype="boolean")
        if pd.api.types.is_bool_dtype(series):
            return series.astype("boolean")
        if not _is_string_like_dtype(series):
            raise pa.errors.SchemaError(
                schema=self,
                data=series,
                message=f"Expected string dtype, got {series.dtype} instead.",
            )
        return convert_xflag_to_bool(series).astype("boolean")


@pa.engines.pandas_engine.Engine.register_dtype
@pa.dtypes.immutable
class NegatedXFlag(pa.engines.pandas_engine.BOOL):
    """Represents SAP XFlag data type, but negated.

    XFlag is a single character field that can be either "X" or empty.
    Using this type will coerce the values to boolean (False/True).
    """

    def coerce(self, series: pd.Series) -> pd.Series:
        if len(series) == 0:
            return pd.Series(dtype="boolean")
        if pd.api.types.is_bool_dtype(series):
            return series.astype("boolean")
        if not _is_string_like_dtype(series):
            raise pa.errors.SchemaError(
                schema=self,
                data=series,
                message=f"Expected string dtype, got {series.dtype} instead.",
            )
        return ~convert_xflag_to_bool(series).astype("boolean")


@pa.engines.pandas_engine.Engine.register_dtype()
@pa.dtypes.immutable
class Bool(pa.engines.pandas_engine.BOOL):
    """Represents SAP Bool data type.

    Bool is a character field.
    Using this type will coerce the values to boolean (True/False).

    Note: This type is not the same as XFlag.
    It will coerce any non-empty string to True.
    """

    def coerce(self, series: pd.Series) -> pd.Series:
        if len(series) == 0:
            return pd.Series(dtype="boolean")
        if pd.api.types.is_bool_dtype(series):
            return series.astype("boolean")
        if pd.api.types.is_integer_dtype(series):
            return series.astype("boolean")
        if not _is_string_like_dtype(series):
            raise pa.errors.SchemaError(
                schema=self,
                data=series,
                message=f"Expected string dtype, got {series.dtype} instead.",
            )
        return convert_str_to_bool(series).astype("boolean")


@pa.engines.pandas_engine.Engine.register_dtype
@pa.dtypes.immutable
class Date(pa.engines.pandas_engine.Date):
    """Represents SAP Date data type.

    Date is an 8 character field in the format YYYYMMDD.
    Using this type will coerce the values to datetime.date.
    """

    def coerce(self, series: pd.Series) -> pd.Series:
        if len(series) == 0:
            return pd.Series(dtype="datetime64[s]")
        if not _is_string_like_dtype(series):
            raise pa.errors.SchemaError(
                schema=self,
                data=series,
                message=f"Expected string dtype, got {series.dtype} instead.",
            )
        return convert_str_to_date(series)


@pa.engines.pandas_engine.Engine.register_dtype
@pa.dtypes.immutable
class Percent(pa.engines.pandas_engine.FLOAT64):
    """Represents SAP Percent data type.

    Percent is an integer field that represents a percentage
    with values between 0 and 100 instead of 0.0 and 1.0.
    Using this type will coerce the values to float and divide by 100.
    """

    def coerce(self, series: pd.Series) -> pd.Series:
        if len(series) == 0:
            return pd.Series(dtype="Float64")
        if not pd.api.types.is_numeric_dtype(series):
            raise pa.errors.SchemaError(
                schema=self,
                data=series,
                message=f"Expected numeric dtype, got {series.dtype} instead.",
            )
        return convert_float_to_percent(series).astype("Float64")


@pa.engines.pandas_engine.Engine.register_dtype()
@pa.dtypes.immutable
class Integer(pa.engines.pandas_engine.INT32):
    """Represents SAP Integer data type.

    Integer is a character field that represents an integer.
    Using this type will coerce the values to int.
    """

    def coerce(self, series: pd.Series) -> pd.Series:
        if len(series) == 0:
            return pd.Series(dtype="Int32")
        if pd.api.types.is_integer_dtype(series):
            return series.astype("Int32")
        if pd.api.types.is_float_dtype(series):
            return series.astype("Int32")
        if not _is_string_like_dtype(series):
            raise pa.errors.SchemaError(
                schema=self,
                data=series,
                message=f"Expected string dtype, got {series.dtype} instead.",
            )
        return convert_str_to_int(series).astype("Int32")


@pa.engines.pandas_engine.Engine.register_dtype
@pa.dtypes.immutable
class Decimal(pa.engines.pandas_engine.FLOAT64):
    """Represents SAP Decimal data type.

    Decimal is a character field that represents a decimal number.
    Using this type will coerce the values to float.
    """

    def coerce(self, series: pd.Series) -> pd.Series:
        if len(series) == 0:
            return pd.Series(dtype="Float64")
        if pd.api.types.is_integer_dtype(series):
            return series.astype("Float64")
        if pd.api.types.is_float_dtype(series):
            return series.astype("Float64")
        if not _is_string_like_dtype(series):
            raise pa.errors.SchemaError(
                schema=self,
                data=series,
                message=f"Expected string dtype, got {series.dtype} instead.",
            )
        return convert_str_to_float(series).astype("Float64")


def convert_xflag_to_bool(values: pd.Series) -> pa.typing.Series[bool]:
    values = values.fillna("")
    values = values.map({"X": True, "": False})
    if values.isna().any():
        raise ValueError("Conversion failed because some values could not be mapped.")
    return values.astype(bool)


def convert_str_to_bool(values: pd.Series) -> pa.typing.Series[bool]:
    values = values.replace({"0": pd.NA, "": pd.NA})
    values[~values.isna()] = True
    with pd.option_context("future.no_silent_downcasting", True):
        values = values.fillna(False)
    return values.astype(bool)


def convert_str_to_int(values: pd.Series) -> pa.typing.Series[int]:
    values = pd.to_numeric(values, errors="coerce")
    values = values.fillna(0)
    return values.astype(int)


def convert_float_to_percent(values: pd.Series) -> pa.typing.Series[float]:
    values = values.fillna(0)
    values = values.astype(float) / 100
    return values


def convert_str_to_float(values: pd.Series) -> pa.typing.Series[float]:
    values = pd.to_numeric(values, errors="coerce")
    values = values.fillna(0.0)
    return values.astype(float)


def convert_str_to_date(values: pd.Series) -> pa.typing.Series[dt.date]:
    values = pd.Series(np.where(values == "00000000", pd.NaT, values), dtype=str)
    values = values.apply(
        lambda d: dt.datetime.strptime(d, "%Y%m%d").date() if not pd.isna(d) else pd.NaT
    )
    return values
