import re

_MAX_SEARCH_TEXT_LENGTH = 1_000_000
_MAX_SEARCH_VALUES_COUNT = 10_000
_DOUBLE_SEMICOLON = ";;"


def normalize_search_terms(search_term: str) -> list[str]:
    """Normalizes a pasted multi-select search string into a list of individual terms.
    - If the string contains ';;', it is split on that delimiter.
    - Otherwise, newlines or tabs are used as delimiters (whichever is more frequent).
    - If no delimiter is found, the whole string is treated as one term.
    - Results are trimmed, deduplicated, and limited to _MAX_SEARCH_VALUES_COUNT entries.

    Args:
        search_term: The raw search string from user input.

    Returns:
        A deduplicated list of normalized search terms.

    Raises:
        ValueError: If the input exceeds size limits or contains invalid characters.
    """
    if not search_term or not search_term.strip():
        return []

    if len(search_term) > _MAX_SEARCH_TEXT_LENGTH:
        raise ValueError(
            f"Search text exceeds maximum length of {_MAX_SEARCH_TEXT_LENGTH} characters."
        )

    if "\x00" in search_term:
        raise ValueError("Invalid characters detected in search data.")

    if _DOUBLE_SEMICOLON in search_term:
        tokens = [t.strip() for t in search_term.split(_DOUBLE_SEMICOLON)]
        tokens = [t for t in tokens if t]
        return _dedupe_with_limit(tokens)

    # Strip trailing CRLF then normalize CRLF → LF
    cleaned = search_term[:-2] if search_term.endswith("\r\n") else search_term
    normalized = cleaned.replace("\r\n", "\n")

    newlines = normalized.count("\n") + normalized.count("\r")
    tabs = normalized.count("\t")

    if newlines > 0 and newlines >= tabs:
        tokens = [t.strip() for t in re.split(r"[\n\r]", normalized)]
    elif tabs > 0:
        tokens = [t.strip() for t in normalized.split("\t")]
    else:
        tokens = [normalized.strip()]

    tokens = [t for t in tokens if t]
    return _dedupe_with_limit(tokens)


def _dedupe_with_limit(values: list[str]) -> list[str]:
    seen = set()
    result = []
    for v in values:
        if v not in seen:
            seen.add(v)
            result.append(v)

    if len(result) > _MAX_SEARCH_VALUES_COUNT:
        raise ValueError(
            f"Too many values detected: {len(result)}. Maximum allowed: {_MAX_SEARCH_VALUES_COUNT}."
        )

    return result


def camel_to_snake_case(s: str) -> str:
    """Converts a given string from CamelCase to snake_case

    Args:
        s (str): String in CamelCase

    Returns:
        str: String in snake_case
    """
    return (s[0] + re.sub(r"[A-Z]", lambda m: "_" + m.group(0), s[1:])).lower()
