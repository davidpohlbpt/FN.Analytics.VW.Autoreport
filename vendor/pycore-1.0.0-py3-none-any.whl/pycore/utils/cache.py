import sys

if sys.version_info[0] == 3 and sys.version_info[1] >= 8:
    # starting with Python 3.8, this is available from functools
    from functools import cached_property
else:
    # Before 3.8, an additional library is needed
    from cached_property import cached_property
