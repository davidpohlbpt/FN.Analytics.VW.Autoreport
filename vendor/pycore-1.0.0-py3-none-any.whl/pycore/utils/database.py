import json
import logging
import re
import urllib
from contextlib import contextmanager

import pydantic.json
import sqlalchemy as sa
from sqlalchemy.engine.base import Engine
from sqlalchemy.orm.session import Session, sessionmaker
from sqlalchemy.pool import StaticPool


class DbReadOnlyError(RuntimeError):
    pass


class TableDoesNotExistError(ValueError):

    def __init__(self, table: str, schema: str):
        msg_schema = f" in schema '{schema}'" if schema else ""
        msg = f"The table '{table}' does not exist{msg_schema}."
        super().__init__(msg)


class ColumnDoesNotExistError(ValueError):

    def __init__(self, columns, table: sa.Table):
        msg_schema = f"{table.schema}." if table.schema is not None else ""
        if isinstance(columns, (list, set)):
            columns_str = ", ".join(columns)
            msg = f"The columns '{columns_str}' do not exist in table '{msg_schema}{table.name}'."
        else:
            msg = f"The column '{columns}' does not exist in table '{msg_schema}{table.name}'."
        super().__init__(msg)


def get_sqlalchemy_conn_str(conn_str: str, database: str | None = None):
    sqlite_re = r"^sqlite:///"
    ado_net_re = r"^Server=([^;]*);.*Initial Catalog=([^;]*);.*User ID=([^;]*);.*Password=([^;]*);"
    odbc_re = (
        r"^Driver={ODBC Driver \d+ for SQL Server};Server=([^;]*);.*Database=([^;]*);"
    )
    if re.search(sqlite_re, conn_str, flags=re.IGNORECASE):
        return conn_str
    elif re.search(ado_net_re, conn_str, flags=re.IGNORECASE):
        return get_odbc_from_adonet_conn_str(conn_str=conn_str, database=database)
    elif re.search(odbc_re, conn_str, flags=re.IGNORECASE):
        if database:
            return re.sub(
                r"database=\w+;",
                f"database={database};",
                conn_str,
                flags=re.IGNORECASE,
            )
        else:
            return conn_str
    else:
        raise ValueError("The connection string has an unknown type")


def get_odbc_from_adonet_conn_str(conn_str: str, database: str | None = None):
    # Get components from connection string

    components = {
        "server": r"Server=([^;]*);",
        "database": r"Initial Catalog=([^;]*);",
        "user": r"User ID=([^;]*);",
        "password": r"Password=([^;]*);",
    }

    for component, pattern in components.items():
        match = re.search(pattern, conn_str, flags=re.IGNORECASE)
        components[component] = match.group(1) if match else None

    components["database"] = database

    # Create new suitable connection string with components

    server, database, user, password = components.values()
    conn_str = f"Driver={{ODBC Driver 17 for SQL Server}};Server={server};Database={database};Uid={user};Pwd={password};Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;"

    return conn_str


def is_engine_active(engine: Engine) -> bool:
    """Indicates whether the given engine can connect to the underlying database server.

    Args:
        engine (Engine): Database engine.

    Returns:
        bool: True, if a connection could be established. False else.
    """
    try:
        with engine.connect() as conn:
            _ = conn.execute(sa.text("SELECT 1"))
        return True
    except Exception:
        return False


def get_engine_from_conn_str(conn_str: str, **kwargs) -> Engine:
    if re.match(r"(?:[^=;]+=[^;]+;?)+", conn_str):
        # ODBC connection string
        params = urllib.parse.quote_plus(conn_str)
        engine = sa.create_engine(
            "mssql+pyodbc:///?odbc_connect=%s" % params,
            pool_pre_ping=True,
            fast_executemany=True,
            json_serializer=pydantic_json_serializer,
            **kwargs,
        )
    else:
        # Other format, e.g. SQLite
        # Without the extra args, for testing
        engine = sa.create_engine(
            conn_str,
            poolclass=StaticPool,
            json_serializer=pydantic_json_serializer,
            connect_args={"check_same_thread": False},
        )
    return engine


def get_session_scope_func(session_maker: sessionmaker):
    @contextmanager
    def session_scope(read_only: bool = False):
        """Provide a transactional scope around a series of operations."""
        if read_only:
            session = session_maker(expire_on_commit=False)
        else:
            session = session_maker()
        try:
            yield session
            if not read_only:
                session.commit()
            else:
                if session.dirty:
                    raise sa.exc.ProgrammingError(
                        "There must not be any write operations in read-only session scopes."
                    )
        except BaseException as err:
            logging.error(err)
            session.rollback()
            raise
        finally:
            session.close()

    return session_scope


def pydantic_json_serializer(*args, **kwargs) -> str:
    return json.dumps(*args, default=pydantic.json.pydantic_encoder, **kwargs)


class PydanticModel(sa.types.TypeDecorator):
    impl = sa.types.JSON

    def __init__(self, model):
        super().__init__()
        self.model = model

    # def load_dialect_impl(self, dialect):
    # return dialect.type_descriptor(sa.JSON())

    def process_bind_param(self, value, dialect):
        if value is None:
            return None

        if isinstance(value, dict):
            # Try to convert dictionaries into the model
            value = self.model.model_validate(value)

        if not isinstance(value, self.model):
            raise ValueError(
                f"Value must be of type '{self.model.__name__}' not '{type(value).__name__}'."
            )

        return value.model_dump()

    def process_result_value(self, value, dialect):
        return self.model.model_validate(value) if value else None


def func_scope(database, read_only: bool = False):
    def outer_wrapper(func):
        def inner_wrapper(*args, **kwargs):
            db, args, kwargs = get_db_from_args(*args, **kwargs)

            if db:
                return func(db, *args, **kwargs)

            with database.session_scope(read_only=read_only) as db:
                return func(db, *args, **kwargs)

        return inner_wrapper

    return outer_wrapper


def meth_scope(db_attr: str, read_only: bool = False):
    def outer_wrapper(func):
        def inner_wrapper(self, *args, **kwargs):
            db, args, kwargs = get_db_from_args(*args, **kwargs)
            if db:
                return func(self, db, *args, **kwargs)

            if not hasattr(self, db_attr):
                raise ValueError(f"'{db_attr}' must refer to a class attribute.")
            database = getattr(self, db_attr)
            if not hasattr(database, "session_scope"):
                raise ValueError(
                    f"'{db_attr}' must refer to an attribute of type 'OdbcDatabase'."
                )
            session_scope = getattr(database, "session_scope")

            with session_scope(read_only=read_only) as db:
                return func(self, db, *args, **kwargs)

        return inner_wrapper

    return outer_wrapper


def get_db_from_args(*args, **kwargs):
    if len(args) > 0 and isinstance(args[0], Session):
        return args[0], args[1:], kwargs

    if "db" not in kwargs:
        return None, args, kwargs

    if not isinstance(kwargs["db"], Session):
        raise ValueError(
            "The keyword argument 'db' must be a SQLAlchemy session object."
        )

    return kwargs.pop("db"), args, kwargs


def reflect_table(
    engine: Engine,
    table_name: str,
    schema: str | None = None,
    meta: sa.MetaData | None = None,
) -> sa.Table:
    if meta is None:
        meta = sa.MetaData()

    try:
        return sa.Table(table_name, meta, schema=schema, autoload_with=engine)
    except sa.exc.NoSuchTableError as e:
        logging.warning(f"Table '{table_name}' does not exist in schema '{schema}'.")
        raise e
    except Exception as e:
        logging.error(
            f"Error while reflecting table '{table_name}' in schema '{schema}'."
        )
        raise e


def get_first_existing_column(table: sa.Table, column_names: list[str]) -> str:
    table_columns = {c.name.lower(): c.name for c in table.columns}

    for column_name in column_names:
        if column_name.lower() in table_columns:
            return table_columns[column_name.lower()]
    logging.error(f"None of the columns {column_names} exist in table {table.name}.")
