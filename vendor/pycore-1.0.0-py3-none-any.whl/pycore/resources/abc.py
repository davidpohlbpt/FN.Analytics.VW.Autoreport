from abc import ABC, abstractmethod
from collections.abc import Sequence

import pydantic
import requests

from pycore.utils.cache import cached_property
from pycore.utils.network import requests_retry_session


class ResourceState(pydantic.BaseModel):
    uri: str
    is_active: bool
    details: str | None = None


class Resource(ABC):
    """Metaclass for resources.

    Used to define common attributes of all resources.
    """

    def __new__(cls, *args, shell: bool = False, **kwargs):
        if shell:
            return ResourceShell(cls, *args, **kwargs)
        else:
            return object.__new__(cls)

    @property
    @abstractmethod
    def is_active(self) -> bool:
        """Indicates whether the resource can be reached and is ready for use.

        This method should never fail with an exception.
        Any exception must be caught and the method must return False instead.

        Returns:
            bool: True if resource is active, False else.
        """
        ...

    @property
    @abstractmethod
    def uri(self) -> str:
        """Returns a unique resource identifier (URI) of the resource.

        The URI makes clear which environment and which specific resource in the respective environment is used.
        This method should never fail with an exception.

        Returns:
            str: URI
        """
        ...

    @property
    def state(self) -> ResourceState:
        """Returns a summary of the resources's state.

        Returns:
            ResourceState: State summary.
        """
        try:
            return ResourceState(uri=self.uri, is_active=self.is_active)
        except Exception as e:
            return ResourceState(uri="unknown", is_active=False, details=str(e))


class ResourceShell:
    """This class delegates every access to its attributes (incl. function calls) to another resource.

    This allows to effectively mock resources during testing and allow easy access at the same time.
    """

    res: Resource

    def __init__(self, cls, *args, **kwargs):
        self.res = cls(*args, **kwargs)

    def __getattr__(self, __name: str):
        return self.res.__getattribute__(__name)

    @property
    def __class__(self):
        return self.res.__class__

    def __repr__(self):
        return self.res.__repr__()


class BlobStorage(Resource):
    """A blob (source_name,) or (source_name, dest_name) pair for bulk operations."""

    BlobPair = str | tuple[str, str]

    @staticmethod
    def _resolve_blob_pair(
        blob: "BlobStorage.BlobPair",
    ) -> tuple[str, str]:
        """Normalise a *BlobPair* into ``(source_name, dest_name)``."""
        if isinstance(blob, str):
            return (blob, blob)
        return blob

    @staticmethod
    def _resolve_blob_name(blob_name: str, prefix: str | None = None) -> str:
        """Resolve the full blob name by prepending the prefix if provided.

        Args:
            blob_name (str): The blob name (file name).
            prefix (Optional[str]): An optional prefix (folder path) prepended to the blob name.
                Callers should include a trailing '/' if folder separation is desired.

        Returns:
            str: The resolved blob name.
        """
        return f"{prefix}{blob_name}" if prefix else blob_name

    @abstractmethod
    def container_exists(self, container_name: str) -> bool: ...

    @abstractmethod
    def create_container(self, container_name: str) -> None: ...

    @abstractmethod
    def delete_container(self, container_name: str) -> None: ...

    @abstractmethod
    def blob_exists(
        self,
        container_name: str,
        blob_name: str,
        prefix: str | None = None,
    ) -> bool: ...

    @abstractmethod
    def read_blob(
        self,
        container_name: str,
        blob_name: str,
        decode: bool | str = "utf-8",
        prefix: str | None = None,
    ) -> str | bytes: ...

    @abstractmethod
    def write_blob(
        self,
        container_name: str,
        blob_name: str,
        blob_data: bytes | bytearray | str,
        override: bool,
        encoding: str,
        prefix: str | None = None,
        metadata: dict[str, str] | None = None,
    ): ...

    @abstractmethod
    def delete_blob(
        self,
        container_name: str,
        blob_name: str,
        prefix: str | None = None,
    ): ...

    @abstractmethod
    def list_blobs(
        self,
        container_name: str,
        prefix: str | None = None,
        metadata: dict[str, str | list[str]] | None = None,
    ) -> list[str]:
        """List all blobs in a container, optionally filtered by prefix and metadata.

        When a prefix is provided, only blobs whose full name starts with the
        prefix are returned **and the prefix is stripped** from each returned
        name.  This means the returned names can be fed directly back into
        ``read_blob``, ``write_blob``, ``blob_exists``, etc. together with the
        same ``prefix`` value.

        When no prefix is given, full blob names are returned as-is.

        When *metadata* is provided, each blob's metadata is retrieved and
        only blobs whose metadata satisfies **all** filter criteria are
        returned.  ``str`` values require an exact match; ``list[str]``
        values match if the blob's value equals **any** of the listed
        values (OR within that key, AND across keys).

        Args:
            container_name: The name of the container.
            prefix: Only return blobs whose names start with this value.
                The prefix itself is removed from the returned names.
            metadata: Optional metadata filter.  When provided, only blobs
                whose metadata matches all criteria are returned.

        Returns:
            Blob names relative to the prefix (or full names when *prefix* is
            ``None``).
        """
        ...

    @abstractmethod
    def list_containers(self): ...

    @abstractmethod
    def copy_blob(
        self,
        source_container: str,
        source_blob: str,
        dest_container: str,
        dest_blob: str,
        override: bool = False,
        source_prefix: str | None = None,
        dest_prefix: str | None = None,
    ) -> None: ...

    @abstractmethod
    def copy_blobs(
        self,
        source_container: str,
        dest_container: str,
        blobs: Sequence[BlobPair],
        override: bool = False,
        source_prefix: str | None = None,
        dest_prefix: str | None = None,
        max_concurrency: int = 8,
    ) -> list[tuple[str, Exception | None]]: ...

    @abstractmethod
    def move_blob(
        self,
        source_container: str,
        source_blob: str,
        dest_container: str,
        dest_blob: str,
        override: bool = False,
        source_prefix: str | None = None,
        dest_prefix: str | None = None,
    ) -> None: ...

    @abstractmethod
    def move_blobs(
        self,
        source_container: str,
        dest_container: str,
        blobs: Sequence[BlobPair],
        override: bool = False,
        source_prefix: str | None = None,
        dest_prefix: str | None = None,
        max_concurrency: int = 8,
    ) -> list[tuple[str, Exception | None]]: ...

    @abstractmethod
    def get_blob_metadata(
        self,
        container_name: str,
        blob_name: str,
        prefix: str | None = None,
    ) -> dict: ...

    @abstractmethod
    def set_blob_metadata(
        self,
        container_name: str,
        blob_name: str,
        metadata: dict,
        prefix: str | None = None,
    ) -> None: ...

    # ------------------------------------------------------------------
    # Metadata filter helper (used by concrete implementations)
    # ------------------------------------------------------------------

    @staticmethod
    def _metadata_match(
        blob_metadata: dict[str, str],
        filter_metadata: dict[str, str | list[str]],
    ) -> bool:
        """Check whether *blob_metadata* satisfies all *filter_metadata* criteria.

        Each key in *filter_metadata* must be present in *blob_metadata*.
        ``str`` values require an exact match; ``list[str]`` values match
        if the blob's value equals **any** of the listed values.
        """
        for key, value in filter_metadata.items():
            blob_value = blob_metadata.get(key)
            if blob_value is None:
                return False
            if isinstance(value, list):
                if blob_value not in value:
                    return False
            elif blob_value != value:
                return False
        return True


class Secret:
    """Reference to a secret in a vault.

    Allows to de-couple secret definition and accessing its value.
    """

    def __init__(self, vault: "Vault", name: str):
        """Creates a reference to a secret without retrieving its value.

        This allows to configure other resources with a secret without having to access the vault.
        This delays the vault access to the time the resource is actually needed.

        Args:
            vault (Vault): Vault the value can be retrieved from.
            name (str): Name of the secret.
        """
        self.vault = vault
        self.name = name

    @cached_property
    def value(self) -> str:
        """Returns the value of this secret by retrieving it from the vault.

        Since this is a cached property, the value is only retrieved from the vault once and from the cache afterwards.

        Returns:
            str: Secret value.
        """
        return self.vault.get_secret_value(name=self.name)


class SecretValue(Secret):
    """Constant secret value that does not depend on a vault."""

    def __init__(self, value: str):
        """Creates a reference to a secret value with a constant underlying value.

        Args:
            value (str): Secret value.
        """
        self.value = value


class Vault(Resource):
    """Resource used to store secrets."""

    def get_secret(self, name: str) -> Secret:
        """Returns a reference to a secret from this vault.

        Since only a reference is returned and not the actual value,
        references to non-existent secrets can be returned as well.

        Args:
            name (str): Name of the secret

        Returns:
            Secret: Secret that can be used to retrieve the secret value
        """
        return Secret(vault=self, name=name)

    @abstractmethod
    def get_secret_value(self, name: str) -> str:
        """Returns a secret value from this vault.

        Accessing secret values is specific to the implementation of the vault.
        Thus, this implementation is abstract.

        Args:
            name (str): Name of the secret

        Returns:
            str: Secret value
        """
        ...


class HttpSession(Resource):
    """Resource used to communicate via HTTP with other Factory Navigator services."""

    def __init__(
        self,
        base_url: str,
        retries: int = 0,
        retry_at_status: list[int] = (500, 502, 504),
        pool_maxsize: int = 10,
    ):
        """Creates a new HTTP session.

        Args:
            base_url (str): Base URL appended as prefix to all request routes sent through this session.
            retries (int, optional): Indicates how often requests should be retried if the server returns one of the listed status codes. Defaults to 0.
            retry_at_status (list[int], optional): List of status codes that should be retried. Defaults to (500, 502, 504).
        """
        self.base_url = base_url
        self.retries = retries
        self.retry_at_status = retry_at_status
        self.pool_maxsize = pool_maxsize

    @property
    def uri(self) -> str:
        """Returns the base URL of this HTTP session as URI.

        If no base URL was provided (e.g. when testing), the constant value `no_base_url_defined` is returned.

        Returns:
            str: Base URL
        """
        return self.base_url or "no_base_url_defined"

    @property
    def is_active(self) -> bool:
        """Returns whether the base URL of this session can be reached with a simple GET.

        Returns:
            bool: True if server can be reached, False else.
        """
        response = self.get("/")
        return response.status_code == requests.codes.ok

    @cached_property
    def session(self):
        s = requests.Session()
        if self.retries > 0:
            return requests_retry_session(
                session=s,
                status_forcelist=self.retry_at_status,
                retries=self.retries,
                pool_maxsize=self.pool_maxsize,
            )
        else:
            return s

    def get(self, url: str, *args, **kwargs) -> requests.Response:
        """Returns the result of a GET request via this HTTP session.

        See [`requests`](https://requests.readthedocs.io/en/latest/) for additional parameters.

        Args:
            url (str): route without base URL (e.g. /tracker/api/v1)

        Returns:
            requests.Response: Response of the server
        """
        return self.request(url=url, method="get", *args, **kwargs)

    def post(self, url: str, *args, **kwargs) -> requests.Response:
        """Returns the result of a POST request via this HTTP session.

        See [`requests`](https://requests.readthedocs.io/en/latest/) for additional parameters.

        Args:
            url (str): route without base URL (e.g. /tracker/api/v1)

        Returns:
            requests.Response: Response of the server
        """
        return self.request(url=url, method="post", *args, **kwargs)

    def put(self, url: str, *args, **kwargs) -> requests.Response:
        """Returns the result of a PUT request via this HTTP session.

        See [`requests`](https://requests.readthedocs.io/en/latest/) for additional parameters.

        Args:
            url (str): route without base URL (e.g. /tracker/api/v1)

        Returns:
            requests.Response: Response of the server
        """
        return self.request(url=url, method="put", *args, **kwargs)

    def delete(self, url: str, *args, **kwargs) -> requests.Response:
        """Returns the result of a DELETE request via this HTTP session.

        See [`requests`](https://requests.readthedocs.io/en/latest/) for additional parameters.

        Args:
            url (str): route without base URL (e.g. /tracker/api/v1)

        Returns:
            requests.Response: Response of the server
        """
        return self.request(url=url, method="delete", *args, **kwargs)

    def request(self, method: str, url: str, *args, **kwargs) -> requests.Response:
        """Returns the result of a GET request via this HTTP session.

        See [`requests`](https://requests.readthedocs.io/en/latest/) for additional parameters.

        Args:
            method (str): Request method. GET, OPTIONS, HEAD, POST, PUT, PATCH, or DELETE.
            url (str): route without base URL (e.g. /tracker/api/v1)

        Returns:
            requests.Response: Response of the server
        """
        url = self.base_url + url
        return self.session.request(method, url, *args, **kwargs)

    def get_absolute(self, url: str, *args, **kwargs) -> requests.Response:
        """Returns the result of a GET request to an already-fully-qualified URL.

        Unlike `get()`, `base_url` is not prepended. Useful for services that must be
        reached directly, bypassing a gateway that doesn't route them (e.g. identity).

        Args:
            url (str): Fully-qualified URL (e.g. http://fn-identity-service/api/v1/...)

        Returns:
            requests.Response: Response of the server
        """
        return self.session.request("get", url, *args, **kwargs)

    def post_absolute(self, url: str, *args, **kwargs) -> requests.Response:
        """Returns the result of a POST request to an already-fully-qualified URL.

        Args:
            url (str): Fully-qualified URL (e.g. http://fn-email-service/api/messages/email)

        Returns:
            requests.Response: Response of the server
        """
        return self.session.request("post", url, *args, **kwargs)
