import json
import logging
import pathlib

from pycore.resources.abc import Vault


class FileVault(Vault):
    """Vault that reads secrets from a JSON file in a mounted Kubernetes secret directory.

    Designed for Kubernetes deployments where a secret is mounted as a volume.
    The secret contains a key (e.g., 'appsettings.secrets.json') whose value is a JSON
    string containing all the application secrets.

    Example Kubernetes secret structure:
    /secrets/
        appsettings.secrets.json  <- This file contains the JSON with all secrets

    The JSON file content:
    {
        "Database-GenericDBConnectionString": "Server=...",
        "AppSettings-StorageAccountConnString": "...",
        "IdentityClientAdmin": "...",
        "OpenAi-ApiKey": "..."
    }
    """

    def __init__(
        self,
        secrets_dir: str | pathlib.Path,
        secrets_filename: str = "appsettings.secrets.json",
    ):
        """Initialize the file vault.

        Args:
            secrets_dir: Path to the directory containing the secrets file (Kubernetes mount point).
            secrets_filename: Name of the file containing the JSON secrets (default: appsettings.secrets.json).
        """
        if isinstance(secrets_dir, str):
            self.secrets_dir = pathlib.Path(secrets_dir)
        else:
            self.secrets_dir = secrets_dir

        self.secrets_filename = secrets_filename
        self.secrets_file = self.secrets_dir / secrets_filename
        self._secrets = None
        self._load_secrets()

    def _load_secrets(self):
        """Load secrets from the JSON file."""
        if not self.secrets_file.exists():
            logging.warning(
                f"Secrets file not found at {self.secrets_file}. "
                f"Expected file '{self.secrets_filename}' in directory {self.secrets_dir}"
            )
            self._secrets = {}
        else:
            try:
                with open(self.secrets_file, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    self._secrets = json.loads(content)
                logging.info(
                    f"Loaded {len(self._secrets)} secrets from {self.secrets_file}"
                )
            except json.JSONDecodeError as e:
                logging.exception(
                    f"Failed to parse secrets file {self.secrets_file}: {e}"
                )
                raise ValueError(f"Invalid JSON in secrets file: {e}")
            except Exception as e:
                logging.exception(
                    f"Failed to read secrets file {self.secrets_file}: {e}"
                )
                raise IOError(f"Failed to read secrets file: {e}")

    @property
    def is_active(self) -> bool:
        """Check if the secrets file exists and was loaded successfully."""
        try:
            return self.secrets_file.exists() and self._secrets is not None
        except Exception:
            return False

    @property
    def uri(self) -> str:
        """Return the URI of the secrets file."""
        return self.secrets_file.absolute().as_uri()

    def get_secret_value(self, name: str) -> str:
        """Retrieve a secret value from the loaded secrets.

        Args:
            name: The name of the secret.

        Returns:
            The secret value.

        Raises:
            KeyError: If the secret is not found.
        """
        if self._secrets is None:
            self._load_secrets()

        if name not in self._secrets:
            available_secrets = list(self._secrets.keys())
            logging.warning(
                f"Secret '{name}' not found in {self.secrets_file}. "
                f"Available secrets: {available_secrets}"
            )
            raise KeyError(f"Secret '{name}' not found in file vault")

        logging.info(f"Retrieved secret '{name}' from file vault")
        return self._secrets[name]

    def reload(self):
        """Reload secrets from the file."""
        self._load_secrets()
