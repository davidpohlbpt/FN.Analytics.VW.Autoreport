import json
import logging
import pathlib
import shutil
import tempfile
from collections.abc import Sequence

from pycore.resources.abc import BlobStorage


class FileStorage(BlobStorage):
    """Blob storage implementation using the local file system.

    Maps Azure Blob Storage concepts to local folders and files:
    - Container -> Root folder (e.g., 'my-container' -> my-container/)
    - Blob -> File with virtual folder support via '/' delimiters in the blob name
      (e.g., blob 'a/b/c/file.txt' -> a/b/c/file.txt within the container folder)

    Metadata is stored in sidecar files with '.meta.json' extension alongside each blob.
    """

    def __init__(
        self,
        root_dir: pathlib.Path | str | None = None,
    ):
        """Initialize the FileStorage with a root directory and optional storage secret name.

        Args:
            root_dir (Union[pathlib.Path, str, None]): The root directory for the file storage.
                If None, a temporary directory will be used.

        Raises:
            ValueError: If the provided root_dir is not a valid path or string.
        """
        if root_dir is None:
            root_dir = pathlib.Path(tempfile.mkdtemp())
            logging.warning(
                f"Using the temporary directory {root_dir} as blob storage. "
                "Any files will be lost after the program execution."
            )

        if isinstance(root_dir, str):
            root_dir = pathlib.Path(root_dir)
        elif not isinstance(root_dir, pathlib.Path):
            raise ValueError("The root_dir must be a pathlib.Path, str, or None.")

        self.root_dir = root_dir

        if not self.root_dir.exists():
            self.root_dir.mkdir(parents=True, exist_ok=True)

    @property
    def is_active(self):
        return self.root_dir.is_dir() and self.root_dir.exists()

    @property
    def uri(self):
        return self.root_dir.absolute().as_uri()

    def container_exists(self, container_name: str) -> bool:
        """Check if a folder exists.

        Args:
            container_name (str): The name of the folder.

        Returns:
            bool: True if the folder exists, False otherwise.
        """
        container_path = self.root_dir / container_name
        return container_path.is_dir()

    def create_container(self, container_name: str) -> None:
        """Create a new container (folder).

        Args:
            container_name (str): The name of the folder.

        Raises:
            RuntimeError: If the container already exists.
        """
        if self.container_exists(container_name):
            raise RuntimeError(f"Container '{container_name}' already exists.")
        (self.root_dir / container_name).mkdir()

    def delete_container(self, container_name: str) -> None:
        """Delete a container (folder) and all its contents.

        Args:
            container_name (str): The name of the folder.

        Raises:
            RuntimeError: If the container does not exist.
        """
        if not self.container_exists(container_name):
            raise RuntimeError(f"Container '{container_name}' does not exist.")
        shutil.rmtree(self.root_dir / container_name)

    def blob_exists(
        self, container_name: str, blob_name: str, prefix: str | None = None
    ) -> bool:
        """Check if a file exists.

        Args:
            container_name (str): The name of the folder.
            blob_name (str): The name of the file.
            prefix (Optional[str]): An optional prefix prepended to blob_name.

        Returns:
            bool: True if the file exists, False otherwise.
        """
        blob_name = self._resolve_blob_name(blob_name, prefix)
        file_path = self.root_dir / container_name / blob_name
        return file_path.is_file()

    def _get_metadata_path(self, container_name: str, blob_name: str) -> pathlib.Path:
        """Get the path to the metadata sidecar file."""
        return self.root_dir / container_name / f"{blob_name}.meta.json"

    def get_blob_metadata(
        self, container_name: str, blob_name: str, prefix: str | None = None
    ) -> dict:
        """Retrieve metadata for a blob."""
        blob_name = self._resolve_blob_name(blob_name, prefix)
        metadata_path = self._get_metadata_path(container_name, blob_name)

        if not metadata_path.is_file():
            return {}  # Return empty metadata if no sidecar file exists

        with open(metadata_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def set_blob_metadata(
        self,
        container_name: str,
        blob_name: str,
        metadata: dict,
        prefix: str | None = None,
    ) -> None:
        """Set metadata for a blob."""
        blob_name = self._resolve_blob_name(blob_name, prefix)
        if not self.blob_exists(container_name, blob_name):
            raise RuntimeError(
                f"The blob '{blob_name}' does not exist in container '{container_name}'."
            )

        metadata_path = self._get_metadata_path(container_name, blob_name)

        with open(metadata_path, "w", encoding="utf-8") as f:
            json.dump(metadata, f, ensure_ascii=False, indent=4)

    def read_blob(
        self,
        container_name: str,
        blob_name: str,
        decode: bool | str = "utf-8",
        prefix: str | None = None,
    ):
        """Read a file from the file system.

        Args:
            container_name (str): The name of the folder.
            blob_name (str): The name of the file.
            decode (Union[bool, str], optional): If False, the file is read as bytes. If True, the file is read as a string.  If a string is provided, the file is read as a string using the provided encoding. Defaults to "utf-8".
            prefix (Optional[str]): An optional prefix prepended to blob_name.

        Returns:
            Union[bytes, str]: The content of the file.

        Raises:
            RuntimeError: If the file does not exist.
        """
        blob_name = self._resolve_blob_name(blob_name, prefix)
        path = self.root_dir / container_name / blob_name

        if not path.is_file():
            raise RuntimeError(
                f"Could not find file '{blob_name}' in folder '{container_name}' directory '{self.root_dir}'."
            )

        if decode is False:
            # Return bytes
            with open(path, "rb") as f:
                return f.read()
        else:
            # Return string, use UTF-8 as default encoding
            decode = "utf-8" if decode is True else decode
            with open(path, "r", encoding=decode) as f:
                return f.read()

    def write_blob(
        self,
        container_name: str,
        blob_name: str,
        blob_data: bytes | bytearray | str,
        override: bool = True,
        encoding: str = "utf-8",
        prefix: str | None = None,
        metadata: dict[str, str] | None = None,
    ):
        """Write a file to the file system.

        Args:
            container_name (str): The name of the folder (container).
            blob_name (str): The name of the file (blob), can include subdirectories.
            blob_data (Union[bytes, bytearray, str]): The content of the file.
            override (bool, optional): If True, the file is overwritten if it exists already.
                If False, an error is raised if the file exists already. Defaults to True.
            encoding (str, optional): The encoding to use when writing a string. Defaults to "utf-8".
            prefix (Optional[str]): An optional prefix prepended to blob_name.
            metadata (Optional[dict[str, str]]): Optional metadata to set on the blob after writing.

        Raises:
            RuntimeError: If the container doesn't exist or if the file exists and override=False.
        """

        if not self.container_exists(container_name):
            raise RuntimeError(
                f"Container '{container_name}' does not exist. "
                f"Create it first or check the container name."
            )

        blob_name = self._resolve_blob_name(blob_name, prefix)
        path = self.root_dir / container_name / blob_name

        if not override and path.exists():
            raise RuntimeError(
                f"The blob '{blob_name}' exists already in container '{container_name}'. "
                f"Set override=True to overwrite it."
            )

        # Create parent directories for nested blob paths (e.g., 'a/b/c/file.txt')
        path.parent.mkdir(parents=True, exist_ok=True)

        if isinstance(blob_data, (bytes, bytearray)):
            mode = "wb"
            encoding = None
        else:
            mode = "w"

        with open(path, mode, encoding=encoding) as f:
            f.write(blob_data)

        if metadata:
            self.set_blob_metadata(container_name, blob_name, metadata)

    def delete_blob(
        self, container_name: str, blob_name: str, prefix: str | None = None
    ):
        """Delete a file from the file system.

        Args:
            container_name (str): The name of the folder.
            blob_name (str): The name of the file.
            prefix (Optional[str]): An optional prefix prepended to blob_name.

        Raises:
            RuntimeError: If the file does not exist.
        """
        blob_name = self._resolve_blob_name(blob_name, prefix)
        if not self.blob_exists(container_name=container_name, blob_name=blob_name):
            raise RuntimeError(
                f"The blob '{blob_name}' does not exist in container '{container_name}'."
            )
        (self.root_dir / container_name / blob_name).unlink()

        # Remove metadata sidecar if it exists
        meta_path = self._get_metadata_path(container_name, blob_name)
        if meta_path.is_file():
            meta_path.unlink()

    def list_blobs(
        self,
        container_name: str,
        prefix: str | None = None,
        metadata: dict[str, str | list[str]] | None = None,
    ) -> list[str]:
        """List all files in a container, optionally filtered by prefix and metadata.

        Returns blob names with '/' delimiters for nested paths, mirroring
        Azure's flat namespace.  Excludes sidecar files (.meta.json,
        .tags.json).

        When *prefix* is provided the prefix is **stripped** from each returned
        name so that the results can be used directly with other blob methods
        (``read_blob``, ``write_blob``, …) using the same *prefix*.

        When *metadata* is provided, each blob's metadata is checked against
        the filter criteria.  ``str`` values require an exact match;
        ``list[str]`` values match if the blob's value equals **any** of the
        listed values (OR within that key, AND across keys).

        Args:
            container_name: The name of the container (folder).
            prefix: Only return blobs whose names start with this value.
                The prefix itself is removed from the returned names.
            metadata: Optional metadata filter.

        Raises:
            RuntimeError: If the container does not exist.

        Returns:
            Blob names relative to the prefix (or full names when *prefix* is
            ``None``).
        """
        if not self.container_exists(container_name):
            raise RuntimeError(f"Container '{container_name}' does not exist.")

        container_path = self.root_dir / container_name
        blob_list = []

        # Recursively find all files
        for file_path in container_path.rglob("*"):
            if file_path.is_file() and not file_path.name.endswith(
                (".meta.json", ".tags.json")
            ):
                relative_path = file_path.relative_to(container_path)
                # Convert to forward slashes for consistency with Azure
                blob_name = str(relative_path).replace("\\", "/")

                if not prefix or blob_name.startswith(prefix):
                    stripped = blob_name[len(prefix) :] if prefix else blob_name
                    blob_list.append((blob_name, stripped))

        if not metadata:
            return [stripped for _, stripped in blob_list]

        return [
            stripped
            for blob_name, stripped in blob_list
            if self._metadata_match(
                self.get_blob_metadata(container_name, blob_name), metadata
            )
        ]

    def list_containers(self) -> list[str]:
        """List all folders in the root directory.

        Returns:
            list[str]: The list of folders in the root directory.
        """
        return [f.name for f in self.root_dir.iterdir() if f.is_dir()]

    def copy_blob(
        self,
        source_container: str,
        source_blob: str,
        dest_container: str,
        dest_blob: str,
        override: bool = False,
        source_prefix: str | None = None,
        dest_prefix: str | None = None,
    ) -> None:
        """Copy a blob (file) within or across containers.

        Args:
            source_container: Source container (folder) name.
            source_blob: Source blob (file) name.
            dest_container: Destination container (folder) name.
            dest_blob: Destination blob (file) name.
            override: If True, overwrite destination if it exists.
            source_prefix: Optional prefix prepended to source_blob.
            dest_prefix: Optional prefix prepended to dest_blob.

        Raises:
            RuntimeError: If source doesn't exist, destination container
                doesn't exist, or destination exists and override is False.
        """
        results = self.copy_blobs(
            source_container,
            dest_container,
            [(source_blob, dest_blob)],
            override=override,
            source_prefix=source_prefix,
            dest_prefix=dest_prefix,
        )
        _, err = results[0]
        if err is not None:
            raise err

    def copy_blobs(
        self,
        source_container: str,
        dest_container: str,
        blobs: Sequence[str | tuple[str, str]],
        override: bool = False,
        source_prefix: str | None = None,
        dest_prefix: str | None = None,
        max_concurrency: int = 8,
    ) -> list[tuple[str, Exception | None]]:
        """Copy multiple blobs (files) within or across containers.

        Args:
            source_container: Source container (folder) name.
            dest_container: Destination container (folder) name.
            blobs: Blob names to copy.  Each element is either a ``str``
                (same name for source and destination) or a
                ``(source_name, dest_name)`` tuple.
            override: If True, overwrite destination blobs if they exist.
            source_prefix: Optional prefix prepended to each source blob name.
            dest_prefix: Optional prefix prepended to each destination blob name.
            max_concurrency: Ignored for local file storage.

        Returns:
            A list of ``(source_blob_name, error)`` tuples.  ``error`` is
            ``None`` for blobs that were copied successfully.
        """
        results: list[tuple[str, Exception | None]] = []
        for blob in blobs:
            src_name, dst_name = self._resolve_blob_pair(blob)
            resolved_src = self._resolve_blob_name(src_name, source_prefix)
            resolved_dst = self._resolve_blob_name(dst_name, dest_prefix)
            try:
                if not self.blob_exists(source_container, resolved_src):
                    raise RuntimeError(
                        f"The source blob does not exist: "
                        f"{source_container}/{resolved_src}"
                    )

                if not self.container_exists(dest_container):
                    raise RuntimeError(
                        f"The destination container does not exist: {dest_container}"
                    )

                if self.blob_exists(dest_container, resolved_dst) and not override:
                    raise RuntimeError(
                        f"The destination blob already exists: "
                        f"{dest_container}/{resolved_dst}"
                    )

                src_path = self.root_dir / source_container / resolved_src
                dst_path = self.root_dir / dest_container / resolved_dst
                dst_path.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(str(src_path), str(dst_path))

                # Copy metadata sidecar if it exists
                src_meta = self._get_metadata_path(source_container, resolved_src)
                if src_meta.is_file():
                    dst_meta = self._get_metadata_path(dest_container, resolved_dst)
                    dst_meta.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(str(src_meta), str(dst_meta))

                results.append((src_name, None))
            except Exception as e:
                results.append((src_name, e))
        return results

    def move_blob(
        self,
        source_container: str,
        source_blob: str,
        dest_container: str,
        dest_blob: str,
        override: bool = False,
        source_prefix: str | None = None,
        dest_prefix: str | None = None,
    ) -> None:
        """Move (copy then delete) a blob within or across containers.

        Args:
            source_container: Source container (folder) name.
            source_blob: Source blob (file) name.
            dest_container: Destination container (folder) name.
            dest_blob: Destination blob (file) name.
            override: If True, overwrite destination if it exists.
            source_prefix: Optional prefix prepended to source_blob.
            dest_prefix: Optional prefix prepended to dest_blob.

        Raises:
            RuntimeError: If source doesn't exist, destination container
                doesn't exist, or destination exists and override is False.
        """
        results = self.move_blobs(
            source_container,
            dest_container,
            [(source_blob, dest_blob)],
            override=override,
            source_prefix=source_prefix,
            dest_prefix=dest_prefix,
        )
        _, err = results[0]
        if err is not None:
            raise err

    def move_blobs(
        self,
        source_container: str,
        dest_container: str,
        blobs: Sequence[str | tuple[str, str]],
        override: bool = False,
        source_prefix: str | None = None,
        dest_prefix: str | None = None,
        max_concurrency: int = 8,
    ) -> list[tuple[str, Exception | None]]:
        """Move multiple blobs sequentially (local filesystem).

        Args:
            source_container: Source container (folder) name.
            dest_container: Destination container (folder) name.
            blobs: Blob names to move.  Each element is either a ``str``
                (same name for source and destination) or a
                ``(source_name, dest_name)`` tuple.
            override: If True, overwrite destination blobs if they exist.
            source_prefix: Optional prefix prepended to each source blob name.
            dest_prefix: Optional prefix prepended to each destination blob name.
            max_concurrency: Ignored for local file storage.

        Returns:
            A list of ``(source_blob_name, error)`` tuples.  ``error`` is
            ``None`` for blobs that were moved successfully.
        """
        results = self.copy_blobs(
            source_container,
            dest_container,
            blobs,
            override=override,
            source_prefix=source_prefix,
            dest_prefix=dest_prefix,
        )

        for src_name, err in results:
            if err is None:
                resolved_src = self._resolve_blob_name(src_name, source_prefix)
                self.delete_blob(source_container, resolved_src)

        return results


class TempFileStorage(FileStorage):
    """A file storage that uses a temporary directory as root directory."""

    def __init__(self):
        # Use temporary directory
        root_dir = tempfile.mkdtemp()
        logging.warning(
            f"Using the temporary directory {root_dir} as blob storage. Any file will be lost after the program execution."
        )
        super().__init__(root_dir)
