import logging
import os

from pycore.resources.abc import Vault


class EnvVault(Vault):
    def __init__(self, prefix: str = ""):
        self.prefix = prefix

    @property
    def uri(self) -> str:
        return self.prefix

    @property
    def is_active(self) -> bool:
        return True

    def get_secret_value(self, name: str) -> str:
        if self.prefix:
            name = f"{self.prefix}{name}"
        secret = os.environ.get(name)
        if secret is None:
            logging.warning(
                f"Could not obtain secret {name} from environment variables."
            )
        return secret
