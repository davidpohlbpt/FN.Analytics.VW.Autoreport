import pathlib

import pydantic
from pydantic_settings import BaseSettings

from pycore.resources.abc import BlobStorage, SecretValue, Vault
from pycore.resources.env import EnvVault
from pycore.resources.file import FileStorage
from pycore.resources.odbc import OdbcDatabase, SqlServerDatabase


class LocalSettings(BaseSettings):
    """Settings required for using local resources."""

    local_sqlserver_conn_str: str | None = None
    """Full connection string to the local database.
    """

    local_sqlserver_host: str = r"localhost\SQLEXPRESS"
    """Host name of the local database server.

    For SQL Server Express, this defaults to `localhost\\SQLEXPRESS`.
    """

    local_sqlserver_db: str | None = None
    """Database name used in the local database server.

    Defaults to the configured application's database name.
    """

    local_blob_dir: pathlib.Path | None = None
    """Directory from (to) which blobs (i.e. files) are read (written).

    Defaults to a new folder in the user directory, e.g., `C:/users/firstname.lastname/myproject_data/`.
    """

    @pydantic.model_validator(mode="after")
    def set_conn_str(self):
        """Sets the connection string if not provided."""

        # Set local_sqlserver_db if not provided
        if not self.local_sqlserver_db:
            from pycore.config import settings

            self.local_sqlserver_db = settings.app_db_name

        # Set local_sqlserver_conn_str if not provided
        if not self.local_sqlserver_conn_str:
            host = self.local_sqlserver_host
            db = self.local_sqlserver_db
            odbc_conn_str = (
                "Driver={{ODBC Driver 17 for SQL Server}};"
                "Server={host};Database={db};Trusted_Connection=yes;"
            ).format(host=host, db=db)
            self.local_sqlserver_conn_str = odbc_conn_str

        return self

    @pydantic.model_validator(mode="after")
    def set_blob_dir(self):
        """Sets the blob directory if not provided."""
        if self.local_blob_dir:
            return self

        from pycore.config import settings

        self.local_blob_dir = pathlib.Path.home() / (
            settings.app_name.lower() + "_data"
        )
        return self


def load_local_resources(base=None) -> tuple[OdbcDatabase, Vault, BlobStorage]:
    settings = LocalSettings()

    storage = FileStorage(root_dir=settings.local_blob_dir, shell=True)
    conn_secret = SecretValue(value=settings.local_sqlserver_conn_str)
    database = SqlServerDatabase(
        conn_secret=conn_secret,
        db_name=settings.local_sqlserver_db,
        base=base,
        shell=True,
    )
    rdp_db = SqlServerDatabase(conn_secret=conn_secret, db_name="ReportDB", shell=True)
    md_db = SqlServerDatabase(
        conn_secret=conn_secret, db_name="MasterDataDB", shell=True
    )
    batch_api_db = SqlServerDatabase(
        conn_secret=conn_secret, db_name="BatchApiDB", shell=True
    )
    vault = EnvVault(shell=True)

    return database, vault, storage, rdp_db, md_db, batch_api_db
