try:
    # Using ELK resources requires additional libraries
    import elasticsearch
except ImportError as e:
    raise ImportError(
        "Please install optional ELK dependencies with 'poetry install -E elk'"
    ) from e
