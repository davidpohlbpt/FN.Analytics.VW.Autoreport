import logging
import os
import socket
from datetime import datetime

from elasticsearch import Elasticsearch

from pycore.config import settings
from pycore.resources.abc import Resource, Secret
from pycore.utils.cache import cached_property


class Elastic(Resource):
    def __init__(self, url_secret: Secret, index_name: str):
        self.url_secret = url_secret
        self.index_name = index_name

    @cached_property
    def es(self):
        try:
            url = self.url_secret.value
            url = url.replace("/elastic", ":443/elastic")
            es = Elasticsearch(url, request_timeout=5, verify_certs=True)
            if not es.ping():
                raise RuntimeError("Failed to connect to ElasticSearch.")
            return es
        except Exception as e:
            raise RuntimeError(f"Failed to connect to ElasticSearch: {e}")

    @property
    def uri(self):
        return self.url_secret.value

    @property
    def is_active(self) -> bool:
        try:
            return bool(self.es.ping())
        except RuntimeError:
            return False

    def send_record(self, record: logging.LogRecord):
        if not self.es:
            return

        data = {
            "@timestamp": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S"),
            "level": record.levelname,
            "message": record.message,
            "fields": {
                "SourceContext": f"Python Service: {settings.app_name}",
                "MachineName": socket.gethostname(),
                "EnvironmentName": settings.environment,
                "EnvironmentUserName": os.getlogin(),
            },
        }

        try:
            return self.es.index(index=self.index_name, document=data)
        except Exception as e:
            logging.error(f"Failed to log to ElasticSearch: {e}")
