import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from collections.abc import Sequence

from azure.storage.blob import (
    BlobServiceClient,
    ContainerSasPermissions,
    generate_container_sas,
)

from pycore.resources.abc import BlobStorage, Secret
from pycore.utils.cache import cached_property


class AzureBlobStorage(BlobStorage):
    """Blob storage based on the Azure Blob Storage."""

    def __init__(self, conn_secret: Secret):
        self.conn_secret = conn_secret

    @cached_property
    def blob_service_client(self):
        return BlobServiceClient.from_connection_string(self.conn_secret.value)

    @property
    def is_active(self) -> bool:
        try:
            next(self.blob_service_client.list_containers())
            return True
        except StopIteration:
            return True  # Connection OK, but no containers
        except Exception:
            return False

    @property
    def uri(self) -> str:
        return self.blob_service_client.url

    def _ensure_container_client(self, container_name: str):
        """Return a ``ContainerClient`` after verifying the container exists.

        Raises:
            RuntimeError: If the container does not exist.
        """
        container_client = self.blob_service_client.get_container_client(container_name)
        if not container_client.exists():
            raise RuntimeError(
                f"The specified container does not exist: {container_name}"
            )
        return container_client

    def _ensure_blob_client(
        self,
        container_name: str,
        blob_name: str,
        prefix: str | None = None,
    ):
        """Return a ``BlobClient`` after verifying both container and blob exist.

        The *prefix* is resolved via :meth:`_resolve_blob_name`.

        Raises:
            RuntimeError: If the container or blob does not exist.
        """
        blob_name = self._resolve_blob_name(blob_name, prefix)
        container_client = self._ensure_container_client(container_name)
        blob_client = container_client.get_blob_client(blob=blob_name)
        if not blob_client.exists():
            raise RuntimeError(f"The specified blob does not exist: {blob_name}")
        return blob_client

    def container_exists(self, container_name: str) -> bool:
        """Verifies if container with given name exists

        Args:
            container_name (str): Name of the container

        Returns:
            bool: returns True if the container exists, or false otherwise
        """
        container_client = self.blob_service_client.get_container_client(container_name)
        return container_client.exists()

    def blob_exists(
        self, container_name: str, blob_name: str, prefix: str | None = None
    ) -> bool:
        """Verifies if blob with given name exists inside given container

        Args:
            container_name (str): Name of the container
            blob_name (str): Name of the blob
            prefix (Optional[str]): An optional prefix prepended to blob_name

        Returns:
            bool: returns True if the blob exists, or false otherwise
        """
        blob_name = self._resolve_blob_name(blob_name, prefix)
        container_client = self.blob_service_client.get_container_client(container_name)
        if not container_client.exists():
            return False
        blob_client = container_client.get_blob_client(blob=blob_name)
        return blob_client.exists()

    def create_container(self, container_name: str):
        """Creates a new container.

        Args:
            container_name (str): Name of the container

        Raises:
            RuntimeError: Raises an exception if the container already exists
        """
        if self.container_exists(container_name):
            raise RuntimeError(f"Container {container_name} already exists")
        self.blob_service_client.create_container(container_name)
        logging.info(f"Container {container_name} was created")

    def delete_container(self, container_name: str):
        """Deletes a container.

        Args:
            container_name (str): Name of the container

        Raises:
            RuntimeError: Raises an exception if the container does not exist
        """
        self._ensure_container_client(container_name)
        self.blob_service_client.delete_container(container_name)
        logging.info(f"Container {container_name} was deleted")

    def read_blob(
        self,
        container_name: str,
        blob_name: str,
        decode: bool | str = "utf-8",
        prefix: str | None = None,
    ) -> str | bytes | bytearray | None:
        """Reads the content of a blob

        Args:
            container_name (str): Name of the container
            blob_name (str): Name of the blob
            decode (Union[bool, str], optional): If True, the content will be decoded to string. Defaults to "utf-8".
            prefix (Optional[str]): An optional prefix prepended to blob_name.

        Returns:
            Union[str, bytes, bytearray, bool]: Returns the content of the blob. Returns False if the blob does not exist
        """
        blob_client = self._ensure_blob_client(container_name, blob_name, prefix)
        try:
            data = blob_client.download_blob().readall()
        except Exception as e:
            raise RuntimeError(
                f"There was an error downloading the requested file: {e}"
            )
        decode = "utf-8" if decode is True else decode
        if decode:
            try:
                data = data.decode(decode)
            except Exception as e:
                raise RuntimeError(f"Data cannot be decoded to string. {e}")
        return data

    def write_blob(
        self,
        container_name: str,
        blob_name: str,
        blob_data: bytes | bytearray | str,
        override: bool = False,
        encoding: str = "utf-8",
        prefix: str | None = None,
        metadata: dict[str, str] | None = None,
    ):
        """Writes data to a blob

        Args:
            container_name (str): Name of the container
            blob_name (str): Name of the blob
            blob_data (Union[bytes, bytearray, str]): Data to be written to the blob
            override (bool, optional): If True, the blob will be overwritten if it already exists. Defaults to False.
            encoding (str, optional): Encoding to be used if blob_data is of type str. Defaults to "utf-8".
            prefix (Optional[str]): An optional prefix prepended to blob_name.
            metadata (Optional[dict[str, str]]): Optional metadata to set on the blob after upload.

        Raises:
            TypeError: If blob_data is not of type str, bytes, or bytearray.
            RuntimeError: If the container does not exist or if the blob already exists and override is False.
        """
        if not isinstance(blob_data, (bytes, bytearray, str)):
            raise TypeError(
                "blob_data must be of type str, bytes, or bytearray, "
                f"got {type(blob_data).__name__}"
            )

        if isinstance(blob_data, str):
            blob_data = blob_data.encode(encoding)

        blob_name = self._resolve_blob_name(blob_name, prefix)
        container_client = self._ensure_container_client(container_name)
        blob_client = container_client.get_blob_client(blob=blob_name)
        if blob_client.exists():
            if not override:
                raise RuntimeError(f"The specified blob already exists: {blob_name}")
            blob_client.delete_blob()

        try:
            blob_client.upload_blob(blob_data)
        except Exception as e:
            raise RuntimeError(f"An error occurred while writing the blob: {e}")

        if metadata:
            blob_client.set_blob_metadata(metadata)

    def delete_blob(
        self, container_name: str, blob_name: str, prefix: str | None = None
    ) -> None:
        """Deletes a blob

        Args:
            container_name (str): Name of the container
            blob_name (str): Name of the blob
            prefix (Optional[str]): An optional prefix prepended to blob_name.

        Raises:
            RuntimeError: Raises an exception if the container does not exist or if the blob does not exist
        """
        blob_client = self._ensure_blob_client(container_name, blob_name, prefix)
        blob_client.delete_blob()

    def list_blobs(
        self,
        container_name: str,
        prefix: str | None = None,
        metadata: dict[str, str | list[str]] | None = None,
    ) -> list[str]:
        """List all blobs in a container, optionally filtered by prefix and metadata.

        When *prefix* is provided the prefix is **stripped** from each returned
        name so that the results can be used directly with other blob methods
        (``read_blob``, ``write_blob``, …) using the same *prefix*.

        When *metadata* is provided, each blob's metadata is checked against
        the filter criteria.  ``str`` values require an exact match;
        ``list[str]`` values match if the blob's value equals **any** of the
        listed values (OR within that key, AND across keys).

        Args:
            container_name: The name of the Azure container.
            prefix: Only return blobs whose names start with this value.
                The prefix itself is removed from the returned names.
            metadata: Optional metadata filter.

        Raises:
            RuntimeError: If the container does not exist.

        Returns:
            Blob names relative to the prefix (or full names when *prefix* is
            ``None``).
        """
        container_client = self._ensure_container_client(container_name)

        if metadata:
            result = []
            for b in container_client.list_blobs(
                name_starts_with=prefix, include="metadata"
            ):
                blob_meta = b.metadata or {}
                if self._metadata_match(blob_meta, metadata):
                    name = b.name[len(prefix) :] if prefix else b.name
                    result.append(name)
            return result

        return [
            b.name[len(prefix) :] if prefix else b.name
            for b in container_client.list_blobs(name_starts_with=prefix)
        ]

    def list_containers(self) -> list[str]:
        """Lists all containers

        Returns:
            list[str]: Returns a list of all containers
        """
        return [c["name"] for c in self.blob_service_client.list_containers()]

    def get_blob_metadata(
        self, container_name: str, blob_name: str, prefix: str | None = None
    ) -> dict:
        """Retrieve metadata for a blob."""
        blob_client = self._ensure_blob_client(container_name, blob_name, prefix)
        return blob_client.get_blob_properties().metadata

    def copy_blob(
        self,
        source_container: str,
        source_blob: str,
        dest_container: str,
        dest_blob: str,
        override: bool = False,
        source_prefix: str | None = None,
        dest_prefix: str | None = None,
    ) -> None:
        """Copy a blob server-side within the same storage account.

        Args:
            source_container: Name of the source container.
            source_blob: Name of the source blob.
            dest_container: Name of the destination container.
            dest_blob: Name of the destination blob.
            override: If True, overwrite the destination blob if it exists.
            source_prefix: Optional prefix prepended to source_blob.
            dest_prefix: Optional prefix prepended to dest_blob.

        Raises:
            RuntimeError: If source doesn't exist, destination container
                doesn't exist, or destination blob exists and override is False.
        """
        results = self.copy_blobs(
            source_container,
            dest_container,
            [(source_blob, dest_blob)],
            override=override,
            source_prefix=source_prefix,
            dest_prefix=dest_prefix,
            max_concurrency=1,
        )
        _, err = results[0]
        if err is not None:
            raise err

    def copy_blobs(
        self,
        source_container: str,
        dest_container: str,
        blobs: Sequence[str | tuple[str, str]],
        override: bool = False,
        source_prefix: str | None = None,
        dest_prefix: str | None = None,
        max_concurrency: int = 8,
    ) -> list[tuple[str, Exception | None]]:
        """Copy multiple blobs server-side within the same storage account.

        Validates containers once, generates a single SAS token, then copies
        blobs concurrently.

        Args:
            source_container: Name of the source container.
            dest_container: Name of the destination container.
            blobs: Blob names to copy (relative to prefix).  Each element is
                either a ``str`` (same name for source and destination) or a
                ``(source_name, dest_name)`` tuple.
            override: If True, overwrite destination blobs if they exist.
            source_prefix: Optional prefix prepended to each source blob name.
            dest_prefix: Optional prefix prepended to each destination blob name.
            max_concurrency: Maximum number of parallel copy operations.

        Returns:
            A list of ``(source_blob_name, error)`` tuples.  ``error`` is
            ``None`` for blobs that were copied successfully.
        """
        if not self.container_exists(source_container):
            raise RuntimeError(
                f"The source container does not exist: {source_container}"
            )
        if not self.container_exists(dest_container):
            raise RuntimeError(
                f"The destination container does not exist: {dest_container}"
            )

        container_sas = generate_container_sas(
            account_name=self.blob_service_client.account_name,
            container_name=source_container,
            account_key=self.blob_service_client.credential.account_key,
            permission=ContainerSasPermissions(read=True),
            expiry=datetime.now(timezone.utc) + timedelta(hours=1),
        )

        source_cont_client = self.blob_service_client.get_container_client(
            source_container
        )
        dest_cont_client = self.blob_service_client.get_container_client(dest_container)

        results: list[tuple[str, Exception | None]] = []

        def _copy_one(
            blob: str | tuple[str, str],
        ) -> tuple[str, Exception | None]:
            src_name, dst_name = self._resolve_blob_pair(blob)
            resolved_src = self._resolve_blob_name(src_name, source_prefix)
            resolved_dst = self._resolve_blob_name(dst_name, dest_prefix)
            try:
                src_client = source_cont_client.get_blob_client(blob=resolved_src)
                dst_client = dest_cont_client.get_blob_client(blob=resolved_dst)

                if not src_client.exists():
                    raise RuntimeError(
                        f"The source blob does not exist: "
                        f"{source_container}/{resolved_src}"
                    )

                if not override and dst_client.exists():
                    raise RuntimeError(
                        f"The destination blob already exists: "
                        f"{dest_container}/{resolved_dst}"
                    )

                source_url = f"{src_client.url}?{container_sas}"
                dst_client.start_copy_from_url(source_url, requires_sync=True)
                return (src_name, None)
            except Exception as e:
                return (src_name, e)

        with ThreadPoolExecutor(max_workers=max_concurrency) as pool:
            futures = {pool.submit(_copy_one, b): b for b in blobs}
            for future in as_completed(futures):
                results.append(future.result())

        return results

    def move_blob(
        self,
        source_container: str,
        source_blob: str,
        dest_container: str,
        dest_blob: str,
        override: bool = False,
        source_prefix: str | None = None,
        dest_prefix: str | None = None,
    ) -> None:
        """Move (copy then delete) a blob server-side within the same storage account.

        Args:
            source_container: Name of the source container.
            source_blob: Name of the source blob.
            dest_container: Name of the destination container.
            dest_blob: Name of the destination blob.
            override: If True, overwrite the destination blob if it exists.
            source_prefix: Optional prefix prepended to source_blob.
            dest_prefix: Optional prefix prepended to dest_blob.

        Raises:
            RuntimeError: If source doesn't exist, destination container
                doesn't exist, or destination blob exists and override is False.
        """
        results = self.move_blobs(
            source_container,
            dest_container,
            [(source_blob, dest_blob)],
            override=override,
            source_prefix=source_prefix,
            dest_prefix=dest_prefix,
            max_concurrency=1,
        )
        _, err = results[0]
        if err is not None:
            raise err

    def move_blobs(
        self,
        source_container: str,
        dest_container: str,
        blobs: Sequence[str | tuple[str, str]],
        override: bool = False,
        source_prefix: str | None = None,
        dest_prefix: str | None = None,
        max_concurrency: int = 8,
    ) -> list[tuple[str, Exception | None]]:
        """Move multiple blobs server-side within the same storage account.

        Copies blobs concurrently via :meth:`copy_blobs`, then batch-deletes
        the sources (up to 256 per batch, the Azure limit).

        Args:
            source_container: Name of the source container.
            dest_container: Name of the destination container.
            blobs: Blob names to move (relative to prefix).  Each element is
                either a ``str`` (same name for source and destination) or a
                ``(source_name, dest_name)`` tuple.
            override: If True, overwrite destination blobs if they exist.
            source_prefix: Optional prefix prepended to each source blob name.
            dest_prefix: Optional prefix prepended to each destination blob name.
            max_concurrency: Maximum number of parallel copy operations.

        Returns:
            A list of ``(source_blob_name, error)`` tuples.  ``error`` is
            ``None`` for blobs that were moved successfully.
        """
        results = self.copy_blobs(
            source_container,
            dest_container,
            blobs,
            override=override,
            source_prefix=source_prefix,
            dest_prefix=dest_prefix,
            max_concurrency=max_concurrency,
        )

        # Batch-delete source blobs that were copied successfully
        # (up to 256 per call, the Azure limit).
        source_cont_client = self.blob_service_client.get_container_client(
            source_container
        )
        to_delete = [
            self._resolve_blob_name(src_name, source_prefix)
            for src_name, err in results
            if err is None
        ]
        batch_size = 256
        for i in range(0, len(to_delete), batch_size):
            batch = to_delete[i : i + batch_size]
            source_cont_client.delete_blobs(*batch)

        return results

    def set_blob_metadata(
        self,
        container_name: str,
        blob_name: str,
        metadata: dict,
        prefix: str | None = None,
    ) -> None:
        """Set metadata for a blob."""
        blob_client = self._ensure_blob_client(container_name, blob_name, prefix)
        blob_client.set_blob_metadata(metadata)
