import logging

from azure.core.exceptions import (
    ClientAuthenticationError,
    ResourceNotFoundError,
    ServiceRequestError,
)
from azure.identity import ClientSecretCredential
from azure.keyvault.secrets import SecretClient

from pycore.resources.abc import Vault


class AzureKeyVault(Vault):
    """Key vault client based on managed identity of the app."""

    def __init__(
        self,
        url: str,
        tenant_id: str | None = None,
        client_id: str | None = None,
        client_secret: str | None = None,
        test_secret: str | None = None,
        conn_str: list[str] | str | None = None,
    ):
        self._test_secret = test_secret or "Database-GenericDBConnectionString"
        self.url = url
        self.client = None

        if isinstance(conn_str, str):
            conn_str = [conn_str]

        if conn_str:
            self.credential = [parse_key_vault_conn_str(c) for c in conn_str if c]
        else:
            self.credential = [
                ClientSecretCredential(tenant_id, client_id, client_secret)
            ]

    @property
    def is_active(self) -> bool:

        try:
            self.get_secret_value(self._test_secret)
            return True
        except ResourceNotFoundError:
            logging.info(f"Login to Azure key vault {self.uri} was successful.")
            return True
        except ClientAuthenticationError:
            logging.error(
                f"Login to Azure key vault {self.uri} failed due to wrong credentials."
            )
            return False
        except ServiceRequestError:
            logging.error(
                f"Login to Azure key vault {self.uri} because the URL could not be reached."
            )
            return False
        except Exception:
            return False

    @property
    def uri(self) -> str:
        return self.url

    def get_client(self, name: str) -> SecretClient:
        for idx, cred in enumerate(self.credential):
            try:
                client = SecretClient(vault_url=self.url, credential=cred)
                client.get_secret(name)
            except ClientAuthenticationError as e:
                if idx == len(self.credential) - 1:
                    raise e
            else:
                break
        return client

    def get_secret_value(self, name: str) -> str:
        if not self.client:
            self.client = self.get_client(name)

        try:
            logging.info(f"Retrieving secret '{name}' from key vault '{self.url}'.")
            return self.client.get_secret(name).value
        except Exception as e:
            logging.warning(f"Could not obtain secret ('{e}').")
            raise e


def parse_key_vault_conn_str(conn_str: str) -> ClientSecretCredential:
    creds = {}
    parts = conn_str.split(";")

    for part in parts:
        key_val = part.split("=")

        if len(key_val) == 2:
            creds[key_val[0]] = key_val[1]

    if not all(k in creds for k in ["TenantId", "AppId", "AppKey"]):
        raise ValueError("Invalid connection string: cannot be parsed.")

    return ClientSecretCredential(
        creds.get("TenantId"), creds.get("AppId"), creds.get("AppKey")
    )
