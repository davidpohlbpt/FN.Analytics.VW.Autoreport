try:
    # Using Azure resources requires additional libraries
    import azure
except ImportError as e:
    raise ImportError(
        "Please install optional azure dependencies with 'poetry install --extras azure'"
    ) from e

import logging

import pydantic
from pydantic_settings import BaseSettings

from pycore.resources.abc import BlobStorage, SecretValue, Vault
from pycore.resources.azure.keyvault import AzureKeyVault
from pycore.resources.azure.storage import AzureBlobStorage
from pycore.resources.odbc import OdbcDatabase, SqlServerDatabase

logging.getLogger("azure").setLevel(logging.ERROR)


class AzureSettings(BaseSettings):
    kv_url: str | None = pydantic.Field(None, validation_alias="keyvaulturl")
    """URL at which the key vault can be reached, e.g. 'https://devfactory-kv10.vault.azure.net/'
    """

    az_sqlserver_conn_str: str | None = None

    # New way of accessing through conn_str

    key_vault_conn_str: str | list[str] | None = None
    """Connenction string in the format that C# services use.
    """

    csp_key_vault_conn_str: str | None = None
    ea_key_vault_conn_str: str | None = None

    # Offline mode settings

    offline_mode: bool = False
    """Enable offline mode to use file-based vault and storage instead of Azure services.
    """

    offline_secrets_dir: str | None = None
    """Path to the directory containing the secrets JSON file (Kubernetes secret mount).
    The directory should contain a file (default: appsettings.secrets.json) with all secrets in JSON format.
    Example: /secrets/appsettings.secrets.json
    Defaults to './secrets' in the current working directory.
    """

    offline_secrets_filename: str = "appsettings.secrets.json"
    """Name of the JSON file containing secrets within the offline_secrets_dir.
    Defaults to 'appsettings.secrets.json'.
    """

    offline_storage_dir: str | None = None
    """Directory for file-based blob storage in offline mode.
    Defaults to './storage' in the current working directory.
    """

    # Access to key vaults in EA subscriptions (e.g. Max Aicher)

    ea_kv_client_id: str | None = "268e9fcd-6457-4ef0-9b74-55c16ebaa4bd"
    """Client ID of the principal allowed to connect to enterprise subscription key vaults, e.g., '5f1d09ac-97a2-466a-9d34-1560fb6267fd'
    """
    ea_kv_client_secret: str | None = None
    """Client secret of the principal allowed to connect to enterprise subscription key vaults, e.g., '0be5fcaa-1949-4a01-bd4a-9491ea7f5540'
    """
    ea_kv_tenant_id: str | None = "aa321b6e-c2f4-42f8-95b8-4d018e6d28ec"
    """Tenant ID of the enterprise subscriptions.
    Check with colleagues for value or generate new one [here](https://portal.azure.com/#view/Microsoft_AAD_RegisteredApps/ApplicationMenuBlade/~/Overview/appId/0be5fcaa-1949-4a01-bd4a-9491ea7f5540/isMSAApp~/false)
    """

    # Access to key vaults in old subscriptions

    kv_client_id: str = "0be5fcaa-1949-4a01-bd4a-9491ea7f5540"
    """Client ID of the principal allowed to connect to legacy / development subscription key vaults, e.g., '5f1d09ac-97a2-466a-9d34-1560fb6267fd'
    """
    kv_client_secret: str | None = None
    """Client secret of the principal allowed to connect to legacy / development subscription key vaults, e.g., '0be5fcaa-1949-4a01-bd4a-9491ea7f5540'
    """
    kv_tenant_id: str = "5f1d09ac-97a2-466a-9d34-1560fb6267fd"
    """Tenant ID of the legacy / development subscriptions.
    Check with colleagues for value or generate new one [here](https://portal.azure.com/#view/Microsoft_AAD_RegisteredApps/ApplicationMenuBlade/~/Overview/appId/0be5fcaa-1949-4a01-bd4a-9491ea7f5540/isMSAApp~/false)
    """

    @pydantic.field_validator("csp_key_vault_conn_str")
    def validate_key_vault_conn_str(cls, v, info):
        if not v:
            v = info.data.get("key_vault_conn_str")
        return v


def _load_offline_resources(
    azure_settings: AzureSettings, base=None
) -> tuple[OdbcDatabase, Vault, BlobStorage, OdbcDatabase, OdbcDatabase, OdbcDatabase]:
    """Load resources for offline mode using file-based vault and storage.

    This function is called when offline_mode is enabled in AzureSettings.
    It creates file-based alternatives to Azure Key Vault and Blob Storage.

    Secrets are stored as individual files in a directory (Kubernetes secret volume mount style).

    Args:
        azure_settings: Azure settings including offline mode configuration
        base: SQLAlchemy declarative base for database models

    Returns:
        Tuple of (database, vault, storage, rdp_db, md_db, batch_api_db)
    """
    import pathlib

    from pycore.config import settings
    from pycore.resources.file import FileStorage
    from pycore.resources.file_vault import FileVault

    # --------------------------------- File Vault ------------------------------- #

    secrets_dir = azure_settings.offline_secrets_dir or "./secrets"
    secrets_path = pathlib.Path(secrets_dir)
    if not secrets_path.is_absolute():
        secrets_path = pathlib.Path.cwd() / secrets_path

    vault = FileVault(
        secrets_dir=secrets_path,
        secrets_filename=azure_settings.offline_secrets_filename,
        shell=True,
    )
    logging.info(
        f"Using file vault from: {secrets_path / azure_settings.offline_secrets_filename}"
    )

    # --------------------------------- Database --------------------------------- #

    if azure_settings.az_sqlserver_conn_str:
        db_secret = SecretValue(azure_settings.az_sqlserver_conn_str)
    else:
        db_secret = vault.get_secret("Database-GenericDBConnectionString")

    database = SqlServerDatabase(
        conn_secret=db_secret, db_name=settings.app_db_name, base=base, shell=True
    )
    rdp_db = SqlServerDatabase(conn_secret=db_secret, db_name="ReportDB", shell=True)
    md_db = SqlServerDatabase(conn_secret=db_secret, db_name="MasterDataDB", shell=True)
    batch_api_db = SqlServerDatabase(
        conn_secret=db_secret, db_name="BatchApiDB", shell=True
    )

    # -------------------------------- File Storage ------------------------------ #

    storage_dir = azure_settings.offline_storage_dir or "./storage"
    storage_path = pathlib.Path(storage_dir)
    if not storage_path.is_absolute():
        storage_path = pathlib.Path.cwd() / storage_path
    storage = FileStorage(root_dir=storage_path, shell=True)

    return database, vault, storage, rdp_db, md_db, batch_api_db


def load_azure_resources(
    base=None,
) -> tuple[OdbcDatabase, Vault, BlobStorage, OdbcDatabase, OdbcDatabase, OdbcDatabase]:
    from pycore.config import settings  # delay import

    azure_settings = AzureSettings()

    # Check if offline mode is enabled
    if azure_settings.offline_mode:
        logging.info("Loading resources in OFFLINE mode (no Azure connectivity)")
        return _load_offline_resources(azure_settings, base)

    # --------------------------------- Key Vault -------------------------------- #

    vault = AzureKeyVault(
        url=azure_settings.kv_url,
        conn_str=[
            azure_settings.csp_key_vault_conn_str,
            azure_settings.ea_key_vault_conn_str,
        ],
        shell=True,
    )

    # --------------------------------- Database --------------------------------- #

    if azure_settings.az_sqlserver_conn_str:
        db_secret = SecretValue(azure_settings.az_sqlserver_conn_str)
    else:
        db_secret = vault.get_secret("Database-GenericDBConnectionString")
    database = SqlServerDatabase(
        conn_secret=db_secret, db_name=settings.app_db_name, base=base, shell=True
    )
    rdp_db = SqlServerDatabase(conn_secret=db_secret, db_name="ReportDB", shell=True)
    md_db = SqlServerDatabase(conn_secret=db_secret, db_name="MasterDataDB", shell=True)
    batch_api_db = SqlServerDatabase(
        conn_secret=db_secret, db_name="BatchApiDB", shell=True
    )
    # ---------------------------------- Storage --------------------------------- #

    storage_acc_secret = vault.get_secret("AppSettings-StorageAccountConnString")
    storage = AzureBlobStorage(conn_secret=storage_acc_secret, shell=True)

    return database, vault, storage, rdp_db, md_db, batch_api_db
