import logging

from pycore.resources.abc import HttpSession, Secret


class OpenAiSession(HttpSession):

    def __init__(
        self,
        base_url: str,
        api_key: Secret,
        deployment_name: str,
        retries: int = 3,
        pool_maxsize: int = 20,
    ):
        super().__init__(
            base_url,
            retries=retries,
            retry_at_status=(429, 503, 504),
            pool_maxsize=pool_maxsize,
        )
        self.deployment_name = deployment_name
        self.api_key = api_key
        self.session.headers.update({"Content-Type": "application/json"})

    def request(self, method, url, *args, **kwargs):
        if "api-key" not in self.session.headers:
            self.session.headers.update(
                {
                    "api-key": self.api_key.value,
                }
            )

        return super().request(method, url, *args, **kwargs)

    def get_completion(
        self,
        user_prompt: str,
        system_prompt: str = "",
        temperature: int | None = None,
        **kwargs,
    ) -> str:

        url = "/chat/completions"
        payload = {
            "model": self.deployment_name,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "n": 1,
            **kwargs,
        }

        if temperature is not None:
            payload["temperature"] = temperature

        response = self.post(url, json=payload)

        if response.status_code == 200:
            response_data = response.json()
            if len(response_data["choices"]) != 1:
                raise RuntimeError(
                    f"Expected exactly one choice, but got {len(response_data['choices'])}."
                )
            choice = response_data["choices"][0]
            finish_reason = choice.get("finish_reason")
            if finish_reason not in ("stop",):
                raise RuntimeError(f"Unexpected finish_reason: {finish_reason}")
            return choice["message"]["content"]

        else:
            logging.error(
                f"Completion failed with status code {response.status_code}: {response.text}."
            )
            logging.error(f"Failed user prompt: {user_prompt}")
            logging.error(f"Failed system prompt: {system_prompt}")

            raise RuntimeError(
                f"Request failed with status code {response.status_code}: {response.text}"
            )
