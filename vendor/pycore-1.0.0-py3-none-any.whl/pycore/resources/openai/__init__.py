import pydantic
from pydantic_settings import BaseSettings

from pycore.resources.abc import Vault
from pycore.resources.openai.openai import OpenAiSession


class OpenAiSettings(BaseSettings):

    base_url: str = "https://fnfoundry9.services.ai.azure.com/api/projects/dqnproject"
    deployment_name: str = "gpt-5.4"
    secret_name: str = "OpenAi-ApiKey"


def load_openai_session(vault: Vault) -> OpenAiSession:

    openai_settings = OpenAiSettings()

    api_key = vault.get_secret(openai_settings.secret_name)

    openai = OpenAiSession(
        base_url=openai_settings.base_url,
        api_key=api_key,
        deployment_name=openai_settings.deployment_name,
    )

    return openai
