import abc
import logging
import os

import oauthlib
import pydantic
import requests
from oauthlib.oauth2 import TokenExpiredError
from requests_oauthlib import OAuth2Session

from pycore.resources.abc import HttpSession, Secret
from pycore.utils.cache import cached_property
from pycore.utils.network import requests_retry_session

TOKEN_URL = "{base_url}/identity/connect/token"


def bearer_auth_header(access_token: str | None) -> dict[str, str]:
    """Builds an `Authorization: Bearer <token>` header dict, or `{}` if no token is given."""
    return {"Authorization": f"Bearer {access_token}"} if access_token else {}


class OAuthClientConfig(pydantic.BaseModel):
    client_id: str
    client_secret: str
    grant_type: str
    scope: str


class NoAuthHttpSession(HttpSession):
    """Base class for HTTP sessions that do not require authentication."""


class AuthHttpSession(HttpSession, abc.ABC):
    """Base class for HTTP sessions that require authentication."""

    def __init__(self, base_url: str, http_secret: Secret, token_url: str | None = None):
        super().__init__(base_url)
        self.http_secret = http_secret
        self._token_base_url = base_url  # do not go through admin gateway
        # Allows the identity server to be reached at a different address than base_url
        # (e.g. directly, bypassing a gateway that doesn't route the token endpoint).
        self._token_url = token_url or TOKEN_URL.format(base_url=self._token_base_url)
        self.base_url = base_url
        self.identity_cfg = None

    @abc.abstractmethod
    def _init_auth_session(self, client_id: str) -> OAuth2Session:
        """Initializes an OAuth2Session object for the given client ID."""

    @abc.abstractmethod
    def _get_token_creds(self) -> dict:
        """Returns the credentials required to retrieve an access token for the given client ID."""

    @property
    def is_active(self):
        try:
            self.session
            return True
        except RuntimeError:
            return False

    @cached_property
    def session(self):
        """Returns an OAuth2Session object which allows to connect to the underlying server."""
        # Identity Server configuration
        try:
            self.identity_cfg = OAuthClientConfig.model_validate_json(
                self.http_secret.value
            )
        except pydantic.ValidationError as e:
            raise RuntimeError(
                f"Failed to parse OAuth client configuration from secret '{self.http_secret.name}' ('{e}')."
            )
        s = self._init_auth_session(client_id=self.identity_cfg.client_id)
        self.update_token(session=s)
        if self.retries > 0:
            return requests_retry_session(session=s)
        else:
            return s

    def update_token(self, session):
        """Updates the access token of the given OAuth2Session object."""
        token_url = self._token_url
        token_creds = self._get_token_creds()
        token_creds["token_url"] = token_url
        try:
            session.fetch_token(**token_creds)
            logging.warning(f"Retrieved new admin access token via {token_url}.")
        except Exception as e:
            raise RuntimeError(
                f"Failed to update admin access token via {token_url} ('{e}')."
            )

    @staticmethod
    def _withhold_own_token_if_authorization_provided(kwargs: dict) -> dict:
        """OAuth2Session.request() attaches its own stored token via `add_token()`,
        overwriting an explicit `Authorization` header (e.g. a forwarded user bearer
        token) unless told to withhold it."""
        if "Authorization" in (kwargs.get("headers") or {}):
            kwargs["withhold_token"] = True
        return kwargs

    def request(self, method, url, *args, **kwargs):
        """Sends a request to the underlying server."""
        url = self.base_url + url
        kwargs = self._withhold_own_token_if_authorization_provided(kwargs)
        try:
            return self.session.request(method, url, *args, **kwargs)
        except TokenExpiredError:
            expires_info = ""
            if hasattr(self.session, "token") and isinstance(self.session.token, dict):
                expires_at = self.session.token.get("expires_at")
                if expires_at:
                    expires_info = f" at {expires_at}"
            else:
                expires_info = " (could not determine expiry time)"

            logging.error(f"Admin access token expired{expires_info}.")
            self.update_token(self.session)
            return self.session.request(method, url, *args, **kwargs)

    def get_absolute(self, url: str, *args, **kwargs) -> requests.Response:
        """See `HttpSession.get_absolute`. Also withholds this session's own token when
        the caller already supplied an explicit `Authorization` header."""
        kwargs = self._withhold_own_token_if_authorization_provided(kwargs)
        return self.session.request("get", url, *args, **kwargs)

    def post_absolute(self, url: str, *args, **kwargs) -> requests.Response:
        """See `HttpSession.post_absolute`. Also withholds this session's own token when
        the caller already supplied an explicit `Authorization` header."""
        kwargs = self._withhold_own_token_if_authorization_provided(kwargs)
        return self.session.request("post", url, *args, **kwargs)


class UserHttpSession(AuthHttpSession):
    """HTTP session for user authentication."""

    def _init_auth_session(self, client_id) -> OAuth2Session:
        # Username + password authentication flow
        client = oauthlib.oauth2.LegacyApplicationClient(client_id=client_id)
        return OAuth2Session(client=client)

    def _get_token_creds(self) -> dict:
        return {
            "client_secret": self.identity_cfg.client_secret,
            "scope": self.identity_cfg.scope,
            "username": os.environ.get("username"),
            "password": os.environ.get("password"),
        }


class AdminHttpSession(AuthHttpSession):
    """HTTP session for admin authentication, required for the admin API gateway."""

    def _init_auth_session(self, client_id) -> OAuth2Session:
        client = oauthlib.oauth2.BackendApplicationClient(client_id=client_id)
        return OAuth2Session(client=client)

    def _get_token_creds(self) -> dict:
        return {
            "client_secret": self.identity_cfg.client_secret,
            "scope": self.identity_cfg.scope,
        }
