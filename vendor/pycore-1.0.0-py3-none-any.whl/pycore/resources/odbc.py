import binascii
import logging
import os

import pandas as pd
import pyodbc
import sqlalchemy as sa
from sqlalchemy.engine.base import Engine
from sqlalchemy.ext.compiler import compiles
from sqlalchemy.orm import DeclarativeMeta, declarative_base, sessionmaker
from sqlalchemy.schema import CreateColumn
from sqlalchemy.sql import Insert, text

from pycore.resources.abc import Resource, Secret, SecretValue
from pycore.utils.cache import cached_property
from pycore.utils.database import (
    ColumnDoesNotExistError,
    TableDoesNotExistError,
    get_engine_from_conn_str,
    get_session_scope_func,
    get_sqlalchemy_conn_str,
)

CONVENTION = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}

meta = sa.MetaData(naming_convention=CONVENTION)
DeclarativeBase = declarative_base(metadata=meta)


class OdbcDatabase(Resource):
    """Interface to a relational, ODBC database (e.g. SQL Server).

    Offers standard methods to execute SQL queries or interact with table metadata.
    """

    def __init__(self, conn_secret: Secret, db_name: str, base=None):
        if not base:
            self.meta = sa.MetaData(naming_convention=CONVENTION)
            self.base = declarative_base(metadata=self.meta)
        else:
            self.meta = base.metadata
            self.base = base

        self.db_name = db_name

        # Delay access to actual secret until database is needed
        self.conn_secret = conn_secret

        # Avoid repetitively reflecting the same objects
        self._tables = {}

    @cached_property
    def engine(self) -> Engine:
        """Returns an SQLAlchemy engine object which allows to connect to the underlying database.

        For details, refer to the [SQLAlchemy documentation](https://docs.sqlalchemy.org/en/20/core/engines.html)

        Returns:
            Engine: engine object.
        """
        conn_str = self.conn_secret.value
        odbc_conn_str = get_sqlalchemy_conn_str(
            conn_str=conn_str, database=self.db_name
        )
        return get_engine_from_conn_str(odbc_conn_str)

    @cached_property
    def Sessionmaker(self) -> sessionmaker:
        """Returns an SQLAlchemy sessionmaker object which allows to create sessions."""
        return sessionmaker(bind=self.engine)

    @property
    def session_scope(self):
        """Returns a context manager for an SQLAlchemy session."""
        return get_session_scope_func(self.Sessionmaker)

    @property
    def is_active(self) -> bool:
        """Indicates if a successful connection to the database could be established.

        For this purpose, a dummy raw SQL query ("SELECT 1") is sent to the database.

        Returns:
            bool: True if connection was successful, False otherwise.
        """
        try:
            self.execute_raw_query(query="SELECT 1")
            return True
        except Exception:
            return False

    def get_table(
        self, table: str | sa.Table | sa.orm.DeclarativeMeta, schema: str | None = None
    ) -> sa.Table:
        """Returns a SQLAlchemy table object if the given table exists in the database.

        The retrieved tables are cached for faster retrieval.

        Args:
            table (Union[str, sa.Table, sa.orm.DeclarativeMeta]): Table name
            schema (str, optional): Schema name. Only considered if the table name is passed as string. Defaults to None.

        Raises:
            TableDoesNotExistError: If the table does not exist in the database.

        Returns:
            sa.Table: SQLAlchemy table object.
        """
        if isinstance(table, sa.Table):
            # Input is already a table object
            return table

        if isinstance(table, sa.orm.DeclarativeMeta):
            # Get table from OR mapper
            return table.__table__

        table_id = (schema, table)
        if table_id in self._tables:
            # Get table from cache
            if len(self._tables[table_id].c) > 0:
                return self._tables[table_id]
            logging.error("Cached table found with no columns")
            self.meta = sa.MetaData(naming_convention=CONVENTION)

        try:
            # Reflect table from database
            table = sa.Table(table, self.meta, schema=schema, autoload_with=self.engine)
            self._tables[table_id] = table
            return table
        except sa.exc.NoSuchTableError as exc:
            raise TableDoesNotExistError(table, schema) from exc
        except Exception:
            # Reflection also fails for reasons unrelated to a missing table (e.g. connection
            # errors); those must not be reported as "table does not exist".
            logging.exception(
                "Failed to reflect table.", extra={"table": table, "schema": schema}
            )
            raise

    def has_table(
        self, table: str | sa.Table | sa.orm.DeclarativeMeta, schema: str | None = None
    ):
        try:
            self.get_table(table=table, schema=schema)
            return True
        except TableDoesNotExistError:
            return False

    @staticmethod
    def has_col(table: sa.Table, col: str) -> bool:
        """Checks if the given column exists in the given table without logging a warning.


        Args:
            table (sa.Table): Table object.
            col (str): Column name.

        Returns:
            bool: True if the column exists, False otherwise.
        """
        for c in table.c:
            if c.key.lower() == col.lower():
                return True
        return False

    @staticmethod
    def get_col(table: sa.Table, col: str) -> sa.Column | None:
        """Returns a SQLAlchemy column object if the given column exists in the table and raises an Error and logs a Warning otherwise.

        Args:
            table (sa.Table): Table object.
            col (str): Column name.

        Raises:
            ColumnDoesNotExistError: If the column does not exist in the table.

        Returns:
            Union[sa.Column, None]: Column object or None if the column does not exist.
        """
        for c in table.c:
            if c.key.lower() == col.lower():
                return c
        all_columns = ", ".join([c.key for c in table.c])
        logging.warning(
            f"Column {col} does not exist in table {table.name}. Available columns: {all_columns}."
        )
        raise ColumnDoesNotExistError(col, table)

    @staticmethod
    def get_json_val(col: sa.Column, field: str, label: str) -> sa.Column:
        """Returns the JSON values of a SQLAlchemy column object if the given field exists in the column."""

        return col[field].label(label)

    @staticmethod
    def update_json_column(
        col: sa.Column, keys: list[str]
    ) -> sa.sql.elements.ClauseElement:
        """Returns a SQL expression to update a JSON column with the given keys.

        Args:
            col (sa.Column): Column object.
            keys (list[str]): List of keys to be updated.

        Returns:
            Tuple[sa.text, dict]: SQL expression and parameter names.
        """
        raise NotImplementedError("Method not implemented for this database type.")

    def execute_raw_query(self, query: str) -> pd.DataFrame:
        """Reads the results of a SQL query string as data frame.

        Args:
            query (str): Query to be executed.

        Returns:
            pd.DataFrame: Resulting data frame.
        """
        with self.engine.connect() as con:
            return pd.read_sql_query(
                sql=sa.text(query) if isinstance(query, str) else query, con=con
            )

    def drop_all_tables(self):
        """Drops all database tables defined based on this database."""
        self.base.metadata.drop_all(bind=self.engine)

    def conditional_delete_from_table(
        self, table: sa.Table, condition: sa.sql.expression.ClauseElement
    ):
        """Deletes all rows from the given table that match the given condition.

        Args:
            table (sa.Table): Table object.
        """
        with self.engine.connect() as con:
            con.execute(sa.sql.expression.delete(table).where(condition))
            con.commit()

    def create_all_tables(self):
        """Creates all database tables defined based on this database.

        Tables that already exist will not be re-created.
        """
        logging.info("Creating all schemas and tables in the database.")
        schemas = set()
        for table in self.base.metadata.tables.values():
            if table.schema:
                schemas.add(table.schema)
        for schema in schemas:
            self.create_schema(schema, fail_if_exists=False)
        self.base.metadata.create_all(bind=self.engine)

    def create_seed_data(self, data: list[list[object]]):
        """Creates seed data in the database.

        Args:
            data (list[list[object]]): List of lists of objects to be inserted into the database.
        """
        with self.session_scope() as db:
            # Clear existing data
            logging.warning("Deleting data in all tables.")
            for table in reversed(self.meta.sorted_tables):
                db.execute(table.delete())

            # Insert new data
            for objects in data:
                types = {type(o) for o in objects}
                assert len(types) == 1, "All objects in a list must have the same type."
                type_ = types.pop()
                logging.warning(
                    f"Creating {len(objects)} objects in table '{type_.__table__.name}'"
                )
                db.bulk_save_objects(objects)

    def get_schema_names(self) -> list[str]:
        """Returns the names of all schemas in the database.

        Returns:
            list[str]: List of schema names.

        """
        return sa.inspect(self.engine).get_schema_names()

    def has_schema(self, schema: str) -> bool:
        """Checks if the database has a schema with the given name.

        Args:
            schema (str): Schema name.

        Returns:
            bool: True if the schema exists, False otherwise.

        """
        return schema in self.get_schema_names()

    def create_schema(self, schema: str, fail_if_exists: bool = True):
        """Creates the given schema if it does not exist yet.

        Args:
            schema (str): Schema name.
            fail_if_exists (bool, optional): If True, an exception is raised if the schema already exists. Defaults to True.

        """
        if fail_if_exists and self.has_schema(schema):
            raise ValueError(
                f"The schema '{schema}' already exists in the database {self.uri}."
            )
        elif self.has_schema(schema):
            return
        stmt = sa.schema.CreateSchema(schema)
        with self.engine.connect() as con:
            con.execute(stmt)
            con.commit()

    def drop_schema(self, schema: str, fail_if_not_exists: bool = True):
        """Drops the given schema if it exists.

        Args:
            schema (str): Schema name.
            fail_if_not_exists (bool, optional): If True, an exception is raised if the schema does not exist. Defaults to True.

        """
        if fail_if_not_exists and not self.has_schema(schema):
            raise ValueError(
                f"The schema '{schema}' doesn't exist in the database {self.uri}."
            )
        elif not self.has_schema(schema):
            return
        stmt = sa.schema.DropSchema(schema)
        with self.engine.connect() as con:
            con.execute(stmt)
            con.commit()

    def execute_with_identity_insert(
        self,
        insert_stmt: Insert,
        model: DeclarativeMeta | None = None,
        table: str | None = None,
        schema: str | None = None,
    ):
        """Executes the given SQL statement with identity insert enabled for the given model.

        Args:
            insert_stmt (Insert): Insert statement
            model (DeclarativeMeta, optional): Model object. Defaults to None.
            table (str, optional): Table name. Defaults to None.
            schema (str, optional): Schema name. Defaults to None.
        """

        _ = model  # only needed with SQL Server
        _ = table  # only needed with SQL Server
        _ = schema  # only needed with SQL Server
        with self.engine.connect() as con:
            con.execute(insert_stmt)
            con.commit()

    def truncate_table(self, table: str, schema: str | None = None):
        """Truncates the given table.

        Args:
            table (str): Table name.
            schema (str, optional): Schema name. Defaults to None.
        """

        sa_table = self.get_table(table=table, schema=schema)

        del_stmt = sa.delete(sa_table)

        with self.session_scope() as db:
            db.execute(del_stmt)


class SqlServerDatabase(OdbcDatabase):
    """Database class for Microsoft SQL Server."""

    @cached_property
    def engine(self):
        """Returns the SQLAlchemy engine object for the database."""
        # Connection to SQL Server is not possible without database name
        if not self.db_name:
            raise ValueError(
                "Please provide a default database name via the setting 'APP_DB_NAME' in your '.env.global' file."
            )
        return super().engine

    @property
    def uri(self) -> str:
        """Returns the unique ODBC connection string of the database.

        The connection string includes at least the server and database name.
        If necessary, the password is replaced by "*****".

        Returns:
            str: ODBC connection string.
        """
        e = self.engine  # make sure engine can be created before connection attempt
        cnxn = None
        server = "server_unreachable"

        try:
            cnxn = e.raw_connection()
            server = str(cnxn.getinfo(pyodbc.SQL_SERVER_NAME)) + "." + self.db_name
        except Exception:
            server = "server_unknown"
        finally:
            if cnxn:
                cnxn.close()
        return server

    @staticmethod
    def get_json_val(col: sa.Column, field: str, label: str) -> sa.Column:
        """Returns the JSON values of a SQLAlchemy column object if the given field exists in the column."""

        return sa.func.JSON_VALUE(col, f"$.{field}").label(label)

    @staticmethod
    def update_json_column(
        col: sa.Column, keys: list[str]
    ) -> tuple[sa.sql.elements.ClauseElement, dict]:
        """Returns a SQL expression to update a JSON column with the given keys.

        Args:
            col (sa.Column): Column object.
            keys (list[str]): List of keys to be updated.

        Returns:
            Tuple[sa.text, dict]: SQL expression and parameter names.
        """

        if not isinstance(col, sa.Column):
            raise ValueError("Input must be a SQLAlchemy column object.")

        if not isinstance(col.type, sa.JSON):
            raise ValueError(f"Column '{col.name}' is not of type JSON.")

        expr = f"[{col.name}]"

        for key in keys:
            expr = f"JSON_MODIFY({expr}, '$.{key}', :{key})"

        return sa.text(expr)

    def execute_with_identity_insert(
        self,
        insert_stmt: Insert,
        model: DeclarativeMeta | None = None,
        table: str | None = None,
        schema: str | None = None,
    ):
        """Executes the given SQL statement with identity insert enabled for the given model.

        Args:
            insert_stmt (Insert): Insert statement
            model (DeclarativeMeta, optional): Model object. Defaults to None.
            table (str, optional): Table name. Defaults to None.
            schema (str, optional): Schema name. Defaults to None.
        """

        if model and not table:

            table_name = model.__table__.name

            if model.__table__.schema:
                table_name = f"{model.__table__.schema}.{table_name}"

        if table and not schema:
            table_name = table

        if table and schema:
            table_name = f"{schema}.{table}"

        if not table_name and not model:
            raise ValueError("Please provide a table name or model.")

        try:
            with self.engine.connect() as con:
                con.execute(text(f"SET IDENTITY_INSERT {table_name} ON"))
                con.execute(insert_stmt)
                con.commit()
        except Exception as e:
            logging.error(e)
            raise e
        finally:
            with self.engine.connect() as con:
                con.execute(text(f"SET IDENTITY_INSERT {table_name} OFF"))
                con.commit()

    def truncate_table(self, table: str, schema: str | None = None):
        """Truncates the given table.

        Args:
            table (str): Table name.
            schema (str, optional): Schema name. Defaults to None.
        """

        sa_table = self.get_table(table=table, schema=schema)

        if sa_table.schema is None:
            truncate_stmt = sa.text(f"TRUNCATE TABLE {sa_table.name}")
        else:
            truncate_stmt = sa.text(f"TRUNCATE TABLE {sa_table.schema}.{sa_table.name}")

        with self.session_scope() as db:
            db.execute(truncate_stmt)


@compiles(CreateColumn, "sqlite")
def _plain_column_for_computed_columns_on_sqlite(element, compiler, **kw):
    """Computed() columns are declared with vendor-specific DDL text (e.g. MSSQL T-SQL) that
    SQLite can't run. SqliteDatabase is used as an offline/unit-test stand-in for the same
    shared `DeclarativeBase` metadata production models register onto, so any such column must
    degrade to a plain column here rather than fail create_all().
    """
    column = element.element
    if column.computed is not None:
        element = CreateColumn(sa.Column(column.name, column.type, nullable=column.nullable))
    return compiler.visit_create_column(element, **kw)


class SqliteDatabase(OdbcDatabase):
    """Database class for SQLite."""

    def __init__(self, schemas: list | None = None, base=None):
        super(SqliteDatabase, self).__init__(
            conn_secret=SecretValue(value="sqlite:///:memory:"), db_name=None, base=base
        )
        for schema in schemas or []:
            self.create_schema(schema)
        self.id = binascii.b2a_hex(os.urandom(6)).decode()

    def get_schema_names(self) -> list[str]:
        """Returns the names of all schemas in the database.

        Returns:
            list[str]: List of schema names.

        """
        with self.engine.connect() as con:
            result = con.execute(
                sa.text("SELECT name FROM pragma_database_list;")
            ).fetchall()
        return [r[0] for r in result]

    def create_schema(self, schema: str, fail_if_exists: bool = True):
        """Creates the given schema if it does not exist yet.

        Args:
            schema (str): Schema name.
            fail_if_exists (bool, optional): If True, an exception is raised if the schema already exists. Defaults to True.

        """
        if fail_if_exists and self.has_schema(schema):
            raise ValueError(
                f"The schema '{schema}' already exists in the database {self.uri}."
            )
        elif self.has_schema(schema):
            return
        with self.engine.connect() as con:
            con.execute(sa.text(f"ATTACH DATABASE ':memory:' AS {schema}"))
            con.commit()

    def drop_schema(self, schema: str, fail_if_not_exists: bool = True):
        """Drops the given schema if it exists.

        Args:
            schema (str): Schema name.
            fail_if_not_exists (bool, optional): If True, an exception is raised if the schema does not exist. Defaults to True.

        """
        if fail_if_not_exists and not self.has_schema(schema):
            raise ValueError(
                f"The schema '{schema}' doesn't exist in the database {self.uri}."
            )
        elif not self.has_schema(schema):
            return
        with self.engine.connect() as con:
            con.execute(sa.text(f"DETACH DATABASE {schema}"))
            con.commit()

    @property
    def uri(self) -> str:
        """Returns the unique ODBC connection string of the database."""
        return str(self.engine.url) + "/" + self.id

    @staticmethod
    def update_json_column(
        col: sa.Column, keys: list[str]
    ) -> sa.sql.elements.ClauseElement:
        """Returns a SQL expression to update a JSON column with the given keys.

        Args:
            col (sa.Column): Column object.
            keys (list[str]): List of keys to be updated.

        Returns:
            Tuple[sa.text, dict]: SQL expression and parameter names.
        """
        expr = col
        for k in keys:
            expr = sa.func.json_set(expr, f"$.{k}", sa.bindparam(k))

        return expr


def get_table_col(table: sa.Table, col: str) -> sa.Column:
    """Returns a SQLAlchemy column object if the given column exists in the table."""
    for c in table.c:
        if c.key.lower() == col.lower():
            return c.key
    return None
