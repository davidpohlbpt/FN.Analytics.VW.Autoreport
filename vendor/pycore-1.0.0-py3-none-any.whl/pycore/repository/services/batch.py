import logging

import requests
import sqlalchemy as sa

from pycore.enum import ServiceType
from pycore.repository.services.base import Service
from pycore.resources.abc import HttpSession
from pycore.resources.odbc import OdbcDatabase, SqlServerDatabase
from pycore.schemas import BatchTask, BatchTaskList
from pycore.utils.maintenance import deprecated_method

TASK_LIST_URL = "{prefix}/api/v1/Task"
SERVICE_TABLE = "T_CONTROL_Service"


class BatchRepository(Service):
    def __init__(
        self,
        database: OdbcDatabase,
        http_session: HttpSession,
        prefix: str | None = None,
        env: str | None = None,
    ):
        self.database = database
        super().__init__(http_session, prefix, env, service_type=ServiceType.BATCH)

    @property
    @deprecated_method
    def declarative_base(self):
        return self.database.base

    def create_task(self, task: BatchTask) -> bool:
        """Creates a task in the Batch service.

        Args:
            task (BatchTask): Task to be created.

        Returns:
            bool: Indicates whether the task could be created successfully.
        """
        return self.create_tasks(tasks=BatchTaskList(tasks=[task]))

    def create_tasks(self, tasks: BatchTaskList) -> bool:
        """Creates a list of tasks in the Batch service.

        Args:
            tasks (BatchTaskList): List of tasks to be created.

        Returns:
            bool: Indicates whether the tasks could be created successfully.
        """
        scen_id = tasks.tasks[0].scenario_id if tasks.tasks else None
        load_id = tasks.tasks[0].load_id if tasks.tasks else None
        task_type_id = tasks.tasks[0].task_type_id if tasks.tasks else None
        extra = {"scen_id": scen_id, "load_id": load_id, "task_type_id": task_type_id}

        url = TASK_LIST_URL.format(prefix=self.prefix)
        response = self.session.post(
            url, json=tasks.model_dump(mode="json", by_alias=True)
        )

        created_successfully = response.status_code == requests.codes.ok
        if created_successfully:
            logging.info(f"Successfully created {len(tasks.tasks)} tasks.", extra=extra)
        else:
            logging.error(f"Failed to create tasks: {response.text}", extra=extra)

        return created_successfully

    def upgrade_image(
        self,
        image_name: str,
        image_tag: str,
    ):
        """Updates the image tag of the service with the given image name.

        Args:
            batch_api_db (SqlServerDatabase): Database connection.
            image_name (str): Name of the image to be updated.
            image_tag (str): New tag of the image.

        Returns:
            None
        """

        service_table = sa.Table(
            SERVICE_TABLE,
            sa.MetaData(),
            autoload_with=self.database.engine,
        )

        with self.database.session_scope() as conn:
            stmt = (
                service_table.update()
                .where(service_table.c.ImageName == image_name)
                .values(ImageTag=image_tag)
            )
            conn.execute(stmt)
