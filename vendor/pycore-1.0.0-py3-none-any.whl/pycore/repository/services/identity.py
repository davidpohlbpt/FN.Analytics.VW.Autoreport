import logging

import requests
from typing import Optional
from urllib.parse import quote

from pycore.enum import ServiceType
from pycore.repository.services.base import Service
from pycore.resources.abc import HttpSession
from pycore.resources.http import bearer_auth_header
from pycore.workbench.contracts import DimensionWithValueModel, FnUserModel, MenuItemModel

DIMENSION_VALUE_URL = (
    "{prefix}/api/v1/DimensionValues/{dimension_value_id}?menuItemId={menu_item_id}"
)
ALL_USERS_URL = "{prefix}/api/v1/users/getAll"
USER_BY_ID_URL = "{prefix}/api/v1/users/getUserById/{user_id}"
USER_BY_EMAIL_URL = "{prefix}/api/v1/users/getUser/{email}"
MENU_ITEM_BY_ID_URL = "{prefix}/api/v1/menu/getMenuItemById/{menu_item_id}"


class IdentityRepository(Service):
    def __init__(
        self,
        http_session: HttpSession,
        prefix: str | None = None,
        env: str | None = None,
    ):
        if prefix is None and env is None:
            prefix = ""
        super().__init__(http_session, prefix, env, service_type=ServiceType.IDENTITY)

    def get_dimension_value_by_id(
        self,
        dimension_value_id: int,
        menu_item_id: int,
        access_token: str = None,
    ) -> Optional[DimensionWithValueModel]:
        """Retrieves one dimension value by id.

        Args:
            dimension_value_id (int): Dimension value id.
            menu_item_id (int): Menu item id.
            access_token (str, optional): Access token passed as bearer token. Defaults to None.

        Returns:
            Optional[DimensionWithValueModel]: Retrieved model or None if not found.
        """
        url = DIMENSION_VALUE_URL.format(
            prefix=self.prefix,
            dimension_value_id=dimension_value_id,
            menu_item_id=menu_item_id,
        )
        headers = bearer_auth_header(access_token)
        response = self.session.get(url, headers=headers)

        if response.status_code == requests.codes.ok:
            # Identity wraps responses as {"result": ...}, same envelope as our own endpoints.
            data = response.json()
            result = data.get("result") if isinstance(data, dict) else None
            return DimensionWithValueModel(**result) if result else None
        else:
            logging.warning(
                "Dimension value lookup call failed. "
                f"url={url} status_code={response.status_code}",
                extra={"url": url, "status_code": response.status_code},
            )
            return None

    def get_all_users(self, access_token: str = None) -> list[FnUserModel]:
        """Retrieves every user visible to the caller.

        Mirrors the .NET `IIdentityService.GetAllUsers()`, which incident
        history and comments use to resolve stored user ids into display
        values. The call is delegated with the caller's token, so the result
        is caller-scoped and must not be cached across requests.

        Args:
            access_token (str, optional): Access token passed as bearer token. Defaults to None.

        Returns:
            list[FnUserModel]: Retrieved users, or an empty list when the lookup fails.
        """
        url = ALL_USERS_URL.format(prefix=self.prefix)
        headers = bearer_auth_header(access_token)
        response = self.session.get(url, headers=headers)

        if response.status_code != requests.codes.ok:
            logging.warning(
                "User lookup call failed.",
                extra={"url": url, "status_code": response.status_code},
            )
            return []

        data = response.json()
        result = data.get("result") if isinstance(data, dict) else None
        if not isinstance(result, list):
            return []
        return [FnUserModel(**item) for item in result if isinstance(item, dict)]

    def get_user_by_id(self, user_id: str, access_token: str = None) -> Optional[FnUserModel]:
        """Retrieves one user by their identity id.

        Args:
            user_id (str): Identity user id.
            access_token (str, optional): Access token passed as bearer token. Defaults to None.

        Returns:
            Optional[FnUserModel]: Retrieved user or None if not found.
        """
        url = USER_BY_ID_URL.format(
            prefix=self.prefix, user_id=quote(user_id, safe="")
        )
        return self._get_single(url, FnUserModel, access_token, "User lookup by id failed.")

    def get_user_by_email(self, email: str, access_token: str = None) -> Optional[FnUserModel]:
        """Retrieves one user by their email address.

        Args:
            email (str): User email.
            access_token (str, optional): Access token passed as bearer token. Defaults to None.

        Returns:
            Optional[FnUserModel]: Retrieved user or None if not found.
        """
        url = USER_BY_EMAIL_URL.format(
            prefix=self.prefix, email=quote(email, safe="")
        )
        return self._get_single(url, FnUserModel, access_token, "User lookup by email failed.")

    def get_menu_item_by_id(
        self, menu_item_id: int, access_token: str = None
    ) -> Optional[MenuItemModel]:
        """Retrieves one menu item by id.

        Args:
            menu_item_id (int): Menu item id.
            access_token (str, optional): Access token passed as bearer token. Defaults to None.

        Returns:
            Optional[MenuItemModel]: Retrieved menu item or None if not found.
        """
        url = MENU_ITEM_BY_ID_URL.format(
            prefix=self.prefix, menu_item_id=menu_item_id
        )
        return self._get_single(url, MenuItemModel, access_token, "Menu item lookup failed.")

    def _get_single(self, url: str, model, access_token: str | None, failure_message: str):
        headers = bearer_auth_header(access_token)
        response = self.session.get(url, headers=headers)

        if response.status_code != requests.codes.ok:
            logging.warning(
                failure_message, extra={"url": url, "status_code": response.status_code}
            )
            return None

        data = response.json()
        result = data.get("result") if isinstance(data, dict) else None
        return model(**result) if isinstance(result, dict) else None
