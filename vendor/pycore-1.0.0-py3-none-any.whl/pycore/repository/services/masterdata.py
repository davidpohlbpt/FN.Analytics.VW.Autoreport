from pycore.repository.data import DataRepository
from pycore.resources.odbc import OdbcDatabase


class MasterDataRepository(DataRepository):
    def __init__(self, database: OdbcDatabase):
        self.database = database
