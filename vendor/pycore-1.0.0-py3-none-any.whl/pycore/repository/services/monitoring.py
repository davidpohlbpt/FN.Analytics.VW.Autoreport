import logging

import requests

from pycore.enum import ServiceType
from pycore.repository.services.base import Service
from pycore.resources.abc import HttpSession
from pycore.schemas import LogMessage

LOG_URL = "{prefix}/api/log"
SERVICE_LOGS_URL = "{prefix}/api/log/service"


class MonitoringRepository(Service):
    def __init__(
        self,
        http_session: HttpSession,
        prefix: str | None = None,
        env: str | None = None,
    ):
        super().__init__(http_session, prefix, env, service_type=ServiceType.MONITORING)

    def log_message(self, message: LogMessage) -> bool:
        """Sends a log message to the Monitoring service.

        Python log levels are mapped to Monitoring service levels.
        Any Python log level below 'INFO` is set to None and any level above `ERROR` to `Error.`

        For automatic sending via Python's `logging` module,
        the `pycore.logs.http_handler.HttpServiceHandler` is added to the root logger.

        Args:
            message (LogMessage): Message to be send.

        Returns:
            bool: True if successful, False else.
        """
        url = LOG_URL.format(prefix=self.prefix)
        data = message.model_dump(by_alias=True)
        # Convert from Python logging scale (integer) to Monitoring Service
        data["logLevel"] = get_log_level(message.log_level)
        data["valuesArray"] = message.values_array.model_dump_json(exclude_none=True)
        try:
            response = self.session.post(url, json=data)
            return response.status_code == requests.codes.ok
        except Exception as e:
            logging.error(f"Failed to log to MonitoringService ('{e}').")
            return False

    def retrieve_service_logs(
        self, service_name: str, **kwargs
    ) -> list[LogMessage] | None:
        """Retrieves logs for a specific service.
        Filters logs with the given parameters.

        Args:
            service_name (str): Name of the service to retrieve logs for.
            **kwargs: Filters for the logs. (e.g. entity_id=1)
        Returns:
            List[LogMessage]: List of logs.
        """
        url = SERVICE_LOGS_URL.format(prefix=self.prefix)
        data = {"service": service_name, "parameters": kwargs}
        try:
            response = self.session.post(url, json=data)
            return [LogMessage.model_validate(log) for log in response.json()]
        except Exception as e:
            logging.error(f"Failed to retrieve logs from MonitoringService ('{e}').")
            return None


def get_log_level(level: int):
    """Translates Python logging levels to MonitoringService logging levels.

    Args:
        level (int): Python logging level.

    Returns:
        str: MonitoringService logging level.
    """
    if level < logging.INFO:
        return None
    elif level == logging.INFO:
        return "Information"
    elif level <= logging.WARNING:
        return "Warning"
    else:
        return "Error"
