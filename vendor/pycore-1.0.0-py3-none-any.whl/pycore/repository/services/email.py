import logging

import requests

from pycore.enum import ServiceType
from pycore.repository.services.base import PREFIXES, Service
from pycore.resources.abc import HttpSession, Vault
from pycore.resources.http import AdminHttpSession

SEND_EMAIL_URL = "{prefix}/api/messages/email"

# `EmailService.SendEmail`'s default message type.
DEFAULT_EMAIL_TYPE = 5


class EmailRepository(Service):
    """Sends templated emails through the FactoryNavigator email service."""

    def __init__(
        self,
        http_session: HttpSession,
        vault: Vault,
        prefix: str | None = None,
        env: str | None = None,
    ):
        if prefix is None and env is None:
            prefix = ""
        self.environment = env
        self._vault = vault
        super().__init__(http_session, prefix, env, service_type=ServiceType.EMAIL)
        self._admin_session = None

    def _get_admin_session(self) -> HttpSession:
        if isinstance(self.session, AdminHttpSession):
            return self.session
        if self._admin_session is None:
            identity_prefix = PREFIXES.get(self.environment, {}).get(
                ServiceType.IDENTITY, "/identity"
            )
            # oauthlib refuses to fetch a token over plain http ("OAuth 2 MUST utilize
            # https"). The admin gateway's own API calls stay on whatever scheme
            # `base_url` normally uses; only the token exchange itself - which carries
            # the client secret - is forced onto https.
            token_url = f"{self.session.base_url}{identity_prefix}/connect/token"
            token_url = token_url.replace("http://", "https://", 1)
            self._admin_session = AdminHttpSession(
                base_url=self.session.base_url,
                http_secret=self._vault.get_secret("IdentityClientAdmin"),
                token_url=token_url,
            )
        return self._admin_session

    def send_email(
        self,
        recipients: list[str],
        subject: str,
        placeholders: dict[str, str | None],
        language_code: str | None,
        cc_recipients: list[str] | None = None,
        email_type: int = DEFAULT_EMAIL_TYPE,
    ) -> bool:
        """Posts one templated email using the configured admin session.

        ``access_token`` is retained for backwards compatibility but is not used.

        Returns:
            bool: True if the email service accepted the message.
        """
        url = SEND_EMAIL_URL.format(prefix=self.prefix)
        payload = {
            "email": recipients,
            "cc": cc_recipients,
            "subject": subject,
            "placeholders": placeholders,
            "languageCode": language_code,
            "type": email_type,
        }

        response = self._get_admin_session().post(url, json=payload)

        if response.status_code not in (requests.codes.ok, requests.codes.created, requests.codes.accepted):
            logging.warning(
                "Send email call failed.",
                extra={"url": url, "status_code": response.status_code},
            )
            return False
        return True
