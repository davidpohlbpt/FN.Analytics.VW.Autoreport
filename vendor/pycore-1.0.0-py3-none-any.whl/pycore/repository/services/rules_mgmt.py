import logging

import requests

from pycore.enum import ServiceType
from pycore.repository.services.base import Service
from pycore.resources.abc import HttpSession
from pycore.resources.http import bearer_auth_header
from pycore.schemas import DevRule
from pycore.workbench.contracts import ExtendedRuleModel

DEV_RULE_URL = "{prefix}/api/v1/DevRule/{rule_id}"
EXTENDED_RULE_URL = "{prefix}/api/v1/Rule/extendedRule"
EXTENDED_RULES_URL = "{prefix}/api/v1/Rule/extendedRules"
EXTENDED_RULES_ENTITIES_URL = "{prefix}/api/v1/Rule/extendedRules/entities"


class RulesMgmtRepository(Service):
    def __init__(
        self,
        http_session: HttpSession,
        prefix: str | None = None,
        env: str | None = None,
    ):
        if prefix is None and env is None:
            prefix = ""
        super().__init__(http_session, prefix, env, service_type=ServiceType.RULES_MGMT)

    def get_rule(self, rule_id: str, access_token: str | None = None) -> DevRule | None:
        """Retrieves a development rule from the Rules Management.

        Args:
            rule_id (str): Technical rule id.
            access_token (str, optional): Access token passed as bearer token. Defaults to None.

        Returns:
            DevRule: Retrieved rule.
        """
        url = DEV_RULE_URL.format(prefix=self.prefix, rule_id=rule_id)
        headers = bearer_auth_header(access_token)
        response = self.session.get(url, headers=headers)

        if response.status_code == requests.codes.ok:
            return DevRule.model_validate(response.json())
        else:
            return None

    def get_extended_rule(
        self, rule_id: str, entity_id: int, scenario_id: int, access_token: str | None = None
    ) -> ExtendedRuleModel | None:
        url = EXTENDED_RULE_URL.format(prefix=self.prefix or "")
        headers = bearer_auth_header(access_token)
        params = {"ruleId": rule_id, "entityId": entity_id, "scenarioId": scenario_id}
        response = self.session.get(url, params=params, headers=headers)

        if response.status_code == requests.codes.ok:
            return ExtendedRuleModel(**response.json())

        logging.warning(
            "Rules management extendedRule call failed.",
            extra={"url": url, "status_code": response.status_code},
        )
        return None

    def get_extended_rules(
        self, entity_id: int, scenario_id: int, access_token: str = None
    ) -> list[ExtendedRuleModel]:
        """Retrieves extended rules for one entity and scenario.

        Args:
            entity_id (int): Entity id.
            scenario_id (int): Scenario id.
            access_token (str, optional): Access token passed as bearer token. Defaults to None.

        Returns:
            list[ExtendedRuleModel]: Retrieved extended rules.
        """
        url = EXTENDED_RULES_URL.format(prefix=self.prefix)
        headers = bearer_auth_header(access_token)
        params = {"entityId": entity_id, "scenarioId": scenario_id}
        response = self.session.get(url, params=params, headers=headers)

        if response.status_code == requests.codes.ok:
            return [ExtendedRuleModel(**item) for item in response.json()]
        else:
            logging.warning(
                "Rules management extendedRules call failed.",
                extra={"url": url, "status_code": response.status_code},
            )
            return []

    def get_extended_rules_for_multiple_entities(
        self, entity_ids: list[int], scenario_id: int, access_token: str = None
    ) -> list[ExtendedRuleModel]:
        """Retrieves extended rules for multiple entities and one scenario.

        Args:
            entity_ids (list[int]): Entity ids.
            scenario_id (int): Scenario id.
            access_token (str, optional): Access token passed as bearer token. Defaults to None.

        Returns:
            list[ExtendedRuleModel]: Retrieved extended rules.
        """
        url = EXTENDED_RULES_ENTITIES_URL.format(prefix=self.prefix)
        headers = bearer_auth_header(access_token)
        data = {"scenarioId": scenario_id, "entityIds": entity_ids}
        response = self.session.post(url, json=data, headers=headers)

        if response.status_code == requests.codes.ok:
            return [ExtendedRuleModel(**item) for item in response.json()]
        else:
            logging.warning(
                "Rules management extendedRules/entities call failed. "
                f"url={url} status_code={response.status_code}",
                extra={"url": url, "status_code": response.status_code},
            )
            return []
