from pycore.enum import EnvironmentType, ServiceType
from pycore.resources.abc import HttpSession


class Service:
    """Base class for all services.

    Provides a session and a prefix for all requests.
    """

    def __init__(
        self,
        http_session: HttpSession,
        prefix: str | None = None,
        env: str | None = None,
        service_type: ServiceType | None = None,
    ):
        self.session = http_session
        self.service_type = service_type
        if prefix and env:
            raise ValueError(
                "Specify either the service prefix _or_ the environment, not both."
            )
        if env:
            self.prefix = PREFIXES[env][service_type]
        else:
            self.prefix = prefix


PREFIXES = {
    EnvironmentType.LOCAL: {
        ServiceType.TRACKER: "/adminapigw/tracker",
        ServiceType.MONITORING: "/adminapigw/monitoring",
        ServiceType.RDP: "/adminapigw/reportdataprovider",
        ServiceType.BATCH: "/adminapigw/batchapi",
        ServiceType.RULES_MGMT: "/adminapigw/rulesmanagementapi",
        ServiceType.TRANSLATION: "/adminapigw/translation",
        ServiceType.IDENTITY: "/identity",
        ServiceType.EMAIL: "/email",
    },
    EnvironmentType.KUBERNETES: {
        ServiceType.TRACKER: "fn-tracker-service/tracker",
        ServiceType.MONITORING: "fn-monitoring-service/monitoring",
        ServiceType.RDP: "fn-reportdataprovider-service/reportdataprovider",
        ServiceType.BATCH: "fn-batch-service/batchapi",
        ServiceType.RULES_MGMT: "fn-rulesmanagementapi-service/rulesmanagementapi",
        ServiceType.TRANSLATION: "fn-translation-service/translation",
        ServiceType.IDENTITY: "fn-identity-service/identity",
        ServiceType.EMAIL: "fn-email-service",
    },
    EnvironmentType.SERVICE_FABRIC: {
        ServiceType.TRACKER: "/TrackerService/tracker",
        ServiceType.MONITORING: "/MonitoringService/monitoring",
        ServiceType.RDP: "/ReportDataProviderService/reportdataprovider",
        ServiceType.BATCH: "/BatchApi/batchapi",
        ServiceType.RULES_MGMT: "/RulesManagementApi/rulesmanagementapi",
        ServiceType.TRANSLATION: "/TranslationService/translation",
        ServiceType.IDENTITY: "/IdentityService/identity",
        ServiceType.EMAIL: "/EmailService/email",
    },
}
