import logging
from collections.abc import Generator
from contextlib import contextmanager

import requests

from pycore.enum import ServiceType
from pycore.repository.services.base import Service
from pycore.resources.abc import HttpSession
from pycore.schemas import (
    ProcessState,
    ProcessStateUpdate,
    TrackerEntityInformation,
    TrackerLoadInformation,
)

LATEST_LOAD_URL = (
    "{prefix}/api/latestload/latestSuccesfulLoads/entityId/{entity_id}/{scenario_id}"
)
LOAD_INFO_URL = "{prefix}/api/load/{load_id}"
PROCESS_STATE_URL = "{prefix}/api/processstate"
ENTITY_INFO_URL = "{prefix}/api/entity/{entity_id}"


class TrackerRepository(Service):
    def __init__(
        self,
        http_session: HttpSession,
        prefix: str | None = None,
        env: str | None = None,
    ):
        super().__init__(http_session, prefix, env, service_type=ServiceType.TRACKER)

    def get_latest_successful_load(
        self, entity_id: int, scenario_id: int
    ) -> int | None:
        """Retrieves the ID of the latest successful load from the Tracker.

        Args:
            entity_id (int): entity ID.
            scenario_id (int): ecenario ID:

        Returns:
            int: load ID.
        """
        url = LATEST_LOAD_URL.format(
            prefix=self.prefix, entity_id=entity_id, scenario_id=scenario_id
        )
        response = self.session.get(url)
        if response.status_code == requests.codes.ok:
            load_id = response.json()[0]
            return load_id
        else:
            return

    def get_load_information(self, load_id: int) -> TrackerLoadInformation | None:
        """Retrieves the information on a given load from the Tracker.

        Args:
            load_id (int): load ID.

        Returns:
            TrackerLoadInformation: load information.
        """
        url = LOAD_INFO_URL.format(prefix=self.prefix, load_id=load_id)
        response = self.session.get(url=url)
        if response.status_code == requests.codes.ok:
            return TrackerLoadInformation.model_validate(response.json())
        else:
            return None

    def get_entity_information(self, entity_id: int) -> TrackerEntityInformation | None:
        """Retrieves the information on a given entity from the Tracker.

        Args:
            entity_id (int): entity ID.

        Returns:
            TrackerEntityInformation: entity information.
        """
        url = ENTITY_INFO_URL.format(prefix=self.prefix, entity_id=entity_id)
        response = self.session.get(url=url)
        if response.status_code == requests.codes.ok:
            return TrackerEntityInformation.model_validate(response.json())
        else:
            return None

    def send_status(self, process_state: ProcessStateUpdate):
        """Sends a status update to the Tracker.

        Args:
            process_state (ProcessStateUpdate): _description_

        Raises:
            RuntimeError: _description_
            e: _description_
        """
        url = PROCESS_STATE_URL.format(
            prefix=self.prefix,
        )
        response = self.session.post(
            url=url, json=process_state.model_dump(by_alias=True)
        )
        if response.status_code == requests.codes.ok:
            logging.warning(
                f"Process state was updated for load {process_state.load_id} to status {process_state.process_state}.",
                extra={
                    "process_id": process_state.process_id,
                    "load_id": process_state.load_id,
                },
            )
        else:
            raise RuntimeError("Process state could not be updated.")

    def service_execution(
        self, process_id: str, load_info: TrackerLoadInformation
    ) -> None:
        return tracker_service_execution(self, process_id, load_info)

    def send_status_processing(
        self, process_id: str, load_info: TrackerLoadInformation
    ):
        update = ProcessStateUpdate(
            load_id=load_info.load_id,
            scen_id=load_info.scen_id,
            entity_id=load_info.entity_id,
            process_id=process_id,
            process_state=ProcessState.PROCESSING,
        )
        return self.send_status(update)

    def send_status_success(self, process_id: str, load_info: TrackerLoadInformation):
        update = ProcessStateUpdate(
            load_id=load_info.load_id,
            scen_id=load_info.scen_id,
            entity_id=load_info.entity_id,
            process_id=process_id,
            process_state=ProcessState.SUCCESS,
        )
        return self.send_status(update)

    def send_status_failed(self, process_id: str, load_info: TrackerLoadInformation):
        update = ProcessStateUpdate(
            load_id=load_info.load_id,
            scen_id=load_info.scen_id,
            entity_id=load_info.entity_id,
            process_id=process_id,
            process_state=ProcessState.FAILED,
        )
        return self.send_status(update)


@contextmanager
def tracker_service_execution(
    tracker: TrackerLoadInformation, process_id: str, load_info: TrackerLoadInformation
) -> Generator:
    extra = {"process_id": process_id, "load_id": load_info.load_id}
    try:
        logging.warning(
            f"Starting execution of process '{process_id}' for load {load_info.load_id}.",
            extra=extra,
        )
        tracker.send_status_processing(process_id=process_id, load_info=load_info)
        yield  # execute logic within with-statement
    except Exception as e:
        logging.error(
            f"Failed to execute process '{process_id}' for load {load_info.load_id}: {e}",
            extra=extra,
        )
        tracker.send_status_failed(process_id=process_id, load_info=load_info)
    else:
        logging.warning(
            f"Successful execution of process '{process_id}' for load {load_info.load_id}.",
            extra=extra,
        )
        tracker.send_status_success(process_id=process_id, load_info=load_info)
