import logging

import requests

from pycore.enum import ServiceType
from pycore.repository.services.base import Service
from pycore.resources.abc import HttpSession
from pycore.resources.http import bearer_auth_header

TRANSLATION_VALUES_URL = "{prefix}/api/v1/translation/values/{language_id}"


class TranslationRepository(Service):
    def __init__(self, http_session: HttpSession, prefix: str = None, env: str = None):
        super().__init__(
            http_session, prefix, env, service_type=ServiceType.TRANSLATION
        )

    def get_translation_values(
        self,
        language_id: str,
        translation_keys: list[str],
        access_token: str = None,
    ) -> dict[str, str]:
        """Retrieves translations for the given keys and language.

        Args:
            language_id (str): Language id.
            translation_keys (list[str]): Translation keys.
            access_token (str, optional): Access token passed as bearer token. Defaults to None.

        Returns:
            dict[str, str]: Key-value translation map.
        """
        url = TRANSLATION_VALUES_URL.format(
            prefix=self.prefix,
            language_id=language_id,
        )
        headers = bearer_auth_header(access_token)
        response = self.session.post(url, json=translation_keys, headers=headers)

        if response.status_code == requests.codes.ok:
            data = response.json()
            return data if isinstance(data, dict) else {}
        else:
            logging.warning(
                "Translation values call failed. "
                f"url={url} status_code={response.status_code}",
                extra={"url": url, "status_code": response.status_code},
            )
            return {}
