import json
from collections.abc import Sequence
from typing import Any

import pandas as pd
import sqlalchemy as sa

from pycore import schemas as s
from pycore.repository.data import DataRepository
from pycore.resources.odbc import OdbcDatabase
from pycore.utils.maintenance import deprecated_method
from pycore.utils.pydantic import translate_to_alias

INC_TABLE = "T_RESULT_Incident"
OCC_TABLE = "T_RESULT_Occurence"
INC_RESOLUTION_TABLE = "T_RESULT_Incident_Resolve"
INC_HIDE_TABLE = "T_RESULT_Incident_HideUser"
INC_COMMENT_TABLE = "T_RESULT_Incident_Comment"
INC_HISTORY_TABLE = "T_RESULT_IncidentHistory"
INC_EVENT_TYPE_TABLE = "T_CONTROL_Incident_EventTypes"
INC_STATUS_TABLE = "T_CONTROL_IncidentValidationStatus"
INC_TAG_TABLE = "T_RESULT_IncidentTag"
GROUP_INFORMATION_TABLE = "T_RESULT_GroupInformation"
DATA_TRANSFER_TABLE = "T_RESULT_DataTransfer"

BATCH_SIZE = 2000


class ReportDataProviderRepository(DataRepository):
    def __init__(self, database: OdbcDatabase):
        self.database = database

    @property
    @deprecated_method
    def declarative_base(self):
        return self.database.base

    def get_incidents(
        self, scen_id: int, filters: list[s.Filter] | None = None, as_df: bool = False
    ) -> pd.DataFrame | list[s.Incident]:
        """Retrieves multiple incidents from the ReportDataProvider.

        Args:
            scen_id (int): scenario ID.
            filters (list[Filter], optional): Applied filters. Defaults to None.
            as_df (bool, optional): Indicates whether the result should be returned as data frame. Defaults to False.

        Returns:
            Union[pd.DataFrame, list[Incident]]: Retrieved incidents.
        """
        all_filters = [
            s.Filter(type=s.FilterOperator.equal, name="scenario_id", value=scen_id)
        ]
        all_filters += filters or []

        for f in all_filters:
            f.name = translate_to_alias(f.name, s.Incident)

        incs = self.read_table_with_filters(
            table=INC_TABLE, filters=all_filters, as_df=False
        )
        incs = [s.Incident.model_validate(i) for i in incs]
        if as_df:
            # Return data frame without aliases
            return pd.DataFrame(data=[i.model_dump() for i in incs])
        else:
            return incs

    def get_incident(self, scen_id: int, inc_id: int) -> s.Incident | None:
        """Retrieves a single incident from the ReportDataProvider.

        Args:
            scen_id (int): scenario ID of the incident.
            inc_id (int): incident ID.

        Returns:
            Incident: Retrieved incident.
        """
        filters = [
            s.Filter(type=s.FilterOperator.equal, name="incident_id", value=inc_id)
        ]
        result = self.get_incidents(scen_id=scen_id, filters=filters)
        if len(result) == 0:
            return
        elif len(result) == 1:
            return result[0]
        else:
            raise ValueError("More than one incident found.")  # pragma: no cover

    def get_incident_events(
        self,
        scen_id: int,
        incident_id: int | None = None,
        filters: list[s.Filter] | None = None,
        as_df: bool = False,
    ) -> pd.DataFrame | list[s.IncidentEvent]:
        """Retrieves multiple incident events from the ReportDataProvider.

        Args:
            scen_id (int): scenario ID.
            incident_id (int, optional): Incident ID for which events are retrieved. Defaults to None.
            filters (list[Filter], optional): Applied filters. Defaults to None.
            as_df (bool, optional): Indicates whether the result should be returned as data frame. Defaults to False.

        Returns:
            Union[pd.DataFrame, list[IncidentEvent]]: Retrieved incidents.
        """
        all_filters = [
            s.Filter(type=s.FilterOperator.equal, name="scenario_id", value=scen_id)
        ]

        if incident_id is not None:
            all_filters.append(
                s.Filter(
                    type=s.FilterOperator.equal, name="incident_id", value=incident_id
                )
            )

        all_filters += filters or []

        for f in all_filters:
            f.name = translate_to_alias(f.name, s.IncidentEvent)

        inc_events = self.read_table_with_filters(
            table=INC_HISTORY_TABLE, filters=all_filters, as_df=False
        )
        inc_events = [s.IncidentEvent.model_validate(i) for i in inc_events]
        if as_df:
            # Return data frame without aliases
            return pd.DataFrame(data=[i.model_dump() for i in inc_events])
        else:
            return inc_events

    def add_incidents(self, incs: list[s.Incident]):
        """Writes a list of incidents to the ReportDataProvider.

        Args:
            incs (list[Incident]): Incidents to be written.
        """
        incs = pd.DataFrame([i.model_dump(by_alias=True) for i in incs])
        self.write_table(INC_TABLE, incs)

    def add_incident(self, inc: s.Incident):
        """Writes a single incident to the ReportDataProvider.

        Args:
            inc (Incident): Incident to be written.
        """
        return self.add_incidents(incs=[inc])

    def add_incident_events(self, inc_events: list[s.IncidentEvent]):
        """Writes a list of incident events to the ReportDataProvider.

        Args:
            incs (list[Incident]): Incidents to be written.
        """
        inc_events = pd.DataFrame([i.model_dump(by_alias=True) for i in inc_events])
        self.write_table(INC_HISTORY_TABLE, inc_events)

    def update_loads_of_incident(self, scen_id: int, inc_id: int, load: int) -> None:
        return self.update_loads_of_incidents(scen_id=scen_id, loads={inc_id: load})

    def update_loads_of_incidents(self, scen_id: int, loads: dict[int, int]):
        inc_table = self.database.get_table(INC_TABLE)

        upd_stmt = (
            sa.update(inc_table)
            .where(
                inc_table.c.ScenarioID == scen_id,
                inc_table.c.IncidentID == sa.bindparam("inc_id"),
            )
            .values(Loads=sa.bindparam("new_load"))
        )

        current_incidents = self.get_incidents(scen_id=scen_id)
        current_incidents_dict = {inc.incident_id: inc for inc in current_incidents}

        with self.database.session_scope() as db:
            inc_params = [
                {
                    "inc_id": inc,
                    "new_load": json.dumps(
                        {"Loads": current_incidents_dict[inc].loads["Loads"] + [load]}
                    ),
                }
                for inc, load in loads.items()
            ]
            db.execute(upd_stmt, inc_params)

    def get_incident_tags(
        self,
        scen_id: int,
        incident_id: int | None = None,
        filters: list[s.Filter] | None = None,
        as_df: bool = False,
    ) -> pd.DataFrame | list[s.IncidentTag]:
        """Retrieves multiple incident tags from the ReportDataProvider.

        Args:
            scen_id (int): scenario ID.
            incident_id (int, optional): Incident ID for which incident tags are retrieved. Defaults to None.
            filters (list[Filter], optional): Applied filters. Defaults to None.
            as_df (bool, optional): Indicates whether the result should be returned as data frame. Defaults to False.

        Returns:
            Union[pd.DataFrame, list[IncidentTag]]: Retrieved incident tags.
        """
        all_filters = [
            s.Filter(type=s.FilterOperator.equal, name="scenario_id", value=scen_id)
        ]

        if incident_id is not None:
            all_filters.append(
                s.Filter(
                    type=s.FilterOperator.equal, name="incident_id", value=incident_id
                )
            )

        all_filters += filters or []

        for f in all_filters:
            f.name = translate_to_alias(f.name, s.IncidentTag)

        inc_tags = self.read_table_with_filters(
            table=INC_TAG_TABLE, filters=all_filters, as_df=False
        )
        inc_tags = [s.IncidentTag.model_validate(i) for i in inc_tags]
        if as_df:
            # Return data frame without aliases
            return pd.DataFrame(data=[i.model_dump() for i in inc_tags])
        else:
            return inc_tags

    def check_incident_tags(
        self, inc_tags: list[s.IncidentTag]
    ) -> tuple[list[s.IncidentTag], Sequence[s.IncidentTag]]:
        """Checks for a list of Incident Tags whether they exist or not.

        Args:
            inc_tags (list[IncidentTag]): Incident Tags to be checked for their existence.

        Returns:
            tuple[list[IncidentTag], Sequence[IncidentTag]]: A tuple containing both the list of new as well as old Incident Tag entries.
        """
        new_incident_tags = []
        existing_incident_tags = []

        for inc_tag in inc_tags:
            checked_inc_tag = self.get_incident_tags(
                scen_id=inc_tag.scenario_id, incident_id=inc_tag.incident_id
            )
            if checked_inc_tag:
                existing_incident_tags.append(inc_tag)
            else:
                new_incident_tags.append(inc_tag)

        return new_incident_tags, existing_incident_tags

    def create_or_update_incident_tag(self, inc_tag: s.IncidentTag) -> None:
        """Updates or creates incident tag entry.

        Args:
            group_information (IncidentTag): Incident Tag entry to be updated or created.

        Returns:
            None
        """
        return self.create_or_update_incident_tags(inc_tags=[inc_tag])

    def create_or_update_incident_tags(self, inc_tags: list[s.IncidentTag]):
        """Updates or creates incident tag entries.

        Args:
            inc_tags (list[IncidentTag]): List of Incident Tag entries to be updated or created.

        Returns:
            None
        """
        if len(inc_tags) == 0:
            return

        unique_scen_ids = {i.scenario_id for i in inc_tags}
        new_inc_ids = {i.incident_id for i in inc_tags}

        if len(unique_scen_ids) > 1:
            raise RuntimeError("Incident Tags must belong to the same scenario.")
        scen_id = next(iter(unique_scen_ids))

        inc_tag_table = self.database.get_table(INC_TAG_TABLE)

        sel_stmt = sa.select(
            inc_tag_table.c.IncidentID,
        ).where(
            inc_tag_table.c.ScenarioID == scen_id,
        )

        upd_stmt = (
            sa.update(inc_tag_table)
            .where(
                inc_tag_table.c.ScenarioID == sa.bindparam("scenario_id"),
                inc_tag_table.c.IncidentID == sa.bindparam("incident_id"),
            )
            .values(
                TagPropertiesID=sa.bindparam("tag_properties_id"),
                ChangedOn=sa.bindparam("changed_on"),
                ChangedBy=sa.bindparam("changed_by"),
            )
        )

        ins_statement = sa.insert(inc_tag_table).values(
            ScenarioID=sa.bindparam("scenario_id"),
            IncidentID=sa.bindparam("incident_id"),
            TagPropertiesID=sa.bindparam("tag_properties_id"),
            ChangedOn=sa.bindparam("changed_on"),
            ChangedBy=sa.bindparam("changed_by"),
        )

        with self.database.session_scope() as db:
            if len(new_inc_ids) < BATCH_SIZE:
                sel_stmt = sel_stmt.where(inc_tag_table.c.IncidentID.in_(new_inc_ids))
                existing_ids = {it[0] for it in db.execute(sel_stmt).fetchall()}
            else:
                existing_ids = set()
                batched_ids_list = [
                    list(new_inc_ids)[i : i + BATCH_SIZE]
                    for i in range(0, len(new_inc_ids), BATCH_SIZE)
                ]
                for batch in batched_ids_list:
                    batch_sel_stmt = sel_stmt.where(
                        inc_tag_table.c.IncidentID.in_(batch),
                    )
                    existing_ids_batch = {
                        it[0] for it in db.execute(batch_sel_stmt).fetchall()
                    }

                    existing_ids.update(existing_ids_batch)

            upd_params = [
                it.model_dump() for it in inc_tags if it.incident_id in existing_ids
            ]
            ins_params = [
                it.model_dump() for it in inc_tags if it.incident_id not in existing_ids
            ]

            if len(upd_params) > 0:
                db.execute(upd_stmt, upd_params)

            if len(ins_params) > 0:
                db.execute(ins_statement, ins_params)

    def delete_incident_tags(self, inc_tags: list[s.IncidentTag]):

        inc_tag_table = self.database.get_table(INC_TAG_TABLE)

        # delete existing incident tags
        if len(inc_tags):
            del_stmt = sa.delete(inc_tag_table).where(
                inc_tag_table.c.ScenarioID == sa.bindparam("scen_id"),
                inc_tag_table.c.IncidentID == sa.bindparam("inc_id"),
            )

            with self.database.session_scope() as db:
                inc_params = [
                    {
                        "scen_id": inc_tag.scenario_id,
                        "inc_id": inc_tag.incident_id,
                    }
                    for inc_tag in inc_tags
                ]
                db.execute(del_stmt, inc_params)

    def get_group_informations(
        self,
        scen_id: int,
        grouping_dimension_id: int | None = None,
        group_id: str | None = None,
        filters: list[s.Filter] | None = None,
        as_df: bool = False,
    ) -> pd.DataFrame | list[s.GroupInformation]:
        """Retrieves multiple group informations from the ReportDataProvider.

        Args:
            scen_id (int): scenario ID.
            grouping_dimension_id (int, optional): Grouping Dimension ID for which informations are retrieved. Defaults to None.
            group_id (str, optional): Group ID for which informations are retrieved. Defaults to None.
            filters (list[Filter], optional): Applied filters. Defaults to None.
            as_df (bool, optional): Indicates whether the result should be returned as data frame. Defaults to False.

        Returns:
            Union[pd.DataFrame, list[GroupInformation]]: Retrieved incidents.
        """
        all_filters = [
            s.Filter(type=s.FilterOperator.equal, name="scenario_id", value=scen_id)
        ]

        if grouping_dimension_id is not None:
            all_filters.append(
                s.Filter(
                    type=s.FilterOperator.equal,
                    name="grouping_dimension_id",
                    value=grouping_dimension_id,
                )
            )

        if group_id is not None:
            all_filters.append(
                s.Filter(type=s.FilterOperator.equal, name="group_id", value=group_id)
            )

        all_filters += filters or []

        for f in all_filters:
            f.name = translate_to_alias(f.name, s.GroupInformation)

        group_informations = self.read_table_with_filters(
            table=GROUP_INFORMATION_TABLE, filters=all_filters, as_df=False
        )
        group_informations = [
            s.GroupInformation.model_validate(i) for i in group_informations
        ]
        if as_df:
            # Return data frame without aliases
            return pd.DataFrame(data=[i.model_dump() for i in group_informations])
        else:
            return group_informations

    def check_group_informations(
        self, group_informations: list[s.GroupInformation]
    ) -> tuple[list[s.GroupInformation], Sequence[s.GroupInformation]]:
        """Checks for a list of Group Informations whether they exist or not.

        Args:
            group_informations (list[GroupInformation]): Group Informations to be checked for their existence.

        Returns:
            tuple[list[GroupInformation], Sequence[GroupInformation]]: A tuple containing both the list of new as well as old Group Information entries.
        """
        new_group_informations = []
        existing_group_informations = []
        for group_info in group_informations:
            checked_group_info = self.get_group_informations(
                scen_id=group_info.scenario_id,
                grouping_dimension_id=group_info.grouping_dimension_id,
                group_id=group_info.group_id,
            )
            if checked_group_info:
                existing_group_informations.append(group_info)
            else:
                new_group_informations.append(group_info)

        return new_group_informations, existing_group_informations

    def create_or_update_group_information(
        self, group_information: s.GroupInformation
    ) -> None:
        """Updates or creates group information entry.

        Args:
            group_information (GroupInformation): Group Information entry to be updated or created.

        Returns:
            None
        """
        return self.create_or_update_group_informations(
            group_informations=[group_information]
        )

    def create_or_update_group_informations(
        self, group_informations: list[s.GroupInformation]
    ) -> None:
        """Updates or creates group information entries.

        Args:
            group_informations (list[GroupInformation]): List of Group Information entries to be updated or created.

        Returns:
            None
        """
        if len(group_informations) == 0:
            return

        unique_scen_ids = {i.scenario_id for i in group_informations}
        unique_group_dim_ids = {i.grouping_dimension_id for i in group_informations}
        new_group_ids = {i.group_id for i in group_informations}

        if len(unique_scen_ids) != 1:
            raise RuntimeError("Group information must belong to the same scenario.")

        if len(unique_group_dim_ids) != 1:
            raise RuntimeError(
                "Group information must belong to the same grouping dimension."
            )

        scen_id = next(iter(unique_scen_ids))
        group_dim_id = next(iter(unique_group_dim_ids))

        grp_info_tab = self.database.get_table(GROUP_INFORMATION_TABLE)

        sel_stmt = sa.select(
            grp_info_tab.c.GroupID,
        ).where(
            grp_info_tab.c.ScenarioID == scen_id,
            grp_info_tab.c.GroupingDimensionID == group_dim_id,
        )

        upd_stmt = (
            sa.update(grp_info_tab)
            .where(
                grp_info_tab.c.ScenarioID == sa.bindparam("scenario_id"),
                grp_info_tab.c.GroupID == sa.bindparam("group_id"),
                grp_info_tab.c.GroupingDimensionID
                == sa.bindparam("grouping_dimension_id"),
            )
            .values(
                Description=sa.bindparam("description"),
                TagPropertiesID=sa.bindparam("tag_properties_id"),
                ChangedOn=sa.bindparam("changed_on"),
                ChangedBy=sa.bindparam("changed_by"),
            )
        )

        ins_statement = sa.insert(grp_info_tab).values(
            ScenarioID=sa.bindparam("scenario_id"),
            GroupingDimensionID=sa.bindparam("grouping_dimension_id"),
            GroupID=sa.bindparam("group_id"),
            TagPropertiesID=sa.bindparam("tag_properties_id"),
            Description=sa.bindparam("description"),
            ChangedOn=sa.bindparam("changed_on"),
            ChangedBy=sa.bindparam("changed_by"),
        )

        with self.database.session_scope() as db:

            if len(new_group_ids) < BATCH_SIZE:
                sel_stmt = sel_stmt.where(grp_info_tab.c.GroupID.in_(new_group_ids))
                existing_ids = {it[0] for it in db.execute(sel_stmt).fetchall()}
            else:
                existing_ids = set()
                batched_ids_list = [
                    list(new_group_ids)[i : i + BATCH_SIZE]
                    for i in range(0, len(new_group_ids), BATCH_SIZE)
                ]
                for batch in batched_ids_list:
                    batch_sel_stmt = sel_stmt.where(grp_info_tab.c.GroupID.in_(batch))
                    existing_ids_batch = {
                        it[0] for it in db.execute(batch_sel_stmt).fetchall()
                    }

                    existing_ids.update(existing_ids_batch)

            upd_params = [
                it.model_dump()
                for it in group_informations
                if it.group_id in existing_ids
            ]
            ins_params = [
                it.model_dump()
                for it in group_informations
                if it.group_id not in existing_ids
            ]

            if len(upd_params) > 0:
                db.execute(upd_stmt, upd_params)

            if len(ins_params) > 0:
                db.execute(ins_statement, ins_params)

    def update_status_of_incident(self, scen_id: int, inc_id: int, status: str) -> None:
        """Updates the status column of a given Incident.

        Args:
            scen_id (int): scenario ID.
            inc_id (int): incident ID of the incident to update.
            status (str): New status value.

        Returns:
            None
        """
        return self.update_status_of_incidents(
            scen_id=scen_id, statuses={inc_id: status}
        )

    def update_status_of_incidents(
        self, scen_id: int, statuses: dict[int, str]
    ) -> None:
        """Updates the status column of given Incidents.

        Args:
            scen_id (int): scenario ID.
            statuses (dict[int, str]): New status values for their respective scenario IDs.

        Returns:
            None
        """
        inc_table = self.database.get_table(INC_TABLE)

        upd_stmt = (
            sa.update(inc_table)
            .where(
                inc_table.c.ScenarioID == scen_id,
                inc_table.c.IncidentID == sa.bindparam("inc_id"),
            )
            .values(Status=sa.bindparam("new_status"))
        )

        with self.database.session_scope() as db:
            inc_params = [
                {"inc_id": inc, "new_status": status}
                for inc, status in statuses.items()
            ]
            db.execute(upd_stmt, inc_params)

    def get_occurences(
        self, scen_id: int, filters: list[s.Filter] | None = None, as_df: bool = False
    ) -> pd.DataFrame | list[s.Occurence]:
        """Retrieves multiple occurences from the ReportDataProvider.

        Args:
            scen_id (int): scenario ID.
            filters (list[Filter], optional): Applied filters. Defaults to None.
            as_df (bool, optional): Indicates whether the result should be returned as data frame. Defaults to False.

        Returns:
            Union[pd.DataFrame, list[Occurence]]: Retrieved occurence.
        """
        all_filters = [
            s.Filter(type=s.FilterOperator.equal, name="ScenarioID", value=scen_id)
        ]
        all_filters += filters or []
        occs = self.read_table_with_filters(
            table=OCC_TABLE, filters=all_filters, as_df=False
        )
        occs = [s.Occurence.model_validate(i) for i in occs]
        if as_df:
            # Return data frame without aliases
            return pd.DataFrame(data=[i.model_dump() for i in occs])
        else:
            return occs

    def get_occurence(self, scen_id: int, occ_id: int) -> s.Occurence | None:
        """Retrieves a single occurence from the ReportDataProvider.

        Args:
            scen_id (int): scenario ID of the occurence.
            occ_id (int): occurence ID.

        Returns:
            Occurence: Retrieved occurence.
        """
        filters = [
            s.Filter(type=s.FilterOperator.equal, name="OccurenceId", value=occ_id)
        ]
        result = self.get_occurences(scen_id=scen_id, filters=filters)
        if len(result) == 0:
            return
        elif len(result) == 1:
            return result[0]
        else:
            raise ValueError("More than one occurence found.")  # pragma: no cover

    def add_occurences(self, occs: list[s.Occurence]) -> None:
        """Writes a list of occurences to the ReportDataProvider.

        Args:
            occs (list[Occurence]): Occurences to be written.
        """
        occs = pd.DataFrame([o.model_dump(by_alias=True) for o in occs])
        self.write_table(OCC_TABLE, occs)

    def add_occurence(self, occ: s.Occurence) -> None:
        """Writes a single occurence to the ReportDataProvider.

        Args:
            occ (Occurence): Occurence to be written.
        """
        self.add_occurences(occs=[occ])

    def update_fields_of_latest_occurence(
        self,
        scen_id: int,
        inc_id: int,
        fields: dict[str, Any],
        delta: bool = False,
        entity_id: int | None = None,
    ) -> None:
        """Updates the fields of the latest occurence of the given incident.

        Args:
            scen_id (int): Scenario ID.
            inc_id (int): Incident ID.
            fields (dict[str, Any]): New fields of the occurence.
            delta (bool, optional): Indicates whether the data contains only the occurence fields that have changed. Defaults to False.
        """
        return self.update_fields_of_latest_occurences(
            scen_id=scen_id, fields={inc_id: fields}, delta=delta, entity_id=entity_id
        )

    def update_fields_of_latest_occurences(
        self,
        scen_id: int,
        fields: dict[int, dict[str, Any]],
        delta: bool = False,
        entity_id: int | None = None,
    ):
        """Updates the fields of the latest occurences of the given incidents.

        Args:
            scen_id (int): Scenario ID.
            fields (dict[int, dict[str, Any]]): New fields of the occurences with given incidents.
            delta (bool, optional): Indicates whether the data contains only the occurence fields that have changed. Defaults to False.
        """
        occ_table = self.database.get_table(OCC_TABLE)

        latest_occs = self._get_latest_occurences(
            scen_id, inc_ids=list(fields.keys()), entity_id=entity_id
        )

        if len(latest_occs) == 0:
            return

        if delta:
            updated_keys = next(iter(fields.values())).keys()
            fields_expr = self.database.update_json_column(
                occ_table.c.Fields, updated_keys
            )
            occ_params = [
                {"occ_id": occ[0], **fields[occ[1]]}
                for occ in latest_occs
                if occ[1] in fields
            ]
        else:
            fields_expr = sa.bindparam("new_fields")
            occ_params = [
                {"occ_id": occ[0], "new_fields": json.dumps(fields[occ[1]])}
                for occ in latest_occs
                if occ[1] in fields
            ]

        where_clause = [
            occ_table.c.ScenarioID == scen_id,
            occ_table.c.OccurenceID == sa.bindparam("occ_id"),
        ]
        if entity_id is not None:
            where_clause.append(occ_table.c.EntityID == entity_id)

        upd_stmt = (
            sa.update(occ_table)
            .where(*where_clause)
            .values(Fields=fields_expr)
            .execution_options(synchronize_session=False)
        )
        with self.database.session_scope() as db:
            for occ_param in occ_params:
                db.execute(upd_stmt, occ_param)

    def _get_delta_expr(
        self, fields: dict[int, dict[str, Any]], occ_table
    ) -> sa.Column:
        keys = next(iter(fields.values())).keys()

        expr = occ_table.c.Fields
        for k in keys:
            expr = sa.func.json_set(expr, f"$.{k}", sa.bindparam(k))

        return expr

    def _get_latest_occurences(
        self, scen_id: int, inc_ids: list[int], entity_id: int | None = None
    ) -> list[tuple[int, int]]:
        """Returns the latest occurence for each incident in the given scenario.

        Since load IDs are monotonically increasing, the latest occurence is the one
        with the highest load ID.

        If more than 1000 incident IDs are given, the function will return all incidents.
        Otherwise, SQLAlchemy will raise an error.

        Args:
            scen_id (int): Scenario ID.
            inc_ids (list[int]): Incident IDs.

        Returns:
            list[tuple[int, int]]: List of tuples with the latest occurence ID and incident ID.

        """

        occ_table = self.database.get_table(OCC_TABLE)

        where = [occ_table.c.ScenarioID == scen_id]
        if inc_ids and len(inc_ids) < 1000:
            where.append(occ_table.c.IncidentID.in_(inc_ids))

        if entity_id is not None:
            where.append(occ_table.c.EntityID == entity_id)

        latest_load = (
            sa.select(
                occ_table.c.IncidentID,
                occ_table.c.ScenarioID,
                sa.func.max(occ_table.c.LoadID).label("LatestLoadID"),
            )
            .where(*where)
            .group_by(occ_table.c.IncidentID, occ_table.c.ScenarioID)
        ).subquery()

        latest_occ_query = sa.select(
            occ_table.c.OccurenceID, occ_table.c.IncidentID
        ).join(
            latest_load,
            sa.and_(
                latest_load.c.IncidentID == occ_table.c.IncidentID,
                latest_load.c.ScenarioID == occ_table.c.ScenarioID,
                latest_load.c.LatestLoadID == occ_table.c.LoadID,
            ),
        )

        with self.database.session_scope() as db:
            return db.execute(latest_occ_query).fetchall()

    def get_existing_incidents(
        self, scen_id: int, entity_id: int | None = None
    ) -> dict[int, list[int]]:
        """Retrieves incident IDs and corresponding occurence IDs from the ReportDataProvider.

        Args:
            scen_id (int): scenario ID.

        Returns:
            dict[int, list[int]]: Dictionary with incident IDs as keys and occurence IDs as values.
        """

        inc_table = self.database.get_table(INC_TABLE)
        occ_table = self.database.get_table(OCC_TABLE)

        query = (
            sa.select(inc_table.c.IncidentID, occ_table.c.OccurenceID)
            .join(
                occ_table,
                sa.and_(
                    inc_table.c.IncidentID == occ_table.c.IncidentID,
                    occ_table.c.ScenarioID == scen_id,
                ),
            )
            .where(inc_table.c.ScenarioID == scen_id)
        )

        if entity_id is not None:
            query = query.where(inc_table.c.EntityID == entity_id)

        with self.database.session_scope() as db:
            result = db.execute(query).fetchall()

        existing_incidents = {}
        for inc_id, occ_id in result:
            existing_incidents.setdefault(inc_id, []).append(occ_id)

        return existing_incidents

    def get_data_transfer(
        self,
        scen_id: int,
        is_transferred: bool = False,
        filters: list[s.Filter] | None = None,
    ) -> pd.DataFrame:
        """Retrieves multiple data transfer entries from the ReportDataProvider.

        Args:
            scen_id (int): Scenario ID.
            is_transferred (bool, optional): If True, retrieves only data transfer entries where 'Transferred' is True. If False, retrieves only entries where 'Transferred' is False. Defaults to False.
            filters (list[Filter], optional): Applied filters. Defaults to None.

        Returns:
            pd.DataFrame: Retrieved data transfer entries.
        """
        all_filters = [
            s.Filter(type=s.FilterOperator.equal, name="ScenarioId", value=scen_id),
            s.Filter(
                type=s.FilterOperator.equal, name="Transferred", value=is_transferred
            ),
        ]
        all_filters += filters or []

        dt_entries = self.read_table_with_filters(
            table=DATA_TRANSFER_TABLE, filters=all_filters, as_df=True
        )

        return pd.DataFrame(data=dt_entries)

    def complete_data_transfer(self, scen_id: int, ids: list[int]) -> None:
        """Updates the 'Transferred' column of the data transfer entries to 'True'.

        Args:
            scen_id (int): scenario ID.
            ids (list(int)): IDs of the data transfer entries to be updated.

        Returns:
            None
        """
        if not ids:
            return

        data_transfer_table = self.database.get_table(DATA_TRANSFER_TABLE)

        upd_stmt = (
            sa.update(data_transfer_table)
            .where(
                data_transfer_table.c.ScenarioId == scen_id,
                data_transfer_table.c.Id == sa.bindparam("id"),
            )
            .values(Transferred=True)
        )

        with self.database.session_scope() as db:
            db.execute(upd_stmt, [{"id": id} for id in ids])
