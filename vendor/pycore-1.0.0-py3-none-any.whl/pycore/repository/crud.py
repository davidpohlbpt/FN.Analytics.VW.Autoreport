import logging

import sqlalchemy as sa

from pycore.utils.collections import maybe_make_list


class CRUDRepository:
    """Base class for CRUD repositories.

    They allow basic create, read, write and update operations on one or more rows of a SQLalchemy table
    """

    def __init__(self, model):
        """Initializes the repository with the model class.

        Args:
            model (object): The model class
        """
        self.model = model
        self.tab = model.__table__

    def get(
        self, db, obj: object | str | int | tuple, raise_error: bool = False
    ) -> object | None:
        """Gets an object from the database.

        Args:
            db (Session): The database session
            obj (Union[object, str, int, Tuple]): The object or its primary key

        Returns:
            Union[object, None]: The object or None if it does not exist
        """
        if isinstance(obj, self.model):
            return obj

        obj = db.get(self.model, obj)
        if obj is None and raise_error:
            raise RuntimeError(
                f"Object {self.model.__name__} with key '{obj}' does not exist in the database."
            )
        return obj

    def get_all(self, db) -> list[object]:
        """Gets all objects from the database.

        Args:
            db (Session): The database session
        """
        return list(db.execute(sa.select(self.model)).scalars().all())

    def get_all_where(self, db, **kwargs) -> list[object]:
        """Gets all objects from the database that match the given criteria.

        Args:
            db (Session): The database session
            **kwargs: The criteria, written as "column_name=value"

        Returns:
            list[object]: The objects
        """
        query = sa.select(self.model)
        query = self._add_where_condition(query, **kwargs)
        return list(db.execute(query).scalars().all())

    def count_all(self, db) -> int:
        """Counts all objects in the database.

        Args:
            db (Session): The database session

        Returns:
            int: The number of objects
        """
        return db.scalar(sa.select(sa.func.count()).select_from(self.model))

    def count_all_where(self, db, **kwargs) -> int:
        """Counts all objects in the database that match the given criteria.

        Args:
            db (Session): The database session
            **kwargs: The criteria, written as "column_name=value"

        Returns:
            int: The number of objects
        """
        query = sa.select(sa.func.count()).select_from(self.model)
        query = self._add_where_condition(query, **kwargs)
        return db.scalar(query)

    def create(self, db, *args, **kwargs):
        """Creates a new object in the database.

        Args:
            db (Session): The database session
            *args: The primary key values, in the correct order, if not passed as kwargs
            **kwargs: The column values, written as "column_name=value"

        Returns:
            object: The created object
        """
        if args:
            key = sa.inspect(self.model).primary_key
            kwargs.update(**{k.name: a for k, a in zip(key, args)})
        db_obj = self.model(**kwargs)
        db.add(db_obj)
        return db_obj

    def create_or_update(self, db, key: str | int | tuple, **kwargs):
        """Creates a new object in the database or updates an existing one.

        Args:
            db (Session): The database session
            key (Union[str, int, Tuple]): The primary key value(s)
            **kwargs: The column values, written as "column_name=value"

        Returns:
            object: The created or updated object

        """
        obj = self.get(db, key)
        if obj:
            return self.update(db, obj, **kwargs)
        else:
            key = maybe_make_list(key)
            return self.create(db, *key, **kwargs)

    def update(self, db, obj, **kwargs) -> None:
        """Updates an object in the database.

        Args:
            db (Session): The database session
            obj (object): The object to update
            **kwargs: The column values, written as "column_name=value"

        Returns:
            object: The updated object
        """
        obj = self.get(db, obj)
        for k, v in kwargs.items():
            if hasattr(obj, k):
                setattr(obj, k, v)
            else:
                raise ValueError(
                    f"Model '{self.model.__name__}' has no colum named '{k}', update is skipped."
                )
        return obj

    def remove(self, db, obj_or_key: object | str | int | tuple) -> None:
        """Removes an object from the database.

        Args:
            db (Session): The database session
            obj_or_key (Union[object, str, int, Tuple]): The object or its primary key

        Raises:
            RuntimeError: If the object does not exist in the database
        """
        obj = self.get(db, obj_or_key)
        if obj:
            db.delete(obj)
        else:
            raise RuntimeError(
                "The object does not exist in the database and, thus, cannot be deleted."
            )

    def remove_all_where(self, db, **kwargs) -> None:
        """Removes all objects from the database that match the given criteria.

        Args:
            db (Session): The database session
            **kwargs: The criteria, written as "column_name=value"

        Raises:
            ValueError: If no criteria are given
        """
        if not kwargs:
            raise ValueError("At least one criteria must be given.")

        query = sa.delete(self.model)
        query = self._add_where_condition(query, **kwargs)
        db.execute(query)

    def _add_where_condition(self, query, **kwargs):
        for col_name, value in kwargs.items():
            if hasattr(self.model, col_name):
                query = query.where(getattr(self.model, col_name) == value)
            else:
                logging.warning(
                    f"Model '{self.model.__name__}' has no colum named '{col_name}', condition is skipped."
                )

        return query
