import datetime as dt
import logging
from ast import Dict
from collections.abc import Sequence
from operator import or_
from typing import Any

import numpy as np
import pandas as pd
import sqlalchemy as sa
from dateutil import parser
from sqlalchemy.sql import union

from pycore.resources.odbc import OdbcDatabase
from pycore.schemas import (
    DataQuery,
    DrillTroughFilter,
    Filter,
    FilterOperator,
    GenericTableColumns,
    GroupOperator,
    IndexOperator,
    NestedFilterGroup,
    NestedFilterList,
)

BATCH_SIZE = 5 * (10**4)  # 50k


def get_nested_filter_list_expression(table, nested_filter_list: NestedFilterList):
    result = None

    for item in nested_filter_list:
        if not OdbcDatabase.has_col(table, item.filter.name):
            continue
        col = OdbcDatabase.get_col(table, item.filter.name)
        operator = item.operator
        expr = get_filter_expression(
            col, item.filter.filter_type, item.filter.value, item.filter.value2
        )
        if result is None:
            result = expr
        else:
            if operator == GroupOperator.OR:
                result = result | expr
            elif operator == GroupOperator.AND:
                result = result & expr
            else:
                raise ValueError(f"Group operator {operator} is not supported.")

    return result


def get_nested_filter_expression(table: sa.Table, nested_filter: NestedFilterGroup):
    if not nested_filter.filters:
        return None

    if not isinstance(nested_filter.filters[0], NestedFilterGroup):
        return get_nested_filter_list_expression(table, nested_filter.filters)

    if len(nested_filter.filters) == 1:
        return get_nested_filter_expression(table, nested_filter.filters[0])

    if len(nested_filter.filters) != 2:
        raise ValueError("Nested filter groups must have exactly two filter groups.")

    left = nested_filter.filters[IndexOperator.LEFT]
    operator = left.group_operator
    right = nested_filter.filters[IndexOperator.RIGHT]

    left_expr = get_nested_filter_expression(table, left)
    right_expr = get_nested_filter_expression(table, right)

    if left_expr is None:
        return right_expr
    if right_expr is None:
        return left_expr

    if operator == GroupOperator.OR:
        return left_expr | right_expr
    elif operator == GroupOperator.AND:
        return left_expr & right_expr
    else:
        raise ValueError(f"Group operator {operator} is not supported.")


def get_filter_expression(
    col: sa.Column, type: FilterOperator, low: Any, high: Any = None
):
    """Returns a SQLAlchemy expression for a filter.

    Args:
        col (sa.Column): Column to be filtered.
        type (FilterOperator): Filter operator.
        low (Any): Lower bound.
        high (Any, optional): Upper bound. Defaults to None.

    Raises:
        ValueError: Raises an exception if the filter operator is not supported.

    Returns:
        sa.sql.expression: SQLAlchemy expression.
    """

    date_types = {
        FilterOperator.date_equal,
        FilterOperator.date_not_equal,
        FilterOperator.date_after,
        FilterOperator.date_strictly_after,
        FilterOperator.date_before,
        FilterOperator.date_strictly_before,
        FilterOperator.date_between,
    }

    if type in date_types:
        low = _to_date_value(low)
        if type == FilterOperator.date_between:
            high = _to_date_value(high)

        if _is_datetime_column(col):
            return _get_datetime_date_filter_expression(
                col=col, type=type, low=low, high=high
            )

    simple_ops = {
        FilterOperator.greater: lambda: col > low,
        FilterOperator.greater_or_equal: lambda: col >= low,
        FilterOperator.less: lambda: col < low,
        FilterOperator.less_or_equal: lambda: col <= low,
        FilterOperator.equal: lambda: col == low,
        FilterOperator.date_equal: lambda: sa.cast(col, sa.Date)
        == sa.cast(low, sa.Date),
        FilterOperator.date_not_equal: lambda: sa.cast(col, sa.Date)
        != sa.cast(low, sa.Date),
        FilterOperator.date_after: lambda: sa.cast(col, sa.Date)
        >= sa.cast(low, sa.Date),
        FilterOperator.date_strictly_after: lambda: sa.cast(col, sa.Date)
        > sa.cast(low, sa.Date),
        FilterOperator.date_before: lambda: sa.cast(col, sa.Date)
        <= sa.cast(low, sa.Date),
        FilterOperator.date_strictly_before: lambda: sa.cast(col, sa.Date)
        < sa.cast(low, sa.Date),
        FilterOperator.exact_search: lambda: col == low,
        FilterOperator.not_equal: lambda: col != low,
        FilterOperator.fuzzy_search: lambda: col.like(f"%{low}%"),
        FilterOperator.not_fuzzy_search: lambda: col.not_like(f"%{low}%"),
        FilterOperator.is_null: lambda: col.is_(None),
        FilterOperator.is_not_null: lambda: col.isnot(None),
        FilterOperator.multiselect: lambda: (
            sa.text("1 = 0")
            if not low
            else sa.text(
                f"{_quote_identifier(col.name)} IN ({', '.join(_sanitize_string_value(v) for v in low)})"
            )
        ),
        FilterOperator.begins_with: lambda: col.like(f"{low}%"),
        FilterOperator.ends_with: lambda: col.like(f"%{low}"),
    }

    complex_ops = {
        FilterOperator.is_null_or_empty: lambda: sa.or_(col.is_(None), col == ""),
        FilterOperator.is_not_null_or_empty: lambda: sa.or_(col.isnot(None), col != ""),
        FilterOperator.multiselect_or_blank: lambda: (
            sa.or_(col.is_(None), col == "")
            if not low
            else sa.or_(
                sa.text(
                    f"{_quote_identifier(col.name)} IN ({', '.join(_sanitize_string_value(v) for v in low)})"
                ),
                sa.or_(col.is_(None), col == ""),
            )
        ),
        FilterOperator.between: lambda: sa.and_(col >= low, col <= high),
        FilterOperator.date_between: lambda: sa.and_(
            sa.cast(col, sa.Date) >= sa.cast(low, sa.Date),
            sa.cast(col, sa.Date) <= sa.cast(high, sa.Date),
        ),
    }

    if type in simple_ops:
        return simple_ops[type]()
    if type in complex_ops:
        return complex_ops[type]()
    raise ValueError(f"Filter operator {type} is not supported.")


def get_is_deleted_expression(table):
    if not OdbcDatabase.has_col(table, GenericTableColumns.is_deleted):
        return None
    col = OdbcDatabase.get_col(table, GenericTableColumns.is_deleted)
    return or_(col == False, col.is_(None))


def _sanitize_string_value(value: str) -> str:
    """Sanitize a string value for safe inclusion in SQL IN clause."""

    if value is None:
        return "NULL"

    # Convert to string and escape single quotes by doubling them
    sanitized = str(value).replace("'", "''")
    return f"'{sanitized}'"


def _quote_identifier(name: str) -> str:
    return "[" + name.replace("]", "]]") + "]"


def _to_date_value(value: Any) -> dt.date:
    if value is None:
        return None
    if isinstance(value, dt.datetime):
        return value.date()
    if isinstance(value, dt.date):
        return value
    return parser.parse(str(value), fuzzy=True).date()


def _is_datetime_column(col: sa.Column) -> bool:
    return isinstance(col.type, sa.DateTime)


def _get_day_bounds(value: dt.date) -> tuple[dt.datetime, dt.datetime]:
    day_start = dt.datetime.combine(value, dt.time.min)
    next_day_start = day_start + dt.timedelta(days=1)
    return day_start, next_day_start


def _get_datetime_date_filter_expression(
    col: sa.Column, type: FilterOperator, low: dt.date, high: dt.date | None = None
):
    low_start, low_next = _get_day_bounds(low)

    if type == FilterOperator.date_equal:
        return sa.and_(col >= low_start, col < low_next)
    if type == FilterOperator.date_not_equal:
        return sa.or_(col < low_start, col >= low_next)
    if type == FilterOperator.date_after:
        return col >= low_start
    if type == FilterOperator.date_strictly_after:
        return col >= low_next
    if type == FilterOperator.date_before:
        return col < low_next
    if type == FilterOperator.date_strictly_before:
        return col < low_start
    if type == FilterOperator.date_between:
        _, high_next = _get_day_bounds(high)
        return sa.and_(col >= low_start, col < high_next)

    raise ValueError(f"Filter operator {type} is not supported.")


class DataRepository:
    def __init__(self, database: OdbcDatabase):
        self.database = database

    # ----------------------------------- Read ----------------------------------- #

    def get_select_statement(
        self,
        table: sa.Table,
        columns: list[str] | None = None,
        jsonable: bool = False,
        distinct: bool = False,
    ):
        if not columns:
            # use all columns
            columns = list(table.c.keys())

        # remove duplicate column names
        columns = list(dict.fromkeys(columns))

        # case-insensitive column names

        columns = [
            OdbcDatabase.get_col(table, c)
            for c in columns
            if OdbcDatabase.has_col(table, c)
        ]

        # keep only existing columns
        columns = [c for c in columns if c is not None]

        if jsonable:
            columns = self.get_jsonable_columns(columns)

        query = sa.select(*columns)

        if distinct:
            query = query.distinct()

        return query

    def get_jsonable_columns(self, columns: list[sa.Column]):
        jsonable_cols = []

        for c in columns:
            if c.type.python_type == dt.date:
                jsonable_cols.append(c.label(c.name).cast(sa.String))
            elif c.type.python_type == dt.datetime:
                jsonable_cols.append(c.label(c.name).cast(sa.String))
            else:
                jsonable_cols.append(c)

        return jsonable_cols

    def read_table(
        self, table: str | sa.Table | sa.orm.DeclarativeMeta, schema: str | None = None
    ) -> pd.DataFrame:
        """Reads the content of a table as data frame.

        Args:
            table (Union[str, sa.Table, sa.orm.DeclarativeMeta]): Table to be read from
            schema (str, optional): Table schema. Only considered if the table name is passed as string. Defaults to None.

        Returns:
            pd.DataFrame: Result data frame.
        """
        table = self.database.get_table(table=table, schema=schema)
        return self.read_table_where(table=table, schema=schema)

    def read_query(
        self, query: DataQuery, jsonable: bool = False, distinct: bool = False
    ) -> pd.DataFrame:
        """Reads the content of a table as data frame.

        Args:
            query (DataQuery): Query to be executed.

        Returns:
            pd.DataFrame: Result data frame.
        """
        return self.read_table_with_filters(
            table=query.table,
            schema=query.schema_,
            columns=query.columns,
            filters=query.filters,
            nested_filters=query.nested_filters,
            drill_through_filters=query.drill_through_filters,
            jsonable=jsonable,
            distinct=distinct,
        )

    def read_table_with_filters(
        self,
        table: str | sa.Table | sa.orm.DeclarativeMeta,
        columns: list[str] | None = None,
        filters: list[Filter] | None = None,
        nested_filters: NestedFilterGroup | None = None,
        drill_through_filters: list[Sequence[DrillTroughFilter]] | None = None,
        schema: str | None = None,
        as_df: bool = True,
        conv_types: bool = False,
        jsonable: bool = False,
        distinct: bool = False,
        filter_deleted: bool = True,
    ) -> pd.DataFrame | list[Dict]:
        """Reads the content of a table as data frame or list of dictionaries.

        Args:
            table (Union[str, sa.Table, sa.orm.DeclarativeMeta]): Table to be read from
            columns (list[str], optional): Columns to be read. Defaults to None.
            filters (list[Filter], optional): Filters to be applied. Defaults to None.
            schema (str, optional): Table schema. Only considered if the table name is passed as string. Defaults to None.
            as_df (bool, optional): If True, returns a data frame. Otherwise, returns a list of dictionaries. Defaults to True.

        Returns:
            Union[pd.DataFrame, list[Dict]]: Result data frame or list of dictionaries.
        """
        table = self.database.get_table(table=table, schema=schema)

        query = self.get_select_statement(
            table=table, columns=columns, jsonable=jsonable, distinct=distinct
        )

        query = self._add_filters_to_table_query(
            table=table, query=query, filters=filters
        )

        query = self._add_drill_through_filters_to_table_query(
            table=table, query=query, drill_through_filters=drill_through_filters
        )

        if nested_filters:
            expr = get_nested_filter_expression(table, nested_filters)
            if expr is not None:
                query = query.filter(expr)

        if filter_deleted:
            is_deleted_expr = get_is_deleted_expression(table)
            if is_deleted_expr is not None:
                query = query.filter(is_deleted_expr)

        with self.database.engine.connect() as con:
            result = pd.read_sql_query(sql=query, con=con)

        if conv_types:
            column_types = {
                c.name: c.type.python_type
                for c in table.columns
                if c.name in result.columns and c.type.python_type != str
            }
            # NULLs in numeric columns will become NaN
            # Type conversion fails w/o errors="ignore"
            # Above type 'str' is excluded because the default column type is 'object'
            # which is also the default column type for strings.
            # If the conversion is applied nonetheless, empty values will become a string 'None'
            result = result.astype(column_types, errors="ignore")

        if not as_df:
            # remove NaNs
            result = result.replace({np.nan: None})
            result = result.to_dict(orient="records")

        return result

    def read_table_where(
        self,
        table: str | sa.Table | sa.orm.DeclarativeMeta,
        schema: str | None = None,
        **filters,
    ) -> pd.DataFrame:
        """Reads the content of a table as data frame.

        Args:
            table (Union[str, sa.Table, sa.orm.DeclarativeMeta]): Table to be read from
            schema (str, optional): Table schema. Only considered if the table name is passed as string. Defaults to None.
            **filters: Filters to be applied. Pass as "column_name=value".

        Returns:
            pd.DataFrame: Result data frame.
        """
        adv_filters = self._get_kwarg_filters(**filters)
        return self.read_table_with_filters(
            table=table, schema=schema, filters=adv_filters
        )

    def _get_kwarg_filters(self, **filters):
        adv_filters = []
        for column, value in filters.items():
            adv_filters.append(
                Filter(type=FilterOperator.equal, value=value, name=column)
            )
        return adv_filters

    def _add_filters_to_table_query(self, table, query, filters: list[Filter]):
        if not filters:
            return query

        for f in filters:
            if not OdbcDatabase.has_col(table, f.name):
                continue
            col = OdbcDatabase.get_col(table, f.name)
            expr = get_filter_expression(
                col=col, type=f.type, low=f.value, high=f.value2
            )
            query = query.filter(expr)

        return query

    def _add_drill_through_filters_to_table_query(
        self, table, query, drill_through_filters: list[Sequence[DrillTroughFilter]]
    ):
        if not drill_through_filters:
            return query
        or_conditions = []
        for r in drill_through_filters:
            conditions = [
                OdbcDatabase.get_col(table, f.column_name) == f.value
                for f in r
                if OdbcDatabase.has_col(table, f.column_name)
            ]
            or_conditions.append(sa.and_(*conditions))

        final_condition = sa.or_(*or_conditions)
        return query.filter(final_condition)

    # ----------------------------------- Write ---------------------------------- #

    def write_table(
        self,
        model: str | sa.Table | sa.orm.DeclarativeMeta,
        df: pd.DataFrame | list[Dict],
        schema: str | None = None,
        chunked: bool = True,
    ) -> None:
        """Writes a data frame or sequence of dictionaries to a table.

        Args:
            model (Union[str, sa.Table, sa.orm.DeclarativeMeta]): Table to be written to
            df (Union[pd.DataFrame, list[Dict]]): Data to be written
            schema (str, optional): Table schema. Only considered if the table name is passed as string. Defaults to None.
            chunked (bool, optional): If True, writes the data in chunks. Defaults to True.
        """
        table = self.database.get_table(table=model, schema=schema)

        if isinstance(df, pd.DataFrame):
            # Reduce to relevant columns
            df = df.drop(columns=df.columns.difference(table.c.keys()))
            df = df.replace({np.nan: None})
            df = df.to_dict(orient="records")
        else:
            keys = table.c.keys()
            df = [{k: v for k, v in row.items() if k in keys} for row in df]

        if len(df) == 0:
            logging.warning(f"Empty data frame for {table}. Not storing.")
            return

        # Use scoped session if given, create temporary otherwise
        if len(df) < BATCH_SIZE or not chunked:
            self._write_batch(model=table, df=df)
        else:
            nb_batches = len(df) / BATCH_SIZE
            batch_list = np.array_split(df, nb_batches)
            for batch in batch_list:
                self._write_batch(model=table, df=list(batch))

    def _write_batch(self, model: sa.Table, df: list[Dict]):
        """Writes a data frame to a table within a transactional scope.

        Args:
            model (sa.orm.DeclarativeMeta):  Table model to be written to.
            df (pd.DataFrame): Data frame containing the data to be written.
        """
        query = model.insert()
        with self.database.engine.connect() as con:
            con.execute(query, df)
            con.commit()

    # ---------------------------------- Delete ---------------------------------- #

    def delete_table(
        self, table: str | sa.Table | sa.orm.DeclarativeMeta, schema: str | None = None
    ):
        """Deletes all rows from a table.

        Args:
            table (Union[str, sa.Table, sa.orm.DeclarativeMeta]): Table to be deleted from
            schema (str, optional): Table schema. Only considered if the table name is passed as string. Defaults to None.
        """
        table = self.database.get_table(table=table, schema=schema)
        query = table.delete()
        with self.database.engine.connect() as con:
            con.execute(query)
            con.commit()

    def delete_table_with_filters(
        self,
        table: str | sa.Table | sa.orm.DeclarativeMeta,
        filters: list[Filter],
        schema: str | None = None,
    ):
        """Deletes all rows from a table.

        Args:
            table (Union[str, sa.Table, sa.orm.DeclarativeMeta]): Table to be deleted from
            filters (list[Filter]): Filters to be applied.
            schema (str, optional): Table schema. Only considered if the table name is passed as string. Defaults to None.
        """
        table = self.database.get_table(table=table, schema=schema)
        query = table.delete()
        query = self._add_filters_to_table_query(table, query, filters)
        with self.database.engine.connect() as con:
            con.execute(query)
            con.commit()

    def delete_table_where(
        self,
        table: str | sa.Table | sa.orm.DeclarativeMeta,
        schema: str | None = None,
        **filters,
    ):
        """Deletes all rows from a table.

        Args:
            table (Union[str, sa.Table, sa.orm.DeclarativeMeta]): Table to be deleted from
            schema (str, optional): Table schema. Only considered if the table name is passed as string. Defaults to None.
            **filters: Filters to be applied. Pass as "column_name=value".
        """
        adv_filters = self._get_kwarg_filters(**filters)
        self.delete_table_with_filters(table=table, filters=adv_filters, schema=schema)
