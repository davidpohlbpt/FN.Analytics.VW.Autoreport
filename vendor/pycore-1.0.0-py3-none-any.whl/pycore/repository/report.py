from typing import Any

import pandas as pd
import sqlalchemy as sa
from dateutil import parser

from pycore.repository.data import DataRepository, get_is_deleted_expression
from pycore.resources.odbc import OdbcDatabase
from pycore.schemas import (
    AggregationFunction,
    Filter,
    FilterExpression,
    FilterOperator,
    Query,
)

RANK_LABEL = "___rnk"


def get_aggregation_expression(
    col: sa.Column, agg: AggregationFunction
) -> sa.sql.expression:
    """Returns a SQLAlchemy expression for an aggregation.

    Args:
        col (sa.Column): Column to be aggregated.
        agg (AggregationFunction): Aggregation function.

    Raises:
        ValueError: Raises an exception if the aggregation function is not supported.

    Returns:
        sa.sql.expression: SQLAlchemy select expression.
    """
    if agg is None:
        return col
    elif agg == AggregationFunction.COUNT:
        return sa.func.count(col).label(col.name)
    elif agg == AggregationFunction.SUM:
        return sa.func.sum(col).label(col.name)
    elif agg == AggregationFunction.AVG:
        return sa.func.avg(col).label(col.name)
    elif agg == AggregationFunction.MIN:
        return sa.func.min(col).label(col.name)
    elif agg == AggregationFunction.MAX:
        return sa.func.max(col).label(col.name)
    else:
        raise ValueError(f"Aggregation {agg} is not supported.")


def get_filter_expression(
    col: sa.Column, type: FilterOperator, low: Any, high: Any = None
) -> sa.sql.expression:
    """Returns a SQLAlchemy expression for a filter.

    Args:
        col (sa.Column): Column to be filtered.
        type (FilterOperator): Filter operator.
        low (Any): Lower bound.
        high (Any, optional): Upper bound. Defaults to None.

    Raises:
        ValueError: Raises an exception if the filter operator is not supported.

    Returns:
        sa.sql.expression: SQLAlchemy where expression.
    """
    filter_funcs = {
        FilterOperator.greater: lambda: col > low,
        FilterOperator.greater_or_equal: lambda: col >= low,
        FilterOperator.less: lambda: col < low,
        FilterOperator.less_or_equal: lambda: col <= low,
        FilterOperator.equal: lambda: col == low,
        FilterOperator.date_equal: lambda: sa.cast(col, sa.Date)
        == sa.cast(low, sa.Date),
        FilterOperator.date_not_equal: lambda: sa.cast(col, sa.Date)
        != sa.cast(low, sa.Date),
        FilterOperator.date_after: lambda: sa.cast(col, sa.Date)
        >= sa.cast(low, sa.Date),
        FilterOperator.date_strictly_after: lambda: sa.cast(col, sa.Date)
        > sa.cast(low, sa.Date),
        FilterOperator.date_before: lambda: sa.cast(col, sa.Date)
        <= sa.cast(low, sa.Date),
        FilterOperator.date_strictly_before: lambda: sa.cast(col, sa.Date)
        < sa.cast(low, sa.Date),
        FilterOperator.date_between: lambda: sa.and_(
            sa.cast(col, sa.Date) >= sa.cast(low, sa.Date),
            sa.cast(col, sa.Date) <= sa.cast(high, sa.Date),
        ),
        FilterOperator.exact_search: lambda: col.like(low),
        FilterOperator.not_equal: lambda: col != low,
        FilterOperator.between: lambda: sa.and_(col >= low, col <= high),
        FilterOperator.fuzzy_search: lambda: (
            get_filter_expression(
                col, FilterOperator.date_equal, parser.parse(low, fuzzy=True).date()
            )
            if is_date_column(col)
            else col.like(f"%{low}%")
        ),
        FilterOperator.not_fuzzy_search: lambda: col.not_like(f"%{low}%"),
        FilterOperator.is_null: lambda: col.is_(None),
        FilterOperator.is_not_null: lambda: col.isnot(None),
        FilterOperator.is_not_null_or_empty: lambda: sa.and_(
            col.isnot(None), col != ""
        ),
        FilterOperator.multiselect: lambda: (
            sa.text("1 = 0")
            if not low
            else sa.text(
                f"{_quote_identifier(col.name)} IN ({', '.join(_sanitize_string_value(v) for v in low)})"
            )
        ),
        FilterOperator.multiselect_or_blank: lambda: (
            sa.or_(col.is_(None), col == "")
            if not low
            else sa.or_(
                sa.text(
                    f"{_quote_identifier(col.name)} IN ({', '.join(_sanitize_string_value(v) for v in low)})"
                ),
                sa.or_(col.is_(None), col == ""),
            )
        ),
        FilterOperator.is_null_or_empty: lambda: sa.or_(col.is_(None), col == ""),
        FilterOperator.begins_with: lambda: col.like(f"{low}%"),
        FilterOperator.ends_with: lambda: col.like(f"%{low}"),
    }

    if type in filter_funcs:
        return filter_funcs[type]()
    else:
        raise ValueError(f"Filter operator {type} is not supported.")


def is_date_column(col: sa.Column) -> bool:
    return isinstance(col.type, sa.Date) or isinstance(col.type, sa.DateTime)


def get_minmax_filtered_query(table: sa.Table, sql: sa.sql.Select, filter_: Filter):
    if filter_.type not in (FilterOperator.is_max, FilterOperator.is_min):
        return sql

    col = OdbcDatabase.get_col(table, filter_.name)

    if filter_.type == FilterOperator.is_max:
        col = col.desc()

    rank_col = sa.func.rank().over(order_by=col).label(RANK_LABEL)
    rank_filter = sa.text(f"{RANK_LABEL} = 1")

    subquery = sql.add_columns(rank_col).subquery()

    columns = [c for c in subquery.columns if c.name != RANK_LABEL]

    return sa.select(*columns).where(rank_filter)


def resolve_nested_filter(table: sa.Table, filter_expr: FilterExpression):

    expressions = []

    for f in filter_expr.filters:
        if isinstance(f, Filter):
            col = OdbcDatabase.get_col(table, f.name)
            expr = get_filter_expression(
                col=col, type=f.type, low=f.value, high=f.value2
            )
        elif isinstance(f, FilterExpression):
            expr = resolve_nested_filter(table, f)
        else:
            raise ValueError(f"Filter type {type(f)} is not supported.")

        if expr is not None:
            expressions.append(expr)

    if len(expressions) == 0:
        return None
    elif filter_expr.all_must_be_met:
        return sa.and_(*expressions)
    else:
        return sa.or_(*expressions)


def add_order_by(query: Query, table: sa.Table, sql: sa.sql.Select):
    if query.order_by is None:
        return sql

    for col, asc in query.order_by:
        col = OdbcDatabase.get_col(table, col)
        if col is None:
            continue
        if asc:
            sql = sql.order_by(col)
        else:
            sql = sql.order_by(sa.desc(col))

    return sql


def add_group_by(query: Query, table: sa.Table, sql: sa.sql.Select):
    if not query.groupby:
        return sql

    groupby = [OdbcDatabase.get_col(table, c) for c in query.groupby]

    if query.minmax_filter and query.minmax_filter.name not in query.groupby:
        groupby += [OdbcDatabase.get_col(table, query.minmax_filter.name)]

    groupby = [c for c in groupby if c is not None]
    return sql.group_by(*groupby)


def _sanitize_string_value(value: str) -> str:
    """Sanitize a string value for safe inclusion in SQL IN clause."""

    if value is None:
        return "NULL"

    # Convert to string and escape single quotes by doubling them
    sanitized = str(value).replace("'", "''")
    return f"'{sanitized}'"


def _quote_identifier(name: str) -> str:
    return "[" + name.replace("]", "]]") + "]"


class ReportDataRepository(DataRepository):
    """Repository to query data for generic reports."""

    def get_query_result(self, query: Query) -> pd.DataFrame:
        sql = self._get_sql_query(query)
        with self.database.engine.connect() as con:
            return pd.read_sql_query(sql=sql, con=con)

    def get_raw_query_result(self, query: Query, raw_sql: str):

        query.select = None
        inner_query = self._get_sql_query(query)
        inner_query = inner_query.compile(
            dialect=self.database.engine.dialect,
            compile_kwargs={"literal_binds": True},
        )

        outer_query = raw_sql.replace("?", f"( {inner_query.string} ) as inner_query")
        sql = sa.text(outer_query)

        with self.database.engine.connect() as conn:
            return conn.execute(sql).all()

    def get_query_count(self, query: Query) -> pd.DataFrame:
        sql = self._get_sql_query(query)
        count = sa.func.count().label("count")
        sql = sa.select(count).select_from(sql.alias("subquery"))
        with self.database.engine.connect() as conn:
            result = conn.execute(sql)
            return result.scalar()

    def _get_sql_query(self, query: Query):
        table = self.database.get_table(table=query.table_name, schema=query.schema_)
        if not query.select:
            # use all columns
            select = [c for c in table.c]
        else:
            select = [self.database.get_col(table, c) for c in query.select]
            select = [c for c in select if c is not None]

        if query.aggregation:
            for c, agg in query.aggregation.items():
                col = self.database.get_col(table, c)
                agg = get_aggregation_expression(col, agg)
                select[select.index(col)] = agg

        sql = sa.select(*select)

        if query.distinct:
            sql = sql.distinct()

        if query.filters:
            expr = resolve_nested_filter(table, query.filters)
            if expr is not None:
                sql = sql.filter(expr)

        is_deleted_expr = get_is_deleted_expression(table)
        if is_deleted_expr is not None:
            sql = sql.filter(is_deleted_expr)

        sql = add_group_by(query, table, sql)

        if query.minmax_filter:
            sql = get_minmax_filtered_query(table, sql, query.minmax_filter)

        sql = add_order_by(query, table, sql)

        if query.offset:
            sql = sql.offset(query.offset)

        if query.limit:
            sql = sql.limit(query.limit)

        return sql
