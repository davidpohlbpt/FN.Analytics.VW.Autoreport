import json

import pydantic
import sqlalchemy as sa

from pycore.repository.crud import CRUDRepository
from pycore.resources.odbc import OdbcDatabase
from pycore.utils.collections import (
    get_flat_list_from_model,
    get_nested_dict,
    has_complex_type,
    recursive_update,
    to_json_type,
)
from pycore.utils.pydantic import MakeOptional


class SettingTypeBaseModel:
    # ------------------------------- Primary keys ------------------------------- #

    setting_type_id = sa.Column(sa.String(200), primary_key=True)

    # ------------------------------ Main properties ----------------------------- #

    is_complex = sa.Column(sa.Boolean, nullable=False)
    default = sa.Column(sa.String, nullable=True)


class SettingBaseModel:
    # ------------------------------- Primary keys ------------------------------- #

    entity_id = sa.Column(sa.Integer, primary_key=True)
    setting_type_id = sa.Column(sa.String(200), primary_key=True)

    # ------------------------------ Main properties ----------------------------- #

    value = sa.Column(sa.String, nullable=True)


class SettingsRepository:
    def __init__(
        self,
        database: OdbcDatabase,
        model,
        setting_type_model: SettingTypeBaseModel,
        setting_model: SettingBaseModel,
    ):
        self.database = database
        self.model = model
        self.setting_type_repo = CRUDRepository(model=setting_type_model)
        self.setting_repo = CRUDRepository(model=setting_model)

        class UpdateModel(self.model, MakeOptional):
            pass

        self.update_model = UpdateModel

    def save_defaults(self, settings: pydantic.BaseModel) -> None:
        """Saves the default settings.

        Before saving, the settings are validated against the model.
        If a setting does not have a default value, it is set to None.
        The validation does not fail in this case.

        Args:
            settings (pydantic.BaseModel): The settings to save. Must be valid.
        """
        settings = self.update_model(
            **settings.model_dump(exclude_none=True)
        )  # validate settings
        flat_list = get_flat_list_from_model(settings)
        with self.database.session_scope() as db:
            for key, value in flat_list:
                is_complex = has_complex_type(value, date_is_complex=False)
                value = to_json_type(value)
                self.setting_type_repo.create_or_update(
                    db, key, default=value, is_complex=is_complex
                )

    def save_entity(self, settings: pydantic.BaseModel, entity_id: int) -> None:
        """Saves the settings for the given entity.

        Before saving, the settings are validated against the model.

        Args:
            settings (pydantic.BaseModel): The settings to save. Must be valid.
            entity_id (int): The entity id.
        """
        settings = self.model.model_validate(settings.model_dump())  # validate settings
        flat_list = get_flat_list_from_model(settings)
        with self.database.session_scope() as db:
            for key, value in flat_list:
                setting_type = self.setting_type_repo.get(db, key)
                value = to_json_type(value)

                if self.is_equal_value(setting_type.default, value):
                    continue  # don't store defaults redundantly
                self.setting_repo.create_or_update(db, (entity_id, key), value=value)

    def is_equal_value(
        self, db_val: str, new_val: str | int | float | bool | None
    ) -> bool:
        if db_val is None and new_val is None:
            return True
        elif db_val == new_val:
            return True
        elif db_val == str(new_val):
            return True
        else:
            return False

    def _get_nested_defaults(self):
        with self.database.session_scope() as db:
            setting_types = self.setting_type_repo.get_all(db)

            flat_list = []
            for s in setting_types:
                value = s.default

                # NULL is not a valid default value
                if value is None:
                    continue

                if s.is_complex:
                    value = json.loads(value)

                flat_list.append((s.setting_type_id, value))

        return get_nested_dict(flat_list)

    def _get_nested_entity(self, entity_id: int):
        with self.database.session_scope() as db:
            settings = self.setting_repo.get_all_where(db, entity_id=entity_id)
            setting_types = self.setting_type_repo.get_all(db)

            flat_list = []
            for s in settings:
                st = next(
                    (
                        st
                        for st in setting_types
                        if st.setting_type_id == s.setting_type_id
                    ),
                    None,
                )
                if st is None:
                    # Should not occur due to foreign key constraint
                    raise ValueError(
                        f"Setting type '{s.setting_type_id}' for entity '{entity_id}' not found."
                    )  # pragma: no cover
                value = json.loads(s.value) if st.is_complex else s.value
                flat_list.append((s.setting_type_id, value))
        return get_nested_dict(flat_list)

    def get_defaults(self) -> pydantic.BaseModel:
        """Returns the default settings as a pydantic model.

        If a setting does not have a default value, the validation does not fail.
        Instead, the value is set to None.
        """
        nested_dict = self._get_nested_defaults()
        return self.update_model.model_validate(nested_dict)

    def get_entity(self, entity_id: int) -> pydantic.BaseModel:
        """Returns the settings for the given entity as a pydantic model.

        A full validation is performed.
        """
        nested_defaults = self._get_nested_defaults()
        nested_entity = self._get_nested_entity(entity_id=entity_id)
        nested_entity = recursive_update(nested_defaults, nested_entity)
        return self.model.model_validate(nested_entity)
