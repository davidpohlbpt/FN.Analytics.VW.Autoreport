import re
import uuid
from datetime import datetime

import pydantic
import sqlalchemy as sa
from sqlalchemy.dialects.mssql import DATETIME2, UNIQUEIDENTIFIER

from pycore import easy
from pycore import schemas as s
from pycore.resources.odbc import SqlServerDatabase
from pycore.schemas import GenericTableColumns
from pycore.utils.database import ColumnDoesNotExistError


def _quote_identifier(name: str) -> str:
    return "[" + name.replace("]", "]]") + "]"


def _safe_bind_name(name: str) -> str:
    return re.sub(r"\W", "_", name)


class TableEditPartialResponse(pydantic.BaseModel):
    success: bool
    details: str | None = None


def transform_field_data_type(field: s.FieldValue) -> any:
    if field.new_value is None:
        return None  # Assuming None is always valid

    def transform_boolean(value: str) -> bool:
        if value.lower() not in ["true", "false"]:
            raise ValueError("Boolean value must be 'true' or 'false'")
        return value.lower() == "true"

    def transform_restricted_boolean(value: str) -> bool:
        if value.lower() != "true":
            raise ValueError("Restricted boolean update value must be 'true'")
        return True

    type_transformers = {
        s.ColumnType.BOOLEAN: transform_boolean,
        s.ColumnType.RESTRICTED_BOOLEAN: transform_restricted_boolean,
    }

    transformer = type_transformers.get(field.data_type)
    if transformer is None:
        return field.new_value

    return transformer(field.new_value)


class TableEditRepository:
    """
    A repository for editing tables in SQL Server.

    This implementation is specifically designed for SQL Server and uses SQL Server-specific features
    such as OUTPUT INTO for compatibility with triggers during insert, update, and delete operations.
    """

    def __init__(self, database: SqlServerDatabase, email: str):
        self.database = database
        self.transaction_id = str(uuid.uuid4())
        self.email = email
        self.edit_datetime = datetime.now()

    def set_audit_table(self, has_audit: bool):
        if has_audit:
            self.audit_tab = self.database.get_table(
                table="T_AUDIT_HistorizedData", schema="dbo"
            )
        else:
            self.audit_tab = None

    def set_data_table(self, data_table: s.DataTable):
        self.data_tab = self.database.get_table(
            table=data_table.table_name, schema=data_table.table_schema
        )

    def _extend_edit_table_values(self, values: dict) -> dict:
        extended_values = {
            **values,
            GenericTableColumns.last_edited_at.value: self.edit_datetime,
            GenericTableColumns.last_edited_by.value: self.email,
            GenericTableColumns.last_transaction_id.value: self.transaction_id,
            GenericTableColumns.last_transaction_date.value: datetime.now(),
        }
        return extended_values

    def _get_audit_table_values(
        self, field, before_value, after_value, row_id, event_type
    ) -> dict:
        values = {
            "Table": self.data_tab.name,
            "Field": field,
            "BeforeValue": before_value,
            "AfterValue": after_value,
            "RowID": row_id,
            "EventType": event_type,
            "TransactionOwner": self.email,
            "Automatic": False,
            "Reason": None,
            "TransactionID": self.transaction_id,
            "TransactionDate": datetime.now(),
        }
        return values

    def insert_rows(
        self, table_insert: list[s.InsertOperation] | None
    ) -> TableEditPartialResponse:

        if not table_insert:
            return TableEditPartialResponse(success=False)

        try:
            insert_stmt, params = self._get_insert_stmt(table_insert)

            with self.database.session_scope() as db:
                result = db.execute(insert_stmt, params)

                rows = result.fetchall()
                new_rowid = [row.RowID for row in rows]

                if self.audit_tab is not None:
                    audit_stmt = self._get_audit_insert_stmt(table_insert, new_rowid)
                    db.execute(audit_stmt)

        except Exception as e:
            return TableEditPartialResponse(success=False, details=str(e))

        return TableEditPartialResponse(success=True)

    def update_rows(
        self, table_update: list[s.UpdateOperation] | None
    ) -> TableEditPartialResponse:

        if not table_update:
            return TableEditPartialResponse(success=False)

        try:
            update_statements = self._get_update_stmt(table_update)

            with self.database.session_scope() as db:
                update_details = {}
                for update_stmt, update_fields in update_statements:
                    result = db.execute(update_stmt)
                    for row in result:
                        row_id = row.RowID
                        update_details[row_id] = update_fields

                if self.audit_tab is not None:
                    audit_stmt = self._get_audit_update_stmt(update_details)
                    db.execute(audit_stmt)

        except Exception as e:
            return TableEditPartialResponse(success=False, details=str(e))

        return TableEditPartialResponse(success=True)

    def delete_rows(
        self, table_delete: list[s.DeleteOperation] | None
    ) -> TableEditPartialResponse:

        if not table_delete:
            return TableEditPartialResponse(success=False)

        try:
            delete_stmt = self._get_delete_stmt(table_delete)

            with self.database.session_scope() as db:
                result = db.execute(delete_stmt)
                del_row_id = result.scalars().fetchall()
                if self.audit_tab is not None:
                    audit_stmt = self._get_audit_delete_stmt(del_row_id)
                    db.execute(audit_stmt)

        except Exception as e:
            return TableEditPartialResponse(success=False, details=str(e))

        return TableEditPartialResponse(success=True)

    @property
    def _data_table_name(self) -> str:
        """
        Returns the name of the data table with schema if available.
        """
        name = _quote_identifier(self.data_tab.name)
        if self.data_tab.schema:
            return f"{_quote_identifier(self.data_tab.schema)}.{name}"
        return name

    def _get_insert_stmt(
        self, table_insert: list[s.InsertOperation] | None
    ) -> tuple[sa.sql.expression.TextClause, dict]:
        row_inserts = [
            {
                field.column_name: self.transform_field_insert_data_type(field)
                for field in insert_operation.insert_fields
            }
            for insert_operation in table_insert
        ]
        insert_stmt, params = self._get_insert_stmt_with_output(row_inserts)
        return insert_stmt, params

    def _get_insert_stmt_with_output(
        self, row_inserts: list[dict]
    ) -> tuple[sa.sql.expression.TextClause, dict]:
        """
        Constructs a raw SQL insert statement with OUTPUT clause for SQL Server.

        This function allows to circumvent the limitation of SQLAlchemy not supporting the OUTPUT clause for temporary tables in SQL Server,
        which is required to support triggers on insert statements.

        Args:
            row_inserts (list[dict]): List of dictionaries containing column names and values to insert.

        Returns:
            Tuple[sa.sql.expression.TextClause, dict]: Raw SQL insert statement with OUTPUT clause and parameters dictionary.
        """
        columns = list(row_inserts[0].keys())
        column_names = ", ".join(_quote_identifier(col) for col in columns)
        bind_names = {col: _safe_bind_name(col) for col in columns}

        values_clause_parts = [
            f"({', '.join(f':{bind_names[col]}_{idx}' for col in columns)})"
            for idx in range(len(row_inserts))
        ]

        params = {
            f"{bind_names[col]}_{idx}": row[col]
            for idx, row in enumerate(row_inserts)
            for col in columns
        }

        values_clause = ", ".join(values_clause_parts)
        data_table_name = self._data_table_name

        insert_stmt = sa.text(f"""
            SET NOCOUNT ON;
            DECLARE @TemporaryOutputTable TABLE (RowID INT);
            INSERT INTO {data_table_name} ({column_names})
            OUTPUT inserted.RowID INTO @TemporaryOutputTable
            VALUES {values_clause};
            SELECT RowID FROM @TemporaryOutputTable;
            """)

        return insert_stmt, params

    def _get_update_stmt(self, update_operations) -> list:
        update_statements = []

        # Construct separate update statements for each row update
        for update_operation in update_operations:
            values = {
                field.column_name: transform_field_data_type(field)
                for field in update_operation.update_fields
            }
            update_values = self._extend_edit_table_values(values)
            conditions = [
                f"{_quote_identifier(pk.column_name)} = :{_safe_bind_name(pk.column_name)}"
                for pk in update_operation.primary_keys
            ]
            where_clause = " AND ".join(conditions)

            data_table_name = self._data_table_name

            set_clause = ", ".join(
                f"{_quote_identifier(key)} = :{_safe_bind_name(key)}"
                for key in update_values.keys()
            )

            update_stmt = sa.text(f"""
                SET NOCOUNT ON;
                DECLARE @TemporaryOutputTable TABLE (RowID INT);
                UPDATE {data_table_name}
                SET {set_clause}
                OUTPUT inserted.RowID INTO @TemporaryOutputTable
                WHERE {where_clause};
                SELECT RowID FROM @TemporaryOutputTable;
                """)
            # Bind parameters for the update values
            for key, value in update_values.items():
                update_stmt = update_stmt.bindparams(
                    sa.bindparam(_safe_bind_name(key), value)
                )
            # Bind parameters for the primary keys
            for pk in update_operation.primary_keys:
                update_stmt = update_stmt.bindparams(
                    sa.bindparam(_safe_bind_name(pk.column_name), pk.value)
                )

            update_statements.append((update_stmt, update_operation.update_fields))

        return update_statements

    def _get_delete_stmt(self, delete_operations) -> str:
        conditions = []
        row_values = {}
        param_counter = 1
        for delete_operation in delete_operations:
            row_conditions = []
            for pk in delete_operation.primary_keys:
                param_name = f"{_safe_bind_name(pk.column_name)}_{param_counter}"
                row_conditions.append(
                    f"{_quote_identifier(pk.column_name)} = :{param_name}"
                )
                row_values[param_name] = pk.value
            conditions.append(f"({ ' AND '.join(row_conditions) })")
            param_counter += 1

        where_clause = " OR ".join(conditions)
        values = {GenericTableColumns.is_deleted.value: True}
        delete_values = self._extend_edit_table_values(values)

        data_table_name = self._data_table_name

        set_clause = ", ".join(
            f"{_quote_identifier(key)} = :{_safe_bind_name(key)}"
            for key in delete_values.keys()
        )

        delete_stmt = sa.text(f"""
            SET NOCOUNT ON;
            DECLARE @TemporaryOutputTable TABLE (RowID INT);
            UPDATE {data_table_name}
            SET {set_clause}
            OUTPUT deleted.RowID INTO @TemporaryOutputTable
            WHERE {where_clause};
            SELECT RowID FROM @TemporaryOutputTable;
            """)

        # Bind parameters for the delete values
        for key, value in delete_values.items():
            delete_stmt = delete_stmt.bindparams(
                sa.bindparam(_safe_bind_name(key), value)
            )

        # Bind parameters for the row conditions
        for param_name, value in row_values.items():
            delete_stmt = delete_stmt.bindparams(sa.bindparam(param_name, value))
        return delete_stmt

    def _get_audit_insert_stmt(self, insert_operations, new_row_id) -> str:
        row_insert = []
        for insert_operation, row_id in zip(insert_operations, new_row_id):
            for field in insert_operation.insert_fields:
                values = self._get_audit_table_values(
                    field=field.column_name,
                    before_value=None,
                    after_value=field.new_value,
                    row_id=row_id,
                    event_type="INSERT",
                )
                row_insert.append(values)
        insert_stmt = sa.insert(self.audit_tab).values(row_insert)
        return insert_stmt

    def _get_audit_update_stmt(self, update_details) -> str:
        row_insert = []
        for row_id, fields in update_details.items():
            for field in fields:
                values = self._get_audit_table_values(
                    field=field.column_name,
                    before_value=field.old_value,
                    after_value=field.new_value,
                    row_id=row_id,
                    event_type="UPDATE",
                )
                row_insert.append(values)
        insert_stmt = sa.insert(self.audit_tab).values(row_insert)
        return insert_stmt

    def _get_audit_delete_stmt(self, del_row_id) -> str:
        row_insert = []
        for row_id in del_row_id:
            values = self._get_audit_table_values(
                field=GenericTableColumns.is_deleted.value,
                before_value=False,
                after_value=True,
                row_id=row_id,
                event_type="DELETE",
            )
            row_insert.append(values)
        insert_stmt = sa.insert(self.audit_tab).values(row_insert)
        return insert_stmt

    def transform_field_insert_data_type(
        self, field: s.FieldValue
    ) -> str | bool | None:
        if field.new_value is None:
            return None
        if self.data_tab.c[field.column_name].type.python_type != bool:
            return field.new_value
        if field.new_value.lower() not in ["true", "false"]:
            raise ValueError("Boolean value must be 'true' or 'false'")
        return field.new_value.lower() == "true"


def validate_data_columns_exist(
    table_edit_operations: s.TableEditOperations, data_table: sa.Table
) -> None:
    data_columns = set()
    if table_edit_operations.update_operations:
        for update_operation in table_edit_operations.update_operations:
            for field in update_operation.update_fields:
                data_columns.add(field.column_name)
    if table_edit_operations.insert_operations:
        for insert_operation in table_edit_operations.insert_operations:
            for field in insert_operation.insert_fields:
                data_columns.add(field.column_name)
    # Verify if all columns exist in the table
    missing_columns = data_columns - set(data_table.columns.keys())
    if missing_columns:
        raise ColumnDoesNotExistError(missing_columns, data_table)


def validate_update_data(
    table_edit_operations: s.TableEditOperations, data_table: sa.Table
) -> s.TableEditOperations:
    if not table_edit_operations.update_operations:
        return table_edit_operations  # Early return if update_operations is None

    with easy.database.session_scope() as db:
        for update_operation in table_edit_operations.update_operations:
            restricted_boolean_column_names = get_restricted_boolean_columns(
                update_operation
            )

            if restricted_boolean_column_names:
                current_values = fetch_current_values(
                    db, data_table, restricted_boolean_column_names, update_operation
                )
                compare_and_remove_fields(
                    table_edit_operations, update_operation, current_values
                )

    table_edit_operations.validate()
    return table_edit_operations


def get_restricted_boolean_columns(update_operation: s.UpdateOperation) -> list[str]:
    return [
        field.column_name
        for field in update_operation.update_fields
        if field.data_type == s.ColumnType.RESTRICTED_BOOLEAN
    ]


def fetch_current_values(
    db,
    data_table: sa.Table,
    column_names: list[str],
    update_operation: s.UpdateOperation,
):
    select_stmt = sa.select(*[data_table.c[col] for col in column_names]).where(
        sa.and_(
            *[
                data_table.c[pk.column_name] == pk.value
                for pk in update_operation.primary_keys
            ]
        )
    )
    result = db.execute(select_stmt)
    return result.fetchone()


def compare_and_remove_fields(
    table_edit_operations: s.TableEditOperations,
    update_operation: s.UpdateOperation,
    current_values,
):
    for field in update_operation.update_fields:
        if field.data_type == s.ColumnType.RESTRICTED_BOOLEAN:
            current_value = current_values._mapping[field.column_name]
            # Compare the old_value with the current value
            if str(current_value) != field.old_value:
                # remove current field from update_operations
                table_edit_operations.remove_field_from_update(
                    update_operation=update_operation, field=field
                )


def get_audit_table(meta: sa.MetaData) -> sa.Table:
    """
    Get the audit table for the given metadata
    """

    return sa.Table(
        "T_AUDIT_HistorizedData",
        meta,
        sa.Column("HistoryID", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column("TransactionID", UNIQUEIDENTIFIER),
        sa.Column("TransactionDate", DATETIME2(precision=3), default=sa.func.now()),
        sa.Column("TransactionOwner", sa.String),
        sa.Column("EventType", sa.String),
        sa.Column("Table", sa.String),
        sa.Column("RowID", sa.Integer),
        sa.Column("Field", sa.String),
        sa.Column("BeforeValue", sa.String),
        sa.Column("AfterValue", sa.String),
        sa.Column("Automatic", sa.Boolean),
        sa.Column("Reason", sa.String),
        schema="dbo",
    )
