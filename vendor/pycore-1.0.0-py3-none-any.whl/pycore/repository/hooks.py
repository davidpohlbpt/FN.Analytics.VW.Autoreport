import functools
import logging
import warnings
from collections.abc import Callable
from inspect import signature
from typing import Any

from pycore.enum import HookType
from pycore.repository.settings import SettingsRepository
from pycore.schemas import DataAction, DataQuery, Filter, FilterExpression, Query


def validate_hook(hook_type: str, expected_params: list[Any]):
    """Decorator for validating the hooked-in objects.

    Args:
        hook_type (str): The type of the hook.
        expected_params (list[Any]): The expected parameters of the hooked-in object.

    Raises:
        RuntimeError: If the web service was already started.
        ValueError: If the hooked-in object is not callable or if the number of parameters does not match.
        ValueError: If the parameter annotations do not match the expected annotations.
        ValueError: If the hook was already added.
    """

    def _validate_hook(func):
        def __validate_hook(repo: "HookRepository", hook_key: str, callable: Callable):
            if not repo.is_open:
                raise RuntimeError(
                    f"{hook_type.title()}s can only be hooked-in before the web services was started."
                )

            if not isinstance(callable, Callable):
                raise ValueError(
                    f"The hooked-in object for the {hook_type.lower()} '{hook_key}' must be callable."
                )

            act_params = list(signature(callable).parameters.values())
            if len(act_params) != len(expected_params):
                raise ValueError(
                    f"The hooked-in callable for the {hook_type.lower()} '{hook_key}' must take exactly {len(expected_params)} argument(s), "
                    f"not {len(act_params)}."
                )

            for i, (callable_param, param) in enumerate(
                zip(act_params, expected_params)
            ):
                if callable_param.annotation not in param:
                    raise ValueError(
                        f"The argument at position {i + 1} for the {hook_type.lower()} '{hook_key}' "
                        f"must be annotated as '{param}' not as '{callable_param.annotation}'."
                    )

            if hook_key in repo._hooks[hook_type]:
                logging.warning(
                    f"The {hook_type.lower()} '{hook_key}' was already hooked-in and is overwritten."
                )
            return func(repo, hook_key, callable)

        return __validate_hook

    return _validate_hook


def sfdl_compatibility(func):
    """Ensures that PyCore projects don't have to change their hook logic when migrating to the SFDL endpoints.

    Changing from the old "DataQuery" to the new "Query" can be done at the projects convenience.
    """

    # Hooked-in sources are validated beforehand, so we can assume that the callable has exactly one parameter.
    expected_param = list(signature(func).parameters.values())[0].annotation

    def convert_query(query: Query) -> DataQuery:
        """This conversion is only necessary for hooked-in data sources.

        It can be removed onces all PyCore projects & reports were migrated to the SFDL endpoints.
        For this purpose, it is sufficient that only a flat list of filters is supported.
        """

        def flatten_expr(expr: FilterExpression) -> list[Filter]:
            filters = []
            for filter_ in expr.filters:
                if isinstance(filter_, FilterExpression):
                    filters += flatten_expr(filter_)
                else:
                    filters.append(filter_)

            return filters

        filters = flatten_expr(query.filters)

        return DataQuery(
            schema_=query.schema_,
            table=query.table_name,
            columns=query.select,
            filters=filters,
        )

    @functools.wraps(func)
    def wrapper(query: Query | DataQuery):

        if isinstance(query, Query) and expected_param == DataQuery:
            warnings.warn(
                "pycore.schemas.DataQuery is deprecated. Use command uvicorn pycore.schemas.Query instead.",
            )
            query = convert_query(query)
        return func(query)

    return wrapper


class HookRepository:
    """A repository that allows to hook-in objects into the pycore."""

    def __init__(self):
        self.reset()

    @property
    def is_open(self) -> bool:
        """Returns whether the repository is open or not, depending on whether the web service was already started."""
        return self._open

    def reset(self):
        """Resets the repository to its initial state."""
        self._hooks = {t: {} for t in HookType}
        self._open = True

    @validate_hook(hook_type=HookType.INTERACTION, expected_params=[(DataAction,)])
    def hook_in_interaction(self, action: str, func: Callable) -> None:
        """Allows to hook-in a custom action into the data action endpoint.

        The hooked-in action must follow a strict form:

        - it must be a callable Python object (e.g. a function)
        - the object is called with a single parameter (the action)
        - the parameter is of type `pycore.data.schemas.Action` and also annotated accordingly.

        The action can return any result as long as it can be converted to a JSON object.
        This includes lists, dictionaries and scalar values (int, float, str).

        Args:
            action (str): Action name.
            func (Callable): Action to be executed.

        Raises:
            ValueError: The hooked-in action does not comply with the restrictions stated above.
        """
        self._hooks[HookType.INTERACTION][action] = func

    @validate_hook(hook_type=HookType.SOURCE, expected_params=[(DataQuery, Query)])
    def hook_in_source(self, source: str, func: Callable) -> None:
        """Allows to hook-in a custom source into the data retrieval endpoint.

        The hooked-in source must follow a strict form:

        - it must be a callable Python object (e.g. a function)
        - the object is called with a single parameter (the query)
        - the parameter is of type `pycore.data.schemas.DataQuery` and also annotated accordingly.
        - the object return value is of type `pycore.data.schemas.DataModel` and also annotated accordingly.

        Args:
            source (str): Data source name
            func (Callable): Query to be executed.

        Raises:
            ValueError: The hooked-in source does not comply with the restrictions stated above.
        """
        func = sfdl_compatibility(func)
        self._hooks[HookType.SOURCE][source] = func

    def hook_in_process(self, process: str, func: Callable) -> None:
        """Allows to hook-in a custom process into the tracker endpoint.

        The hooked-in process must follow a strict form:

        - it must be a callable Python object (e.g. a function)
        - the object is called with a single parameter (the load information)
        - the parameter is of type `pycore.repository.services.schemas.TrackerLoadInformation` and also annotated accordingly.

        The process can return any result as long as it can be converted to a JSON object.
        This includes lists, dictionaries and scalar values (int, float, str).

        Args:
            process (str): Process name.
            func (Callable): Process to be executed.

        Raises:
            ValueError: The hooked-in process does not comply with the restrictions stated above.
        """
        self._hooks[HookType.PROCESS][process] = func

    def get_sources(self) -> list[str]:
        """Returns all hooked-in data source names

        Returns:
            list[str]: List of data source names.
        """
        return list(self._hooks[HookType.SOURCE].keys())

    def get_interactions(self) -> list[str]:
        """Returns all hooked-in data action names.

        Returns:
            list[str]: List of data action names.
        """
        return list(self._hooks[HookType.INTERACTION].keys())

    def get_processes(self) -> list[str]:
        """Returns all hooked-in process names.

        Returns:
            list[str]: List of process names.
        """
        return list(self._hooks[HookType.PROCESS].keys())

    def is_hooked_in_source(self, source: str):
        return source in self._hooks[HookType.SOURCE]

    def is_hooked_in_interaction(self, action: str):
        return action in self._hooks[HookType.INTERACTION]

    def is_hooked_in_process(self, process: str):
        return process in self._hooks[HookType.PROCESS]

    def has_hooked_settings(self):
        return bool(self._hooks.get(HookType.SETTING))

    def get_interaction(self, name: str) -> Callable:
        """Returns a callable action if it is hooked-in.

        Args:
            name (str): Name of the action to be executed.

        Raises:
            NotImplementedError: The action is not hooked-in.

        Returns:
            Callable: Callable to execute the action.
        """
        if name in self._hooks[HookType.INTERACTION]:
            return self._hooks[HookType.INTERACTION][name]
        else:
            raise NotImplementedError(
                f"The action '{name}' must be hooked-in, otherwise it can be executed."
            )

    def get_process(self, name: str) -> Callable:
        """Returns a callable process if it is hooked-in.

        Args:
            name (str): Name of the process to be executed.

        Raises:
            NotImplementedError: The process is not hooked-in.

        Returns:
            Callable: Callable to execute the process.
        """
        if name in self._hooks[HookType.PROCESS]:
            return self._hooks[HookType.PROCESS][name]
        else:
            raise NotImplementedError(
                f"The process '{name}' must be hooked-in, otherwise it can be executed."
            )

    def get_source(self, name: str) -> Callable:
        """Returns a callable data source it is hooked-in.

        Args:
            name (str): Name of the data source to be queried.

        Raises:
            NotImplementedError: The query's source is not hooked-in.

        Returns:
            DataModel: Callable to execute the query.
        """
        if name in self._hooks[HookType.SOURCE]:
            return self._hooks[HookType.SOURCE][name]
        else:
            raise NotImplementedError(
                f"The source '{name}' must be hooked-in, otherwise it can be queried."
            )

    def hook_in_settings(self, settings_repo: SettingsRepository) -> None:
        """Allows to hook-in a custom settings repository into the pycore.

        Args:
            settings_repo (SettingsRepository): The settings repository to be hooked-in.

        """
        if self._hooks.get(HookType.SETTING):
            logging.warning(
                "The settings hook was already added and is overwritten. This is not recommended."
            )

        self._hooks[HookType.SETTING] = settings_repo

    def get_hooked_in_settings(self) -> SettingsRepository:
        """Returns the hooked-in settings repository.

        Raises:
            ValueError: The settings hook was not added.

        Returns:
            SettingsRepository: The hooked-in settings repository.
        """

        if HookType.SETTING not in self._hooks:
            raise ValueError("The settings hook was not added and cannot be retrieved.")

        return self._hooks[HookType.SETTING]

    def close(self):
        """Closes the repository and prevents further hook-ins."""
        logging.info("Closing hook repository.")
        self._open = False
