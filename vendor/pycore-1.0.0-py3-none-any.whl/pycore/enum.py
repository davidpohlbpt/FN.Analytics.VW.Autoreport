import enum

from pycore.utils.pydantic import CaseInsensitiveEnum


class FilterType(CaseInsensitiveEnum):
    IN = "IN"
    EQUAL = "EQUAL"
    EQUALS = "="


class ResourceType(str, enum.Enum):
    LOCAL = "LOCAL"
    """Indicates the use of local resources like a local folder or a local SQLEXPRESS database.
    """
    MEMORY = "MEMORY"
    """Indicates the use of non-persistent resources like an in-memory SQLite database or a temporary local folder.
    """
    AZURE = "AZURE"
    """Indicates the use of Azure cloud resources like a hosted SQL Server or Azure Key Vault
    """
    AWS = "AWS"
    """Indicates the use of AWS cloud resources. Currently not supported.
    """


class EnvironmentType(str, enum.Enum):
    LOCAL = "LOCAL"
    """Indicates that the code is running on a local computer.
    """
    SERVICE_FABRIC = "SERVICE_FABRIC"
    """Indicates that the code is running in an Azure Service Fabric cluster.
    """
    KUBERNETES = "KUBERNETES"
    """Indicates that the code is running in a K8 cluster.
    """


class ProcessState(str, enum.Enum):
    PROCESSING = "Processing"
    SUCCESS = "Success"
    FAILED = "Failed"


class TaskStatus(int, enum.Enum):
    NEW = 0
    IN_PROGRESS = 1
    SUCCESS = 2
    FAILED = 3


class FileExtension(str, enum.Enum):
    """Serialization format for blob-backed DataFrames.

    Declared on a ``BlobDataFrame`` subclass via
    ``blob_config = BlobConfig(file_extension=FileExtension.CSV)``.
    When omitted, ``PARQUET`` is the default.
    """

    PARQUET = "parquet"
    CSV = "csv"
    XLSX = "xlsx"


class HookType(str, enum.Enum):
    SOURCE = "SOURCE"
    INTERACTION = "INTERACTION"
    PROCESS = "PROCESS"
    SETTING = "CONFIG"


class ServiceType(enum.Enum):
    """Enumeration of all Factory Navigator service types."""

    TRACKER = "tracker"
    MONITORING = "monitoring"
    RDP = "report_data_provider"
    BATCH = "batch"
    RULES_MGMT = "rules_management"
    TRANSLATION = "translation"
    IDENTITY = "identity"
    EMAIL = "email"
