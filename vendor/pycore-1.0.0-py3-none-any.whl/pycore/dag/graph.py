import logging
import typing
from collections.abc import Callable, Iterable
from typing import Annotated, Any

from pycore.dag.assets.base import BaseAsset, Df
from pycore.dag.context import Context, Event
from pycore.dag.node import Node
from pycore.utils.callable import get_arg_type, has_argument, merge_args_into_kwargs

ALLOWED_GRAPH_ARG_TYPES = [int, float, str, bool, list, tuple, dict, Any, Df, Annotated]


def graph(
    typechecked: bool = False,
    logged: bool = True,
) -> Callable:
    """Decorator for graphs.

    Args:
        typechecked (bool, optional): Whether to validate argument types at execution time. Defaults to False.
        logged (bool, optional): Whether to log the execution of the graph. Defaults to True.
    """

    if isinstance(typechecked, Callable):
        # The decorator was called without arguments.
        return graph()(typechecked)

    def inner(compute_fn: Callable) -> Graph:
        return Graph(
            compute_fn=compute_fn,
            typechecked=typechecked,
            logged=logged,
        )

    return inner


class Graph(Node):
    def __init__(
        self,
        compute_fn: Callable,
        typechecked: bool,
        logged: bool,
    ):
        super().__init__(compute_fn=compute_fn, typechecked=typechecked, logged=logged)
        self.assets_in = self.get_input_assets()
        self.assets_out = self.get_output_assets()

    def __call__(self, *args, **kwargs):
        kwargs = merge_args_into_kwargs(self.compute_fn, args, kwargs)
        return super().__call__(context=kwargs.pop("context"), **kwargs)

    def get_input_assets(self) -> dict[str, BaseAsset]:
        assets = {}

        for arg, annotation in self.compute_fn.__annotations__.items():
            if arg == "context" or arg == "return":
                continue
            asset = Graph.get_asset_from_annotation(arg, annotation)
            assets[arg] = asset

        return assets

    def get_output_assets(self) -> dict[str, BaseAsset]:
        assets = {}

        if "return" not in self.compute_fn.__annotations__:
            raise ValueError(f"Graph {self} does not have a return type.")

        return_type = self.compute_fn.__annotations__["return"]

        origin = typing.get_origin(return_type)
        if origin == typing.Annotated:
            return_types = [return_type]
        elif origin == tuple:
            return_types = return_type.__args__
        else:
            raise ValueError(f"Return type of graph {self} is invalid: {return_type}.")

        for idx, annotation in enumerate(return_types):
            asset = Graph.get_asset_from_annotation(f"return_{idx}", annotation)
            assets[asset.name] = asset

        return assets

    @staticmethod
    def get_asset_from_annotation(arg: str, annotation):
        metadata = annotation.__dict__.get("__metadata__", None)
        if not metadata:
            raise ValueError(
                f"Argument {arg} of graph {graph} is not annotated with an asset."
            )

        if len(metadata) != 1:
            raise ValueError(
                f"Argument {arg} of graph {graph} is annotated with multiple assets."
            )

        asset = metadata[0]
        if not isinstance(asset, BaseAsset):
            raise ValueError(
                f"Argument {arg} of graph {graph} is annotated with an invalid asset: {asset}."
            )

        return asset

    def get_input_types(self) -> dict[str, Any]:
        asset_types = {}

        # Whatever is provided to 'ins' must match the function arguments
        # excl. context and return value.
        if len(self.ins) != len(self.compute_fn.__annotations__) - 2:
            raise ValueError(
                f"The graph function {self} has more arguments than input assets."
            )

        for asset in self.ins:
            if not has_argument(self.compute_fn, asset.name):
                raise ValueError(
                    f"Input asset {asset.name} is not a valid argument of graph {self}."
                )

            asset_type = get_arg_type(self.compute_fn, asset.name)
            if asset_type is None:
                raise ValueError(
                    f"Input asset {asset.name} of graph {self} is not annotated with a type."
                )

            if asset_type not in ALLOWED_GRAPH_ARG_TYPES:
                raise ValueError(
                    f"Input asset {asset.name} has an invalid type: {asset_type}."
                )

            asset_types[asset.name] = asset_type

        return asset_types

    def get_return_types(self) -> dict[str, Any]:
        """"""
        return_types = {}

        return_type = get_arg_type(self.compute_fn, "return")

        if return_type is None:
            logging.critical(
                f"The graph {self} does not have a return type."
                "Please add one using the syntax 'def graph( ... ) -> Type: ...'"
            )
            raise ValueError("Graph return type is not annotated.")

        if return_type == tuple:
            for asset, asset_type in zip(self.outs, return_type.__args__):
                if asset_type not in ALLOWED_GRAPH_ARG_TYPES:
                    raise ValueError(
                        f"Output asset {asset.name} has an invalid type: {asset_type}."
                    )

                return_types[asset.name] = asset_type

        elif return_type in ALLOWED_GRAPH_ARG_TYPES:
            if len(self.outs) != 1:
                raise ValueError(
                    f"Graph {self} has a single return type but multiple output assets."
                )

            return {self.outs[0].name: return_type}
        else:
            raise ValueError(f"Return type of graph {self} is invalid: {return_type}.")

    def execute_with_context(self, context: Context):
        return execute_with_context(self, context)


def remove_outputs_with_context(assets: Iterable[BaseAsset], context: Context):
    """Remove the outputs of a graph in a given context.

    Args:
        graph (Graph): The graph to execute.
        context (dict): The context to use.
    """

    for asset in assets:
        asset.remove(context)


def store_outputs_with_context(
    graph: Graph, context: Context, outputs: tuple
) -> dict[str, Any]:
    """Store the outputs of a graph in a given context.

    If storing any output fails, all previously stored outputs are removed.

    Args:
        graph (Graph): The graph to execute.
        context (dict): The context to use.
        outputs (Tuple): The outputs to store.
    """

    stored = []
    output_dict = {}

    try:
        for idx, asset in enumerate(graph.assets_out.values()):
            asset.store(context, outputs[idx])
            stored.append(asset)
            output_dict[asset.name] = outputs[idx]
    except Exception as e:
        remove_outputs_with_context(reversed(stored), context)
        raise e

    return output_dict


def load_inputs_from_context(graph: Graph, context: Context) -> dict[str, Any]:
    """Load the inputs of a graph from a given context.

    Args:
        graph (Graph): The graph to execute.
        context (dict): The context to use.
    """
    loaded_inputs = {}

    for arg, asset in graph.assets_in.items():
        loaded_inputs[arg] = asset.load(context)

    return loaded_inputs


class ExecutionResult:
    """The result of a graph execution.

    Attributes:
        outputs: The outputs of the graph.
        events: The events that occurred during execution.
    """

    def __init__(self, outputs: dict[str, Any], events: list[Event]):
        self.outputs = outputs
        self.events = events

    def __getitem__(self, key: str) -> Any:
        return self.outputs[key]

    def __contains__(self, item: Any) -> bool:
        if not isinstance(item, str):
            raise TypeError("ExecutionResult can only be queried with string keys.")

        return item in self.outputs

    def __repr__(self) -> str:
        outputs = ", ".join(
            [f"{k}:{type(v).__name__}" for k, v in self.outputs.items()]
        )
        return f"ExecutionResult(outputs=({outputs})"


def execute_with_context(graph: Graph, context: Context) -> ExecutionResult:
    """Execute a graph with a given context.

    Args:
        graph (Graph): The graph to execute.
        context (dict): The context to use.
    """

    loaded_inputs = load_inputs_from_context(graph, context)

    outputs_to_store = graph(context=context, **loaded_inputs)

    if not isinstance(outputs_to_store, tuple):
        outputs_to_store = (outputs_to_store,)

    output_dict = store_outputs_with_context(graph, context, outputs_to_store)

    return ExecutionResult(outputs=output_dict, events=context.events)
