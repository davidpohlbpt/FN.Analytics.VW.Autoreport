import logging
import math
import time
import warnings
from collections import namedtuple
from collections.abc import Callable
from sys import getsizeof
from typing import Any, Protocol, runtime_checkable

import pydantic

from pycore.repository.data import DataRepository
from pycore.resources.abc import BlobStorage
from pycore.resources.odbc import OdbcDatabase
from pycore.utils.callable import get_arg, has_argument, merge_args_into_kwargs


@runtime_checkable
class RunInformation(Protocol):
    """Structural type for run/execution identification.

    Any object whose attributes match the fields expected by the DAG
    assets (e.g. ``load_id``, ``entity_id``) can be used.  The built-in
    :class:`~pycore.schemas.LoadInformation` satisfies this protocol
    automatically, but so does any custom Airflow or plain-object
    equivalent.

    All fields are optional at the protocol level because different
    orchestration systems may provide different subsets.
    """

    ...


Event = namedtuple("Event", ["name", "duration", "bytes_in", "bytes_out", "arguments"])
Argument = namedtuple("Argument", ["name", "type", "length"])


class Context:
    """The context is the object that is passed to all functions in the DAG.

    All information that the operations need must be provided.
    The rest can be left empty.

    Attributes:
        settings: The pydantic settings object.
        data_repo: The data repository.
        cache: The cache.
        run_info: Information identifying the current run/execution.
            Accepts any object with the attributes required by the DAG
            assets (e.g. ``load_id``, ``entity_id``).  The built-in
            :class:`~pycore.schemas.LoadInformation` works out of the
            box, as does any custom Airflow or plain-object equivalent.
        databases: Set of OdbcDatabase objects for multi-database operations.
        storage: The default blob storage.
        storages: Named blob storages for multi-storage operations.
    """

    def __init__(
        self,
        settings: pydantic.BaseModel | None = None,
        data_repo: DataRepository | None = None,
        cache: dict[str, Any] | None = None,
        run_info: RunInformation | None = None,
        databases: set[OdbcDatabase] | None = None,
        storage: BlobStorage | None = None,
        storages: dict[str, BlobStorage] | None = None,
        # --- Deprecated alias ---
        load: RunInformation | None = None,
    ):
        if load is not None:
            if run_info is not None:
                raise ValueError(
                    "Cannot specify both 'run_info' and the deprecated "
                    "'load' argument. Use 'run_info' only."
                )
            warnings.warn(
                "The 'load' parameter is deprecated. Use 'run_info' instead.",
                DeprecationWarning,
                stacklevel=2,
            )
            run_info = load

        self.settings = settings
        self.data_repo = data_repo
        self.cache = cache or {}
        self.run_info = run_info
        self.databases = databases or set()
        self.storage = storage
        self.storages = storages or {}
        self.events = []

    @property
    def load(self):
        """Deprecated alias for :attr:`run_info`."""
        warnings.warn(
            "'Context.load' is deprecated. Use 'Context.run_info' instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.run_info

    @load.setter
    def load(self, value):
        """Deprecated setter for :attr:`run_info`."""
        warnings.warn(
            "'Context.load' is deprecated. Use 'Context.run_info' instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        self.run_info = value

    def get_data_repo(self, database_name: str | None = None) -> DataRepository | None:
        """Get a data repository for the specified database.

        Args:
            database_name: Name of the database. If None, returns the default data_repo.

        Returns:
            DataRepository for the specified database, or None if no default data_repo is configured.

        Raises:
            ValueError: If the specified database is not configured.
        """
        if database_name is None:
            return self.data_repo

        # Find the database by name
        for db in self.databases:
            if db.db_name == database_name:
                return DataRepository(database=db)

        raise ValueError(
            f"Database '{database_name}' is not configured in the context."
        )

    def get_storage(self, storage_name: str | None = None) -> BlobStorage:
        """Get a blob storage by name.

        Args:
            storage_name: Name of the storage. If None, returns the default storage.

        Returns:
            The BlobStorage instance.

        Raises:
            ValueError: If the specified storage is not configured or no default
                storage is available.
        """
        if storage_name is None:
            if self.storage is None:
                raise ValueError("No default storage is configured in the context.")
            return self.storage

        if storage_name not in self.storages:
            raise ValueError(
                f"Storage '{storage_name}' is not configured in the context."
            )
        return self.storages[storage_name]

    def log_event(self, event: Event):
        self.events.append(event)

    @classmethod
    def from_context(cls, context, *args, **kwargs):
        return cls(
            *args,
            settings=context.settings,
            data_repo=context.data_repo,
            cache=context.cache,
            run_info=context.run_info,
            databases=context.databases,
            storage=context.storage,
            storages=context.storages,
            **kwargs,
        )


def logged_to_context(fn: Callable):
    if not has_argument(fn, "context"):
        raise ValueError("Logged functions require a context as first argument.")

    def wrapper(*args, **kwargs):
        name = fn.__name__
        context = get_arg(fn, "context", args, kwargs)

        start = time.time()

        bytes_in = getsizeof(args) + getsizeof(kwargs)
        arguments = get_arg_information(fn, args, kwargs)
        arguments = [a for a in arguments if a.name != "context"]

        logging.info(f"Starting execution of step {name} (bytes_in={bytes_in})")

        result = fn(*args, **kwargs)

        bytes_out = getsizeof(result)

        end = time.time() + 0.001  # avoid 0 duration
        duration = math.ceil((end - start) * 100) / 100  # round up to 2 decimals
        logging.info(
            f"Finished execution of step {name} "
            f"(bytes_out={bytes_out}, duration={duration})"
        )

        event = Event(
            name=name,
            duration=duration,
            bytes_in=bytes_in,
            bytes_out=bytes_out,
            arguments=arguments,
        )
        context.log_event(event)

        return result

    return wrapper


def get_arg_information(
    fn: Callable, args: list[Any], kwargs: dict[str, Any]
) -> list[Argument]:
    kwargs = merge_args_into_kwargs(fn, args, kwargs)

    shapes = []

    for name, value in kwargs.items():
        if hasattr(value, "__len__"):
            length = len(value)
        else:
            length = None

        shapes.append(
            Argument(
                name=name,
                type=type(value).__name__,
                length=length,
            )
        )

    return shapes
