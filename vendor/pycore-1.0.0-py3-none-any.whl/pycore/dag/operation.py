import abc
from collections.abc import Callable

import pydantic

from pycore.dag.context import Context
from pycore.dag.node import Node
from pycore.utils.callable import (
    check_full_annotation,
    get_arg_type,
    has_argument,
    merge_args_into_kwargs,
)


def operation(
    typechecked: bool = True, chunked_by: str | None = None, logged: bool = True
) -> Callable:
    """Decorator for operations.

    Args:
        typechecked (bool, optional): Whether to validate argument types at execution time. Defaults to True.
        chunked_by (str, optional): The name of the argument to chunk by. Defaults to None. Must reference an argument of type DataFrame or Iterable.
    """

    if isinstance(typechecked, Callable):
        # decorator is used w/o arguments
        return operation()(typechecked)

    def inner(compute_fn: Callable) -> Operation:
        return Operation(
            compute_fn=compute_fn,
            typechecked=typechecked,
            chunked_by=chunked_by,
            logged=logged,
        )

    return inner


class OperationConfig(pydantic.BaseModel):
    """The configuration of an operation."""

    chunk_size: int = 1000

    @staticmethod
    def from_settings(settings: pydantic.BaseModel) -> "OperationConfig":
        """Initializes the configuration from settings.

        Args:
            settings (pydantic.BaseModel): The settings to use.
        """
        raise NotImplementedError(
            "The mapping between global settings and operation config is missing."
        )


class Operation(Node):
    def __init__(
        self, compute_fn: Callable, typechecked: bool, chunked_by: str, logged: bool
    ):
        check_full_annotation(compute_fn)
        super().__init__(
            compute_fn=compute_fn,
            typechecked=typechecked,
            logged=logged,
            chunked_by=chunked_by,
        )

    def __call__(self, *args, **kwargs):
        kwargs = merge_args_into_kwargs(self.compute_fn, args, kwargs)
        self.inject_config(kwargs)

        if "config" in kwargs:
            kwargs["chunk_size"] = kwargs.get("config").chunk_size

        return super().__call__(**kwargs)

    def inject_config(self, kwargs):
        if not has_argument(self.compute_fn, "config"):
            return  # config is not required by the operation

        if "config" in kwargs:
            return  # config was already provided by the caller

        context: Context = kwargs["context"]
        config_type: OperationConfig = get_arg_type(
            fn=self.compute_fn, arg_name="config", base_type=OperationConfig
        )

        kwargs["config"] = config_type.from_settings(settings=context.settings)
