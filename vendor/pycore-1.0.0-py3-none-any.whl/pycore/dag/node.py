from collections.abc import Callable
from typing import Any

import beartype
import pandas as pd

from pycore.dag.context import Context, logged_to_context
from pycore.utils.callable import has_argument, merge_args_into_kwargs
from pycore.utils.collections import merge_chunks, split_in_chunks


class Node:
    """A node represents a unit of work in a graph.

    Attributes:
        compute_fn (Callable): The function to execute.
        typechecked (bool): Whether to validate argument types at execution time.
        logged (bool): Whether to log the execution of the node.
    """

    def __init__(
        self,
        compute_fn: Callable,
        typechecked: bool,
        logged: bool,
        chunked_by: str | None = None,
    ):
        if not has_argument(compute_fn, "context"):
            raise ValueError("Operations require a context argument.")
        self.typechecked = typechecked
        self.compute_fn = compute_fn
        self.logged = logged
        self.chunked_by = chunked_by

    def __call__(self, context: Context, chunk_size: int = 1000, **kwargs):
        fn = self.compute_fn

        if self.typechecked:
            fn = beartype.beartype(fn)

        if self.logged:
            fn = logged_to_context(fn)

        if self.chunked_by is None:
            result = fn(context=context, **kwargs)
        else:
            result = chunked_call(
                fn=fn,
                context=context,
                chunked_by=self.chunked_by,
                chunk_size=chunk_size,
                kwargs=kwargs,
            )
        return result

    @property
    def name(self) -> str:
        """Returns the name of the underlying function as name.

        Returns:
            str: The name of the node.
        """
        return self.compute_fn.__name__

    def __repr__(self):
        return f"{self.__class__.__name__}(name='{self.name}')"


def chunked_call(
    fn: Callable,
    context: Context,
    chunked_by: str,
    chunk_size: int,
    kwargs: dict[str, Any],
):
    chunks = split_in_chunks(kwargs[chunked_by], chunk_size=chunk_size)

    partial_results = []
    chunk_kwargs = kwargs.copy()

    for chunk in chunks:
        chunk_kwargs[chunked_by] = chunk
        partial_result = fn(context=context, **chunk_kwargs)
        partial_results.append(partial_result)

    result = merge_chunks(partial_results)

    return result
