import enum
import logging
import warnings
from typing import Annotated, Any

import pandas as pd
import pandera.pandas as pa
import sqlalchemy as sa
from sqlalchemy.orm import declarative_base

from pycore.dag.context import Context
from pycore.utils.pandera import df_model_to_db_table

Df = pa.typing.DataFrame
NullableFloat = pd.Float64Dtype
NullableInt = pd.Int64Dtype
NullableBool = pa.BOOL
NullableDate = pa.DateTime
Json = pa.Object


class Category:
    @classmethod
    def __class_getitem__(cls, enum_cls: enum.Enum):
        return pa.Category(categories=enum_cls)


class BaseDataFrame(pa.DataFrameModel):
    """Base class for your own pandera dataframes.

    This class provides some convenience methods for converting to and from pandas dataframes.
    """

    # Domain config attributes excluded from pandera's field detection.
    _DOMAIN_CONFIG_ATTRS = frozenset({"blob_config", "table_config"})

    # TODO: Remove as soon as INA is migrated
    _db_table = None

    @classmethod
    def _get_model_attrs(cls):
        attrs = super()._get_model_attrs()
        return {k: v for k, v in attrs.items() if k not in cls._DOMAIN_CONFIG_ATTRS}

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)

        has_table_column = "table" in cls.__annotations__
        has_metadata = hasattr(cls, "Config") and hasattr(cls.Config, "metadata")
        if not has_metadata:
            return

        has_table_config = (
            isinstance(cls.Config.metadata, dict) and "table" in cls.Config.metadata
        )

        if has_table_column and has_table_config:
            raise ValueError(
                "Only one configuration method (table column or table "
                "configuration) can be specified."
            )

        if not has_table_config:
            return

        warnings.warn(
            f"{cls.__name__}: Using Config.metadata dict with a 'table' key "
            f"is deprecated. Subclass TableDataFrame and set a class-level "
            f"'table_config = TableConfig(...)' attribute instead.",
            DeprecationWarning,
            stacklevel=2,
        )

        table_config = cls.Config.metadata.get("table")
        schema, table, base = table_config[0], table_config[1], table_config[2]

        cls.table = df_model_to_db_table(cls, base=base, table=table, schema=schema)
        cls.orm = cls.as_orm_class(table=cls.table)

    class Config:
        coerce = True

    @classmethod
    def get_pandas_dtypes(cls) -> dict[str, str]:
        dtypes = {col: dtype for col, dtype in cls.to_schema().dtypes.items()}

        for col, dtype in dtypes.items():
            dtypes[col] = dtype.type

        return dtypes

    @classmethod
    def as_table(
        cls, base, table: str | None = None, schema: str | None = None
    ) -> sa.Table:
        """Returns an SQLAlchemy table object for this dataframe.

        Args:
            base: The SQLAlchemy declarative base, from pycore.easy.
            table: The name of the table. Defaults to the name of the dataframe.
            schema: The name of the schema. Defaults to the name of the dataframe.

        Returns:
            An SQLAlchemy table object for this dataframe.
        """

        return df_model_to_db_table(cls, base=base, table=table, schema=schema)

    @classmethod
    def as_orm_class(
        cls, base=None, table: str | None = None, schema: str | None = None
    ):
        """Returns an SQLAlchemy ORM class for this dataframe.

        Args:
            base: The SQLAlchemy declarative base, from pycore.easy.
            table: The name of the table. Defaults to the name of the dataframe.
            schema: The name of the schema. Defaults to the name of the dataframe.

        Returns:
            An SQLAlchemy ORM class for this dataframe.
        """
        if not isinstance(table, sa.Table):
            if base is None:
                raise ValueError("You must provide a base when passing a table name.")
            table = cls.as_table(base, table, schema)
        else:
            base = declarative_base(metadata=table.metadata)

        class ORMClass(base):
            __table__ = table
            __name__ = cls.__name__

        ORMClass.__name__ = cls.__name__
        return ORMClass

    @classmethod
    def as_empty_data_frame(cls) -> pd.DataFrame:
        """Creates an empty pandas dataframe with the same columns and types as this dataframe."""
        dtypes = cls.get_pandas_dtypes()
        return pd.DataFrame(
            {col: pd.Series(dtype=dtype) for col, dtype in dtypes.items()}
        )

    @classmethod
    def from_data_frame(cls, df: pd.DataFrame, drop: bool = False) -> pd.DataFrame:
        """Converts a pandas dataframe to this dataframe model by coercing and validating the types."""

        dtypes = cls.get_pandas_dtypes()
        dtypes = {k: v for k, v in dtypes.items() if k in df.columns}
        # Prevent conversion of NAs to strings 'None' or 'NA'
        with pd.option_context("future.no_silent_downcasting", True):
            df = df.where(pd.isna(df), df.astype(dtypes)).infer_objects()

        excess_columns = [col for col in df.columns if col not in dtypes]
        all_columns = list(dtypes.keys()) + excess_columns

        # arrange in correct order (if kept, excess cols at the end)
        df = df[all_columns]
        if drop:
            df = df.drop(columns=excess_columns)

        return cls(df)


class PartitionBy(enum.Enum):
    """Used to declare whether assets are partitioned by load or entity."""

    LOAD = "load"
    ENTITY = "entity"


class BaseAsset:
    """Base class for assets.

    Assets are used to store and load data between tasks.
    They can be stored anywhere based on the specific asset type.

    Args:
        name: The name of the asset.
        partition_by: Whether the asset is partitioned by load or entity.
    """

    def __init__(self, name: str, partition_by: PartitionBy | list[str] | None = None):
        self.name = name
        self.partition_by = partition_by
        self.type = None

    def load(self, context: Context) -> Any:
        """Loads the asset from the in-memory cache.

        Args:
            context: The execution context.
        """
        return load_asset_from_cache(context, self)

    def store(self, context: Context, value: Any) -> None:
        """Stores the asset in the in-memory cache.

        Args:
            context: The execution context.
            value: The value to be stored.
        """
        return store_asset_in_cache(context, self, value)

    def remove(self, context: Context) -> None:
        """Removes the asset from the in-memory cache.

        Args:
            context: The execution context.
        """
        return remove_asset_from_cache(context, self)


def load_asset_from_cache(context: Context, asset: BaseAsset) -> Any:
    return context.cache[asset.name]


def store_asset_in_cache(context: Context, asset: BaseAsset, value: Any) -> None:
    context.cache[asset.name] = value


def remove_asset_from_cache(context: Context, asset: BaseAsset) -> None:
    if asset.name in context.cache:
        del context.cache[asset.name]
    else:
        logging.warning(
            f"Asset {asset.name} is not cached and, thus, cannot be removed."
        )


class DfDict:
    """Convenience type: ``DfDict[MyDF]`` → ``dict[str, Df[MyDF]]``.

    Use this to annotate operation parameters or return values that carry
    a dictionary of DataFrames (e.g. multi-file blob data) without
    coupling the signature to a storage backend::

        @operation
        def merge(context: Context, files: DfDict[MaterialFiles]) -> Df[Combined]:
            ...
    """

    def __class_getitem__(cls, item):
        return dict[str, Df[item]]


class AssetAnnotation:
    def __init__(self, cls, **kwargs):
        self.cls = cls
        self.kwargs = kwargs

    def __getitem__(self, item):
        if not isinstance(item, tuple):
            item = (item,)
        type_ = item[0]
        args = item[1:]
        return Annotated[Df[type_], self.cls(*args, type=type_, **self.kwargs)]


Asset = AssetAnnotation(cls=BaseAsset)
