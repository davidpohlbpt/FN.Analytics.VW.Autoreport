import pandas as pd

from pycore.dag.assets.base import AssetAnnotation, BaseDataFrame, PartitionBy
from pycore.dag.assets.db import TableAsset


class SapDataFrame(BaseDataFrame):
    """Base class for dataframes that are loaded from SAP."""

    @classmethod
    def from_data_frame(cls, df: pd.DataFrame) -> pd.DataFrame:

        # Rename columns
        rename_map = cls.get_rename_map()
        df = df.rename(columns=rename_map)

        # Remove columns that are not in the schema
        schema_columns = cls.to_schema().columns.keys()
        actual_columns = [column for column in df.columns if column in schema_columns]
        df = df[actual_columns]

        return cls(df)

    @classmethod
    def to_schema(cls) -> dict:
        rename_map = cls.get_rename_map()
        schema = super().to_schema()
        schema.columns = {rename_map.get(k, k): v for k, v in schema.columns.items()}
        for c in schema.columns.values():
            c.name = rename_map.get(c.name, c.name)
        return schema

    @classmethod
    def get_rename_map(cls) -> dict:
        return {getattr(cls, v): v for v in cls.__annotations__}

    class Config:
        coerce = True


class SapTableAssetAnnotation(AssetAnnotation):
    def __getitem__(self, item):
        if not isinstance(item, tuple):
            item = (item,)

        if len(item) < 2:
            raise ValueError("You must pass two arguments: table type & table name")
        type_ = item[0]
        table_name = item[1]
        args = (type_, table_name, *item[2:])
        return super().__getitem__(args)


SapTable = SapTableAssetAnnotation(TableAsset)
SapEntityTable = SapTableAssetAnnotation(TableAsset, partition_by=PartitionBy.ENTITY)
SapLoadTable = SapTableAssetAnnotation(TableAsset, partition_by=PartitionBy.LOAD)
