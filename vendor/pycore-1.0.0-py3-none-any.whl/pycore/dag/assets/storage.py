import io
from dataclasses import dataclass
from typing import Annotated

import pandas as pd

from pycore.dag.assets.base import (
    AssetAnnotation,
    BaseAsset,
    BaseDataFrame,
    Df,
    PartitionBy,
)
from pycore.dag.context import Context
from pycore.enum import FileExtension

# ---------------------------------------------------------------------------
# BlobConfig and BlobDataFrame class definitions
# ---------------------------------------------------------------------------


@dataclass
class BlobConfig:
    """Configuration for a blob-storage-backed DataFrame.

    Defines how a :class:`BlobDataFrame` is serialized to and read from
    blob storage.  Declare as a class-level ``blob_config`` attribute on
    the DataFrame class::

        class Sales(BlobDataFrame):
            amount: float
            region: str

            blob_config = BlobConfig(
                container_name="analytics",
                file_name="Sales",
                file_extension=FileExtension.CSV,
            )

            class Config:
                coerce = True

    For multi-file mode, use ``folder`` instead of ``file_name``::

        class MaterialFiles(BlobDataFrame):
            col_a: int

            blob_config = BlobConfig(
                container_name="raw-data",
                folder="input/materials",
                file_extension=FileExtension.CSV,
            )

    Args:
        container_name: Name of the storage container (Azure container
            or local folder).
        file_name: Blob file name for single-file mode.  Mutually
            exclusive with *folder*.
        folder: Folder path within the container for multi-file mode
            (e.g. ``"input/materials"``).  All blobs under this folder
            matching the configured ``file_extension`` are loaded.
            Mutually exclusive with *file_name*.
        file_extension: Serialization format.  Defaults to
            :attr:`FileExtension.PARQUET`.
        storage_name: Named storage from the execution context.
            ``None`` uses the context's default storage.
        partition_candidates: Allowed partition column names.  When set,
            any ``partition_by`` on the asset is validated against this
            list at construction time.
    """

    container_name: str
    file_name: str | None = None
    folder: str | None = None
    file_extension: FileExtension = FileExtension.PARQUET
    storage_name: str | None = None
    partition_candidates: list[str] | None = None

    def __post_init__(self):
        if not isinstance(self.file_extension, FileExtension):
            raise ValueError(
                f"file_extension must be a FileExtension enum member, "
                f"got {self.file_extension!r}."
            )
        if self.file_name is not None and self.folder is not None:
            raise ValueError("file_name and folder are mutually exclusive.")
        # Normalize folder: fix separators, collapse doubles, ensure trailing "/"
        # An empty/root folder ("" or "/") normalizes to "" (no prefix).
        if self.folder is not None:
            normalized = self.folder.replace("\\", "/").strip("/")
            while "//" in normalized:
                normalized = normalized.replace("//", "/")
            self.folder = normalized + "/" if normalized else ""


class BlobDataFrame(BaseDataFrame):
    """Base class for pandera DataFrames backed by blob storage.

    Declare the blob mapping via a class-level ``blob_config`` attribute
    using a :class:`BlobConfig`::

        class SalesData(BlobDataFrame):
            amount: float
            region: str

            blob_config = BlobConfig(
                container_name="analytics",
                file_name="SalesData",
                file_extension=FileExtension.CSV,
            )

            class Config:
                coerce = True

    The ``BlobConfig`` dataclass validates its fields at construction
    time (e.g. ``file_name`` and ``folder`` are mutually exclusive,
    ``file_extension`` must be a ``FileExtension`` member).
    ``partition_candidates`` are validated against the schema columns at
    class-definition time.

    """

    def __init_subclass__(cls, **kwargs):
        # --- New style: class-level blob_config attribute ---
        own_config = cls.__dict__.get("blob_config")

        super().__init_subclass__(**kwargs)

        config = own_config if isinstance(own_config, BlobConfig) else None

        # --- Enforcement ---
        if config is None:
            raise TypeError(
                f"{cls.__name__} subclasses BlobDataFrame but does not "
                f"provide a 'blob_config = BlobConfig(...)' attribute."
            )

        # Validate partition_candidates against actual schema columns.
        if config.partition_candidates is not None:
            schema_columns = set(cls.to_schema().columns.keys())
            invalid = [
                c for c in config.partition_candidates if c not in schema_columns
            ]
            if invalid:
                raise ValueError(
                    f"partition_candidates {invalid} are not columns on "
                    f"{cls.__name__}. Available columns: "
                    f"{sorted(schema_columns)}"
                )


# ---------------------------------------------------------------------------
# Helpers – type config resolution
# ---------------------------------------------------------------------------


def _resolve_type_blob_config(type_) -> BlobConfig | None:
    """Return the ``BlobConfig`` from *type_*'s ``blob_config`` attribute."""
    if type_ is None:
        return None
    config = getattr(type_, "blob_config", None)
    return config if isinstance(config, BlobConfig) else None


def _blob_attr(type_, attr: str, default=None):
    """Read a blob config attribute from the ``blob_config`` class attribute."""
    cfg = _resolve_type_blob_config(type_)
    if cfg is not None:
        return getattr(cfg, attr, default)
    return default


# ---------------------------------------------------------------------------
# Helpers – file-extension resolution & serialization dispatch
# ---------------------------------------------------------------------------


def _get_file_extension(type_) -> FileExtension:
    """Resolve the ``FileExtension`` for a ``BaseDataFrame`` subclass.

    Reads from ``blob_config.file_extension``.  Defaults to ``PARQUET``.
    """
    return _blob_attr(type_, "file_extension", FileExtension.PARQUET)


def _get_file_name(type_) -> str | None:
    """Return ``file_name`` from a DF class's ``blob_config``."""
    return _blob_attr(type_, "file_name")


def _get_folder(type_) -> str | None:
    """Return ``folder`` from a DF class's ``blob_config``."""
    return _blob_attr(type_, "folder")


def _get_partition_candidates(type_) -> list[str] | None:
    """Return ``partition_candidates`` from a DF class."""
    return _blob_attr(type_, "partition_candidates")


def _get_container_name(type_) -> str | None:
    """Return ``container_name`` from a DF class."""
    return _blob_attr(type_, "container_name")


def _get_storage_name(type_) -> str | None:
    """Return ``storage_name`` from a DF class."""
    return _blob_attr(type_, "storage_name")


def _serialize_df(df: pd.DataFrame, ext: FileExtension) -> bytes:
    """Serialize a DataFrame to bytes in the given format."""
    buffer = io.BytesIO()
    if ext == FileExtension.PARQUET:
        df.to_parquet(buffer, index=False)
    elif ext == FileExtension.CSV:
        df.to_csv(buffer, index=False, encoding="utf-8")
    elif ext == FileExtension.XLSX:
        df.to_excel(buffer, index=False, engine="openpyxl")
    else:
        raise ValueError(f"Unsupported file extension: {ext!r}")
    return buffer.getvalue()


def _deserialize_df(data: bytes, ext: FileExtension) -> pd.DataFrame:
    """Deserialize bytes to a DataFrame based on the format."""
    if ext == FileExtension.PARQUET:
        return pd.read_parquet(io.BytesIO(data))
    elif ext == FileExtension.CSV:
        return pd.read_csv(io.BytesIO(data), encoding="utf-8")
    elif ext == FileExtension.XLSX:
        return pd.read_excel(io.BytesIO(data), engine="openpyxl")
    else:
        raise ValueError(f"Unsupported file extension: {ext!r}")


# ---------------------------------------------------------------------------
# Partition helpers
# ---------------------------------------------------------------------------


def _resolve_partition_columns(partition_by) -> list[str]:
    """Return a flat list of column names for the given ``partition_by`` value.

    Handles ``PartitionBy`` enum members as well as custom string / list
    specifications.
    """
    if partition_by is None:
        return []
    elif isinstance(partition_by, list):
        return [
            _resolve_partition_column(partition_column)
            for partition_column in partition_by
        ]
    else:
        return [_resolve_partition_column(partition_by)]


def _resolve_partition_column(partition_column) -> str:
    """Return a flat list of column names for the given ``partition_by`` value.

    Handles ``PartitionBy`` enum members as well as custom string / list
    specifications.
    """
    if partition_column == PartitionBy.LOAD:
        return "load_id"
    elif partition_column == PartitionBy.ENTITY:
        return "entity_id"
    elif isinstance(partition_column, str):
        return partition_column
    else:
        raise ValueError(
            f"Invalid partition_by value: {partition_column!r}. Must be a "
            f"PartitionBy enum member, or a string."
        )


def _validate_partition_candidates(type_, partition_by) -> None:
    """Raise if ``partition_by`` references columns not in ``partition_candidates``."""
    if type_ is None or partition_by is None:
        return

    candidates = _get_partition_candidates(type_)
    if candidates is None:
        raise ValueError(
            f"Type {type_.__name__} must declare 'partition_candidates' in its "
            "blob_config when using 'partition_by'."
        )

    part_cols = _resolve_partition_columns(partition_by)
    invalid = [c for c in part_cols if c not in candidates]
    if invalid:
        raise ValueError(
            f"partition_by columns {invalid} are not in "
            f"partition_candidates {candidates} of {type_.__name__}."
        )


def _resolve_value_from_context(context: Context, column: str):
    """Resolve a single attribute value from the execution context.

    Checks ``context.run_info``, ``context.settings``, then ``context``
    in that order.
    """
    if context.run_info is not None and hasattr(context.run_info, column):
        return getattr(context.run_info, column)
    elif context.settings is not None and hasattr(context.settings, column):
        return getattr(context.settings, column)
    elif hasattr(context, column):
        return getattr(context, column)
    else:
        raise ValueError(
            f"Attribute '{column}' does not exist in the execution context."
        )


def _resolve_known_candidate_metadata(
    context: Context, type_, partition_by
) -> dict[str, str]:
    """Resolve metadata values for the partition_candidates covered by *partition_by*.

    These are the candidates whose values are determined by the execution
    context (as opposed to being derived from DataFrame data).
    """
    candidates = _get_partition_candidates(type_) or []
    if not candidates:
        return {}

    known_cols = set(_resolve_partition_columns(partition_by))
    meta: dict[str, str] = {}
    for col in candidates:
        if col in known_cols:
            meta[col] = str(_resolve_value_from_context(context, col))
    return meta


def _get_remaining_candidates(type_, partition_by) -> list[str]:
    """Return partition_candidates NOT covered by *partition_by*."""
    candidates = _get_partition_candidates(type_) or []
    known = set(_resolve_partition_columns(partition_by))
    return [c for c in candidates if c not in known]


def _build_candidate_prefix(values: dict[str, str], candidates: list[str]) -> str:
    """Build a path prefix from candidate values in their declared order.

    Example::

        >>> _build_candidate_prefix(
        ...     {"entity_id": "42", "load_id": "7"},
        ...     ["entity_id", "load_id"],
        ... )
        'entity_id=42/load_id=7/'
    """
    parts = [f"{c}={values[c]}" for c in candidates]
    return "/".join(parts) + "/"


def _resolve_all_candidate_metadata(
    context: Context,
    type_,
    partition_by,
    group_values: dict[str, str] | None = None,
) -> dict[str, str]:
    """Resolve metadata values for ALL ``partition_candidates``.

    * Known candidates (in *partition_by*) are resolved from the context.
    * Remaining candidates use *group_values* (from DataFrame ``groupby``).

    Returns an empty dict when *type_* is ``None`` or has no candidates.
    """
    candidates = _get_partition_candidates(type_) or []
    if not candidates:
        return {}

    known_cols = (
        set(_resolve_partition_columns(partition_by)) if partition_by else set()
    )
    meta: dict[str, str] = {}
    for col in candidates:
        if col in known_cols:
            meta[col] = str(_resolve_value_from_context(context, col))
        elif group_values and col in group_values:
            meta[col] = str(group_values[col])
        else:
            raise ValueError(
                f"Cannot resolve value for candidate '{col}': "
                f"not in partition_by and not in group_values."
            )
    return meta


# ---------------------------------------------------------------------------
# BlobAsset
# ---------------------------------------------------------------------------


class BlobAsset(BaseAsset):
    """Represents an asset that is stored as a blob in a BlobStorage container.

    Maps DAG partitioning concepts to blob storage:

    - Container → Azure container or local folder
    - Blob name → Derived from ``blob_config.file_name`` or the pandera
      type class name.
    - Partition → Prefix-based path (e.g. ``{entity_id}/{blob}``)
      plus blob metadata for discoverability.
    - File format → Derived from ``blob_config.file_extension``
      (default: Parquet).

    **Single-file mode** (default, or when ``file_name`` is set):
    ``load()`` returns a single ``pd.DataFrame``; ``store()`` accepts one.

    **Multi-file mode** (when ``folder`` is set):
    ``load()`` returns ``dict[str, pd.DataFrame]`` keyed by blob name;
    ``store()`` accepts ``dict[str, pd.DataFrame]``.
    All blobs under the folder matching the configured ``file_extension``
    are included.

    Args:
        container_name: The name of the storage container.  When ``None``,
            read from the type's ``blob_config.container_name``.
        type: The pandera DataFrameModel type, if applicable.
        partition_by: Whether the asset is partitioned by load or entity.
        storage_name: The name of the storage this blob belongs to (optional).
            When ``None``, read from the type's ``blob_config.storage_name``,
            falling back to the default storage from the context.
    """

    def __init__(
        self,
        container_name: str | None = None,
        type=None,
        partition_by: PartitionBy | list[str | PartitionBy] | str | None = None,
        storage_name: str | None = None,
    ):
        # Resolve container_name: explicit arg > type metadata
        resolved_container = container_name or _get_container_name(type)
        if resolved_container is None:
            raise ValueError(
                "container_name must be provided either as an argument, "
                "in the annotation, or in the type's blob_config attribute."
            )

        # Resolve storage_name: explicit arg > type metadata
        resolved_storage = storage_name or _get_storage_name(type)

        _validate_partition_candidates(type, partition_by)

        file_name = _get_file_name(type)
        folder = _get_folder(type)
        self.is_multi_file = folder is not None

        if self.is_multi_file:
            # Multi-file: folder_prefix from explicit folder config
            self.blob_name = None
            self.folder_prefix = folder  # already normalized with trailing "/"
        else:
            # Single-file: blob name from file_name or class name
            self.blob_name = file_name or (type.__name__ if type else None)
            if self.blob_name is None:
                raise ValueError(
                    "blob_name cannot be determined: provide 'file_name' in "
                    "blob_config or pass a 'type' argument."
                )
            self.folder_prefix = None

        self.file_extension = _get_file_extension(type)

        display_name = self.folder_prefix or self.blob_name
        name = f"{resolved_container}/{display_name}"
        super().__init__(name, partition_by)
        self.container_name = resolved_container
        self.type = type
        self.storage_name = resolved_storage

    def load(self, context: Context) -> pd.DataFrame | dict[str, pd.DataFrame]:
        """Loads the asset from blob storage.

        Args:
            context: The execution context.

        Returns:
            A single ``pd.DataFrame`` in single-file mode, or
            ``dict[str, pd.DataFrame]`` in multi-file mode.
        """
        return load_asset_from_storage(context, self)

    def store(
        self,
        context: Context,
        value: pd.DataFrame | dict[str, pd.DataFrame],
    ) -> None:
        """Stores the asset in blob storage.

        Args:
            context: The execution context.
            value: A ``pd.DataFrame`` (single-file) or
                ``dict[str, pd.DataFrame]`` (multi-file).
        """
        return store_asset_in_storage(context, self, value)

    def remove(self, context: Context) -> None:
        """Removes the asset from blob storage.

        Args:
            context: The execution context.
        """
        return remove_asset_from_storage(context, self)


def get_partition_blob_info(
    context: Context, asset: BlobAsset
) -> tuple[str | None, dict[str, str]]:
    """Derive the blob prefix and metadata from the partition configuration.

    Returns:
        A tuple of ``(prefix, metadata)`` where *prefix* is the path prefix
        (e.g. ``"42/"`` or ``"42/123/"``) and *metadata* is a dict of
        string key-value pairs for blob metadata.  Both are empty /
        ``None`` when the asset is not partitioned.
    """
    if not asset.partition_by:
        return None, {}

    if asset.partition_by == PartitionBy.LOAD:
        value = str(context.run_info.load_id)
        return f"{value}/", {"load_id": value}

    elif asset.partition_by == PartitionBy.ENTITY:
        value = str(context.run_info.entity_id)
        return f"{value}/", {"entity_id": value}

    else:
        # Custom partition_by: single string or list of attribute names
        if isinstance(asset.partition_by, str):
            part_columns = [asset.partition_by]
        else:
            part_columns = asset.partition_by

        prefix_parts: list[str] = []
        metadata: dict[str, str] = {}

        for column in part_columns:
            if hasattr(context.run_info, column):
                value = getattr(context.run_info, column)
            elif hasattr(context.settings, column):
                value = getattr(context.settings, column)
            elif hasattr(context, column):
                value = getattr(context, column)
            else:
                raise ValueError(
                    f"Attribute '{column}' does not exist in the execution context."
                )

            str_value = str(value)
            prefix_parts.append(str_value)
            metadata[column] = str_value

        prefix = "/".join(prefix_parts) + "/"
        return prefix, metadata


# ---------------------------------------------------------------------------
# Partition-column stripping / restoration helpers
# ---------------------------------------------------------------------------


def _strip_partition_columns(df: pd.DataFrame, partition_by) -> pd.DataFrame:
    """Remove partition columns from *df* (copy) before serialization.

    *partition_by* may be a ``PartitionBy`` enum, a string, a list of
    column names, or ``None``.  When it is already a plain ``list[str]``
    it is used directly (e.g. the full ``partition_candidates`` list).
    """
    cols_to_strip = (
        partition_by
        if isinstance(partition_by, list)
        else _resolve_partition_columns(partition_by)
    )
    cols_present = [c for c in cols_to_strip if c in df.columns]
    if not cols_present:
        return df
    return df.drop(columns=cols_present)


def _restore_partition_columns(
    df: pd.DataFrame, metadata: dict[str, str]
) -> pd.DataFrame:
    """Add partition columns back to *df* from the stored *metadata*."""
    for col, value in metadata.items():
        # Attempt to restore as int if it looks numeric
        try:
            df[col] = int(value)
        except (ValueError, TypeError):
            df[col] = value
    return df


# ---------------------------------------------------------------------------
# Prefix composition helpers
# ---------------------------------------------------------------------------


def _build_full_prefix(
    partition_prefix: str | None, folder_prefix: str | None
) -> str | None:
    """Combine partition prefix and folder prefix into a single string."""
    parts = [p for p in (partition_prefix, folder_prefix) if p]
    return "".join(parts) if parts else None


# ---------------------------------------------------------------------------
# Single-file operations
# ---------------------------------------------------------------------------


def _load_single_file(context: Context, asset: BlobAsset) -> pd.DataFrame:
    storage = context.get_storage(asset.storage_name)
    candidates = _get_partition_candidates(asset.type) or []
    ext = asset.file_extension
    blob_file = f"{asset.blob_name}.{ext.value}"

    if not candidates:
        # No candidate-based partitioning — single blob read.
        data = storage.read_blob(asset.container_name, blob_file, decode=False)
        df = _deserialize_df(data, ext)
        if asset.type is not None:
            df = asset.type.from_data_frame(df)
        return df

    # Resolve known metadata from context (partition_by scope).
    known_meta = _resolve_known_candidate_metadata(
        context, asset.type, asset.partition_by
    )

    if len(known_meta) == len(candidates):
        # All candidates known → deterministic single-file read.
        prefix = _build_candidate_prefix(known_meta, candidates)
        data = storage.read_blob(
            asset.container_name, blob_file, decode=False, prefix=prefix
        )
        df = _deserialize_df(data, ext)
        df = _restore_partition_columns(df, known_meta)
        if asset.type is not None:
            df = asset.type.from_data_frame(df)
        return df

    # Partial partition — metadata-based discovery, read & concatenate.
    matching_blobs = storage.list_blobs(
        asset.container_name, metadata=known_meta if known_meta else {}
    )
    matching = [b for b in matching_blobs if b.endswith(blob_file)]

    dfs: list[pd.DataFrame] = []
    for full_blob_name in matching:
        data = storage.read_blob(asset.container_name, full_blob_name, decode=False)
        blob_meta = storage.get_blob_metadata(asset.container_name, full_blob_name)
        df = _deserialize_df(data, ext)
        df = _restore_partition_columns(df, blob_meta)
        dfs.append(df)

    if not dfs:
        raise RuntimeError(
            f"No blobs found for asset '{asset.name}' with metadata {known_meta}."
        )

    result = pd.concat(dfs, ignore_index=True)
    if asset.type is not None:
        result = asset.type.from_data_frame(result)
    return result


def _store_single_file(context: Context, asset: BlobAsset, value: pd.DataFrame) -> None:
    storage = context.get_storage(asset.storage_name)
    candidates = _get_partition_candidates(asset.type) or []
    ext = asset.file_extension
    blob_file = f"{asset.blob_name}.{ext.value}"

    if not candidates:
        # No candidate-based partitioning — write one blob.
        blob_data = _serialize_df(value, ext)
        storage.write_blob(
            container_name=asset.container_name,
            blob_name=blob_file,
            blob_data=blob_data,
            override=True,
            encoding="utf-8",
        )
        return

    remaining = _get_remaining_candidates(asset.type, asset.partition_by)

    if not remaining:
        # All candidates covered by partition_by — single file.
        all_meta = _resolve_all_candidate_metadata(
            context, asset.type, asset.partition_by
        )
        prefix = _build_candidate_prefix(all_meta, candidates)
        df_to_write = _strip_partition_columns(value.copy(), candidates)
        blob_data = _serialize_df(df_to_write, ext)
        storage.write_blob(
            container_name=asset.container_name,
            blob_name=blob_file,
            blob_data=blob_data,
            override=True,
            encoding="utf-8",
            prefix=prefix,
            metadata=all_meta,
        )
    else:
        # Partial partition — split DF by remaining candidates.
        groupby_key = remaining[0] if len(remaining) == 1 else remaining
        grouped = value.groupby(groupby_key, sort=False)
        for group_key, group_df in grouped:
            if not isinstance(group_key, tuple):
                group_key = (group_key,)
            group_vals = {col: str(val) for col, val in zip(remaining, group_key)}
            all_meta = _resolve_all_candidate_metadata(
                context, asset.type, asset.partition_by, group_vals
            )
            prefix = _build_candidate_prefix(all_meta, candidates)
            df_to_write = _strip_partition_columns(group_df.copy(), candidates)
            blob_data = _serialize_df(df_to_write, ext)
            storage.write_blob(
                container_name=asset.container_name,
                blob_name=blob_file,
                blob_data=blob_data,
                override=True,
                encoding="utf-8",
                prefix=prefix,
                metadata=all_meta,
            )


def _remove_single_file(context: Context, asset: BlobAsset) -> None:
    storage = context.get_storage(asset.storage_name)
    candidates = _get_partition_candidates(asset.type) or []
    ext = asset.file_extension
    blob_file = f"{asset.blob_name}.{ext.value}"

    if not candidates:
        if storage.blob_exists(asset.container_name, blob_file):
            storage.delete_blob(asset.container_name, blob_file)
        return

    known_meta = _resolve_known_candidate_metadata(
        context, asset.type, asset.partition_by
    )

    if len(known_meta) == len(candidates):
        prefix = _build_candidate_prefix(known_meta, candidates)
        if storage.blob_exists(asset.container_name, blob_file, prefix=prefix):
            storage.delete_blob(asset.container_name, blob_file, prefix=prefix)
        return

    # Partial — metadata-based discovery and delete all matching.
    matching_blobs = storage.list_blobs(
        asset.container_name, metadata=known_meta if known_meta else {}
    )
    matching = [b for b in matching_blobs if b.endswith(blob_file)]
    for full_blob_name in matching:
        storage.delete_blob(asset.container_name, full_blob_name)


# ---------------------------------------------------------------------------
# Multi-file helpers
# ---------------------------------------------------------------------------


def _matches_extension(blob_name: str, ext: FileExtension) -> bool:
    """Return ``True`` if *blob_name* ends with the given file extension."""
    return blob_name.endswith(f".{ext.value}")


def _read_matching_blobs(
    storage,
    container_name: str,
    blobs: list[str],
    ext: FileExtension,
    prefix: str | None,
    metadata_to_restore: dict[str, str] | None,
    type_,
) -> dict[str, pd.DataFrame]:
    """Read and deserialize blobs matching the file extension into a dict."""
    result: dict[str, pd.DataFrame] = {}
    for blob_name in blobs:
        if not _matches_extension(blob_name, ext):
            continue
        data = storage.read_blob(container_name, blob_name, decode=False, prefix=prefix)
        df = _deserialize_df(data, ext)
        if metadata_to_restore:
            df = _restore_partition_columns(df, metadata_to_restore)
        if type_ is not None:
            df = type_.from_data_frame(df)
        result[blob_name] = df
    return result


def _delete_matching_blobs(
    storage,
    container_name: str,
    blobs: list[str],
    ext: FileExtension,
    prefix: str | None,
) -> None:
    """Delete blobs matching the file extension."""
    for blob_name in blobs:
        if _matches_extension(blob_name, ext):
            storage.delete_blob(container_name, blob_name, prefix=prefix)


def _write_blob_entries(
    storage,
    container_name: str,
    value: dict[str, pd.DataFrame],
    ext: FileExtension,
    candidates: list[str],
    prefix: str | None,
    metadata: dict[str, str] | None,
) -> None:
    """Write each DataFrame in *value* as a blob under *prefix*."""
    for blob_key, df in value.items():
        df_to_write = _strip_partition_columns(df.copy(), candidates)
        blob_data = _serialize_df(df_to_write, ext)
        storage.write_blob(
            container_name=container_name,
            blob_name=blob_key,
            blob_data=blob_data,
            override=True,
            encoding="utf-8",
            prefix=prefix,
            metadata=metadata,
        )


# ---------------------------------------------------------------------------
# Multi-file operations
# ---------------------------------------------------------------------------


def _load_multi_file(context: Context, asset: BlobAsset) -> dict[str, pd.DataFrame]:
    storage = context.get_storage(asset.storage_name)
    candidates = _get_partition_candidates(asset.type) or []
    ext = asset.file_extension

    if not candidates:
        blobs = storage.list_blobs(asset.container_name, prefix=asset.folder_prefix)
        return _read_matching_blobs(
            storage,
            asset.container_name,
            blobs,
            ext,
            asset.folder_prefix,
            None,
            asset.type,
        )

    known_meta = _resolve_known_candidate_metadata(
        context, asset.type, asset.partition_by
    )

    if len(known_meta) == len(candidates):
        candidate_prefix = _build_candidate_prefix(known_meta, candidates)
        full_prefix = _build_full_prefix(candidate_prefix, asset.folder_prefix)
        blobs = storage.list_blobs(asset.container_name, prefix=full_prefix)
        return _read_matching_blobs(
            storage,
            asset.container_name,
            blobs,
            ext,
            full_prefix,
            known_meta,
            asset.type,
        )

    # Partial partition — metadata-based discovery.
    matching_blobs = storage.list_blobs(
        asset.container_name, metadata=known_meta if known_meta else {}
    )
    result: dict[str, pd.DataFrame] = {}
    for full_blob_name in matching_blobs:
        if not _matches_extension(full_blob_name, ext):
            continue
        data = storage.read_blob(asset.container_name, full_blob_name, decode=False)
        blob_meta = storage.get_blob_metadata(asset.container_name, full_blob_name)
        df = _deserialize_df(data, ext)
        df = _restore_partition_columns(df, blob_meta)
        if asset.type is not None:
            df = asset.type.from_data_frame(df)
        if full_blob_name in result:
            result[full_blob_name] = pd.concat(
                [result[full_blob_name], df], ignore_index=True
            )
        else:
            result[full_blob_name] = df
    return result


def _store_multi_file(
    context: Context,
    asset: BlobAsset,
    value: dict[str, pd.DataFrame],
) -> None:
    storage = context.get_storage(asset.storage_name)
    candidates = _get_partition_candidates(asset.type) or []
    ext = asset.file_extension

    if not candidates:
        _write_blob_entries(
            storage,
            asset.container_name,
            value,
            ext,
            candidates,
            asset.folder_prefix,
            None,
        )
        return

    remaining = _get_remaining_candidates(asset.type, asset.partition_by)

    if not remaining:
        all_meta = _resolve_all_candidate_metadata(
            context, asset.type, asset.partition_by
        )
        candidate_prefix = _build_candidate_prefix(all_meta, candidates)
        full_prefix = _build_full_prefix(candidate_prefix, asset.folder_prefix)
        _write_blob_entries(
            storage,
            asset.container_name,
            value,
            ext,
            candidates,
            full_prefix,
            all_meta,
        )
        return

    # Partial partition — split each DF by remaining candidates.
    for blob_key, df in value.items():
        _store_grouped_blob(
            storage,
            context,
            asset,
            blob_key,
            df,
            candidates,
            remaining,
            ext,
        )


def _store_grouped_blob(
    storage,
    context,
    asset,
    blob_key,
    df,
    candidates,
    remaining,
    ext,
) -> None:
    """Group *df* by *remaining* candidates and write one blob per group."""
    groupby_key = remaining[0] if len(remaining) == 1 else remaining
    grouped = df.groupby(groupby_key, sort=False)
    for group_key, group_df in grouped:
        if not isinstance(group_key, tuple):
            group_key = (group_key,)
        group_vals = {col: str(val) for col, val in zip(remaining, group_key)}
        all_meta = _resolve_all_candidate_metadata(
            context, asset.type, asset.partition_by, group_vals
        )
        candidate_prefix = _build_candidate_prefix(all_meta, candidates)
        full_prefix = _build_full_prefix(candidate_prefix, asset.folder_prefix)
        df_to_write = _strip_partition_columns(group_df.copy(), candidates)
        blob_data = _serialize_df(df_to_write, ext)
        storage.write_blob(
            container_name=asset.container_name,
            blob_name=blob_key,
            blob_data=blob_data,
            override=True,
            encoding="utf-8",
            prefix=full_prefix,
            metadata=all_meta,
        )


def _remove_multi_file(context: Context, asset: BlobAsset) -> None:
    """Delete all matching blobs for the asset's partition scope."""
    storage = context.get_storage(asset.storage_name)
    candidates = _get_partition_candidates(asset.type) or []
    ext = asset.file_extension

    if not candidates:
        blobs = storage.list_blobs(asset.container_name, prefix=asset.folder_prefix)
        _delete_matching_blobs(
            storage, asset.container_name, blobs, ext, asset.folder_prefix
        )
        return

    known_meta = _resolve_known_candidate_metadata(
        context, asset.type, asset.partition_by
    )

    if len(known_meta) == len(candidates):
        candidate_prefix = _build_candidate_prefix(known_meta, candidates)
        full_prefix = _build_full_prefix(candidate_prefix, asset.folder_prefix)
        blobs = storage.list_blobs(asset.container_name, prefix=full_prefix)
        _delete_matching_blobs(storage, asset.container_name, blobs, ext, full_prefix)
        return

    # Partial — metadata-based discovery.
    matching_blobs = storage.list_blobs(
        asset.container_name, metadata=known_meta if known_meta else {}
    )
    _delete_matching_blobs(storage, asset.container_name, matching_blobs, ext, None)


# ---------------------------------------------------------------------------
# Public dispatchers (called by BlobAsset methods)
# ---------------------------------------------------------------------------


def load_asset_from_storage(
    context: Context, asset: BlobAsset
) -> pd.DataFrame | dict[str, pd.DataFrame]:
    """Load a blob asset — dispatches to single-file or multi-file mode."""
    if asset.is_multi_file:
        return _load_multi_file(context, asset)
    return _load_single_file(context, asset)


def store_asset_in_storage(
    context: Context,
    asset: BlobAsset,
    value: pd.DataFrame | dict[str, pd.DataFrame],
) -> None:
    """Store a blob asset — dispatches to single-file or multi-file mode."""
    if asset.is_multi_file:
        if not isinstance(value, dict):
            raise TypeError(
                "Multi-file BlobAsset expects dict[str, pd.DataFrame], "
                f"got {type(value).__name__}."
            )
        _store_multi_file(context, asset, value)
    else:
        if not isinstance(value, pd.DataFrame):
            raise TypeError(
                "Single-file BlobAsset expects pd.DataFrame, "
                f"got {type(value).__name__}."
            )
        _store_single_file(context, asset, value)


def remove_asset_from_storage(context: Context, asset: BlobAsset) -> None:
    """Remove a blob asset — dispatches to single-file or multi-file mode."""
    if asset.is_multi_file:
        _remove_multi_file(context, asset)
    else:
        _remove_single_file(context, asset)


class BlobAssetAnnotation(AssetAnnotation):
    """Annotation helper for declaring BlobAsset-typed DAG inputs/outputs.

    Usage::

        # Inline container name
        Blob[MyDataFrame, "my-container"]

        # Pre-configured container
        MyBlob = BlobAssetAnnotation(BlobAsset, container_name="my-container")
        MyBlob[MyDataFrame]
    """

    def __init__(
        self,
        asset_class,
        partition_by=None,
        storage_name=None,
        container_name=None,
    ):
        self.asset_class = asset_class
        self.partition_by = partition_by
        self.storage_name = storage_name
        self.container_name = container_name
        super().__init__(asset_class)

    def __getitem__(self, item):
        if not isinstance(item, tuple):
            item = (item,)

        type_ = item[0]
        container_override = item[1] if len(item) > 1 else None

        # Resolve container: annotation arg > preset on annotation > type config
        container_name = (
            container_override or self.container_name or _get_container_name(type_)
        )

        if container_name is None:
            raise ValueError(
                "container_name must be provided either in the annotation, "
                "as Blob[Type, 'container-name'], or in the type's "
                "blob_config attribute (BlobConfig)."
            )

        # Resolve storage_name: preset on annotation > type config
        storage_name = self.storage_name or _get_storage_name(type_)

        asset_kwargs = {
            "partition_by": self.partition_by,
            "storage_name": storage_name,
        }

        args = (container_name, type_)
        asset = self.asset_class(*args, **asset_kwargs)

        # Auto-detect multi-file mode and adjust the type hint.
        if asset.is_multi_file:
            type_hint = dict[str, Df[type_]]
        else:
            type_hint = Df[type_]

        return Annotated[type_hint, asset]


Blob = BlobAssetAnnotation(BlobAsset)
EntityBlob = BlobAssetAnnotation(BlobAsset, partition_by=PartitionBy.ENTITY)
LoadBlob = BlobAssetAnnotation(BlobAsset, partition_by=PartitionBy.LOAD)
