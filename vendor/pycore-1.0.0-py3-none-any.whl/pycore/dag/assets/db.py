import warnings
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Annotated, Any

import pandas as pd
import sqlalchemy as sa

from pycore.dag.assets.base import (
    AssetAnnotation,
    BaseAsset,
    BaseDataFrame,
    Df,
    PartitionBy,
)
from pycore.dag.context import Context
from pycore.schemas import Filter, FilterOperator
from pycore.utils.database import get_first_existing_column
from pycore.utils.pandera import df_model_to_db_table


@dataclass
class TableConfig:
    """Configuration for a database-table-backed DataFrame.

    Defines how a :class:`TableDataFrame` maps to a database table via
    SQLAlchemy.  Declare as a class-level ``table_config`` attribute on
    the DataFrame class::

        class Sales(TableDataFrame):
            amount: float

            table_config = TableConfig(
                base=Base,
                table_name="Sales",
                schema="dbo",
            )

            class Config:
                coerce = True
                unique = ["amount"]

    Args:
        base: SQLAlchemy declarative base used for table creation.
        table_name: Name of the database table.  When ``None``, the
            DataFrame class name is used.
        schema: Database schema name.  ``None`` uses the database's
            default schema.
        database_name: Named database from the execution context.
            ``None`` uses the context's default ``data_repo``.
    """

    base: Any
    table_name: str | None = None
    schema: str | None = None
    database_name: str | None = None


class TableDataFrame(BaseDataFrame):
    """Base class for pandera DataFrames backed by a database table.

    Declare the table mapping via a class-level ``table_config`` attribute
    using a :class:`TableConfig`::

        class Sales(TableDataFrame):
            amount: float

            table_config = TableConfig(
                base=Base,
                table_name="Sales",
                schema="dbo",
                database_name="my_database",
            )

            class Config:
                coerce = True
                unique = ["amount"]

    """

    def __init_subclass__(cls, **kwargs):

        # --- New style: class-level table_config attribute ---
        own_config = cls.__dict__.get("table_config")

        # Always run pandera / BaseDataFrame init first.
        super().__init_subclass__(**kwargs)

        config = own_config if isinstance(own_config, TableConfig) else None

        # --- Enforcement ---
        if config is None:
            raise TypeError(
                f"{cls.__name__} subclasses TableDataFrame but does not "
                f"provide a 'table_config = TableConfig(...)' attribute. "
                f"Either add a table_config or subclass BaseDataFrame instead."
            )

        table_name = own_config.table_name or cls.__name__
        cls.table = df_model_to_db_table(
            cls, base=own_config.base, table=table_name, schema=own_config.schema
        )
        cls.orm = cls.as_orm_class(table=cls.table)


def _resolve_type_table_config(type_) -> TableConfig | None:
    """Return the ``TableConfig`` from *type_*'s ``table_config`` attribute."""
    if type_ is None:
        return None
    config = getattr(type_, "table_config", None)
    return config if isinstance(config, TableConfig) else None


class TableAsset(BaseAsset):
    """Represents an asset that is stored in a database table.

    Args:
        table: The name of the table or an SQLAlchemy table object.
        type: The type of the asset, if it is not a pandas dataframe.
        partition_by: Whether the asset is partitioned by load or entity.
        database_name: The name of the database this table belongs to (optional).
            When ``None``, read from the type's ``table_config.database_name``
            or falls back to the default data_repo.
    """

    def __init__(
        self,
        table: sa.Table | str,
        type: Any = None,
        partition_by: PartitionBy | None = None,
        database_name: str | None = None,
    ):
        if isinstance(table, str):
            name = table
        elif table.schema is not None:
            name = f"{table.schema}.{table.name}"
        else:
            name = table.name
        super().__init__(name, partition_by)
        self.table = table
        self.type = type

        # Resolve database_name: explicit arg > TableConfig > legacy metadata
        if database_name is not None:
            self.database_name = database_name
        else:
            tbl_cfg = _resolve_type_table_config(type)
            if tbl_cfg is not None:
                self.database_name = tbl_cfg.database_name
            else:
                meta = getattr(getattr(type, "Config", None), "metadata", None)
                self.database_name = meta.get("database_name") if meta else None

    def load(self, context: Context) -> Any:
        """Loads the asset from the database.

        Args:
            context: The execution context.

        Returns:
            The loaded value, a pandas dataframe.
        """
        return load_asset_from_database(context, self)

    def store(self, context: Context, value: pd.DataFrame) -> None:
        """Stores the asset in the database.

        Args:
            context: The execution context.
            value: The value to be stored.
        """
        return store_asset_in_database(context, self, value)

    def remove(self, context: Context) -> None:
        """Removes the asset from the database.

        Args:
            context: The execution context.
        """
        return remove_asset_from_database(context, self)


def get_partition_db_filters(
    context: Context, asset: BaseAsset
) -> tuple[list[Filter], Sequence[str]]:

    try:
        data_repo = context.get_data_repo(getattr(asset, "database_name", None))
    except ValueError as e:
        raise ValueError(f"Failed to resolve database for asset '{asset.name}': {e}")

    if not isinstance(asset.table, sa.Table):
        asset.table = data_repo.database.get_table(asset.table)

    column_names = [c.name for c in asset.table.columns]

    if not asset.partition_by:
        return [], column_names

    if asset.partition_by == PartitionBy.LOAD:

        field = get_first_existing_column(asset.table, ["load_id", "loadid"])
        value = context.run_info.load_id

        if not field:
            return [], column_names

        filters = [Filter(name=field, type=FilterOperator.equal, value=value)]
        column_names = [c for c in column_names if c != field]

    elif asset.partition_by == PartitionBy.ENTITY:

        field = get_first_existing_column(asset.table, ["entity_id", "entityid"])
        value = context.run_info.entity_id

        if not field:
            return [], column_names

        if isinstance(value, list):
            filter_type = FilterOperator.multiselect
            # Keep entity_id column because multiple values are selected
        else:
            filter_type = FilterOperator.equal
            column_names = [c for c in column_names if c != field]

        filters = [Filter(name=field, type=filter_type, value=value)]

    else:

        filters, column_names = get_filters_from_set_of_columns(context, asset)

    return filters, column_names


def get_filters_from_set_of_columns(
    context: Context, asset: BaseAsset
) -> tuple[list[Filter], Sequence[str]]:

    filters = []
    column_names = [c.name for c in asset.table.columns]

    if isinstance(asset.partition_by, str):
        part_columns = [asset.partition_by]
    else:
        part_columns = asset.partition_by

    for column in part_columns:

        candidates = [column, column.replace("_", "")]
        field = get_first_existing_column(asset.table, candidates)

        if hasattr(context.run_info, column):
            value = getattr(context.run_info, column)
        elif hasattr(context.settings, column):
            value = getattr(context.settings, column)
        elif hasattr(context, column):
            value = getattr(context, column)
        else:
            raise ValueError(
                f"Attribute {column} does not exist in the execution context."
            )

        if not field:
            return [], column_names

        filters.append(Filter(name=field, type=FilterOperator.equal, value=value))
        column_names = [c for c in column_names if c != field]

    return filters, column_names


def load_asset_from_database(context: Context, asset: TableAsset) -> pd.DataFrame:
    try:
        data_repo = context.get_data_repo(asset.database_name)
    except ValueError as e:
        raise ValueError(f"Failed to resolve database for asset '{asset.name}': {e}")

    filters, columns = get_partition_db_filters(context, asset)

    df = data_repo.read_table_with_filters(
        asset.table, columns=columns, filters=filters, as_df=True
    )

    if asset.type is not None:
        df = asset.type.from_data_frame(df)

    return df


def remove_asset_from_database(context: Context, asset: TableAsset):
    try:
        data_repo = context.get_data_repo(asset.database_name)
    except ValueError as e:
        raise ValueError(f"Failed to resolve database for asset '{asset.name}': {e}")

    filters, _ = get_partition_db_filters(context, asset)
    data_repo.delete_table_with_filters(asset.table, filters=filters)


def set_partition_for_db(context: Context, asset: TableAsset, value: pd.DataFrame):
    filters, _ = get_partition_db_filters(context, asset)

    for filter in filters:
        value[filter.name] = filter.value


def store_asset_in_database(context: Context, asset: TableAsset, value: pd.DataFrame):
    try:
        data_repo = context.get_data_repo(asset.database_name)
    except ValueError as e:
        raise ValueError(f"Failed to resolve database for asset '{asset.name}': {e}")

    remove_asset_from_database(context, asset)
    set_partition_for_db(context, asset, value)
    data_repo.write_table(asset.table, value)


class TableAssetAnnotation(AssetAnnotation):
    def __init__(self, asset_class, partition_by=None, database_name=None):
        self.asset_class = asset_class
        self.partition_by = partition_by
        self.database_name = database_name
        super().__init__(asset_class)

    def __getitem__(self, item):
        if not isinstance(item, tuple):
            item = (item,)
        type_ = item[0]

        # Determine table name with fallback to class name
        if hasattr(type_, "table"):
            tab = type_.table
        elif hasattr(type_, "_db_table") and type_._db_table is not None:
            warnings.warn(
                f"Using the deprecated attribute _db_table for type {type_.__name__}."
            )
            tab = type_._db_table
        else:
            # Automatically use class name as table name
            tab = type_.__name__

        # Resolve database_name: preset on annotation > TableConfig > legacy metadata
        tbl_cfg = _resolve_type_table_config(type_)
        if tbl_cfg is not None:
            type_db_name = tbl_cfg.database_name
        else:
            meta = getattr(getattr(type_, "Config", None), "metadata", None)
            type_db_name = meta.get("database_name") if meta else None
        database_name = self.database_name or type_db_name

        asset_kwargs = getattr(self, "kwargs", {}).copy()
        asset_kwargs["database_name"] = database_name
        asset_kwargs["partition_by"] = self.partition_by

        args = (tab, type_)
        return Annotated[Df[type_], self.asset_class(*args, **asset_kwargs)]


Table = TableAssetAnnotation(TableAsset)
EntityTable = TableAssetAnnotation(TableAsset, partition_by=PartitionBy.ENTITY)
LoadTable = TableAssetAnnotation(TableAsset, partition_by=PartitionBy.LOAD)
