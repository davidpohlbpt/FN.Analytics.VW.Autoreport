from __future__ import annotations

from typing import Any, Optional

import fastapi

from pycore import easy
from pycore.workbench.contracts import WorkbenchRequestBase
from pycore.workbench.filters import normalize_filters_payload


def entity_ids_for_request(request: WorkbenchRequestBase) -> list[int]:
    if request.entity_ids:
        return request.entity_ids
    if request.entity_id is not None:
        return [request.entity_id]
    return []


def load_ids_for_request(request: WorkbenchRequestBase) -> list[int]:
    if request.load_ids:
        return request.load_ids
    if request.load_id is not None:
        return [request.load_id]
    return []


def resolve_dimension_value_filter_if_needed(
    request: WorkbenchRequestBase,
    access_token: Optional[str] = None,
) -> list[dict[str, Any]]:
    if not request.has_scoping or not request.dimension_value_id or request.dimension_value_id <= 0:
        return []

    try:
        dimension_value = easy.identity.get_dimension_value_by_id(
            dimension_value_id=request.dimension_value_id,
            menu_item_id=request.menu_item_id,
            access_token=access_token,
        )
    except TypeError:
        dimension_value = easy.identity.get_dimension_value_by_id(
            dimension_value_id=request.dimension_value_id,
            menu_item_id=request.menu_item_id,
        )
    if dimension_value is None:
        raise fastapi.HTTPException(
            status_code=404,
            detail="Dimension value not found or no permission given.",
        )

    source = (dimension_value.dimension_source or "").lower()
    path = "Fields"
    if source in {"incident", "incidents"}:
        path = "Incident"
    elif source == "rules":
        path = "Rule"
    elif source in ("occurence", "occurrence"):
        path = "Fields"
    elif source in ("fields", "parsedfields"):
        path = "Fields"

    return [
        {
            "type": "equal",
            "name": dimension_value.dimension_name,
            "value": dimension_value.dimension_value,
            "path": path,
        }
    ]


def append_dimension_scoping_filters(
    normalized_filters: list,
    request: WorkbenchRequestBase,
    access_token: Optional[str] = None,
) -> list:
    dimension_filters = resolve_dimension_value_filter_if_needed(request, access_token)
    if not dimension_filters:
        return normalized_filters
    normalized_filters.extend(normalize_filters_payload(dimension_filters))
    return normalized_filters
