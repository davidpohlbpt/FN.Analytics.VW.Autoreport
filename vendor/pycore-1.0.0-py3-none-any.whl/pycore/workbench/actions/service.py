"""Read and mutation behavior for the workbench action endpoints.

Mirrors the .NET `WorkbenchActionService` / `IncidentCommentService` and the
repositories they delegate to. Functions take an open SQLAlchemy session so the
FastAPI handlers stay orchestration-only and the behavior remains testable
without HTTP.
"""

import datetime as dt
from typing import Iterable, Optional, Sequence

import sqlalchemy as sa
from sqlalchemy.orm import Session

from pycore.workbench.actions.constants import (
    ERROR_MESSAGE_DELETED_INCIDENTS,
    ERROR_MESSAGE_NO_INCIDENTS_SUPPLIED,
    EVENT_NAME_ASSIGNED,
    EVENT_NAME_COMMENTED,
    EVENT_NAME_DELETED,
    EVENT_NAME_HIDDEN,
    EVENT_NAME_MARKED_RESOLVED,
    EVENT_NAME_RESTORED,
    EVENT_NAME_UNASSIGNED,
    EVENT_NAME_UNHIDDEN,
    SYSTEM_ACTION_USER_ID,
)
from pycore.workbench.actions.contracts import (
    IncidentActionModel,
    WorkbenchIncidentCommentResponse,
    WorkbenchIncidentHistoryResponse,
)
from pycore.workbench.actions.exceptions import (
    EventTypeNotFoundError,
    IncidentNotFoundError,
    OperationNotAllowedError,
)
from pycore.workbench.actions.users import UserDirectory
from pycore.workbench.models import (
    Incident,
    IncidentComment,
    IncidentDelete,
    IncidentEventType,
    IncidentHideUser,
    IncidentHistory,
    IncidentResolve,
)

# `T_CONTROL_Incident_EventTypes` row describing an incident's first occurrence.
# The .NET handler looks it up by id rather than by event name.
FIRST_OCCURRENCE_EVENT_TYPE_ID = 1

# .NET dates comments two minutes ahead so they sort after the history row
# written in the same request.
COMMENT_DATE_OFFSET = dt.timedelta(minutes=2)


def _utc_now() -> dt.datetime:
    # The stored columns are naive `datetime`, so drop the tzinfo after reading UTC.
    return dt.datetime.now(dt.timezone.utc).replace(tzinfo=None)


def get_incident_history(
    session: Session,
    incident_id: int,
    scenario_id: int,
    directory: Optional[UserDirectory] = None,
) -> list[WorkbenchIncidentHistoryResponse]:
    """Returns the chronological event log for one incident in one scenario.

    When the incident has no stored first-occurrence event, a synthetic entry
    derived from `Incident.Created` is appended, matching .NET behavior.
    """
    directory = directory or UserDirectory()

    incident = session.execute(
        sa.select(Incident.IncidentID, Incident.Created).where(
            Incident.IncidentID == incident_id,
            Incident.ScenarioId == scenario_id,
        )
    ).first()

    if incident is None:
        raise IncidentNotFoundError(
            f"Incident not found for IncidentId: {incident_id}, ScenarioId: {scenario_id}"
        )

    statement = (
        sa.select(
            IncidentHistory.IncidentHistoryID,
            IncidentHistory.IncidentID,
            IncidentHistory.ScenarioID,
            IncidentHistory.EventTypeID,
            IncidentHistory.DateTime,
            IncidentHistory.UserId,
            IncidentHistory.LoadID,
            IncidentHistory.RuleID,
            IncidentHistory.Comment,
            IncidentHistory.HideUntil,
            IncidentHistory.Values,
            IncidentEventType.TranslationKey.label("EventTypeDescription"),
        )
        .outerjoin(
            IncidentEventType,
            IncidentHistory.EventTypeID == IncidentEventType.EventTypeID,
        )
        .where(
            IncidentHistory.IncidentID == incident_id,
            IncidentHistory.ScenarioID == scenario_id,
        )
        .order_by(IncidentHistory.RuleID, IncidentHistory.IncidentID)
    )

    history = [
        WorkbenchIncidentHistoryResponse(
            incident_history_id=row.IncidentHistoryID,
            incident_id=row.IncidentID,
            scenario_id=row.ScenarioID,
            event_type_id=row.EventTypeID,
            date_time=row.DateTime,
            user_id=directory.resolve_email(row.UserId),
            load_id=row.LoadID,
            rule_id=row.RuleID,
            comment=row.Comment,
            event_type_description=row.EventTypeDescription,
            hide_until=row.HideUntil,
            values=row.Values,
        )
        for row in session.execute(statement)
    ]

    if not any(entry.event_type_id == FIRST_OCCURRENCE_EVENT_TYPE_ID for entry in history):
        history.append(_build_first_occurrence_entry(session, incident_id, scenario_id, incident.Created))

    return history


def _build_first_occurrence_entry(
    session: Session,
    incident_id: int,
    scenario_id: int,
    created: Optional[object],
) -> WorkbenchIncidentHistoryResponse:
    translation_key = session.execute(
        sa.select(IncidentEventType.TranslationKey).where(
            IncidentEventType.EventTypeID == FIRST_OCCURRENCE_EVENT_TYPE_ID
        )
    ).scalar_one_or_none()

    return WorkbenchIncidentHistoryResponse(
        incident_history_id=0,
        incident_id=incident_id,
        scenario_id=scenario_id,
        event_type_id=FIRST_OCCURRENCE_EVENT_TYPE_ID,
        date_time=created,
        event_type_description=translation_key,
    )


def get_incident_comments(
    session: Session,
    incident_ids: Sequence[int],
    scenario_id: int,
    directory: Optional[UserDirectory] = None,
) -> list[list[WorkbenchIncidentCommentResponse]]:
    """Returns comments grouped per incident, in the requested incident order.

    Incidents without comments are omitted entirely rather than yielding an
    empty inner list, matching the .NET `GetIncidentCommentsAsync` shape.
    """
    if not incident_ids:
        return []

    directory = directory or UserDirectory()

    statement = (
        sa.select(
            IncidentComment.Id,
            IncidentComment.IncidentID,
            IncidentComment.ScenarioID,
            IncidentComment.UserId,
            IncidentComment.Date,
            IncidentComment.Comment,
        )
        .where(
            IncidentComment.IncidentID.in_(incident_ids),
            IncidentComment.ScenarioID == scenario_id,
        )
        .order_by(IncidentComment.Date.desc())
    )

    comments_by_incident: dict[int, list[WorkbenchIncidentCommentResponse]] = {}
    for row in session.execute(statement):
        comments_by_incident.setdefault(row.IncidentID, []).append(
            WorkbenchIncidentCommentResponse(
                id=row.Id,
                incident_id=row.IncidentID,
                scenario_id=row.ScenarioID,
                user_id=row.UserId,
                username=directory.resolve_username(row.UserId),
                date=row.Date,
                comment=row.Comment,
                # .NET does not project LoadId onto this response; keep it null for parity.
                load_id=None,
            )
        )

    return [
        comments_by_incident[incident_id]
        for incident_id in dict.fromkeys(incident_ids)
        if incident_id in comments_by_incident
    ]


def resolve_event_type_id(session: Session, event_name: str) -> int:
    # The control table can hold more than one row per event name, so pin the
    # lookup to the lowest id instead of relying on unordered `FIRST` semantics.
    event_type_id = session.execute(
        sa.select(IncidentEventType.EventTypeID)
        .where(IncidentEventType.EventName == event_name)
        .order_by(IncidentEventType.EventTypeID)
    ).scalars().first()

    if event_type_id is None:
        raise EventTypeNotFoundError(f"Incident event type `{event_name}` is not configured.")
    return event_type_id


def forbid_operation_on_deleted_incidents(
    session: Session, incident_ids: Sequence[int], scenario_id: int
) -> None:
    if not incident_ids:
        return

    deleted_exists = session.execute(
        sa.select(IncidentDelete.IncidentID)
        .where(
            IncidentDelete.IncidentID.in_(incident_ids),
            IncidentDelete.ScenarioID == scenario_id,
        )
        .limit(1)
    ).first()

    if deleted_exists is not None:
        raise OperationNotAllowedError(ERROR_MESSAGE_DELETED_INCIDENTS)


def _add_history(
    session: Session,
    incident_ids: Iterable[int],
    scenario_id: int,
    event_type_id: int,
    user_id: Optional[str],
    load_ids: Optional[dict[int, int]] = None,
    comment: Optional[str] = None,
    occurred_at: Optional[dt.datetime] = None,
) -> None:
    occurred_at = occurred_at or _utc_now()
    load_ids = load_ids or {}

    session.add_all(
        [
            IncidentHistory(
                IncidentID=incident_id,
                ScenarioID=scenario_id,
                EventTypeID=event_type_id,
                DateTime=occurred_at,
                UserId=user_id,
                LoadID=load_ids.get(incident_id),
                Comment=comment,
            )
            for incident_id in incident_ids
        ]
    )


def _load_ids_by_incident(incidents: Sequence[IncidentActionModel]) -> dict[int, int]:
    return {incident.incident_id: incident.load_id for incident in incidents}


def _existing_incident_ids(
    session: Session, incident_ids: Sequence[int], scenario_id: int
) -> list[int]:
    return list(
        session.execute(
            sa.select(Incident.IncidentID).where(
                Incident.IncidentID.in_(incident_ids),
                Incident.ScenarioId == scenario_id,
            )
        ).scalars()
    )


def get_incident_business_rules(
    session: Session,
    incident_ids: Sequence[int],
    scenario_id: int,
    entity_ids: Optional[Sequence[int]] = None,
) -> dict[int, str]:
    """Returns the business rule id per incident, used to describe assignment emails."""
    if not incident_ids:
        return {}

    statement = sa.select(Incident.IncidentID, Incident.BusinessRuleId).where(
        Incident.IncidentID.in_(incident_ids),
        Incident.ScenarioId == scenario_id,
    )
    if entity_ids:
        statement = statement.where(Incident.EntityId.in_(entity_ids))

    return {row.IncidentID: row.BusinessRuleId or "" for row in session.execute(statement)}


def assign_incidents(
    session: Session,
    incident_ids: Sequence[int],
    scenario_id: int,
    assigned_user_email: str,
) -> bool:
    """Assigns every incident to `assigned_user_email` and logs the change."""
    return _set_assigned_user(
        session, incident_ids, scenario_id, assigned_user_email, EVENT_NAME_ASSIGNED
    )


def unassign_incidents(
    session: Session, incident_ids: Sequence[int], scenario_id: int
) -> bool:
    return _set_assigned_user(session, incident_ids, scenario_id, None, EVENT_NAME_UNASSIGNED)


def _set_assigned_user(
    session: Session,
    incident_ids: Sequence[int],
    scenario_id: int,
    assigned_user_email: Optional[str],
    event_name: str,
) -> bool:
    if not incident_ids:
        raise OperationNotAllowedError(ERROR_MESSAGE_NO_INCIDENTS_SUPPLIED)

    forbid_operation_on_deleted_incidents(session, incident_ids, scenario_id)
    event_type_id = resolve_event_type_id(session, event_name)

    existing_ids = set(_existing_incident_ids(session, incident_ids, scenario_id))
    missing = [incident_id for incident_id in incident_ids if incident_id not in existing_ids]
    if missing:
        raise IncidentNotFoundError(
            f"Invalid IncidentIDs {missing} supplied for ScenarioID: {scenario_id}."
        )

    session.execute(
        sa.update(Incident)
        .where(Incident.IncidentID.in_(incident_ids), Incident.ScenarioId == scenario_id)
        .values(AssignedUser=assigned_user_email)
    )
    # .NET records the assignee's email as the history actor, and null on unassign.
    _add_history(session, incident_ids, scenario_id, event_type_id, assigned_user_email)
    return True


def hide_incidents(
    session: Session,
    incidents: Sequence[IncidentActionModel],
    scenario_id: int,
    user_id: str,
    user_email: str,
    hide_until: Optional[dt.datetime],
) -> bool:
    if not incidents:
        return False

    incident_ids = [incident.incident_id for incident in incidents]
    forbid_operation_on_deleted_incidents(session, incident_ids, scenario_id)
    event_type_id = resolve_event_type_id(session, EVENT_NAME_HIDDEN)

    load_ids = _load_ids_by_incident(incidents)
    existing_ids = _existing_incident_ids(session, incident_ids, scenario_id)
    if not existing_ids:
        return True

    existing_hides = {
        hide.IncidentID: hide
        for hide in session.execute(
            sa.select(IncidentHideUser).where(
                IncidentHideUser.IncidentID.in_(existing_ids),
                IncidentHideUser.ScenarioID == scenario_id,
                IncidentHideUser.UserId == user_id,
            )
        ).scalars()
    }

    for incident_id in existing_ids:
        hide = existing_hides.get(incident_id)
        if hide is None:
            hide = IncidentHideUser(IncidentID=incident_id, ScenarioID=scenario_id)
            session.add(hide)
        hide.UserId = user_id
        hide.HideUntil = hide_until
        hide.Email = user_email
        hide.CreatedBy = user_email
        hide.LoadId = load_ids.get(incident_id)

    _add_history(session, existing_ids, scenario_id, event_type_id, user_email)
    return True


def show_incidents(
    session: Session,
    incident_ids: Sequence[int],
    scenario_id: int,
    user_email: str,
) -> bool:
    if not incident_ids:
        return False

    forbid_operation_on_deleted_incidents(session, incident_ids, scenario_id)
    event_type_id = resolve_event_type_id(session, EVENT_NAME_UNHIDDEN)

    hidden_ids = list(
        session.execute(
            sa.select(IncidentHideUser.IncidentID).where(
                IncidentHideUser.IncidentID.in_(incident_ids),
                IncidentHideUser.ScenarioID == scenario_id,
            )
        ).scalars()
    )

    # .NET writes no history when nothing was hidden, but still reports success.
    if not hidden_ids:
        return True

    session.execute(
        sa.delete(IncidentHideUser).where(
            IncidentHideUser.IncidentID.in_(incident_ids),
            IncidentHideUser.ScenarioID == scenario_id,
        )
    )
    _add_history(session, incident_ids, scenario_id, event_type_id, user_email)
    return True


def resolve_incidents(
    session: Session,
    incidents: Sequence[IncidentActionModel],
    scenario_id: int,
    user_id: str,
    user_email: str,
) -> bool:
    """Marks incidents resolved; returns False when nothing was resolved."""
    if not incidents:
        return False

    incident_ids = [incident.incident_id for incident in incidents]
    forbid_operation_on_deleted_incidents(session, incident_ids, scenario_id)

    existing_ids = _existing_incident_ids(session, incident_ids, scenario_id)
    if not existing_ids:
        return False

    event_type_id = resolve_event_type_id(session, EVENT_NAME_MARKED_RESOLVED)
    load_ids = _load_ids_by_incident(incidents)

    session.add_all(
        [
            IncidentResolve(
                IncidentID=incident_id,
                ScenarioID=scenario_id,
                LoadId=load_ids.get(incident_id, 0),
                UserId=user_id,
                CreatedBy=user_email,
            )
            for incident_id in existing_ids
        ]
    )
    _add_history(session, existing_ids, scenario_id, event_type_id, user_email)
    return True


def mark_incidents_as_deleted(
    session: Session,
    incidents: Sequence[IncidentActionModel],
    scenario_id: int,
    current_user_id: str,
    load_id: int = 0,
) -> bool:
    """Marks incidents deleted, skipping any that are already deleted."""
    incident_ids = [incident.incident_id for incident in incidents]
    if not incident_ids:
        raise OperationNotAllowedError(ERROR_MESSAGE_NO_INCIDENTS_SUPPLIED)

    existing_ids = set(_existing_incident_ids(session, incident_ids, scenario_id))
    already_deleted = set(
        session.execute(
            sa.select(IncidentDelete.IncidentID).where(
                IncidentDelete.IncidentID.in_(incident_ids),
                IncidentDelete.ScenarioID == scenario_id,
            )
        ).scalars()
    )
    pending_ids = [
        incident_id
        for incident_id in incident_ids
        if incident_id in existing_ids and incident_id not in already_deleted
    ]
    if not pending_ids:
        return True

    event_type_id = resolve_event_type_id(session, EVENT_NAME_DELETED)

    session.execute(
        sa.delete(IncidentHideUser).where(
            IncidentHideUser.IncidentID.in_(pending_ids),
            IncidentHideUser.ScenarioID == scenario_id,
        )
    )
    deleted_on = _utc_now()
    session.add_all(
        [
            IncidentDelete(
                IncidentID=incident_id,
                ScenarioID=scenario_id,
                UserId=current_user_id,
                CreatedOn=deleted_on,
            )
            for incident_id in pending_ids
        ]
    )
    _add_history(
        session,
        pending_ids,
        scenario_id,
        event_type_id,
        current_user_id,
        load_ids={
            incident.incident_id: incident.load_id or load_id for incident in incidents
        },
        occurred_at=deleted_on,
    )
    return True


def restore_incidents(
    session: Session,
    incident_ids: Sequence[int],
    scenario_id: int,
    current_user_id: str,
    load_id: int = 0,
) -> bool:
    """Restores incidents, writing history only for the ones actually deleted."""
    if not incident_ids:
        raise OperationNotAllowedError(ERROR_MESSAGE_NO_INCIDENTS_SUPPLIED)

    restored_ids = list(
        session.execute(
            sa.select(IncidentDelete.IncidentID).where(
                IncidentDelete.IncidentID.in_(incident_ids),
                IncidentDelete.ScenarioID == scenario_id,
            )
        ).scalars()
    )
    if not restored_ids:
        return True

    event_type_id = resolve_event_type_id(session, EVENT_NAME_RESTORED)

    session.execute(
        sa.delete(IncidentDelete).where(
            IncidentDelete.IncidentID.in_(restored_ids),
            IncidentDelete.ScenarioID == scenario_id,
        )
    )
    _add_history(
        session,
        restored_ids,
        scenario_id,
        event_type_id,
        current_user_id,
        load_ids=dict.fromkeys(restored_ids, load_id),
    )
    return True


def unhide_expired_incidents(session: Session) -> bool:
    """Removes hide rows whose `HideUntil` has passed and logs the unhide.

    An incident is only unhidden when *every* one of its hide rows has expired,
    matching the .NET `LogUnhiddenElementsAsync` sweep.
    """
    today = _utc_now().date()

    eligible_ids = list(
        session.execute(
            sa.select(IncidentHideUser.IncidentID)
            .group_by(IncidentHideUser.IncidentID)
            .having(
                sa.func.count()
                == sa.func.sum(
                    sa.case(
                        (
                            sa.and_(
                                IncidentHideUser.HideUntil.is_not(None),
                                sa.cast(IncidentHideUser.HideUntil, sa.Date) <= today,
                            ),
                            1,
                        ),
                        else_=0,
                    )
                )
            )
        ).scalars()
    )

    if not eligible_ids:
        return False

    expired_rows = list(
        session.execute(
            sa.select(
                IncidentHideUser.IncidentID,
                IncidentHideUser.ScenarioID,
                IncidentHideUser.HideUntil,
                IncidentHideUser.LoadId,
            ).where(IncidentHideUser.IncidentID.in_(eligible_ids))
        )
    )

    if not expired_rows:
        return False

    event_type_id = resolve_event_type_id(session, EVENT_NAME_UNHIDDEN)

    # One history row per (incident, scenario), carrying the latest hide expiry.
    latest_by_incident: dict[tuple[int, int], object] = {}
    for row in expired_rows:
        key = (row.IncidentID, row.ScenarioID)
        current = latest_by_incident.get(key)
        if current is None or (row.HideUntil or dt.datetime.min) > (
            current.HideUntil or dt.datetime.min
        ):
            latest_by_incident[key] = row

    session.execute(
        sa.delete(IncidentHideUser).where(IncidentHideUser.IncidentID.in_(eligible_ids))
    )

    unhidden_at = _utc_now()
    session.add_all(
        [
            IncidentHistory(
                IncidentID=incident_id,
                ScenarioID=scenario_id,
                EventTypeID=event_type_id,
                DateTime=row.HideUntil or unhidden_at,
                UserId=SYSTEM_ACTION_USER_ID,
                LoadID=row.LoadId,
            )
            for (incident_id, scenario_id), row in latest_by_incident.items()
        ]
    )
    return True


def comment_incidents(
    session: Session,
    incidents: Sequence[IncidentActionModel],
    scenario_id: int,
    comment: str,
    user_id: str,
    user_email: str,
) -> bool:
    if not incidents:
        return False

    event_type_id = resolve_event_type_id(session, EVENT_NAME_COMMENTED)

    commented_at = _utc_now()
    session.add_all(
        [
            IncidentComment(
                IncidentID=incident.incident_id,
                ScenarioID=scenario_id,
                Comment=comment,
                Date=commented_at + COMMENT_DATE_OFFSET,
                UserId=user_id,
                CreatedBy=user_email,
                LoadId=incident.load_id,
            )
            for incident in incidents
        ]
    )
    _add_history(
        session,
        [incident.incident_id for incident in incidents],
        scenario_id,
        event_type_id,
        user_email,
        comment=comment,
        occurred_at=commented_at,
    )
    return True
