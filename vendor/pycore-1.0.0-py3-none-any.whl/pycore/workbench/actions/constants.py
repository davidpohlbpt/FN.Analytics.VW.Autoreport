"""Named constants for the workbench action surface.

Values mirror the .NET `WorkbenchActionController` / `WorkbenchActionService`
behavior so PyCore stays contract-compatible with the FnApiGateway callers.
"""

import re

WORKBENCH_ACTION_PREFIX = "/api/v1/workbenchAction"

ROUTE_HISTORY = "/history/{incident_id}/{scenario_id}"
ROUTE_ASSIGN = "/assign"
ROUTE_UNASSIGN = "/unassign"
ROUTE_SHOW = "/show"
ROUTE_HIDE = "/hide"
ROUTE_HIDE_EXPIRED = "/hideExpired"
ROUTE_RESOLVE = "/resolve"
ROUTE_DELETE = "/delete"
ROUTE_RESTORE = "/restore"
ROUTE_GROUP_ACTION = "/groupAction"
ROUTE_COMMENTS = "/comments"
ROUTE_GROUP_COMMENTS = "/groupComments"
ROUTE_COMMENT = "/comment"

# `T_CONTROL_Incident_EventTypes.EventName` values written to incident history.
# Spelling follows the deployed control table, which is not always correct English.
EVENT_NAME_ASSIGNED = "Assigned"
EVENT_NAME_UNASSIGNED = "Unassigned"
EVENT_NAME_HIDDEN = "Hidden"
EVENT_NAME_UNHIDDEN = "Unhidden"
EVENT_NAME_MARKED_RESOLVED = "MarkedResolved"
EVENT_NAME_COMMENTED = "Commented"
EVENT_NAME_DELETED = "Deleted"
EVENT_NAME_RESTORED = "Restored"

# `NonDatabase.Constants.ActionType.SystemAction` — the user id recorded on
# history rows written by the hideExpired sweep rather than by a real user.
SYSTEM_ACTION_USER_ID = "SystemAction"

COMMENT_MAX_LENGTH = 256

# Mirrors `Core.Common.Validators.StringMustNotContainHTML`.
HTML_TAG_RE = re.compile(r"<[^>]+>")
ERROR_MESSAGE_HTML_NOT_ALLOWED = "The input should not contain HTML code."

ERROR_MESSAGE_OPERATION_NOT_ALLOWED = "Operation not allowed"
ERROR_MESSAGE_DELETED_INCIDENTS = "Hide not allowed on deleted Incidents"
ERROR_MESSAGE_ACTION_ON_DELETED_VIEW = "Action not supported on Deleted Incidents"
ERROR_MESSAGE_DELETE_NOT_ALLOWED = "Deletion not allowed on this workbench"
ERROR_MESSAGE_RESTORE_NOT_ALLOWED = "Restore not allowed on this workbench"
ERROR_MESSAGE_ACTION_NOT_SUPPORTED = "Incident Action not supported"
ERROR_MESSAGE_MISSING_GROUPING_DIMENSION = (
    "A selected group cannot be resolved without a grouping dimension."
)

# Grouping dimensions that .NET's `HandleGrouping` resolves against the rule set
# rather than against a column. Routing is by dimension name first, origin second.
RULE_GROUPING_DIMENSIONS: frozenset[str] = frozenset(
    {
        "criticality",
        "legacy",
        "solvable",
        "masterdata",
        "groupingdimension1",
        "groupingdimension2",
    }
)

# Grouping dimensions that always resolve to an `Incident` column, whatever the
# origin claims - `BusinessRuleId` in particular is a column, not a rule lookup.
INCIDENT_GROUPING_DIMENSIONS: frozenset[str] = frozenset(
    {"businessruleid", "assigneduser"}
)
ERROR_MESSAGE_INVALID_USER_EMAIL = "Invalid user email."
ERROR_MESSAGE_INVALID_MENU_ITEM = "Invalid menu item."
ERROR_MESSAGE_NO_INCIDENTS_SUPPLIED = "No incidents supplied."

ERROR_CODE_OPERATION_NOT_ALLOWED = "operation_not_allowed"
