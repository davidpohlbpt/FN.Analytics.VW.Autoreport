"""Resolves a workbench group selection into concrete incidents.

Mirrors the .NET `WorkbenchActionService.GetSelectedIncidentsIds`: a group whose
`isSelected` flag is false contributes only its explicit inclusions, while a
selected group is resolved by running the workbench filters scoped to that
group's dimension value and then removing its exclusions.
"""

from typing import Optional

from sqlalchemy.orm import Session

from pycore.schemas import FilterOperator
from pycore.workbench.actions.constants import (
    ERROR_MESSAGE_MISSING_GROUPING_DIMENSION,
    INCIDENT_GROUPING_DIMENSIONS,
    RULE_GROUPING_DIMENSIONS,
)
from pycore.workbench.actions.contracts import (
    GroupIncidentOccurrence,
    WorkbenchGroupActionRequest,
)
from pycore.workbench.actions.exceptions import OperationNotAllowedError
from pycore.workbench.constants import (
    EMPTY,
    ORIGIN_FIELDS,
    ORIGIN_INCIDENT,
    ORIGIN_INCIDENTS,
    ORIGIN_RULES,
)
from pycore.workbench.contracts import WorkbenchGroupsRequest
from pycore.workbench.filters import (
    normalize_filters_payload,
    route_filters,
    route_search_parameters,
)
from pycore.workbench.models import Incident, Occurrence
from pycore.workbench.query.base import build_base_query
from pycore.workbench.rule_matching import resolve_rule_scope

# .NET treats a blank group title as the null/empty bucket.
EMPTY_GROUP_VALUE = EMPTY


def build_query_request(request: WorkbenchGroupActionRequest) -> WorkbenchGroupsRequest:
    """Projects a group action request onto the shared workbench query contract."""
    dimension, origin = resolve_grouping(request)
    return WorkbenchGroupsRequest(
        menu_item_id=request.menu_item_id,
        scenario_id=request.scenario_id,
        entity_id=request.entity_id,
        entity_ids=request.entity_ids,
        load_id=request.load_id,
        load_ids=request.load_ids,
        reporting_unit_id=request.reporting_unit_id,
        dimension_value_id=request.dimension_value_id,
        has_scoping=request.has_scoping,
        show_hidden=request.show_hidden,
        show_deleted=request.show_deleted,
        filters=request.filters,
        search_parameters=request.search_parameters,
        grouping_dimension=dimension,
        grouping_dimension_origin=origin or None,
        computed_occurrence_columns=request.computed_occurrence_columns,
        workbench_default_filters=request.workbench_default_filters,
    )


def build_group_scope_filter(
    request: WorkbenchGroupActionRequest, group_value: str
) -> list[dict]:
    """Builds the filter that scopes a query to one group's value.

    Mirrors .NET's `HandleGrouping`, which routes on the dimension name first
    and only falls back to the origin: `BusinessRuleId`/`AssignedUser` are
    `Incident` columns even when the caller labels their origin as `rule`.

    Raises:
        OperationNotAllowedError: if no grouping dimension is available. Without
            one the query cannot be narrowed to the group, and returning an
            unscoped filter would silently apply the action to every incident
            in the scenario.
    """
    dimension, origin = resolve_grouping(request)

    if not dimension:
        raise OperationNotAllowedError(ERROR_MESSAGE_MISSING_GROUPING_DIMENSION)

    normalized_dimension = dimension.lower().strip()
    is_empty_group = not group_value or group_value == EMPTY_GROUP_VALUE

    if normalized_dimension in RULE_GROUPING_DIMENSIONS:
        path = ORIGIN_RULES
    elif (
        normalized_dimension in INCIDENT_GROUPING_DIMENSIONS
        or origin == ORIGIN_INCIDENT
    ):
        path = ORIGIN_INCIDENTS
    else:
        path = ORIGIN_FIELDS

    operator = (
        FilterOperator.is_null.value
        if is_empty_group and path == ORIGIN_INCIDENTS
        else FilterOperator.equal.value
    )

    return [
        {
            "type": operator,
            "name": dimension,
            "value": group_value,
            "path": path,
        }
    ]


def resolve_grouping(
    request: WorkbenchGroupActionRequest,
) -> tuple[Optional[str], str]:
    """Returns the grouping dimension and origin, from either carrier field.

    .NET copies `GroupingDimension`/`GroupingDimensionOrigin` onto `Grouping`
    before querying, so callers may populate either one.
    """
    grouping = request.grouping
    dimension = request.grouping_dimension or (grouping.dimension_column if grouping else None)
    origin = request.grouping_dimension_origin or (grouping.origin if grouping else None)
    return dimension or None, (origin or "").lower().strip()


def _incident_occurrence_columns(statement):
    return statement.with_only_columns(
        Incident.IncidentID.label("incident_id"),
        Incident.BusinessRuleId.label("business_rule_id"),
        Occurrence.EntityId.label("entity_id"),
        Occurrence.LoadId.label("load_id"),
    )


def _rows_to_occurrences(rows) -> list[GroupIncidentOccurrence]:
    return [
        GroupIncidentOccurrence(
            incident_id=row.incident_id,
            business_rule_id=row.business_rule_id or "",
            entity_id=row.entity_id or 0,
            load_id=row.load_id or 0,
        )
        for row in rows
    ]


def resolve_group_incidents(
    session: Session,
    request: WorkbenchGroupActionRequest,
    access_token: Optional[str] = None,
) -> list[GroupIncidentOccurrence]:
    """Returns every incident targeted by the request's group selection."""
    selected: list[GroupIncidentOccurrence] = []
    seen: set[int] = set()

    for group_value, selection in (request.groups_selection or {}).items():
        if selection.is_selected:
            rows = _resolve_selected_group(session, request, group_value, access_token)
            excluded = set(selection.exclusions)
            rows = [row for row in rows if row.incident_id not in excluded]
        else:
            rows = _resolve_included_incidents(session, request, selection.inclusions)

        for row in rows:
            if row.incident_id not in seen:
                seen.add(row.incident_id)
                selected.append(row)

    return selected


def _resolve_included_incidents(
    session: Session,
    request: WorkbenchGroupActionRequest,
    inclusions: list[int],
) -> list[GroupIncidentOccurrence]:
    if not inclusions:
        return []

    query_request = build_query_request(request)
    statement = build_base_query(query_request, include_user_filters=False)
    statement = _incident_occurrence_columns(statement).where(
        Incident.IncidentID.in_(inclusions)
    )
    return _rows_to_occurrences(session.execute(statement))


def _resolve_selected_group(
    session: Session,
    request: WorkbenchGroupActionRequest,
    group_value: str,
    access_token: Optional[str],
) -> list[GroupIncidentOccurrence]:
    query_request = build_query_request(request)
    normalized_filters = normalize_filters_payload(query_request.filters)
    normalized_filters += normalize_filters_payload(
        build_group_scope_filter(request, group_value)
    )
    routed_filters = route_filters(
        normalized_filters
    )
    routed_search_parameters = route_search_parameters(
        query_request.search_parameters, query_request.computed_occurrence_columns
    )

    entity_ids = query_request.entity_ids or (
        [query_request.entity_id] if query_request.entity_id else []
    )
    rule_scope = resolve_rule_scope(
        rule_filters=routed_filters.rule,
        entity_ids=entity_ids,
        scenario_id=query_request.scenario_id,
        access_token=access_token,
    )

    statement = build_base_query(
        query_request,
        routed_filters=routed_filters,
        routed_search_parameters=routed_search_parameters,
        include_user_filters=True,
    )
    statement = _incident_occurrence_columns(statement)

    if routed_filters.rule:
        # .NET only queries when the rule filters matched at least one rule
        # (`if (businessRules.Count > 0)`), and then constrains with an include
        # list. Never invert this into an exclusion: an empty match must select
        # nothing, not every incident whose rule is unknown.
        if not rule_scope.included_rule_ids:
            return []
        statement = statement.where(
            Incident.BusinessRuleId.in_(rule_scope.included_rule_ids)
        )

    return _rows_to_occurrences(session.execute(statement))
