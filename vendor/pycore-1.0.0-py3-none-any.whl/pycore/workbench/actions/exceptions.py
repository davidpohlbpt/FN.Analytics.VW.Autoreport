class WorkbenchActionError(Exception):
    """Base class for workbench action failures with a defined HTTP mapping."""


class IncidentNotFoundError(WorkbenchActionError):
    """Raised when a targeted incident does not exist in the given scenario."""


class OperationNotAllowedError(WorkbenchActionError):
    """Mirrors the .NET `InvalidOperationException` paths mapped to HTTP 400."""


class EventTypeNotFoundError(WorkbenchActionError):
    """Raised when a required `T_CONTROL_Incident_EventTypes` row is missing."""
