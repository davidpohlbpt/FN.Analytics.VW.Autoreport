"""Request/response contracts for the `/api/v1/workbenchAction` surface.

Field names and aliases mirror the .NET `FN.Workbench.Contracts` types so the
FnApiGateway can deserialize PyCore responses into its own models unchanged.
Where the .NET property uses an `ID` suffix (`IncidentID`, `ScenarioID`, ...)
its camelCase JSON name keeps the uppercase `ID`, which the repo's `to_camel`
generator would render as `Id` — those fields carry an explicit alias.
"""

import datetime as dt
import enum
from typing import Any, Optional, Union

import pydantic

from pycore.utils.pydantic import CamelModel
from pycore.workbench.actions.constants import (
    COMMENT_MAX_LENGTH,
    ERROR_MESSAGE_HTML_NOT_ALLOWED,
    HTML_TAG_RE,
)
from pycore.workbench.contracts import (
    ScenarioIdAliasMixin,
    WorkbenchDefaultFilter,
    WorkbenchFilterItem,
    WorkbenchSearchParam,
    WorkbenchSortingModel,
)


class GroupAction(enum.IntEnum):
    """Mirrors `FN.Workbench.Contracts.Models.GroupActions`."""

    show = 0
    hide = 1
    comment = 2
    assign = 3
    unassign = 4
    resolve = 5
    delete = 6
    restore = 7

    @classmethod
    def _missing_(cls, value: Any) -> "GroupAction | None":
        # The .NET enum serializes as an int, but callers may send the name.
        if isinstance(value, str):
            return cls.__members__.get(value.strip().lower())
        return None


class IncidentActionModel(CamelModel):
    """Mirrors `IncidentActionModel` / `IncidentAssignModel`."""

    incident_id: int
    load_id: int = 0
    entity_id: int = 0


class GroupSelectionModel(CamelModel):
    is_selected: bool = False
    inclusions: list[int] = pydantic.Field(default_factory=list)
    exclusions: list[int] = pydantic.Field(default_factory=list)


class WorkbenchActionGroupingModel(CamelModel):
    """Mirrors the .NET `WorkbenchGroupingModel` used by group actions.

    Distinct from `pycore.workbench.contracts.WorkbenchGroupingModel`, which
    carries the reduced `dimension`/`origin` shape used by the data endpoints.
    """

    dimension_id: int = 0
    dimension_column: str = ""
    value: str = ""
    origin: str = ""


class EditIncidentRequest(CamelModel, ScenarioIdAliasMixin):
    """Mirrors `NonDatabase.ViewModels.EditIncidentViewModel`.

    Serialized by .NET as `incidentIDs`/`scenarioID`; `ScenarioIdAliasMixin`
    resolves those case-insensitively against the generated aliases.
    """

    incident_ids: list[int] = pydantic.Field(default_factory=list)
    scenario_id: int
    load_id: Optional[int] = None


class WorkbenchAssignUserRequest(CamelModel, ScenarioIdAliasMixin):
    incident_ids: list[int] = pydantic.Field(default_factory=list)
    assigned_incidents: list[IncidentActionModel] = pydantic.Field(default_factory=list)
    scenario_id: int
    entity_id: int = 0
    menu_item_id: int = 0
    dimension_value_id: int = 0
    user_id: str = ""
    user_email: str = ""
    send_to_current_user: bool = False
    comment: Optional[str] = None
    load_id: Optional[int] = None

    @pydantic.field_validator("comment")
    @classmethod
    def reject_html_in_comment(cls, value: Optional[str]) -> Optional[str]:
        if value and HTML_TAG_RE.search(value):
            raise ValueError(ERROR_MESSAGE_HTML_NOT_ALLOWED)
        return value


class WorkbenchHideIncidentsRequest(CamelModel, ScenarioIdAliasMixin):
    scenario_id: int
    incidents: list[IncidentActionModel] = pydantic.Field(default_factory=list)
    hide_until: Optional[dt.datetime] = None


class WorkbenchResolveIncidentsRequest(CamelModel, ScenarioIdAliasMixin):
    scenario_id: int
    incidents: list[IncidentActionModel] = pydantic.Field(default_factory=list)


class WorkbenchDeleteIncidentsRequest(CamelModel, ScenarioIdAliasMixin):
    scenario_id: int
    incidents: list[IncidentActionModel] = pydantic.Field(default_factory=list)


class WorkbenchRestoreIncidentsRequest(CamelModel, ScenarioIdAliasMixin):
    scenario_id: int
    load_id: int = 0
    incident_ids: list[int] = pydantic.Field(default_factory=list)


class WorkbenchCommentIncidentsRequest(CamelModel, ScenarioIdAliasMixin):
    scenario_id: int
    incidents: Optional[list[IncidentActionModel]] = None
    comment: str = pydantic.Field(max_length=COMMENT_MAX_LENGTH)


class WorkbenchGroupActionRequest(CamelModel, ScenarioIdAliasMixin):
    """Mirrors `WorkbenchGroupActionContract` (request + scoping extensions).

    The .NET property is `ScenId`; `ScenarioIdAliasMixin` maps it onto
    `scenario_id` so every action path shares one scenario field name.
    """

    groups_selection: dict[str, GroupSelectionModel] = pydantic.Field(default_factory=dict)
    action: GroupAction
    comment: Optional[str] = None
    user_email: Optional[str] = None
    user_id: Optional[str] = None
    hide_until: Optional[dt.datetime] = None
    menu_item_id: int = 0
    entity_id: int = 0
    load_id: int = 0
    scenario_id: int
    reporting_unit_id: int = 0
    dimension_value_id: int = 0
    show_hidden: bool = False
    show_deleted: bool = False
    filters: Optional[Union[str, list[WorkbenchFilterItem]]] = None
    load_ids: Optional[list[int]] = None
    entity_ids: Optional[list[int]] = None
    applied_sorting: Optional[WorkbenchSortingModel] = None
    grouping: Optional[WorkbenchActionGroupingModel] = None
    search_parameters: Optional[list[WorkbenchSearchParam]] = None
    workbench_default_filters: Optional[list[WorkbenchDefaultFilter]] = None
    grouping_dimension: Optional[str] = None
    grouping_dimension_origin: Optional[str] = None
    has_scoping: bool = False
    is_workbench_incident_delete_allowed: bool = False
    computed_occurrence_columns: list[str] = pydantic.Field(default_factory=list)


class WorkbenchIncidentHistoryResponse(CamelModel):
    incident_history_id: int = pydantic.Field(alias="incidentHistoryID")
    incident_id: int = pydantic.Field(alias="incidentID")
    scenario_id: int = pydantic.Field(alias="scenarioID")
    event_type_id: Optional[int] = pydantic.Field(default=None, alias="eventTypeID")
    date_time: Optional[dt.datetime] = None
    user_id: Optional[str] = None
    load_id: Optional[int] = pydantic.Field(default=None, alias="loadID")
    rule_id: Optional[str] = pydantic.Field(default=None, alias="ruleID")
    comment: Optional[str] = None
    event_type_description: Optional[str] = None
    hide_until: Optional[dt.datetime] = None
    values: Optional[str] = None


class WorkbenchIncidentCommentResponse(CamelModel):
    id: int
    incident_id: int = pydantic.Field(alias="incidentID")
    scenario_id: int = pydantic.Field(alias="scenarioID")
    user_id: Optional[str] = None
    username: Optional[str] = None
    date: Optional[dt.datetime] = None
    comment: Optional[str] = None
    load_id: Optional[int] = None


class GroupIncidentOccurrence(CamelModel):
    """Mirrors `GroupIncidentOccurence` (.NET spelling kept in the alias)."""

    incident_id: int
    load_id: int = 0
    entity_id: int = 0
    business_rule_id: str = ""
    rule_definition: str = ""


class WorkbenchActionBoolApiResponse(CamelModel):
    result: bool


class WorkbenchHistoryApiResponse(CamelModel):
    result: list[WorkbenchIncidentHistoryResponse]


class WorkbenchCommentsApiResponse(CamelModel):
    result: list[list[WorkbenchIncidentCommentResponse]]


class WorkbenchGroupActionApiResponse(CamelModel):
    result: list[GroupIncidentOccurrence]
