"""Assignment notification email, mirroring the .NET `WorkbenchEmailService`.

Only the assign paths (direct `/assign` and `groupAction` with `Assign`) send an
email; every other workbench action is silent.
"""

import dataclasses
import logging
from typing import Optional, Sequence

from pycore import easy
from pycore.workbench.actions.exceptions import OperationNotAllowedError
from pycore.workbench.contracts import FnUserModel, MenuItemModel

TK_ASSIGN_CURRENT_TITLE = "TN_ER3_AssignCurrentTitle"
TK_ASSIGN_INCIDENT_TITLE = "TN_ER3_AssignIncidentTitle"
TK_ASSIGN_CURRENT_HEADER = "TN_ER3_AssignCurrentHeader"
TK_ASSIGN_INCIDENT_HEADER = "TN_ER3_AssignIncidentHeader"
TK_ASSIGN_CURRENT_SALUTATION = "TN_ER3_AssignCurrentSalutation"
TK_ASSIGN_CURRENT_CONTENT_INCIDENT_LIST = "TN_ER3_AssignCurrentContentIncidentList"
TK_ASSIGN_CURRENT_CONTENT_INCIDENT = "TN_ER3_AssignCurrentContentIncident"
TK_ASSIGN_CURRENT_CONTENT_COMMENT = "TN_ER3_AssignCurrentContentComment"
TK_ASSIGN_CURRENT_CONTENT_END = "TN_ER3_AssignCurrentContentEnd"
TK_ASSIGN_INCIDENT_CONTENT_END = "TN_ER3_AssignIncidentContentEnd"
TK_ASSIGN_CURRENT_ACTION_NAME = "TN_ER3_AssignCurrentActionName"
TK_ASSIGN_INCIDENT_ACTION = "TN_ER3_AssignIncidentAction"
TK_ASSIGN_CURRENT_END = "TN_ER3_AssignCurrentEnd"

ASSIGN_TRANSLATION_KEYS: tuple[str, ...] = (
    TK_ASSIGN_CURRENT_TITLE,
    TK_ASSIGN_INCIDENT_TITLE,
    TK_ASSIGN_CURRENT_HEADER,
    TK_ASSIGN_INCIDENT_HEADER,
    TK_ASSIGN_CURRENT_SALUTATION,
    TK_ASSIGN_CURRENT_CONTENT_INCIDENT_LIST,
    TK_ASSIGN_CURRENT_CONTENT_INCIDENT,
    TK_ASSIGN_CURRENT_CONTENT_COMMENT,
    TK_ASSIGN_CURRENT_CONTENT_END,
    TK_ASSIGN_INCIDENT_CONTENT_END,
    TK_ASSIGN_CURRENT_ACTION_NAME,
    TK_ASSIGN_INCIDENT_ACTION,
    TK_ASSIGN_CURRENT_END,
)

DEFAULT_LANGUAGE_KEY = "en"

ERROR_MESSAGE_NO_INCIDENTS_FOR_EMAIL = "No incidents supplied for the assignment email."
ERROR_MESSAGE_UNRESOLVED_USERS = "Invalid user email."
ERROR_MESSAGE_UNRESOLVED_MENU_ITEM = "Invalid menu item."


@dataclasses.dataclass(frozen=True)
class AssignedIncident:
    incident_id: int
    business_rule_id: str = ""
    rule_definition: str = ""


def build_incidents_list_html(incidents: Sequence[AssignedIncident]) -> str:
    content = ""
    for incident in incidents:
        content += f"<li>Incident {incident.incident_id}"
        if incident.business_rule_id:
            content += f" ({incident.business_rule_id}-{incident.rule_definition})</li>"
        else:
            content += "</li>"
    return content + "<br><br>"


def build_assigned_incidents(
    business_rules_by_incident: dict[int, str],
    scenario_id: int,
    entity_ids: Sequence[int],
    language_key: str,
    access_token: Optional[str] = None,
) -> list[AssignedIncident]:
    """Enriches assigned incidents with their translated business rule definition."""
    if not business_rules_by_incident:
        return []

    rules = (
        easy.rules_mgmt.get_extended_rules_for_multiple_entities(
            entity_ids=list(entity_ids), scenario_id=scenario_id,
            access_token=access_token,
        )
        if entity_ids
        else []
    )
    rule_labels = [rule.business_rule for rule in rules if rule.business_rule]
    translated = (
        easy.translation.get_translation_values(
            language_id=language_key,
            translation_keys=rule_labels,
            access_token=access_token,
        )
        if rule_labels
        else {}
    )
    definitions = {
        rule.business_rule_id: translated.get(rule.business_rule, rule.business_rule or "")
        for rule in rules
    }

    return [
        AssignedIncident(
            incident_id=incident_id,
            business_rule_id=business_rule_id,
            rule_definition=definitions.get(business_rule_id, ""),
        )
        for incident_id, business_rule_id in business_rules_by_incident.items()
    ]


def build_mail_action(menu_item: MenuItemModel, ui_base_url: str, dimension_value_id: int) -> str:
    dimension_query = f"?dimensionValue={dimension_value_id}" if dimension_value_id > 0 else ""
    menu_url = menu_item.url or ""
    if menu_item.is_generic:
        menu_url = f"{menu_url}/{menu_item.menu_item_id}"
    return f"{ui_base_url or ''}{menu_url}{dimension_query}"


def build_assign_email_placeholders(
    incidents: Sequence[AssignedIncident],
    assigned_user: FnUserModel,
    current_user: FnUserModel,
    translations: dict[str, str],
    mail_action: str,
    comment: Optional[str],
    send_to_current_user: bool,
) -> dict[str, Optional[str]]:
    is_multiple = len(incidents) > 1
    has_comment = bool((comment or "").strip())

    content_key = (
        TK_ASSIGN_CURRENT_CONTENT_INCIDENT_LIST
        if is_multiple
        else TK_ASSIGN_CURRENT_CONTENT_INCIDENT
    )
    end_key = (
        TK_ASSIGN_CURRENT_CONTENT_END if is_multiple else TK_ASSIGN_INCIDENT_CONTENT_END
    )

    def translate(key: str) -> str:
        return translations.get(key, "")

    incidents_html = build_incidents_list_html(incidents)
    current_user_name = f"{current_user.first_name or ''} {current_user.last_name or ''}".strip()

    if send_to_current_user:
        mail_content = (
            f"{translate(content_key)} {current_user_name}: <br><br>"
            f"{incidents_html}{translate(end_key)}"
        )
    else:
        comment_html = (
            f"{translate(TK_ASSIGN_CURRENT_CONTENT_COMMENT)}<br><br>{comment}<br><br>"
            if has_comment
            else ""
        )
        mail_content = (
            f"{translate(content_key)} {current_user_name}:"
            f"<br><br>{incidents_html}{comment_html} {translate(end_key)}"
        )

    assigned_user_name = (
        f"{assigned_user.first_name or ''} {assigned_user.last_name or ''}".strip()
    )

    return {
        "TITLE": translate(TK_ASSIGN_CURRENT_TITLE if is_multiple else TK_ASSIGN_INCIDENT_TITLE),
        "MAIL_HEADER": translate(
            TK_ASSIGN_CURRENT_HEADER if is_multiple else TK_ASSIGN_INCIDENT_HEADER
        ),
        "MAIL_SALUTATION": f"{translate(TK_ASSIGN_CURRENT_SALUTATION)} {assigned_user_name},",
        "MAIL_CONTENT": mail_content,
        "MAIL_CONTENT2": None,
        "MAIL_ACTION": mail_action,
        "MAIL_ACTION_NAME": translate(
            TK_ASSIGN_CURRENT_ACTION_NAME if is_multiple else TK_ASSIGN_INCIDENT_ACTION
        ),
        "MAIL_MESSAGE_END": translate(TK_ASSIGN_CURRENT_END),
        "MAIL_HEADER_URL": None,
    }


def send_assign_email(
    incidents: Sequence[AssignedIncident],
    assigned_user: FnUserModel,
    current_user_email: str,
    menu_item_id: int,
    dimension_value_id: int,
    comment: Optional[str],
    ui_base_url: str,
    access_token: Optional[str] = None,
) -> bool:
    """Builds and dispatches the assignment notification to the assignee."""
    if not incidents:
        raise OperationNotAllowedError(ERROR_MESSAGE_NO_INCIDENTS_FOR_EMAIL)

    current_user = easy.identity.get_user_by_email(current_user_email, access_token=access_token)
    if current_user is None or not assigned_user.email:
        raise OperationNotAllowedError(ERROR_MESSAGE_UNRESOLVED_USERS)

    menu_item = easy.identity.get_menu_item_by_id(menu_item_id, access_token=access_token)
    if menu_item is None:
        raise OperationNotAllowedError(ERROR_MESSAGE_UNRESOLVED_MENU_ITEM)

    language_key = assigned_user.language_key or DEFAULT_LANGUAGE_KEY
    translations = easy.translation.get_translation_values(
        language_id=language_key,
        translation_keys=list(ASSIGN_TRANSLATION_KEYS),
        access_token=access_token,
    )

    placeholders = build_assign_email_placeholders(
        incidents=incidents,
        assigned_user=assigned_user,
        current_user=current_user,
        translations=translations,
        mail_action=build_mail_action(menu_item, ui_base_url, dimension_value_id),
        comment=comment,
        send_to_current_user=assigned_user.email == current_user_email,
    )

    sent = easy.email.send_email(
        recipients=[assigned_user.email],
        subject=placeholders["TITLE"],
        placeholders=placeholders,
        language_code=language_key,
    )
    if not sent:
        logging.warning(
            "Assignment email was not accepted by the email service.",
            extra={"menu_item_id": menu_item_id, "incident_count": len(incidents)},
        )
    return sent
