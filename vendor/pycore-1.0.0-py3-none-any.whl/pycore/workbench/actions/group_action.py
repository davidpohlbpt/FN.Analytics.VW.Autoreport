"""Fan-out of a resolved group selection onto the direct action behavior.

Mirrors the .NET `WorkbenchGroupActionCommandHandler`: guards are evaluated
first, the selection is resolved once, and every action then reuses the same
service function the corresponding direct endpoint calls.
"""

from typing import Callable, Optional, Sequence

from sqlalchemy.orm import Session

from pycore.workbench.actions.constants import (
    ERROR_MESSAGE_ACTION_NOT_SUPPORTED,
    ERROR_MESSAGE_ACTION_ON_DELETED_VIEW,
    ERROR_MESSAGE_DELETE_NOT_ALLOWED,
    ERROR_MESSAGE_RESTORE_NOT_ALLOWED,
)
from pycore.workbench.actions.contracts import (
    GroupAction,
    GroupIncidentOccurrence,
    IncidentActionModel,
    WorkbenchGroupActionRequest,
)
from pycore.workbench.actions.exceptions import OperationNotAllowedError
from pycore.workbench.actions.service import (
    assign_incidents,
    comment_incidents,
    hide_incidents,
    mark_incidents_as_deleted,
    resolve_incidents,
    restore_incidents,
    show_incidents,
    unassign_incidents,
)

ACTIONS_NOT_APPLICABLE_ON_DELETED: frozenset[GroupAction] = frozenset(
    {
        GroupAction.delete,
        GroupAction.hide,
        GroupAction.show,
        GroupAction.resolve,
        GroupAction.assign,
        GroupAction.unassign,
    }
)

ACTIONS_REQUIRING_DELETE_PERMISSION: frozenset[GroupAction] = frozenset(
    {GroupAction.delete, GroupAction.restore}
)


def guard_group_action(request: WorkbenchGroupActionRequest) -> None:
    """Rejects actions that cannot run against the deleted-incidents view."""
    if request.show_deleted and request.action in ACTIONS_NOT_APPLICABLE_ON_DELETED:
        raise OperationNotAllowedError(ERROR_MESSAGE_ACTION_ON_DELETED_VIEW)


def _as_action_models(
    incidents: Sequence[GroupIncidentOccurrence],
) -> list[IncidentActionModel]:
    return [
        IncidentActionModel(
            incident_id=incident.incident_id,
            load_id=incident.load_id,
            entity_id=incident.entity_id,
        )
        for incident in incidents
    ]


def _assign_if_resolved(
    session: Session,
    incident_ids: Sequence[int],
    scenario_id: int,
    assigned_user_email: Optional[str],
) -> None:
    if assigned_user_email:
        assign_incidents(session, incident_ids, scenario_id, assigned_user_email)


def perform_group_action(
    session: Session,
    request: WorkbenchGroupActionRequest,
    incidents: Sequence[GroupIncidentOccurrence],
    current_user_id: str,
    current_user_email: str,
    assigned_user_email: Optional[str] = None,
) -> None:
    """Applies the request's action to every resolved incident."""
    action = request.action
    if action in ACTIONS_REQUIRING_DELETE_PERMISSION and not request.is_workbench_incident_delete_allowed:
        raise OperationNotAllowedError(
            ERROR_MESSAGE_DELETE_NOT_ALLOWED
            if action is GroupAction.delete
            else ERROR_MESSAGE_RESTORE_NOT_ALLOWED
        )

    incident_ids = [incident.incident_id for incident in incidents]
    action_models = _as_action_models(incidents)

    handlers: dict[GroupAction, Callable[[], None]] = {
        GroupAction.show: lambda: show_incidents(
            session, incident_ids, request.scenario_id, current_user_email
        ),
        GroupAction.hide: lambda: hide_incidents(
            session,
            action_models,
            request.scenario_id,
            current_user_id,
            current_user_email,
            request.hide_until,
        ),
        GroupAction.assign: lambda: _assign_if_resolved(
            session, incident_ids, request.scenario_id, assigned_user_email
        ),
        GroupAction.unassign: lambda: unassign_incidents(
            session, incident_ids, request.scenario_id
        ),
        GroupAction.comment: lambda: comment_incidents(
            session,
            action_models,
            request.scenario_id,
            request.comment or "",
            current_user_id,
            current_user_email,
        ),
        GroupAction.resolve: lambda: resolve_incidents(
            session,
            action_models,
            request.scenario_id,
            current_user_id,
            current_user_email,
        ),
        GroupAction.delete: lambda: mark_incidents_as_deleted(
            session, action_models, request.scenario_id, current_user_id, request.load_id
        ),
        GroupAction.restore: lambda: restore_incidents(
            session, incident_ids, request.scenario_id, current_user_id, request.load_id
        ),
    }

    handler = handlers.get(action)
    if handler is None:
        raise OperationNotAllowedError(ERROR_MESSAGE_ACTION_NOT_SUPPORTED)
    handler()
