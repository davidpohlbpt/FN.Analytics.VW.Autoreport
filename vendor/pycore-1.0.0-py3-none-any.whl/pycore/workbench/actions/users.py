"""Resolution of stored incident-history/comment user ids into display values.

Mirrors the .NET lookups built from `IIdentityService.GetAllUsers()`: history
rows resolve to an email (matching on either id or email, case-insensitively),
comments resolve to a username (matching on id only).
"""

import dataclasses
from typing import Iterable, Optional

from pycore.workbench.actions.constants import SYSTEM_ACTION_USER_ID
from pycore.workbench.contracts import FnUserModel


@dataclasses.dataclass(frozen=True)
class UserDirectory:
    emails_by_reference: dict[str, str] = dataclasses.field(default_factory=dict)
    usernames_by_id: dict[str, str] = dataclasses.field(default_factory=dict)

    @classmethod
    def from_users(cls, users: Iterable[FnUserModel]) -> "UserDirectory":
        emails_by_reference: dict[str, str] = {}
        usernames_by_id: dict[str, str] = {}

        for user in users:
            if user.email:
                if user.id:
                    emails_by_reference[user.id.lower()] = user.email
                emails_by_reference[user.email.lower()] = user.email
            if user.id and user.user_name:
                usernames_by_id[user.id.lower()] = user.user_name

        return cls(emails_by_reference=emails_by_reference, usernames_by_id=usernames_by_id)

    def resolve_email(self, user_reference: Optional[str]) -> Optional[str]:
        """Returns the email for an id or email, keeping unknown references as-is."""
        if not user_reference or user_reference == SYSTEM_ACTION_USER_ID:
            return user_reference
        return self.emails_by_reference.get(user_reference.lower(), user_reference)

    def resolve_username(self, user_id: Optional[str]) -> Optional[str]:
        if not user_id:
            return None
        return self.usernames_by_id.get(user_id.lower())
