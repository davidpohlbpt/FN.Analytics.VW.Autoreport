from __future__ import annotations

import dataclasses
from typing import Any

from pycore.workbench.contracts import ExtendedRuleModel
from pycore.workbench.filters import ParsedFilter


def get_rule_property_value(rule: ExtendedRuleModel, property_name: str) -> str:
    # Callers pass either a separator-free frontend filter name (`businessRuleID`)
    # or a snake_case field name (`business_rule`) - strip underscores from both
    # sides so `model_dump()`'s snake_case keys (`business_rule_id`) still match.
    normalized_name = property_name.lower().replace("_", "")

    for grouping_dimension in rule.grouping_dimension_query_models:
        if grouping_dimension.grouping_dimension.lower().replace("_", "") == normalized_name:
            return _to_rule_text(grouping_dimension.value)

    for field_name, value in rule.model_dump().items():
        if field_name.lower().replace("_", "") == normalized_name:
            return _to_rule_text(value)

    return ""


def _to_rule_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value)


def _normalize_rule_scalar(value: Any) -> str:
    if value is None:
        return ""

    if isinstance(value, bool):
        return "1" if value else "0"

    text = str(value).strip()
    lowered = text.lower()
    if lowered in {"true", "1", "yes"}:
        return "1"
    if lowered in {"false", "0", "no"}:
        return "0"
    return lowered


def matches_rule_filter(rule: ExtendedRuleModel, parsed_filter: ParsedFilter) -> bool:
    value = get_rule_property_value(rule, parsed_filter.name)
    normalized_value = _normalize_rule_scalar(value)
    normalized_needle = _normalize_rule_scalar(parsed_filter.value)

    if parsed_filter.filter_type.name in ("is_null", "is_null_or_empty"):
        return normalized_value == ""

    if parsed_filter.filter_type.name in ("is_not_null", "is_not_null_or_empty"):
        return normalized_value != ""

    if parsed_filter.filter_type.name in ("equal", "exact_search"):
        return normalized_value == normalized_needle
    if parsed_filter.filter_type.name == "not_equal":
        return normalized_value != normalized_needle
    if parsed_filter.filter_type.name == "fuzzy_search":
        return normalized_needle in normalized_value
    if parsed_filter.filter_type.name == "not_fuzzy_search":
        return normalized_needle not in normalized_value
    if parsed_filter.filter_type.name == "begins_with":
        return normalized_value.startswith(normalized_needle)
    if parsed_filter.filter_type.name == "ends_with":
        return normalized_value.endswith(normalized_needle)
    if parsed_filter.filter_type.name == "multiselect":
        if isinstance(parsed_filter.value, list):
            values = {_normalize_rule_scalar(x) for x in parsed_filter.value}
            return normalized_value in values
    return True


def filter_rules(
    rules: list[ExtendedRuleModel], parsed_filters: list[ParsedFilter]
) -> list[ExtendedRuleModel]:
    if not parsed_filters:
        return rules

    filtered = rules
    for parsed_filter in parsed_filters:
        filtered = [rule for rule in filtered if matches_rule_filter(rule, parsed_filter)]
    return filtered


@dataclasses.dataclass(frozen=True)
class RuleScope:
    """Business rule ids that rule-origin filters include or exclude."""

    included_rule_ids: list[str] | None = None
    excluded_rule_ids: list[str] | None = None


def resolve_rule_scope(
    rule_filters: list[ParsedFilter],
    entity_ids: list[int],
    scenario_id: int,
    access_token: str | None = None,
) -> RuleScope:
    """Turns rule-origin filters into an include/exclude set of business rule ids.

    An empty match set becomes an exclusion of every known rule so the caller
    returns no rows rather than silently ignoring the filter.
    """
    from pycore import easy

    if not rule_filters or not entity_ids:
        return RuleScope()

    rules = easy.rules_mgmt.get_extended_rules_for_multiple_entities(
        entity_ids=entity_ids,
        scenario_id=scenario_id,
        access_token=access_token,
    )
    all_rule_ids = [rule.business_rule_id for rule in rules if rule.business_rule_id]
    filtered_rule_ids = [
        rule.business_rule_id
        for rule in filter_rules(rules, rule_filters)
        if rule.business_rule_id
    ]

    if filtered_rule_ids:
        return RuleScope(included_rule_ids=filtered_rule_ids)
    if all_rule_ids:
        return RuleScope(excluded_rule_ids=all_rule_ids)
    return RuleScope()
