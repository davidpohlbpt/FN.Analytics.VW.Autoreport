from __future__ import annotations

import logging
from collections import defaultdict
from typing import Optional

from pycore import easy
from pycore.workbench.constants import (
    GROUP_PREFIX,
    GROUP_PREFIX_ASSIGNED_USER_DIMENSION,
    GROUP_PREFIX_BUSINESS_RULE_ID_DIMENSION,
    ORIGIN_RULE,
    WORKBENCH_GROUP_VIEW_PARAMETER_COUNT_TK,
)
from pycore.workbench.contracts import WorkbenchDimensionGroup, WorkbenchGroupsRequest
from pycore.workbench.dimension_scoping import entity_ids_for_request
from pycore.workbench.rule_matching import filter_rules, get_rule_property_value
from pycore.workbench.translation_helpers import translate_rule_texts_if_possible


def apply_rule_origin_groups_post_processing(
    request: WorkbenchGroupsRequest,
    groups: list[WorkbenchDimensionGroup],
    routed_filters,
    normalized_filters,
    access_token: Optional[str] = None,
) -> list[WorkbenchDimensionGroup]:
    if (request.grouping_dimension_origin or "").lower() != ORIGIN_RULE:
        return groups

    rules = _resolve_scoped_rules(request, routed_filters, access_token)
    # Rules with no incidents are only surfaced on an unfiltered, unsearched view.
    include_empty_rules = not normalized_filters and not request.search_parameters

    if (request.grouping_dimension or "").lower() == "businessruleid":
        return _business_rule_groups(
            request, groups, rules, include_empty_rules, access_token
        )

    return _regrouped_by_rule_property(request, groups, rules, include_empty_rules)


def _resolve_scoped_rules(
    request: WorkbenchGroupsRequest,
    routed_filters,
    access_token: Optional[str],
) -> list:
    entity_ids = entity_ids_for_request(request)
    if not entity_ids:
        return []

    rules = easy.rules_mgmt.get_extended_rules_for_multiple_entities(
        entity_ids=entity_ids,
        scenario_id=request.scenario_id,
        access_token=access_token,
    )
    if routed_filters and routed_filters.rule:
        return filter_rules(rules, routed_filters.rule)
    return rules


def _rules_by_business_rule_id(rules) -> dict[str, object]:
    return {rule.business_rule_id: rule for rule in rules if rule.business_rule_id}


def _translations_or_empty(
    rules,
    user_language,
    access_token: Optional[str],
    scenario_id,
) -> dict[str, str]:
    try:
        return translate_rule_texts_if_possible(
            rules, user_language, access_token=access_token
        )
    except Exception:
        logging.exception(
            "Workbench rule translation lookup failed.",
            extra={"scenario_id": scenario_id},
        )
        return {}


def _with_missing_rule_groups(
    groups: list[WorkbenchDimensionGroup], rules
) -> list[WorkbenchDimensionGroup]:
    existing_titles = {group.title for group in groups}
    additions: list[WorkbenchDimensionGroup] = []

    for rule in rules:
        if rule.business_rule_id and rule.business_rule_id not in existing_titles:
            additions.append(
                WorkbenchDimensionGroup(title=rule.business_rule_id, count=0)
            )
            existing_titles.add(rule.business_rule_id)

    return [*groups, *additions]


def _decorated_group(
    group: WorkbenchDimensionGroup, rule, translations: dict[str, str]
) -> WorkbenchDimensionGroup:
    description = translations.get(rule.business_rule or "", rule.business_rule or "")
    detail = translations.get(rule.description or "", rule.description or "")

    return WorkbenchDimensionGroup(
        title=group.title,
        count=group.count,
        records=group.records,
        description=description or None,
        extra=(f"{description}. {detail}" if description and detail else detail or None),
        tag=group.tag,
    )


def _business_rule_groups(
    request: WorkbenchGroupsRequest,
    groups: list[WorkbenchDimensionGroup],
    rules,
    include_empty_rules: bool,
    access_token: Optional[str],
) -> list[WorkbenchDimensionGroup]:
    if include_empty_rules:
        groups = _with_missing_rule_groups(groups, rules)

    translations = _translations_or_empty(
        rules, request.user_language, access_token, request.scenario_id
    )
    rules_by_business_rule_id = _rules_by_business_rule_id(rules)

    return [
        _decorated_group(group, rules_by_business_rule_id[group.title], translations)
        if group.title in rules_by_business_rule_id
        else group
        for group in groups
    ]


def _regrouped_by_rule_property(
    request: WorkbenchGroupsRequest,
    groups: list[WorkbenchDimensionGroup],
    rules,
    include_empty_rules: bool,
) -> list[WorkbenchDimensionGroup]:
    dimension = request.grouping_dimension or ""
    rules_by_business_rule_id = _rules_by_business_rule_id(rules)

    regrouped: dict[str, int] = defaultdict(int)
    for group in groups:
        rule = rules_by_business_rule_id.get(group.title)
        if rule is not None:
            regrouped[get_rule_property_value(rule, dimension)] += group.count

    if include_empty_rules:
        for rule in rules:
            regrouped.setdefault(get_rule_property_value(rule, dimension), 0)

    return [
        WorkbenchDimensionGroup(title=title, count=count)
        for title, count in sorted(regrouped.items(), key=lambda kv: kv[1], reverse=True)
    ]


def group_prefix_dimension_name(grouping_dimension: str) -> str:
    normalized = grouping_dimension.lower()
    if normalized == "assigneduser":
        return GROUP_PREFIX_ASSIGNED_USER_DIMENSION
    if normalized == "businessruleid":
        return GROUP_PREFIX_BUSINESS_RULE_ID_DIMENSION
    return grouping_dimension


def augment_groups(
    groups: list[WorkbenchDimensionGroup],
    grouping_dimension: str,
) -> list[WorkbenchDimensionGroup]:
    prefix = f"{GROUP_PREFIX}{group_prefix_dimension_name(grouping_dimension)}"
    for group in groups:
        group.prefix = prefix
        group.summary = WORKBENCH_GROUP_VIEW_PARAMETER_COUNT_TK
        group.dynamic_group_description = group.dynamic_group_description or ""
    return groups
