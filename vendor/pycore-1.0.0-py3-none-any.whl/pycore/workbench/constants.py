import re

UNDEFINED = "TN_Group_Undefined"
EMPTY = ""

GROUP_PREFIX = "TN_ER3_GroupedBy"

INCIDENT_DETAILS_PROPERTY_INCIDENT_ID_TK = "TN_ER3_IncidentID"
INCIDENT_DETAILS_PROPERTY_CRITICALITY_TK = "TN_ER3_Criticality"
INCIDENT_DETAILS_PROPERTY_DESCRIPTION_TK = "TN_ER3_Description"
INCIDENT_DETAILS_PROPERTY_SCOPING_TK = "TN_ER3_Scoping"
INCIDENT_DETAILS_PROPERTY_HELPTEXT_TK = "TN_ER3_HelpText"
INCIDENT_DETAILS_PROPERTY_RISK_TK = "TN_ER3_Risk"

CAN_SEE_CRITICALITY = "CanSeeCriticality"
CAN_SEE_DESCRIPTION = "CanSeeDescription"
CAN_SEE_SCOPING = "CanSeeScoping"
CAN_SEE_SCORING = CAN_SEE_SCOPING
CAN_SEE_HELPTEXT = "CanSeeHelptext"
CAN_SEE_RISK = "CanSeeRisk"
CAN_SEE_SCORE = "CanSeeScore"
CAN_SEE_GROUPING_DIMENSION_LEGACY = "CanSeeGroupingDimension_Legacy"
CAN_SEE_GROUPING_DIMENSION_SOLVABLE = "CanSeeGroupingDimension_Solvable"
CAN_SEE_GROUPING_DIMENSION_MASTERDATA = "CanSeeGroupingDimension_Masterdata"
CAN_SEE_GROUPING_DIMENSION_GROUPING_DIMENSION_1 = "CanSeeGroupingDimension_GroupingDimension1"
CAN_SEE_GROUPING_DIMENSION_GROUPING_DIMENSION_2 = "CanSeeGroupingDimension_GroupingDimension2"

BOOLEAN_STRING_TRUE = "true"
BOOLEAN_STRING_FALSE = "false"

# Canonical (PascalCase) grouping-dimension names used to build a group's `prefix`,
# matching the .NET `AugmentGroups` mapping.
GROUP_PREFIX_ASSIGNED_USER_DIMENSION = "IncidentAssignedUser"
GROUP_PREFIX_BUSINESS_RULE_ID_DIMENSION = "BusinessRuleID"

WORKBENCH_GROUP_VIEW_PARAMETER_COUNT_TK = "TN_Workbench_GroupView_ParameterCount"

ORIGIN_INCIDENT = "incident"
ORIGIN_OCCURRENCE = "occurrence"
ORIGIN_RULE = "rule"

ORIGIN_INCIDENTS = "Incidents"
ORIGIN_FIELDS = "Fields"
ORIGIN_RULES = "Rules"

FIELD_TYPE_STRING = "string"
FIELD_TYPE_NUMERIC = "numeric"
FIELD_TYPE_CURRENCY = "currency"
FIELD_TYPE_DATE = "date"
FIELD_TYPE_BOOLEAN = "boolean"

# OPENJSON's numeric `type` column: 0=null, 1=string, 2=number, 3=boolean, 4=array, 5=object.
OPENJSON_TYPE_TO_FIELD_TYPE: dict[int, str] = {
    1: FIELD_TYPE_STRING,
    2: FIELD_TYPE_NUMERIC,
    3: FIELD_TYPE_BOOLEAN,
}

SCORE_FIELD_NAME = "Score"

# Grouping dimensions whose raw "1"/"0" value gets rendered as a boolean string
# (see permissions.bool_grouping_value). Distinct from CAN_SEE_GROUPING_DIMENSION_*
# (which also covers GroupingDimension1/2, non-boolean dimensions).
BOOLEAN_GROUPING_DIMENSIONS: frozenset[str] = frozenset({"legacy", "masterdata", "solvable"})

DEFAULT_WORKBENCH_SCHEMA = "dbo"

ERROR_CODE_INVALID_REQUEST = "invalid_request"
ERROR_CODE_INTERNAL_ERROR = "internal_error"
ERROR_CODE_DIMENSION_VALUE_NOT_FOUND = "dimension_value_not_found"
ERROR_CODE_UPSTREAM_ERROR = "upstream_error"
ERROR_CODE_VALIDATION_ERROR = "validation_error"
ERROR_CODE_HTTP_ERROR = "http_error"

RULE_SEARCH_FIELDS: tuple[str, ...] = (
    "businessruleid",
    "businessrule",
    "description",
    "dynamicdescription",
    "criticality",
    "risk",
    "legacy",
    "solvable",
    "masterdata",
    "groupingdimension1",
    "groupingdimension2",
)

INCIDENT_COLUMN_WHITELIST: tuple[str, ...] = (
    "incidentid",
    "ruleid",
    "businessruleid",
    "identifier",
    "loads",
    "loadid",
    "reportingunitid",
    "status",
    "created",
    "assigneduser",
    "entityid",
    "scenarioid",
)

# Frontend dimension names that map to Incident table columns.
INCIDENT_DIMENSION_ALIASES: dict[str, str] = {
    "incidentassigneduser": "assigneduser",
}

SAFE_COLUMN_REGEX = r"^\w+$"
SAFE_COLUMN_RE = re.compile(SAFE_COLUMN_REGEX)

# Fallback page size for /search when a caller sends a non-positive `take`,
# keeping the query bounded instead of fetching an unlimited number of rows.
DEFAULT_SEARCH_TAKE = 100

# Fallback page size for /slice when a caller sends a non-positive `take`
# (matches WorkbenchSliceRequest's own Pydantic default).
DEFAULT_SLICE_TAKE = 20

# Mirrors .NET's `WorkbenchIncidentStatus` constants — the allow-list for
# `/smartlist/count`'s `incidentStatusFilterForSubscriptionEmail`.
WORKBENCH_INCIDENT_STATUS_NEW = "new"
WORKBENCH_INCIDENT_STATUS_SOLVED = "solved"
WORKBENCH_INCIDENT_STATUS_SOLVED_CURR = "solvedCurr"
WORKBENCH_INCIDENT_STATUS_ONGOING = "ongoing"
WORKBENCH_INCIDENT_STATUS_REOCCURENCE = "reoccurence"

WORKBENCH_INCIDENT_STATUS_ALLOWLIST: frozenset[str] = frozenset(
    {
        WORKBENCH_INCIDENT_STATUS_NEW,
        WORKBENCH_INCIDENT_STATUS_SOLVED,
        WORKBENCH_INCIDENT_STATUS_SOLVED_CURR,
        WORKBENCH_INCIDENT_STATUS_ONGOING,
        WORKBENCH_INCIDENT_STATUS_REOCCURENCE,
    }
)