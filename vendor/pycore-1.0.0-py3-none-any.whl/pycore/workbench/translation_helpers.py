from __future__ import annotations

from typing import Optional

from pycore import easy
from pycore.workbench.contracts import ExtendedRuleModel


def translate_rule_texts_if_possible(
    rules: list[ExtendedRuleModel],
    user_language: str,
    access_token: Optional[str] = None,
) -> dict[str, str]:
    if not user_language:
        return {}

    keys: set[str] = set()
    for rule in rules:
        if rule.business_rule:
            keys.add(rule.business_rule)
        if rule.description:
            keys.add(rule.description)
        if rule.dynamic_description:
            keys.add(rule.dynamic_description)

    if not keys:
        return {}

    return easy.translation.get_translation_values(
        language_id=user_language,
        translation_keys=list(keys),
        access_token=access_token,
    )


def translate_search_labels_if_possible(
    labels: list[str],
    user_language: str,
    access_token: Optional[str] = None,
) -> dict[str, str]:
    if not user_language:
        return {}

    keys = [label for label in dict.fromkeys(labels) if label]
    if not keys:
        return {}

    return easy.translation.get_translation_values(
        language_id=user_language,
        translation_keys=keys,
        access_token=access_token,
    )
