from __future__ import annotations

import re
from typing import Any

from pycore.workbench.contracts import ExtendedRuleModel

_DYN_DESC_RE = re.compile(r"@(\w+)")


def replace_description_params(fields: dict[str, Any], description: str) -> str:
    if not description:
        return ""

    def repl(match: re.Match) -> str:
        return str(fields.get(match.group(1), "") or "")

    return _DYN_DESC_RE.sub(repl, description)


def replace_rule_param_tokens(value: str, rule: ExtendedRuleModel) -> str:
    if not value:
        return ""

    params_by_name: dict[str, str] = {}
    for info in rule.rule_entity_specific_information_query_models or []:
        for param in info.rule_parameter_query_models or []:
            if param.name:
                params_by_name[str(param.name).strip().lower()] = str(param.value or "")

    def repl(match: re.Match) -> str:
        return params_by_name.get(match.group(1).lower(), "")

    return re.sub(r"\$\$(\w+)", repl, value)
