import dataclasses
import json
from typing import Any, Iterable, Optional, Sequence, Union

import pydantic

from pycore.schemas import FilterOperator

from pycore.workbench.constants import (
    INCIDENT_COLUMN_WHITELIST,
    ORIGIN_INCIDENT,
    ORIGIN_OCCURRENCE,
    ORIGIN_RULE,
    RULE_SEARCH_FIELDS,
)


LEGACY_FILTER_OPERATOR_ALIASES: dict[str, str] = {
    "null": FilterOperator.is_null.value,
    "empty": FilterOperator.is_null.value,
    "notnull": FilterOperator.is_not_null.value,
    "notempty": FilterOperator.is_not_null.value,
    "nullorempty": FilterOperator.is_null_or_empty.value,
    "notnullorempty": FilterOperator.is_not_null_or_empty.value,
}


@dataclasses.dataclass(frozen=True)
class ParsedFilter:
    filter_type: FilterOperator
    name: str
    value: Any
    value2: Optional[Any] = None
    path: Optional[str] = None
    net_path: Optional[str] = None


@dataclasses.dataclass(frozen=True)
class ParsedSearchParameter:
    field_name: str
    value: str


@dataclasses.dataclass
class RoutedFilters:
    incident: list[ParsedFilter] = dataclasses.field(default_factory=list)
    occurrence: list[ParsedFilter] = dataclasses.field(default_factory=list)
    rule: list[ParsedFilter] = dataclasses.field(default_factory=list)


@dataclasses.dataclass
class RoutedSearchParameters:
    incident: list[ParsedSearchParameter] = dataclasses.field(default_factory=list)
    occurrence: list[ParsedSearchParameter] = dataclasses.field(default_factory=list)
    computed_occurrence: list[ParsedSearchParameter] = dataclasses.field(
        default_factory=list
    )
    rule: list[ParsedSearchParameter] = dataclasses.field(default_factory=list)


def normalize_filters_payload(
    filters_payload: Optional[Union[str, Sequence[Any]]],
) -> list[ParsedFilter]:
    if filters_payload is None:
        return []

    raw_filters = _parse_filter_payload(filters_payload)
    return [_normalize_filter_item(filter_item) for filter_item in raw_filters]


def route_filters(
    filters: Sequence[ParsedFilter],
) -> RoutedFilters:
    routed = RoutedFilters()

    for parsed_filter in filters:
        route = classify_filter(parsed_filter)
        if route == ORIGIN_RULE:
            routed.rule.append(parsed_filter)
        elif route == ORIGIN_INCIDENT:
            routed.incident.append(parsed_filter)
        else:
            routed.occurrence.append(parsed_filter)

    return routed


def route_search_parameters(
    search_parameters: Optional[Sequence[Any]],
    computed_occurrence_columns: Optional[Iterable[str]] = None,
) -> RoutedSearchParameters:
    routed = RoutedSearchParameters()

    if not search_parameters:
        return routed

    computed_columns = _to_lowercase_set(computed_occurrence_columns)
    for item in search_parameters:
        field_name, value = _normalize_search_item(item)
        field_name_lower = field_name.lower()
        parameter = ParsedSearchParameter(field_name=field_name, value=value)

        if field_name_lower in RULE_SEARCH_FIELDS:
            routed.rule.append(parameter)
            continue

        if field_name_lower in INCIDENT_COLUMN_WHITELIST:
            routed.incident.append(parameter)
            continue

        if field_name_lower in computed_columns:
            routed.computed_occurrence.append(parameter)
            continue

        routed.occurrence.append(parameter)

    return routed


def classify_filter(parsed_filter: ParsedFilter) -> str:
    path = (parsed_filter.path or parsed_filter.net_path or "").strip().lower()
    name = parsed_filter.name.lower()

    # Explicit path should win over name-based heuristics.
    if path in {ORIGIN_RULE, "rules"}:
        return ORIGIN_RULE

    if path in {ORIGIN_INCIDENT, "incidents"}:
        return ORIGIN_INCIDENT

    if name in RULE_SEARCH_FIELDS:
        return ORIGIN_RULE

    if name in INCIDENT_COLUMN_WHITELIST:
        return ORIGIN_INCIDENT

    # Computed occurrence columns route to "occurrence" the same as any other
    # occurrence field — `_apply_occurrence_filters` resolves the expression
    # differently for them, but `RoutedFilters` has no separate bucket.
    return ORIGIN_OCCURRENCE


def _parse_filter_payload(filters_payload: Union[str, Sequence[Any]]) -> list[Any]:
    if isinstance(filters_payload, str):
        loaded = json.loads(filters_payload)
        if not isinstance(loaded, list):
            raise ValueError("Workbench filters payload must deserialize to a list.")
        return loaded

    return list(filters_payload)


def _normalize_filter_item(filter_item: Any) -> ParsedFilter:
    payload = _to_mapping(filter_item)
    filter_type_raw = (
        payload.get("type")
        or payload.get("filter_type")
        or payload.get("filterType")
    )
    if filter_type_raw is None:
        raise ValueError("Filter item must contain a filter operator in `type`.")

    filter_name = payload.get("name")
    if not filter_name:
        raise ValueError("Filter item must include `name`.")

    filter_type = FilterOperator(_normalize_filter_operator(filter_type_raw))
    value = payload.get("value")
    if filter_type == FilterOperator.multiselect:
        value = _normalize_multiselect_value(value)

    return ParsedFilter(
        filter_type=filter_type,
        name=str(filter_name),
        value=value,
        value2=payload.get("value2"),
        path=payload.get("path"),
        net_path=(
            payload.get("net_path")
            or payload.get("netPath")
            or payload.get("netpath")
        ),
    )


def _normalize_filter_operator(filter_type_raw: Any) -> Any:
    if not isinstance(filter_type_raw, str):
        return filter_type_raw

    normalized = filter_type_raw.strip().lower()
    return LEGACY_FILTER_OPERATOR_ALIASES.get(normalized, filter_type_raw)


def _normalize_multiselect_value(value: Any) -> Any:
    parsed = json.loads(value) if isinstance(value, str) else value

    if not isinstance(parsed, list):
        return parsed

    if parsed and isinstance(parsed[0], dict):
        return _selected_multiselect_names(parsed)

    return parsed


def _selected_multiselect_names(items: Sequence[Any]) -> list[str]:
    return [
        str(item["name"])
        for item in items
        if isinstance(item, dict)
        and item.get("ticked") is not False
        and item.get("name") is not None
    ]


def _normalize_search_item(search_item: Any) -> tuple[str, str]:
    payload = _to_mapping(search_item)
    field_name = payload.get("field_name") or payload.get("fieldName")
    if not field_name:
        raise ValueError("Search parameter must include `field_name`.")
    return str(field_name), str(payload.get("value", ""))


def _to_mapping(value: Any) -> dict[str, Any]:
    if isinstance(value, pydantic.BaseModel):
        return value.model_dump()
    if isinstance(value, dict):
        return value
    raise TypeError("Filter payload values must be dictionaries or pydantic models.")


def _to_lowercase_set(values: Optional[Iterable[str]]) -> set[str]:
    if values is None:
        return set()
    return {value.lower() for value in values}