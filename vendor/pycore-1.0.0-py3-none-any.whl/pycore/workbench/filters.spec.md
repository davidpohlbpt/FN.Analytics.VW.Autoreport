# Spec: `/api/v1/workbenchData/filters` endpoint

Python port of the `.NET` `WorkbenchDataController.GetWorkbenchFilterConfiguration` ("filters")
endpoint, following the same conventions already used for `slice`/`count`/`groups`/`filter-metadata`
in `pycore/api/web/endpoints/workbench.py`.

## Source of truth (.NET)

- Controller: `FactoryNavigator/MasterData/MasterData.API/Controllers/WorkbenchDataController.cs`
  → `GetWorkbenchFilterConfiguration`, `POST api/v1/WorkbenchData/filters`.
- Command/Handler: `FactoryNavigator/MasterData/MasterData.API/Application/Commands/WorkbenchFilterConfiguration/`
- Request contract: `FactoryNavigator/ReportingShared/FN.Workbench.Contracts/Requests/WorkbenchFilterConfigurationRequest.cs`
- Response/model contracts: `FactoryNavigator/ReportingShared/FN.Workbench.Contracts/Models/FilterConfigurationModel.cs`,
  `FactoryNavigator/ReportingShared/FN.Workbench.Contracts/Response/WorkbenchFilterConfigurationResponse.cs`
- Static filter list + operator map: `FactoryNavigator/ReportingShared/FN.Workbench.Core/WorkbenchFiltersHelper.cs`

## What it does (.NET behavior)

1. Starts from a static list of built-in filters (`WorkbenchFiltersHelper.FiltersList`).
2. Runs `sp_ReportDB_OccurenceDistinctFieldsWithLoads_Get` (scoped by `ScenarioID` + `LoadIds`) to
   discover **dynamic** occurrence JSON field names + their JSON value type, and appends one
   `FilterConfigurationModel` per distinct key (path = `Fields`; type inferred from the JSON value
   type, except `Score` which is always forced to `string`).
3. Attaches `Operators` via `WorkbenchFiltersHelper.GetOperatorsByFieldType()` — a
   field-type → allowed-operator-list map.

## Response shape (.NET, confirmed from source)

```csharp
class WorkbenchFilterConfigurationResponse {
    IList<FilterConfigurationModel>? Filters;   // Name, Label, Dimension, Type, Path
    IEnumerable<FilterOperatorsModel>? Operators; // Type, Operators: [{Name, Value}]
}
```

`Operators` is a **list** of `{Type, Operators}` objects (one per field type), not a dict.
Each operator entry is `{Name, Value}` where `Value` is the operator's wire value (matches
`pycore.schemas.FilterOperator`'s `.value` 1:1 — confirmed name-by-name below) and `Name` is a
translation key (`FnFilterTypesTK.*`) whose literal string values are **not available** — they live
in an external package (`NonDatabase.Constants`) not present in either checked-out repo.

## Request shape (.NET, confirmed from source)

```csharp
class WorkbenchFilterConfigurationRequest {
    int ScenarioID;
    IEnumerable<int>? LoadIds;
}
```

**Deviation (intentional):** every other already-implemented Python workbench endpoint
(`groups`/`count`/`slice`/`filter-metadata`/`search`) accepts the full shared `WorkbenchRequestBase`
payload rather than a minimal per-endpoint DTO, because the frontend sends the same request shape
to all workbench endpoints. `WorkbenchFilterConfigurationRequest` should do the same — subclass
`WorkbenchRequestBase` with no extra fields, per the user's explicit instruction to follow the
existing pattern rather than mirror the anemic C# DTO.

## Static filter list (verbatim from `WorkbenchFiltersHelper.FiltersList`)

| name / label | dimension | type | path |
|---|---|---|---|
| `TN_BR` | `BusinessRuleId` | string | Incidents |
| `TN_RA_RuleAssignedUser` | `IncidentAssignedUser` | string | Incidents |
| `TN_RA_Criticality` | `Criticality` | string | Rules |
| `TN_ER3_Status` | `Status` | string | Incidents |
| `TN_ER3_Age` | `age` | numeric | Incidents |
| `TN_ER3_IncidentID` | `IncidentId` | string | Incidents |
| `Legacy` | `Legacy` | boolean (`GetDataTypeFromWorkbenchJsonType(3)`) | Rules |
| `Masterdata` | `Masterdata` | boolean | Rules |
| `Solvable` | `Solvable` | boolean | Rules |
| `GroupingDimension1` | `GroupingDimension1` | string (`GetDataTypeFromWorkbenchJsonType(1)`) | Rules |
| `GroupingDimension2` | `GroupingDimension2` | string | Rules |

`path` values `Incidents`/`Rules` map directly to pycore's existing `ORIGIN_INCIDENTS`/`ORIGIN_RULES`
constants in `pycore/workbench/constants.py` (already `"Incidents"`/`"Rules"`). Dynamic fields use
`ORIGIN_FIELDS` (`"Fields"`), matching the `.NET` handler's `Path = WorkbenchFilterPath.Fields`.

`GroupingDimension.{Legacy,Masterdata,Solvable,GroupingDimension1,GroupingDimension2}` string
constants weren't locatable in source either, but the comparison logic in
`pycore/api/web/endpoints/workbench.py`'s `_get_rule_property_value` already lowercases before
comparing, and `RULE_SEARCH_FIELDS` in `constants.py` already contains the lowercase forms
(`legacy`, `solvable`, `masterdata`, `groupingdimension1`, `groupingdimension2`) — so exact casing
of the literal is functionally irrelevant; use the PascalCase form shown above for readability.

## Operator map (verbatim from `WorkbenchFiltersHelper.GetOperatorsByFieldType`)

`FnFilterTypes.*` values map 1:1 onto existing `pycore.schemas.FilterOperator` members:

| Field type | Operators (`FilterOperator` members) |
|---|---|
| string | `exact_search`, `fuzzy_search`, `not_fuzzy_search`, `is_null` |
| numeric | `equal`, `greater`, `greater_or_equal`, `less`, `less_or_equal`, `is_null`, `not_equal` |
| currency | same list as numeric |
| date | `date_equal`, `date_strictly_after`, `date_after`, `date_before`, `date_not_equal`, `date_between` |
| boolean | `exact_search`, `is_null` |

(`FnFilterTypesTK.Empty` → `FnFilterTypes.Null` maps to `FilterOperator.is_null`; every other
`FnFilterTypes` member has an exact-name-match `FilterOperator` counterpart already in
`pycore/schemas.py`.)

**Open gap:** the `Name` (translation key) string per operator option is unknown — see Open
Questions below. Plan below uses a placeholder (`name == value`) clearly marked for follow-up.

## Dynamic field discovery (Python equivalent of the stored procedure)

No stored procedure needed — SQL Server's `OPENJSON` can do this directly, using the exact same
`CROSS APPLY OPENJSON(o.[Fields])` pattern already established in
`pycore/workbench/query/search.py`'s `WorkbenchSearchSqlBuilder`:

```sql
SELECT DISTINCT j.[key] AS [key], j.[type] AS [type]
FROM [{schema}].[T_RESULT_Occurence] o
CROSS APPLY OPENJSON(o.[Fields]) j
WHERE o.[ScenarioId] = :scenario_id
  AND o.[LoadId] IN (:load_ids...)   -- only when load_ids provided
```

`OPENJSON`'s numeric `type` column: `0`=null, `1`=string, `2`=number, `3`=boolean, `4`=array,
`5`=object — maps directly to `FIELD_TYPE_STRING`/`FIELD_TYPE_NUMERIC`/`FIELD_TYPE_BOOLEAN`
(matching the `.NET` handler's `GetDataTypeFromWorkbenchJsonType(1)`→string,
`GetDataTypeFromWorkbenchJsonType(3)`→boolean confirmed above). Same `Score` special-case as
`.NET`: always force `string` regardless of the detected JSON type.

## Proposed implementation (once approved)

1. **`pycore/workbench/constants.py`** — add:
   - `FIELD_TYPE_STRING = "string"`, `FIELD_TYPE_NUMERIC = "numeric"`, `FIELD_TYPE_CURRENCY = "currency"`,
     `FIELD_TYPE_DATE = "date"`, `FIELD_TYPE_BOOLEAN = "boolean"`
   - `OPENJSON_TYPE_TO_FIELD_TYPE: dict[int, str]` mapping `{1: STRING, 2: NUMERIC, 3: BOOLEAN}`

2. **`pycore/workbench/contracts.py`** — add:
   - `WorkbenchFilterConfigurationRequest(WorkbenchRequestBase): pass`
   - `FilterConfigurationModel(CamelModel)`: `name: str`, `label: str`, `dimension: str`, `type: str`, `path: str`
   - `FilterOperatorOption(CamelModel)`: `name: str`, `value: FilterOperator` (see translation-key gap)
   - `FilterOperatorsModel(CamelModel)`: `type: str`, `operators: list[FilterOperatorOption]`
   - `WorkbenchFilterConfigurationResponse(CamelModel)`: `filters: list[FilterConfigurationModel]`, `operators: list[FilterOperatorsModel]`

3. **New `pycore/workbench/query/filter_configuration.py`**:
   - `STATIC_FILTERS: list[FilterConfigurationModel]` — the 11-entry table above, built once at
     import time.
   - `OPERATORS_BY_FIELD_TYPE: list[FilterOperatorsModel]` — the 5-entry table above, built once.
   - `@dataclasses.dataclass(frozen=True) class DynamicFieldTypesSqlParams` (`scenario_id`,
     `schema="dbo"`, `load_ids: Sequence[int] | None`) + a builder function producing the
     `OPENJSON` SQL + bound params, mirroring `WorkbenchSearchSqlBuilder`'s parameter-binding style
     in `search.py`.
   - `map_openjson_type(json_type: int, key: str) -> str` — the `Score`-special-cased type mapper.

4. **`pycore/api/web/endpoints/workbench.py`** — new:
   ```python
   @router.post("/filters", response_model=WorkbenchFilterConfigurationResponse)
   def get_workbench_filter_configuration(request: WorkbenchFilterConfigurationRequest):
       try:
           sql, params = build_dynamic_field_types_query(request)
           rows = _execute_sql_rows(sql, params)
           dynamic_filters = [
               FilterConfigurationModel(
                   name=row.key, label=row.key, dimension=row.key,
                   type=map_openjson_type(row.type, row.key), path=ORIGIN_FIELDS,
               )
               for row in rows
           ]
           filters = [*STATIC_FILTERS, *dynamic_filters]
           return WorkbenchFilterConfigurationResponse(
               filters=filters, operators=OPERATORS_BY_FIELD_TYPE,
           )
       except ValueError as exc:
           return _error_response(422, "invalid_request", str(exc))
       except Exception as exc:
           logging.error(exc, extra={"scenario_id": request.scenario_id})
           return _error_response(500, "internal_error", "Unexpected workbench filters error.")
   ```

5. **Tests** — new `tests/integration/workbench/test_workbench_filters.py`, following
   `test_workbench_filter_metadata.py`'s pattern: seed `Occurrence` rows with varying `Fields` JSON
   (including a `Score` key) across a couple of `load_id`s/`scenario_id`s, call
   `/api/v1/workbenchData/filters`, and assert:
   - all 11 static filters are present
   - dynamic fields discovered match the seeded JSON keys, with correct inferred types
   - `Score` is forced to `string`
   - `operators` contains exactly the 5 field-type groups with the expected operator lists
   - scoping by `load_ids`/`scenario_id` excludes fields from other scenarios/loads

## Open questions (blocking full accuracy, not blocking a first pass)

1. **Operator translation keys (`FnFilterTypesTK.*` string values)** — needed for `FilterOperatorOption.name`.
   Not found in either repo (`NonDatabase.Constants` package, not checked out anywhere locally).
   Can you supply these, or should the first pass ship with `name == value` as a placeholder?
2. Confirm exact `GroupingDimension.*` and `WorkbenchFilterPath.*` string constant values if you
   have easy access — believed low-risk per the reasoning above, but nice to confirm.

## Verification checklist (once implemented)

- [ ] Unit test for `map_openjson_type` (including the `Score` special case)
- [ ] Integration test per above
- [ ] Manual: call `/api/v1/workbenchData/filters` via Swagger with a real `scenario_id`/`load_ids`
      and compare `filters`/`operators` shape against a live call to the `.NET` `/api/v1/WorkbenchData/filters`
      endpoint for the same scenario
