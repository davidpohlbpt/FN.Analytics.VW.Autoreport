from __future__ import annotations

from typing import Any

from pycore.workbench.constants import (
    BOOLEAN_GROUPING_DIMENSIONS,
    BOOLEAN_STRING_FALSE,
    BOOLEAN_STRING_TRUE,
    CAN_SEE_GROUPING_DIMENSION_GROUPING_DIMENSION_1,
    CAN_SEE_GROUPING_DIMENSION_GROUPING_DIMENSION_2,
    CAN_SEE_GROUPING_DIMENSION_LEGACY,
    CAN_SEE_GROUPING_DIMENSION_MASTERDATA,
    CAN_SEE_GROUPING_DIMENSION_SOLVABLE,
)


def is_field_valid(value: Any) -> bool:
    if value is None:
        return False

    if isinstance(value, (int, float)):
        return value != 0

    if isinstance(value, str):
        normalized = value.strip()
        if normalized in ("", "-"):
            return False
        try:
            return float(normalized) != 0
        except ValueError:
            return True

    return bool(value)


def permission_lookup(permissions: dict[str, str]) -> dict[str, str]:
    normalized: dict[str, str] = {}
    for key, value in (permissions or {}).items():
        normalized[str(key).strip().lower()] = str(value or "")
    return normalized


def permission_is_true(permissions: dict[str, str], key: str) -> bool:
    return permission_lookup(permissions).get(str(key).strip().lower(), "").lower() == "true"


def can_see_grouping_dimension(key: str, permissions: dict[str, str]) -> bool:
    normalized_key = str(key or "").strip()
    if not normalized_key:
        return True

    aliases = {
        "legacy": CAN_SEE_GROUPING_DIMENSION_LEGACY,
        "solvable": CAN_SEE_GROUPING_DIMENSION_SOLVABLE,
        "masterdata": CAN_SEE_GROUPING_DIMENSION_MASTERDATA,
        "groupingdimension1": CAN_SEE_GROUPING_DIMENSION_GROUPING_DIMENSION_1,
        "groupingdimension2": CAN_SEE_GROUPING_DIMENSION_GROUPING_DIMENSION_2,
    }
    lowered = normalized_key.lower()
    if lowered not in aliases:
        return True

    permission_value = permission_lookup(permissions).get(aliases[lowered].lower(), "")
    return permission_value.lower() == "true"


def bool_grouping_value(key: str, value: Any) -> str:
    normalized = str(value or "").strip()
    if key.lower() in BOOLEAN_GROUPING_DIMENSIONS:
        if normalized == "1":
            return BOOLEAN_STRING_TRUE
        if normalized == "0":
            return BOOLEAN_STRING_FALSE
    return str(value or "")
