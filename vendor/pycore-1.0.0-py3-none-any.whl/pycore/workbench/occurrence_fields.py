"""Cleanup helpers for occurrence field values parsed out of `Occurrence.Fields` JSON.

Ports .NET's `OccurrenceFieldsHelper.ParseDatabaseValue` (`FN.Workbench.Core`), which strips
scientific notation introduced by upstream numeric serialization (e.g. `1.23E+05`) back into a
plain decimal string.
"""

from __future__ import annotations

import re
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

SCIENTIFIC_FORMAT_RE = re.compile(r"^[+-]?\d+(\.\d+)?[eE][+-]?\d+$")


def parse_database_value(value: str) -> str:
    if not value:
        return value

    stripped = value.strip()
    if not SCIENTIFIC_FORMAT_RE.fullmatch(stripped):
        return value

    try:
        rounded = Decimal(stripped).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    except InvalidOperation:
        return value

    text = format(rounded, "f")
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return text
