from __future__ import annotations

import dataclasses
from typing import Optional

import sqlalchemy as sa
from sqlalchemy.sql import Select

from pycore.workbench.contracts import WorkbenchExtendedViewRequest
from pycore.workbench.filters import RoutedFilters, RoutedSearchParameters
from pycore.workbench.models import Incident, Occurrence
from pycore.workbench.query.base import build_base_query
from pycore.workbench.query.slice import apply_sorting, normalize_pagination


@dataclasses.dataclass(frozen=True)
class ExtendedViewStatementPlan:
    statement: Select
    count_statement: Select
    skip: int
    take: int


def build_extended_view_statement(
    request: WorkbenchExtendedViewRequest,
    business_rule_id: str,
    routed_filters: Optional[RoutedFilters] = None,
    routed_search_parameters: Optional[RoutedSearchParameters] = None,
) -> ExtendedViewStatementPlan:
    skip, take = normalize_pagination(request.skip, request.take)

    base_statement = build_base_query(
        request,
        routed_filters=routed_filters,
        routed_search_parameters=routed_search_parameters,
        include_user_filters=True,
    ).where(Incident.BusinessRuleId == business_rule_id)

    count_statement = base_statement.with_only_columns(
        sa.func.count(sa.distinct(Incident.IncidentID)).label("count")
    )

    statement = base_statement.with_only_columns(
        Incident.IncidentID.label("incident_id"),
        Incident.BusinessRuleId.label("business_rule_id"),
        Incident.Created.label("created"),
        Occurrence.LoadId.label("load_id"),
        Occurrence.EntityId.label("entity_id"),
        Occurrence.ReportingUnitId.label("reporting_unit_id"),
        Occurrence.Fields.label("fields"),
    )
    statement = apply_sorting(statement, request.applied_sorting)
    statement = statement.offset(skip).limit(take)

    return ExtendedViewStatementPlan(
        statement=statement,
        count_statement=count_statement,
        skip=skip,
        take=take,
    )
