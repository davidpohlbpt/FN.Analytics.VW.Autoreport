"""Shared raw-SQL predicate builders for the workbench occurrence-scoped queries.

`occurrence_sql.py` (groups/count) and `search.py` both filter the same
`T_RESULT_Occurence` rows by scope (load/entity/reporting unit), visibility
(hidden/deleted), and scenario. This module is the single source of truth for
those predicates so the three raw-SQL query builders can't drift out of sync.

The ORM-based query builder in `base.py` expresses the same scope and
visibility semantics against SQLAlchemy Core (`Incident`/`Occurrence` models)
because OPENJSON-based grouping/search can't be expressed there. Any change to
the scope or visibility rules here must be mirrored in `base.py`'s
`_apply_scope_filters` / `_apply_visibility_filters`.

Incident-resolve exclusion is intentionally NOT unified here: `occurrence_sql.py`
and `base.py` only exclude occurrences whose incident was resolved for the
*requested* load(s) (no exclusion at all when no load is specified), while
`search.py` excludes occurrences whose *own* load was resolved regardless of
the request's load scope. This is a pre-existing behavioral difference between
endpoints, not something introduced by this consolidation — see
`build_incident_resolve_exclusion_by_scope_load` vs
`build_incident_resolve_exclusion_by_occurrence_load`.
"""

from __future__ import annotations

import dataclasses
from typing import Any, Optional, Sequence

from pycore.workbench.constants import DEFAULT_WORKBENCH_SCHEMA


@dataclasses.dataclass(frozen=True)
class OccurrenceScopeParams:
    schema: str = DEFAULT_WORKBENCH_SCHEMA
    load_id: Optional[int] = None
    load_ids: Optional[Sequence[int]] = None
    entity_id: Optional[int] = None
    entity_ids: Optional[Sequence[int]] = None
    reporting_unit_id: Optional[int] = None
    show_hidden: bool = False
    show_deleted: bool = False


def add_sequence_parameters(
    sql_parameters: dict[str, Any],
    prefix: str,
    values: Sequence[int],
) -> str:
    placeholders: list[str] = []
    for index, value in enumerate(values):
        key = f"{prefix}_{index}"
        sql_parameters[key] = value
        placeholders.append(f":{key}")
    return ", ".join(placeholders)


def build_scope_predicates(
    predicates: list[str],
    sql_parameters: dict[str, Any],
    params: OccurrenceScopeParams,
    occurrence_alias: str = "o",
) -> None:
    """Appends load/entity/reporting-unit scope predicates against `occurrence_alias`."""

    if params.load_id is not None:
        predicates.append(f"{occurrence_alias}.[LoadId] = :load_id")
        sql_parameters["load_id"] = params.load_id

    if params.load_ids:
        placeholders = add_sequence_parameters(sql_parameters, "load_ids", params.load_ids)
        predicates.append(f"{occurrence_alias}.[LoadId] IN ({placeholders})")

    if params.entity_id is not None:
        predicates.append(f"{occurrence_alias}.[EntityId] = :entity_id")
        sql_parameters["entity_id"] = params.entity_id

    if params.entity_ids:
        placeholders = add_sequence_parameters(sql_parameters, "entity_ids", params.entity_ids)
        predicates.append(f"{occurrence_alias}.[EntityId] IN ({placeholders})")

    if params.reporting_unit_id is not None:
        predicates.append(f"{occurrence_alias}.[ReportingUnitId] = :reporting_unit_id")
        sql_parameters["reporting_unit_id"] = params.reporting_unit_id


def build_visibility_predicates(
    predicates: list[str],
    params: OccurrenceScopeParams,
    incident_id_expression: str,
) -> None:
    """Appends hidden/deleted visibility predicates for the incident identified by
    `incident_id_expression` (e.g. `"i.[IncidentID]"` or `"o.[IncidentID]"`).
    """

    schema = params.schema
    hide_exists_sql = (
        "EXISTS ("
        f"SELECT 1 FROM [{schema}].[T_RESULT_Incident_HideUser] h "
        f"WHERE h.[IncidentId] = {incident_id_expression}"
        ")"
    )
    delete_exists_sql = (
        "EXISTS ("
        f"SELECT 1 FROM [{schema}].[T_RESULT_Incident_Delete] d "
        f"WHERE d.[IncidentId] = {incident_id_expression}"
        ")"
    )

    predicates.append(hide_exists_sql if params.show_hidden else f"NOT {hide_exists_sql}")
    predicates.append(delete_exists_sql if params.show_deleted else f"NOT {delete_exists_sql}")


def build_incident_resolve_exclusion_by_scope_load(
    predicates: list[str],
    sql_parameters: dict[str, Any],
    schema: str,
    incident_id_expression: str,
    load_id: Optional[int],
    load_ids: Optional[Sequence[int]],
) -> None:
    """Excludes occurrences whose incident was resolved for the *requested* load(s).

    No exclusion is applied when neither `load_id` nor `load_ids` is given —
    matches `base.py`'s `_apply_incident_resolve_exclusion` semantics.
    """

    if load_ids:
        placeholders = add_sequence_parameters(sql_parameters, "resolve_load_ids", load_ids)
        predicates.append(
            "NOT EXISTS ("
            f"SELECT 1 FROM [{schema}].[T_RESULT_Incident_Resolve] r "
            f"WHERE r.[IncidentId] = {incident_id_expression} "
            f"AND r.[LoadId] IN ({placeholders})"
            ")"
        )
        return

    if load_id is not None:
        sql_parameters["resolve_load_id"] = load_id
        predicates.append(
            "NOT EXISTS ("
            f"SELECT 1 FROM [{schema}].[T_RESULT_Incident_Resolve] r "
            f"WHERE r.[IncidentId] = {incident_id_expression} "
            "AND r.[LoadId] = :resolve_load_id"
            ")"
        )


def build_incident_resolve_exclusion_by_occurrence_load(
    schema: str,
    occurrence_alias: str = "o",
) -> str:
    """Excludes an occurrence whose *own* load was resolved, regardless of request scope.

    Used by `search.py` — see the module docstring for why this differs from
    `build_incident_resolve_exclusion_by_scope_load`.
    """

    return (
        "NOT EXISTS ("
        f"SELECT 1 FROM [{schema}].[T_RESULT_Incident_Resolve] r "
        f"WHERE r.[IncidentId] = {occurrence_alias}.[IncidentID] "
        f"AND r.[LoadId] = {occurrence_alias}.[LoadId]"
        ")"
    )
