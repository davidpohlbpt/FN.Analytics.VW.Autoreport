from __future__ import annotations

import datetime as dt
from typing import Any, Callable, Iterable, Optional, Sequence

import sqlalchemy as sa
from sqlalchemy.sql import Select

from pycore.schemas import FilterOperator
from pycore.workbench.constants import INCIDENT_COLUMN_WHITELIST, SAFE_COLUMN_RE
from pycore.workbench.constants import INCIDENT_DIMENSION_ALIASES
from pycore.workbench.contracts import WorkbenchRequestBase
from pycore.workbench.filters import (
    ParsedFilter,
    ParsedSearchParameter,
    RoutedFilters,
    RoutedSearchParameters,
)
from pycore.workbench.models import (
    Incident,
    IncidentDelete,
    IncidentHideUser,
    IncidentResolve,
    Occurrence,
)


def build_base_query(
    request: WorkbenchRequestBase,
    routed_filters: Optional[RoutedFilters] = None,
    routed_search_parameters: Optional[RoutedSearchParameters] = None,
    include_user_filters: bool = True,
) -> Select:
    statement = (
        sa.select(Incident, Occurrence)
        .join(Occurrence, Incident.IncidentID == Occurrence.IncidentID)
        .where(Incident.ScenarioId == request.scenario_id)
        .where(Occurrence.ScenarioId == request.scenario_id)
    )

    statement = _apply_scope_filters(statement, request)
    statement = _apply_visibility_filters(statement, request)
    statement = _apply_incident_resolve_exclusion(statement, request)

    if include_user_filters and routed_filters is not None:
        statement = _apply_incident_filters(statement, routed_filters.incident)
        statement = _apply_occurrence_filters(
            statement,
            routed_filters.occurrence,
            request.computed_occurrence_columns,
        )

    if include_user_filters and routed_search_parameters is not None:
        statement = _apply_search_parameters(
            statement,
            routed_search_parameters,
            request.computed_occurrence_columns,
        )

    return statement


def _apply_scope_filters(statement: Select, request: WorkbenchRequestBase) -> Select:
    if request.load_id is not None and request.load_id != 0:
        statement = statement.where(Occurrence.LoadId == request.load_id)

    if request.load_ids:
        statement = statement.where(Occurrence.LoadId.in_(request.load_ids))

    if request.entity_id is not None and request.entity_id != 0:
        statement = statement.where(Occurrence.EntityId == request.entity_id)

    if request.entity_ids:
        statement = statement.where(Occurrence.EntityId.in_(request.entity_ids))

    if request.reporting_unit_id is not None and request.reporting_unit_id != 0:
        statement = statement.where(Occurrence.ReportingUnitId == request.reporting_unit_id)

    return statement


def _apply_visibility_filters(statement: Select, request: WorkbenchRequestBase) -> Select:
    hidden_exists = sa.exists(
        sa.select(1).where(IncidentHideUser.IncidentID == Incident.IncidentID)
    )
    deleted_exists = sa.exists(
        sa.select(1).where(IncidentDelete.IncidentID == Incident.IncidentID)
    )

    statement = statement.where(hidden_exists if request.show_hidden else sa.not_(hidden_exists))
    statement = statement.where(
        deleted_exists if request.show_deleted else sa.not_(deleted_exists)
    )
    return statement


def _apply_incident_resolve_exclusion(
    statement: Select,
    request: WorkbenchRequestBase,
) -> Select:
    resolve_predicates = [IncidentResolve.IncidentID == Incident.IncidentID]

    if request.load_ids:
        resolve_predicates.append(IncidentResolve.LoadId.in_(request.load_ids))
    elif request.load_id is not None:
        resolve_predicates.append(IncidentResolve.LoadId == request.load_id)

    if len(resolve_predicates) <= 1:
        return statement

    resolve_exists = sa.exists(sa.select(1).where(*resolve_predicates))
    return statement.where(sa.not_(resolve_exists))


def _apply_incident_filters(statement: Select, filters: Sequence[ParsedFilter]) -> Select:
    for parsed_filter in filters:
        if parsed_filter.name.lower() == "age":
            statement = statement.where(_build_age_filter_condition(parsed_filter))
            continue

        column = _resolve_incident_column(parsed_filter.name)
        statement = statement.where(_build_filter_condition(column, parsed_filter))
    return statement


def _build_age_filter_condition(parsed_filter: ParsedFilter):
    operator = parsed_filter.filter_type
    created_column = Incident.Created

    if operator in (FilterOperator.is_null, FilterOperator.is_null_or_empty):
        return created_column.is_(None)

    if operator in (FilterOperator.is_not_null, FilterOperator.is_not_null_or_empty):
        return created_column.is_not(None)

    age_value = _parse_age_days(parsed_filter.value, filter_name=parsed_filter.name)

    # Keep age semantics aligned with slice response calculation:
    # age = (today_utc_date - created_date).days
    today = dt.datetime.now(dt.UTC).date()

    def start_of_day(day: dt.date) -> dt.datetime:
        return dt.datetime.combine(day, dt.time.min, tzinfo=dt.UTC)

    if operator == FilterOperator.greater:
        # age > n  => created_date < today - n
        return created_column < start_of_day(today - dt.timedelta(days=age_value))

    if operator == FilterOperator.greater_or_equal:
        # age >= n => created_date <= today - n
        return created_column < start_of_day(today - dt.timedelta(days=age_value - 1))

    if operator == FilterOperator.less:
        # age < n  => created_date > today - n
        return created_column >= start_of_day(today - dt.timedelta(days=age_value - 1))

    if operator == FilterOperator.less_or_equal:
        # age <= n => created_date >= today - n
        return created_column >= start_of_day(today - dt.timedelta(days=age_value))

    if operator in (FilterOperator.equal, FilterOperator.exact_search):
        start = start_of_day(today - dt.timedelta(days=age_value))
        end = start + dt.timedelta(days=1)
        return sa.and_(created_column >= start, created_column < end)

    if operator == FilterOperator.not_equal:
        start = start_of_day(today - dt.timedelta(days=age_value))
        end = start + dt.timedelta(days=1)
        return sa.or_(created_column < start, created_column >= end)

    if operator == FilterOperator.between:
        age_value2 = _parse_age_days(parsed_filter.value2, filter_name=parsed_filter.name)
        lower_age = min(age_value, age_value2)
        upper_age = max(age_value, age_value2)
        # lower_age <= age <= upper_age
        start = start_of_day(today - dt.timedelta(days=upper_age))
        end = start_of_day(today - dt.timedelta(days=lower_age - 1))
        return sa.and_(created_column >= start, created_column < end)

    raise ValueError(f"Unsupported age filter operator `{operator}`.")


def _parse_age_days(value, filter_name: str) -> int:
    try:
        parsed = int(str(value))
    except Exception as exc:
        raise ValueError(
            f"Filter `{filter_name}` expects an integer numeric value for age filtering."
        ) from exc

    if parsed < 0:
        raise ValueError(f"Filter `{filter_name}` age value must be non-negative.")

    return parsed


def _apply_occurrence_filters(
    statement: Select,
    filters: Sequence[ParsedFilter],
    computed_occurrence_columns: Iterable[str],
) -> Select:
    for parsed_filter in filters:
        expression = _resolve_occurrence_expression(
            parsed_filter.name,
            computed_occurrence_columns,
        )
        statement = statement.where(_build_filter_condition(expression, parsed_filter))
    return statement


def _apply_search_parameters(
    statement: Select,
    routed_search_parameters: RoutedSearchParameters,
    computed_occurrence_columns: Iterable[str],
) -> Select:
    for parameter in routed_search_parameters.incident:
        column = _resolve_incident_column(parameter.field_name)
        statement = statement.where(column == parameter.value)

    for parameter in routed_search_parameters.computed_occurrence:
        expression = _resolve_occurrence_expression(
            parameter.field_name,
            computed_occurrence_columns,
        )
        statement = statement.where(expression == parameter.value)

    for parameter in routed_search_parameters.occurrence:
        expression = _resolve_occurrence_expression(
            parameter.field_name,
            computed_occurrence_columns,
        )
        statement = statement.where(expression == parameter.value)

    return statement


def _resolve_incident_column(column_name: str):
    normalized = column_name.lower()
    normalized = INCIDENT_DIMENSION_ALIASES.get(normalized, normalized)
    if normalized not in INCIDENT_COLUMN_WHITELIST:
        raise ValueError(f"Invalid incident column `{column_name}`.")

    for table_column in Incident.__table__.c:
        if table_column.name.lower() == normalized:
            return table_column

    raise ValueError(f"Incident column `{column_name}` does not exist.")


def _resolve_occurrence_expression(
    column_name: str,
    computed_occurrence_columns: Iterable[str],
):
    normalized = column_name.lower()
    computed_columns = {column.lower() for column in computed_occurrence_columns}

    if normalized in computed_columns:
        for table_column in Occurrence.__table__.c:
            if table_column.name.lower() == normalized:
                return table_column
        if not SAFE_COLUMN_RE.fullmatch(column_name):
            raise ValueError(f"Invalid occurrence computed field `{column_name}`.")
        return sa.func.json_value(Occurrence.Fields, f'$."{column_name}"')

    if not SAFE_COLUMN_RE.fullmatch(column_name):
        raise ValueError(f"Invalid occurrence JSON field `{column_name}`.")

    return sa.func.json_value(Occurrence.Fields, f'$."{column_name}"')


def _multiselect_condition(column_expr, parsed_filter: ParsedFilter):
    if not isinstance(parsed_filter.value, list):
        raise ValueError(
            f"Filter `{parsed_filter.name}` expects a list value for `multiselect`, "
            f"got {type(parsed_filter.value).__name__}."
        )
    return column_expr.in_(parsed_filter.value)


def _is_null_condition(column_expr, parsed_filter: ParsedFilter):
    return sa.or_(column_expr.is_(None), column_expr == "")


def _is_not_null_condition(column_expr, parsed_filter: ParsedFilter):
    return sa.and_(column_expr.is_not(None), column_expr != "")


_FILTER_CONDITION_BUILDERS: dict[FilterOperator, Callable[[Any, ParsedFilter], Any]] = {
    FilterOperator.equal: lambda col, flt: col == flt.value,
    FilterOperator.exact_search: lambda col, flt: col == flt.value,
    FilterOperator.not_equal: lambda col, flt: col != flt.value,
    FilterOperator.multiselect: _multiselect_condition,
    FilterOperator.fuzzy_search: lambda col, flt: col.like(f"%{flt.value}%"),
    FilterOperator.not_fuzzy_search: lambda col, flt: sa.not_(col.like(f"%{flt.value}%")),
    FilterOperator.begins_with: lambda col, flt: col.like(f"{flt.value}%"),
    FilterOperator.ends_with: lambda col, flt: col.like(f"%{flt.value}"),
    FilterOperator.greater: lambda col, flt: col > flt.value,
    FilterOperator.greater_or_equal: lambda col, flt: col >= flt.value,
    FilterOperator.less: lambda col, flt: col < flt.value,
    FilterOperator.less_or_equal: lambda col, flt: col <= flt.value,
    FilterOperator.between: lambda col, flt: col.between(flt.value, flt.value2),
    FilterOperator.is_null: _is_null_condition,
    FilterOperator.is_null_or_empty: _is_null_condition,
    FilterOperator.is_not_null: _is_not_null_condition,
    FilterOperator.is_not_null_or_empty: _is_not_null_condition,
}


def _build_filter_condition(column_expr, parsed_filter: ParsedFilter):
    builder = _FILTER_CONDITION_BUILDERS.get(parsed_filter.filter_type)
    if builder is None:
        raise ValueError(
            f"Unsupported filter operator `{parsed_filter.filter_type}` for workbench query."
        )
    return builder(column_expr, parsed_filter)
