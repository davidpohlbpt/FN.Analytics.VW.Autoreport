from __future__ import annotations

import dataclasses
from typing import Any, Optional

import sqlalchemy as sa
from sqlalchemy.sql import Select

from pycore.workbench.constants import ORIGIN_INCIDENT, ORIGIN_OCCURRENCE, ORIGIN_RULE
from pycore.workbench.contracts import WorkbenchGroupsRequest
from pycore.workbench.filters import RoutedFilters, RoutedSearchParameters
from pycore.workbench import models as workbench_models
from pycore.workbench.models import Incident, Occurrence
from pycore.workbench.query.base import build_base_query, _resolve_occurrence_expression
from pycore.workbench.query.occurrence_sql import (
    OccurrenceQueryParams,
    WorkbenchOccurrenceSqlBuilder,
)


@dataclasses.dataclass(frozen=True)
class GroupQueryPlan:
    orm_statement: Optional[Select] = None
    raw_sql: Optional[str] = None
    raw_parameters: dict[str, Any] = dataclasses.field(default_factory=dict)


@dataclasses.dataclass(frozen=True)
class WorkbenchGroupRow:
    title: str
    count: int


def build_groups_query_plan(
    request: WorkbenchGroupsRequest,
    routed_filters: Optional[RoutedFilters] = None,
    routed_search_parameters: Optional[RoutedSearchParameters] = None,
) -> GroupQueryPlan:
    origin = (request.grouping_dimension_origin or "").lower().strip()
    if origin == ORIGIN_RULE:
        return _build_rule_origin_query_plan(
            request,
            routed_filters=routed_filters,
            routed_search_parameters=routed_search_parameters,
        )

    if origin == ORIGIN_INCIDENT:
        statement = _build_incident_group_statement(
            request,
            routed_filters=routed_filters,
            routed_search_parameters=routed_search_parameters,
        )
        return GroupQueryPlan(orm_statement=statement)

    if origin == ORIGIN_OCCURRENCE:
        if request.is_computed_column:
            statement = _build_computed_occurrence_group_statement(
                request,
                routed_filters=routed_filters,
                routed_search_parameters=routed_search_parameters,
            )
            return GroupQueryPlan(orm_statement=statement)

        sql_builder = WorkbenchOccurrenceSqlBuilder()
        raw_sql, raw_parameters = sql_builder.build_groups_query(
            OccurrenceQueryParams(
                scenario_id=request.scenario_id,
                grouping_dimension=request.grouping_dimension or "",
                schema=workbench_models.WORKBENCH_SCHEMA,
                load_id=request.load_id,
                load_ids=request.load_ids,
                entity_id=request.entity_id,
                entity_ids=request.entity_ids,
                reporting_unit_id=request.reporting_unit_id,
                show_hidden=request.show_hidden,
                show_deleted=request.show_deleted,
            )
        )
        return GroupQueryPlan(raw_sql=raw_sql, raw_parameters=raw_parameters)

    raise ValueError(
        f"Unsupported grouping dimension origin `{request.grouping_dimension_origin}`."
    )


def _build_incident_group_statement(
    request: WorkbenchGroupsRequest,
    routed_filters: Optional[RoutedFilters],
    routed_search_parameters: Optional[RoutedSearchParameters],
) -> Select:
    if not request.grouping_dimension:
        raise ValueError("grouping_dimension is required for incident grouping.")

    column = _resolve_incident_column(request.grouping_dimension)
    base_query = build_base_query(
        request,
        routed_filters=routed_filters,
        routed_search_parameters=routed_search_parameters,
        include_user_filters=True,
    )
    return (
        base_query.with_only_columns(
            sa.func.coalesce(sa.cast(column, sa.String), "").label("title"),
            sa.func.count().label("count"),
        )
        .group_by(column)
        .order_by(sa.desc("count"))
    )


def _build_computed_occurrence_group_statement(
    request: WorkbenchGroupsRequest,
    routed_filters: Optional[RoutedFilters],
    routed_search_parameters: Optional[RoutedSearchParameters],
) -> Select:
    if not request.grouping_dimension:
        raise ValueError("grouping_dimension is required for occurrence grouping.")

    column = _resolve_occurrence_expression(
        request.grouping_dimension,
        request.computed_occurrence_columns,
    )
    title_expression = sa.func.coalesce(sa.cast(column, sa.String), "")
    base_query = build_base_query(
        request,
        routed_filters=routed_filters,
        routed_search_parameters=routed_search_parameters,
        include_user_filters=True,
    )
    grouped_source = base_query.with_only_columns(title_expression.label("title")).subquery()
    return (
        sa.select(
            grouped_source.c.title,
            sa.func.count().label("count"),
        )
        .select_from(grouped_source)
        .group_by(grouped_source.c.title)
        .order_by(sa.desc("count"))
    )


def _build_rule_origin_query_plan(
    request: WorkbenchGroupsRequest,
    routed_filters: Optional[RoutedFilters],
    routed_search_parameters: Optional[RoutedSearchParameters],
) -> GroupQueryPlan:
    # Phase 1 skeleton: group by BusinessRuleId on incident rows.
    base_query = build_base_query(
        request,
        routed_filters=routed_filters,
        routed_search_parameters=routed_search_parameters,
        include_user_filters=True,
    )
    statement = (
        base_query.with_only_columns(
            sa.func.coalesce(sa.cast(Incident.BusinessRuleId, sa.String), "").label("title"),
            sa.func.count().label("count"),
        )
        .group_by(Incident.BusinessRuleId)
        .order_by(sa.desc("count"))
    )
    return GroupQueryPlan(orm_statement=statement)


def _resolve_incident_column(column_name: str):
    normalized = column_name.lower()
    for table_column in Incident.__table__.c:
        if table_column.name.lower() == normalized:
            return table_column
    raise ValueError(f"Unknown incident grouping column `{column_name}`.")


