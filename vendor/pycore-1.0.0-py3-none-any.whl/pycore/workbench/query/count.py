from __future__ import annotations

import dataclasses
from typing import Optional, Sequence

import sqlalchemy as sa
from sqlalchemy.sql import Select

from pycore.workbench.contracts import WorkbenchCountRequest
from pycore.workbench.filters import RoutedFilters, RoutedSearchParameters
from pycore.workbench.models import Incident
from pycore.workbench.query.base import build_base_query


@dataclasses.dataclass(frozen=True)
class WorkbenchCountBreakdown:
    total_count: int
    filtered_count: int


@dataclasses.dataclass(frozen=True)
class CountStatements:
    total_statement: Select
    filtered_statement: Select


def build_count_statements(
    request: WorkbenchCountRequest,
    routed_filters: Optional[RoutedFilters] = None,
    routed_search_parameters: Optional[RoutedSearchParameters] = None,
    included_rule_ids: Optional[Sequence[str]] = None,
    excluded_rule_ids: Optional[Sequence[str]] = None,
) -> CountStatements:
    total_base = build_base_query(
        request,
        routed_filters=None,
        routed_search_parameters=None,
        include_user_filters=False,
    )
    filtered_base = build_base_query(
        request,
        routed_filters=routed_filters,
        routed_search_parameters=routed_search_parameters,
        include_user_filters=True,
    )

    total_statement = _to_count_statement(total_base)
    filtered_statement = _to_count_statement(filtered_base)

    filtered_statement = _apply_rule_scope(
        filtered_statement,
        included_rule_ids=included_rule_ids,
        excluded_rule_ids=excluded_rule_ids,
    )

    return CountStatements(
        total_statement=total_statement,
        filtered_statement=filtered_statement,
    )


def _to_count_statement(base_statement: Select) -> Select:
    return base_statement.with_only_columns(
        sa.func.count(sa.distinct(Incident.IncidentID)).label("count")
    )


def _apply_rule_scope(
    statement: Select,
    included_rule_ids: Optional[Sequence[str]],
    excluded_rule_ids: Optional[Sequence[str]],
) -> Select:
    if included_rule_ids:
        statement = statement.where(Incident.BusinessRuleId.in_(included_rule_ids))

    if excluded_rule_ids:
        statement = statement.where(Incident.BusinessRuleId.notin_(excluded_rule_ids))

    return statement
