from __future__ import annotations

import dataclasses
from typing import Any, Optional, Sequence

from pycore.workbench.constants import (
    DEFAULT_WORKBENCH_SCHEMA,
    FIELD_TYPE_BOOLEAN,
    FIELD_TYPE_CURRENCY,
    FIELD_TYPE_DATE,
    FIELD_TYPE_NUMERIC,
    FIELD_TYPE_STRING,
    OPENJSON_TYPE_TO_FIELD_TYPE,
    ORIGIN_FIELDS,
    ORIGIN_INCIDENTS,
    ORIGIN_RULES,
    SCORE_FIELD_NAME,
)
from pycore.workbench.contracts import (
    FilterConfigurationModel,
    FilterOperatorOption,
    FilterOperatorsModel,
)
from pycore.workbench.query.predicates import add_sequence_parameters

_STRING_OPERATOR_DEFINITIONS: tuple[tuple[str, str], ...] = (
    ("Exact", "ExactSearch"),
    ("Contains", "fuzzySearch"),
    ("Not contains", "notFuzzySearch"),
    ("Empty", "null"),
)

_NUMERIC_OPERATOR_DEFINITIONS: tuple[tuple[str, str], ...] = (
    ("Equal", "equal"),
    ("Greater", "higher"),
    ("Greater or equal", "higherOrEqual"),
    ("Less", "lower"),
    ("Less or equal", "lowerOrEqual"),
    ("Empty", "null"),
    ("Not equal", "notEqual"),
)

_DATE_OPERATOR_DEFINITIONS: tuple[tuple[str, str], ...] = (
    ("Equal", "dateEqual"),
    ("Greater", "dateStrictlyAfter"),
    ("Greater or equal", "dateAfter"),
    ("Less or equal", "dateBefore"),
    ("Not equal", "dateNotEqual"),
    ("Between", "dateBetween"),
)

_BOOLEAN_OPERATOR_DEFINITIONS: tuple[tuple[str, str], ...] = (
    ("Exact", "ExactSearch"),
    ("Empty", "null"),
)


def _build_operator_options(
    definitions: Sequence[tuple[str, str]],
) -> list[FilterOperatorOption]:
    return [FilterOperatorOption(name=name, value=value) for name, value in definitions]

STATIC_FILTERS: list[FilterConfigurationModel] = [
    FilterConfigurationModel(
        name="TN_BR", label="TN_BR", dimension="BusinessRuleId",
        type=FIELD_TYPE_STRING, path=ORIGIN_INCIDENTS,
    ),
    FilterConfigurationModel(
        name="TN_RA_RuleAssignedUser", label="TN_RA_RuleAssignedUser",
        dimension="IncidentAssignedUser", type=FIELD_TYPE_STRING, path=ORIGIN_INCIDENTS,
    ),
    FilterConfigurationModel(
        name="TN_RA_Criticality", label="TN_RA_Criticality",
        dimension="Criticality", type=FIELD_TYPE_STRING, path=ORIGIN_RULES,
    ),
    FilterConfigurationModel(
        name="TN_ER3_Status", label="TN_ER3_Status",
        dimension="Status", type=FIELD_TYPE_STRING, path=ORIGIN_INCIDENTS,
    ),
    FilterConfigurationModel(
        name="TN_ER3_Age", label="TN_ER3_Age",
        dimension="age", type=FIELD_TYPE_NUMERIC, path=ORIGIN_INCIDENTS,
    ),
    FilterConfigurationModel(
        name="TN_ER3_IncidentID", label="TN_ER3_IncidentID",
        dimension="IncidentId", type=FIELD_TYPE_STRING, path=ORIGIN_INCIDENTS,
    ),
    FilterConfigurationModel(
        name="Legacy", label="Legacy",
        dimension="Legacy", type=FIELD_TYPE_BOOLEAN, path=ORIGIN_RULES,
    ),
    FilterConfigurationModel(
        name="Masterdata", label="Masterdata",
        dimension="Masterdata", type=FIELD_TYPE_BOOLEAN, path=ORIGIN_RULES,
    ),
    FilterConfigurationModel(
        name="Solvable", label="Solvable",
        dimension="Solvable", type=FIELD_TYPE_BOOLEAN, path=ORIGIN_RULES,
    ),
    FilterConfigurationModel(
        name="GroupingDimension1", label="GroupingDimension1",
        dimension="GroupingDimension1", type=FIELD_TYPE_STRING, path=ORIGIN_RULES,
    ),
    FilterConfigurationModel(
        name="GroupingDimension2", label="GroupingDimension2",
        dimension="GroupingDimension2", type=FIELD_TYPE_STRING, path=ORIGIN_RULES,
    ),
]

OPERATORS_BY_FIELD_TYPE: list[FilterOperatorsModel] = [
    FilterOperatorsModel(
        type=FIELD_TYPE_STRING,
        operators=_build_operator_options(_STRING_OPERATOR_DEFINITIONS),
    ),
    FilterOperatorsModel(
        type=FIELD_TYPE_NUMERIC,
        operators=_build_operator_options(_NUMERIC_OPERATOR_DEFINITIONS),
    ),
    FilterOperatorsModel(
        type=FIELD_TYPE_CURRENCY,
        operators=_build_operator_options(_NUMERIC_OPERATOR_DEFINITIONS),
    ),
    FilterOperatorsModel(
        type=FIELD_TYPE_DATE,
        operators=_build_operator_options(_DATE_OPERATOR_DEFINITIONS),
    ),
    FilterOperatorsModel(
        type=FIELD_TYPE_BOOLEAN,
        operators=_build_operator_options(_BOOLEAN_OPERATOR_DEFINITIONS),
    ),
]


@dataclasses.dataclass(frozen=True)
class DynamicFieldTypesSqlParams:
    scenario_id: int
    schema: str = DEFAULT_WORKBENCH_SCHEMA
    load_id: Optional[int] = None
    load_ids: Optional[Sequence[int]] = None


class WorkbenchFilterConfigurationSqlBuilder:
    def build_dynamic_field_types_query(
        self, params: DynamicFieldTypesSqlParams
    ) -> tuple[str, dict[str, Any]]:
        predicates = ["o.[ScenarioId] = :scenario_id"]
        sql_parameters: dict[str, Any] = {"scenario_id": params.scenario_id}

        if params.load_id is not None:
            predicates.append("o.[LoadId] = :load_id")
            sql_parameters["load_id"] = params.load_id

        if params.load_ids:
            placeholders = add_sequence_parameters(
                sql_parameters,
                "load_ids",
                params.load_ids,
            )
            predicates.append(f"o.[LoadId] IN ({placeholders})")

        where_sql = "\n  AND ".join(predicates)

        query = f"""
SELECT DISTINCT j.[key] AS [key], j.[type] AS [type]
FROM [{params.schema}].[T_RESULT_Occurence] o
CROSS APPLY OPENJSON(o.[Fields]) j
WHERE {where_sql}
""".strip()

        return query, sql_parameters


def map_openjson_type(json_type: int, key: str) -> str:
    if key == SCORE_FIELD_NAME:
        return FIELD_TYPE_STRING
    return OPENJSON_TYPE_TO_FIELD_TYPE.get(json_type, FIELD_TYPE_STRING)
