from __future__ import annotations

from typing import Optional, Sequence

import sqlalchemy as sa
from sqlalchemy.sql import Select

from pycore.workbench.contracts import WorkbenchSmartlistCountRequest
from pycore.workbench.filters import RoutedFilters, RoutedSearchParameters
from pycore.workbench.models import Incident
from pycore.workbench.query.base import build_base_query


def build_smartlist_count_statement(
    request: WorkbenchSmartlistCountRequest,
    routed_filters: Optional[RoutedFilters] = None,
    routed_search_parameters: Optional[RoutedSearchParameters] = None,
    included_rule_ids: Optional[Sequence[str]] = None,
    excluded_rule_ids: Optional[Sequence[str]] = None,
    incident_status: Optional[str] = None,
) -> Select:
    base_statement = build_base_query(
        request,
        routed_filters=routed_filters,
        routed_search_parameters=routed_search_parameters,
        include_user_filters=True,
    )

    statement = base_statement.with_only_columns(
        sa.func.count(sa.distinct(Incident.IncidentID)).label("count")
    )
    statement = _apply_rule_scope(
        statement,
        included_rule_ids=included_rule_ids,
        excluded_rule_ids=excluded_rule_ids,
    )

    if incident_status is not None:
        statement = statement.where(Incident.Status == incident_status)

    return statement


def _apply_rule_scope(
    statement: Select,
    included_rule_ids: Optional[Sequence[str]],
    excluded_rule_ids: Optional[Sequence[str]],
) -> Select:
    if included_rule_ids:
        statement = statement.where(Incident.BusinessRuleId.in_(included_rule_ids))

    if excluded_rule_ids:
        statement = statement.where(Incident.BusinessRuleId.notin_(excluded_rule_ids))

    return statement
