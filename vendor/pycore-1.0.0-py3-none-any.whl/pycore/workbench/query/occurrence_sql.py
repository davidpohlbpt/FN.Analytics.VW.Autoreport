from __future__ import annotations

import dataclasses
from typing import Any, Mapping, Optional, Sequence

from pycore.workbench.constants import (
    DEFAULT_WORKBENCH_SCHEMA,
    INCIDENT_COLUMN_WHITELIST,
    SAFE_COLUMN_RE,
    UNDEFINED,
)
from pycore.workbench.query.predicates import (
    OccurrenceScopeParams,
    build_incident_resolve_exclusion_by_scope_load,
    build_scope_predicates,
    build_visibility_predicates,
)


@dataclasses.dataclass(frozen=True)
class OccurrenceQueryParams:
    scenario_id: int
    grouping_dimension: str
    schema: str = DEFAULT_WORKBENCH_SCHEMA
    load_id: Optional[int] = None
    load_ids: Optional[Sequence[int]] = None
    entity_id: Optional[int] = None
    entity_ids: Optional[Sequence[int]] = None
    reporting_unit_id: Optional[int] = None
    show_hidden: bool = False
    show_deleted: bool = False
    additional_where_sql: Optional[str] = None
    additional_parameters: Mapping[str, Any] = dataclasses.field(default_factory=dict)


class WorkbenchOccurrenceSqlBuilder:
    def validate_safe_column_name(self, column_name: str) -> str:
        if not SAFE_COLUMN_RE.fullmatch(column_name):
            raise ValueError(
                f"Invalid column name `{column_name}`. Only [A-Za-z0-9_] is allowed."
            )
        return column_name

    def validate_incident_column_name(self, column_name: str) -> str:
        normalized = column_name.lower()
        if normalized not in INCIDENT_COLUMN_WHITELIST:
            raise ValueError(
                f"Incident column `{column_name}` is not in the safe whitelist."
            )
        return column_name

    def build_groups_query(self, params: OccurrenceQueryParams) -> tuple[str, dict[str, Any]]:
        title_expression = self._build_group_title_expression(params.grouping_dimension)
        where_sql, sql_parameters = self._build_common_where_clause(params)

        query = f"""
SELECT
    {title_expression} AS Title,
    COUNT(*) AS [Count]
FROM [{params.schema}].[T_RESULT_Occurence] o
INNER JOIN [{params.schema}].[T_RESULT_Incident] i
    ON i.[IncidentID] = o.[IncidentID]
WHERE {where_sql}
GROUP BY {title_expression}
ORDER BY [Count] DESC
""".strip()
        return query, sql_parameters

    def build_record_count_query(
        self,
        params: OccurrenceQueryParams,
    ) -> tuple[str, dict[str, Any]]:
        title_expression = self._build_group_title_expression(params.grouping_dimension)
        where_sql, sql_parameters = self._build_common_where_clause(params)

        query = f"""
SELECT
    {title_expression} AS Title,
    COUNT(DISTINCT CAST(j.[value] AS NVARCHAR(MAX))) AS [Records]
FROM [{params.schema}].[T_RESULT_Occurence] o
INNER JOIN [{params.schema}].[T_RESULT_Incident] i
    ON i.[IncidentID] = o.[IncidentID]
CROSS APPLY OPENJSON(i.[Identifier]) j
WHERE {where_sql}
GROUP BY {title_expression}
""".strip()
        return query, sql_parameters

    def _build_group_title_expression(self, grouping_dimension: str) -> str:
        safe_dimension = self.validate_safe_column_name(grouping_dimension)
        json_path = f"$.\"{safe_dimension}\""
        return (
            "CASE "
            "WHEN NOT EXISTS ("
            "SELECT 1 FROM OPENJSON(o.[Fields]) j "
            f"WHERE j.[key] = '{safe_dimension}'"
            f") THEN '{UNDEFINED}' "
            f"ELSE COALESCE(JSON_VALUE(o.[Fields], '{json_path}'), '') "
            "END"
        )

    def _build_common_where_clause(
        self,
        params: OccurrenceQueryParams,
    ) -> tuple[str, dict[str, Any]]:
        predicates: list[str] = [
            "o.[ScenarioId] = :scenario_id",
            "i.[ScenarioId] = :scenario_id",
        ]
        sql_parameters: dict[str, Any] = {
            "scenario_id": params.scenario_id,
            **dict(params.additional_parameters),
        }

        scope_params = OccurrenceScopeParams(
            schema=params.schema,
            load_id=params.load_id,
            load_ids=params.load_ids,
            entity_id=params.entity_id,
            entity_ids=params.entity_ids,
            reporting_unit_id=params.reporting_unit_id,
            show_hidden=params.show_hidden,
            show_deleted=params.show_deleted,
        )
        build_scope_predicates(predicates, sql_parameters, scope_params, occurrence_alias="o")
        build_visibility_predicates(predicates, scope_params, incident_id_expression="i.[IncidentID]")
        build_incident_resolve_exclusion_by_scope_load(
            predicates,
            sql_parameters,
            params.schema,
            incident_id_expression="i.[IncidentID]",
            load_id=params.load_id,
            load_ids=params.load_ids,
        )

        if params.additional_where_sql:
            predicates.append(f"({params.additional_where_sql})")

        return "\n    AND ".join(predicates), sql_parameters
