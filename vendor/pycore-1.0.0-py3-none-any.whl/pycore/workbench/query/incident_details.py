from __future__ import annotations

import sqlalchemy as sa

from pycore.workbench.models import Incident, Occurrence


def build_incident_details_statement(
    incident_id: int,
    scenario_id: int,
    reporting_unit_id: int,
    load_id: int,
):
    statement = (
        sa.select(Incident.IncidentID, Incident.RuleId, Incident.BusinessRuleId, Occurrence.Fields)
        .join(Occurrence, Occurrence.IncidentID == Incident.IncidentID)
        .where(Incident.IncidentID == incident_id)
        .where(Incident.ScenarioId == scenario_id)
        .where(Occurrence.ScenarioId == scenario_id)
        .where(Occurrence.LoadId == load_id)
        .where(Occurrence.ReportingUnitId == reporting_unit_id)
    )
    return statement
