from __future__ import annotations

from collections import OrderedDict
from typing import Optional, Sequence

import sqlalchemy as sa
from sqlalchemy.sql import Select

from pycore.workbench.constants import (
    INCIDENT_DIMENSION_ALIASES,
    INCIDENT_COLUMN_WHITELIST,
    ORIGIN_FIELDS,
    ORIGIN_INCIDENTS,
    ORIGIN_RULES,
    SAFE_COLUMN_RE,
)
from pycore.workbench.contracts import ExtendedRuleModel, WorkbenchFilterMetadataRequest
from pycore.workbench.filters import RoutedFilters, RoutedSearchParameters
from pycore.workbench.models import Incident, Occurrence
from pycore.workbench.query.base import build_base_query


def normalize_filter_path(path: Optional[str], dimension: str) -> str:
    normalized_path = (path or "").strip()
    if not normalized_path or normalized_path.lower() == "parsedfields":
        return get_filter_net_path(dimension)

    if normalized_path.lower() == ORIGIN_INCIDENTS.lower():
        return ORIGIN_INCIDENTS
    if normalized_path.lower() == ORIGIN_RULES.lower():
        return ORIGIN_RULES
    return ORIGIN_FIELDS


def get_filter_net_path(dimension: str) -> str:
    normalized_dimension = dimension.lower()
    normalized_dimension = INCIDENT_DIMENSION_ALIASES.get(
        normalized_dimension,
        normalized_dimension,
    )
    if normalized_dimension in INCIDENT_COLUMN_WHITELIST:
        return ORIGIN_INCIDENTS
    return ORIGIN_FIELDS


def build_filter_metadata_statement(
    request: WorkbenchFilterMetadataRequest,
    routed_filters: Optional[RoutedFilters] = None,
    routed_search_parameters: Optional[RoutedSearchParameters] = None,
) -> Optional[Select]:
    normalized_path = normalize_filter_path(request.path, request.dimension)

    if normalized_path == ORIGIN_RULES:
        return None

    base_statement = build_base_query(
        request,
        routed_filters=routed_filters,
        routed_search_parameters=routed_search_parameters,
        include_user_filters=True,
    )

    if normalized_path == ORIGIN_INCIDENTS:
        column = _resolve_incident_column(request.dimension)
        search_expression = sa.cast(column, sa.String)
        statement = base_statement.with_only_columns(column.label("value")).distinct()
    else:
        if not SAFE_COLUMN_RE.fullmatch(request.dimension):
            raise ValueError(f"Invalid filter metadata dimension `{request.dimension}`.")
        expression = sa.func.json_value(Occurrence.Fields, f'$."{request.dimension}"')
        search_expression = sa.cast(expression, sa.String)
        statement = base_statement.with_only_columns(expression.label("value")).distinct()

    if request.search_term:
        statement = statement.where(search_expression.like(f"%{request.search_term}%"))

    statement = statement.order_by(sa.literal_column("value"))

    if request.skip > 0:
        statement = statement.offset(request.skip)

    if request.take > 0:
        statement = statement.limit(request.take)

    return statement


def extract_rule_distinct_values(
    dimension: str,
    rules: Sequence[ExtendedRuleModel],
) -> list[str]:
    normalized_dimension = dimension.lower()
    values: OrderedDict[str, None] = OrderedDict()

    for rule in rules:
        value = _get_rule_dimension_value(rule, normalized_dimension)
        if value is None:
            continue
        text_value = str(value)
        if text_value not in values:
            values[text_value] = None

    return list(values.keys())


def _resolve_incident_column(column_name: str):
    normalized = column_name.lower()
    normalized = INCIDENT_DIMENSION_ALIASES.get(normalized, normalized)
    if normalized not in INCIDENT_COLUMN_WHITELIST:
        raise ValueError(f"Invalid incident filter metadata dimension `{column_name}`.")

    for table_column in Incident.__table__.c:
        if table_column.name.lower() == normalized:
            return table_column

    raise ValueError(f"Unknown incident filter metadata column `{column_name}`.")


def _get_rule_dimension_value(
    rule: ExtendedRuleModel,
    normalized_dimension: str,
):
    for grouping_dimension in rule.grouping_dimension_query_models:
        if grouping_dimension.grouping_dimension.lower() == normalized_dimension:
            return grouping_dimension.value

    for field_name, value in rule.dict().items():
        if field_name.lower() == normalized_dimension:
            return value

    return None
