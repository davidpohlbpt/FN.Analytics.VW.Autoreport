from __future__ import annotations

import dataclasses
from typing import Optional, Sequence

import sqlalchemy as sa
from sqlalchemy.sql import Select

from pycore.workbench.constants import (
    DEFAULT_SLICE_TAKE,
    INCIDENT_COLUMN_WHITELIST,
    RULE_SEARCH_FIELDS,
    SAFE_COLUMN_RE,
)
from pycore.workbench.contracts import (
    WorkbenchSliceMeta,
    WorkbenchSliceRequest,
    WorkbenchSortingModel,
)
from pycore.workbench.filters import RoutedFilters, RoutedSearchParameters
from pycore.workbench.models import Incident, IncidentComment, Occurrence
from pycore.workbench.query.base import build_base_query


@dataclasses.dataclass(frozen=True)
class SliceStatementPlan:
    statement: Select
    skip: int
    take: int


def normalize_pagination(skip: int, take: int) -> tuple[int, int]:
    # `take` must always be positive so the query stays bounded: a non-positive
    # value (including the explicit 0 case) falls back to the default page size
    # instead of applying no LIMIT at all.
    normalized_skip = max(skip, 0)
    normalized_take = take if take > 0 else DEFAULT_SLICE_TAKE
    return normalized_skip, normalized_take


def build_slice_meta(skip: int, take: int, returned: int) -> WorkbenchSliceMeta:
    normalized_skip, normalized_take = normalize_pagination(skip, take)
    return WorkbenchSliceMeta(
        skip=normalized_skip,
        take=normalized_take,
        returned=max(returned, 0),
    )


def build_slice_statement(
    request: WorkbenchSliceRequest,
    routed_filters: Optional[RoutedFilters] = None,
    routed_search_parameters: Optional[RoutedSearchParameters] = None,
    included_rule_ids: Optional[Sequence[str]] = None,
    excluded_rule_ids: Optional[Sequence[str]] = None,
    extra_ordering: Sequence = (),
) -> SliceStatementPlan:
    skip, take = normalize_pagination(request.skip, request.take)
    base_statement = build_base_query(
        request,
        routed_filters=routed_filters,
        routed_search_parameters=routed_search_parameters,
        include_user_filters=True,
    )

    statement = base_statement.with_only_columns(
        Incident.IncidentID.label("incident_id"),
        Incident.BusinessRuleId.label("business_rule_id"),
        Incident.Status.label("status"),
        Incident.Created.label("created"),
        Incident.AssignedUser.label("assigned_user"),
        Occurrence.LoadId.label("load_id"),
        Occurrence.EntityId.label("entity_id"),
        Occurrence.ReportingUnitId.label("reporting_unit_id"),
        Occurrence.Fields.label("fields"),
        _has_comments_expression().label("has_comments"),
    )
    statement = _apply_rule_scope(
        statement,
        included_rule_ids=included_rule_ids,
        excluded_rule_ids=excluded_rule_ids,
    )
    statement = apply_sorting(statement, request.applied_sorting)

    for ordering in extra_ordering:
        statement = statement.order_by(ordering)

    statement = statement.offset(skip).limit(take)

    return SliceStatementPlan(statement=statement, skip=skip, take=take)


def _has_comments_expression():
    # T-SQL rejects a bare EXISTS in the SELECT list, so it has to be wrapped in CASE.
    comment_exists = (
        sa.select(sa.literal_column("1"))
        .select_from(IncidentComment)
        .where(
            IncidentComment.IncidentID == Incident.IncidentID,
            IncidentComment.ScenarioID == Incident.ScenarioId,
        )
        .correlate(Incident)
        .exists()
    )
    return sa.case((comment_exists, 1), else_=0)


def _apply_rule_scope(
    statement: Select,
    included_rule_ids: Optional[Sequence[str]],
    excluded_rule_ids: Optional[Sequence[str]],
) -> Select:
    if included_rule_ids:
        statement = statement.where(Incident.BusinessRuleId.in_(included_rule_ids))

    if excluded_rule_ids:
        statement = statement.where(Incident.BusinessRuleId.notin_(excluded_rule_ids))

    return statement


def apply_sorting(
    statement: Select,
    sorting: Optional[WorkbenchSortingModel],
) -> Select:
    if sorting is None or not sorting.active:
        return statement.order_by(Incident.IncidentID.asc())

    direction = (sorting.direction or "").lower().strip()
    sort_expression = resolve_sort_expression(sorting.active)

    if direction == "desc":
        return statement.order_by(sort_expression.desc())
    return statement.order_by(sort_expression.asc())


def resolve_sort_expression(column_name: str):
    normalized = column_name.lower()

    if normalized in RULE_SEARCH_FIELDS:
        return Incident.IncidentID

    if normalized in INCIDENT_COLUMN_WHITELIST:
        for table_column in Incident.__table__.c:
            if table_column.name.lower() == normalized:
                return table_column

    for table_column in Occurrence.__table__.c:
        if table_column.name.lower() == normalized:
            return table_column

    if not SAFE_COLUMN_RE.fullmatch(column_name):
        raise ValueError(f"Invalid sort column `{column_name}`.")

    return sa.func.json_value(Occurrence.Fields, f'$."{column_name}"')
