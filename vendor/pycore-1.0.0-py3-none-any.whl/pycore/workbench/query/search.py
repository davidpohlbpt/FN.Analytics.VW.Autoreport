from __future__ import annotations

import dataclasses
from typing import Any, Mapping, Optional, Sequence

from pycore.workbench.constants import DEFAULT_SEARCH_TAKE, DEFAULT_WORKBENCH_SCHEMA
from pycore.workbench.query.predicates import (
    OccurrenceScopeParams,
    build_incident_resolve_exclusion_by_occurrence_load,
    build_scope_predicates,
    build_visibility_predicates,
)


@dataclasses.dataclass(frozen=True)
class SearchSqlParams:
    scenario_id: int
    schema: str = DEFAULT_WORKBENCH_SCHEMA
    search_term: str = ""
    take: int = 100
    skip: int = 0
    load_id: Optional[int] = None
    load_ids: Optional[Sequence[int]] = None
    entity_id: Optional[int] = None
    entity_ids: Optional[Sequence[int]] = None
    reporting_unit_id: Optional[int] = None
    show_hidden: bool = False
    show_deleted: bool = False
    additional_where_sql: Optional[str] = None
    additional_parameters: Mapping[str, Any] = dataclasses.field(default_factory=dict)


class WorkbenchSearchSqlBuilder:
    def build_search_query(self, params: SearchSqlParams) -> tuple[str, dict[str, Any]]:
        predicates = ["o.[ScenarioId] = :scenario_id"]
        sql_parameters: dict[str, Any] = {
            "scenario_id": params.scenario_id,
            "search": params.search_term,
            **dict(params.additional_parameters),
        }

        scope_params = OccurrenceScopeParams(
            schema=params.schema,
            load_id=params.load_id,
            load_ids=params.load_ids,
            entity_id=params.entity_id,
            entity_ids=params.entity_ids,
            reporting_unit_id=params.reporting_unit_id,
            show_hidden=params.show_hidden,
            show_deleted=params.show_deleted,
        )
        build_scope_predicates(predicates, sql_parameters, scope_params, occurrence_alias="o")
        build_visibility_predicates(
            predicates, scope_params, incident_id_expression="o.[IncidentID]"
        )
        predicates.append(
            build_incident_resolve_exclusion_by_occurrence_load(
                params.schema, occurrence_alias="o"
            )
        )

        if params.additional_where_sql:
            predicates.append(f"({params.additional_where_sql})")

        where_sql = "\n    AND ".join(predicates)

        # SQL Server rejects TOP combined with OFFSET/FETCH in the same SELECT, so
        # pagination always uses OFFSET/FETCH (which requires the ORDER BY below),
        # bounding `take` even when a caller passes a non-positive value.
        sql_parameters["skip"] = max(params.skip, 0)
        sql_parameters["take"] = params.take if params.take > 0 else DEFAULT_SEARCH_TAKE

        query = f"""
SELECT DISTINCT
    'Fields' AS [Dimension],
    j.[key] AS [Name],
    CAST(j.[value] AS NVARCHAR(MAX)) AS [Value]
FROM [{params.schema}].[T_RESULT_Occurence] o
CROSS APPLY OPENJSON(o.[Fields]) j
WHERE {where_sql}
  AND EXISTS (
      SELECT value
      FROM STRING_SPLIT(:search, ';') search_term
      WHERE CAST(j.[value] AS NVARCHAR(MAX)) LIKE '%' + search_term.[value] + '%'
  )
ORDER BY [Name], [Value]
OFFSET :skip ROWS
FETCH NEXT :take ROWS ONLY
""".strip()

        return query, sql_parameters
