import sqlalchemy as sa
from sqlalchemy.orm import relationship

from pycore.resources.odbc import DeclarativeBase

WORKBENCH_SCHEMA = "dbo"
_workbench_schema_configured = False

INCIDENT_TABLE = "T_RESULT_Incident"
OCCURRENCE_TABLE = "T_RESULT_Occurence"
INCIDENT_RESOLVE_TABLE = "T_RESULT_Incident_Resolve"
INCIDENT_HIDE_USER_TABLE = "T_RESULT_Incident_HideUser"
INCIDENT_DELETE_TABLE = "T_RESULT_Incident_Delete"
INCIDENT_HISTORY_TABLE = "T_RESULT_IncidentHistory"
INCIDENT_COMMENT_TABLE = "T_RESULT_Incident_Comment"
INCIDENT_EVENT_TYPE_TABLE = "T_CONTROL_Incident_EventTypes"


def _schema_table_args() -> dict[str, str]:
    # The deployed tables carry triggers, and SQL Server rejects an `OUTPUT`
    # clause without `INTO` on such a target - so SQLAlchemy must not fetch
    # generated keys via implicit RETURNING.
    return {"schema": WORKBENCH_SCHEMA, "implicit_returning": False}


def configure_workbench_schema(schema: str) -> None:
    """Rebinds the workbench ORM models to `schema`.

    This mutates process-wide SQLAlchemy table metadata (`__table__.schema` on
    already-imported model classes), so it must be called exactly once during
    application startup, before any workbench query executes. Calling it again
    later (e.g. per-request or per-tenant) would race with queries already
    built against the previous schema.
    """
    global WORKBENCH_SCHEMA, _workbench_schema_configured

    if _workbench_schema_configured:
        raise RuntimeError(
            "configure_workbench_schema() must be called exactly once at startup; "
            f"the workbench schema is already configured as `{WORKBENCH_SCHEMA}`."
        )

    if not schema:
        raise ValueError("Workbench schema cannot be empty.")

    WORKBENCH_SCHEMA = schema
    for model_cls in (
        Incident,
        Occurrence,
        IncidentResolve,
        IncidentHideUser,
        IncidentDelete,
        IncidentHistory,
        IncidentComment,
        IncidentEventType,
    ):
        model_cls.__table__.schema = schema

    _workbench_schema_configured = True


class Incident(DeclarativeBase):
    __tablename__ = INCIDENT_TABLE
    __table_args__ = _schema_table_args()

    IncidentID = sa.Column(sa.Integer, primary_key=True)
    RuleId = sa.Column(sa.String(100), nullable=True)
    BusinessRuleId = sa.Column(sa.String(100), nullable=True)
    Identifier = sa.Column(sa.String, nullable=True)
    Loads = sa.Column(sa.String, nullable=True)
    LoadId = sa.Column(sa.Integer, nullable=True)
    ReportingUnitId = sa.Column(sa.Integer, nullable=True)
    Status = sa.Column(sa.String(50), nullable=True)
    Created = sa.Column(sa.DateTime, nullable=True)
    AssignedUser = sa.Column(sa.String(200), nullable=True)
    EntityId = sa.Column(sa.Integer, nullable=True)
    ScenarioId = sa.Column(sa.Integer, nullable=False)
    Fields = sa.Column(sa.String, nullable=True)

    occurrences = relationship("Occurrence", back_populates="incident")
    resolves = relationship("IncidentResolve", back_populates="incident")
    hides = relationship("IncidentHideUser", back_populates="incident")
    deletes = relationship("IncidentDelete", back_populates="incident")
    history_entries = relationship("IncidentHistory", back_populates="incident")
    comments = relationship("IncidentComment", back_populates="incident")


class Occurrence(DeclarativeBase):
    __tablename__ = OCCURRENCE_TABLE
    __table_args__ = _schema_table_args()

    OccurenceID = sa.Column(sa.Integer, primary_key=True)
    IncidentID = sa.Column(sa.Integer, sa.ForeignKey(Incident.IncidentID))
    RuleId = sa.Column(sa.String(100), nullable=True)
    BusinessRuleId = sa.Column(sa.String(100), nullable=True)
    LoadId = sa.Column(sa.Integer, nullable=True)
    ReportingUnitId = sa.Column(sa.Integer, nullable=True)
    Fields = sa.Column(sa.String, nullable=True)
    EntityId = sa.Column(sa.Integer, nullable=True)
    ScenarioId = sa.Column(sa.Integer, nullable=False)
    # These mirror real SQL Server computed columns (derived from `Fields`, not stored data) -
    # declaring them as Computed keeps `create_all()`-provisioned schemas (e.g. throwaway test
    # DBs) consistent with the production schema, instead of silently producing plain NULL
    # columns that shadow the JSON values these dimensions are meant to resolve to.
    PotentialGroup = sa.Column(
        sa.String,
        sa.Computed(
            "case when json_path_exists([Fields],'$.PotentialGroup')=(0) then 'TN_Group_Undefined' "
            "when isnull(json_value([Fields],'$.PotentialGroup'),'')='' then 'TN_Group_Empty' "
            "else json_value([Fields],'$.PotentialGroup') end"
        ),
    )
    CustomerNumber = sa.Column(
        sa.String,
        sa.Computed(
            "case when json_path_exists([Fields],'$.CustomerNumber')=(0) then 'TN_Group_Undefined' "
            "when isnull(json_value([Fields],'$.CustomerNumber'),'')='' then 'TN_Group_Empty' "
            "else json_value([Fields],'$.CustomerNumber') end"
        ),
    )

    incident = relationship("Incident", back_populates="occurrences")


class IncidentResolve(DeclarativeBase):
    __tablename__ = INCIDENT_RESOLVE_TABLE
    __table_args__ = _schema_table_args()

    Id = sa.Column(sa.Integer, primary_key=True, autoincrement=True)
    IncidentID = sa.Column(sa.Integer, sa.ForeignKey(Incident.IncidentID))
    ScenarioID = sa.Column(sa.Integer, nullable=False)
    LoadId = sa.Column(sa.Integer, nullable=False)
    UserId = sa.Column(sa.String(250), nullable=True)
    CreatedBy = sa.Column(sa.String, nullable=True)
    CreatedOn = sa.Column(sa.DateTime, nullable=True)

    incident = relationship("Incident", back_populates="resolves")


class IncidentHideUser(DeclarativeBase):
    __tablename__ = INCIDENT_HIDE_USER_TABLE
    __table_args__ = _schema_table_args()

    Id = sa.Column(sa.Integer, primary_key=True, autoincrement=True)
    IncidentID = sa.Column(sa.Integer, sa.ForeignKey(Incident.IncidentID))
    ScenarioID = sa.Column(sa.Integer, nullable=False)
    UserId = sa.Column(sa.String(50), nullable=True)
    HideUntil = sa.Column(sa.DateTime, nullable=True)
    Email = sa.Column(sa.String(256), nullable=True)
    CreatedBy = sa.Column(sa.String, nullable=True)
    CreatedOn = sa.Column(sa.DateTime, nullable=True)
    LoadId = sa.Column(sa.Integer, nullable=True)

    incident = relationship("Incident", back_populates="hides")


class IncidentDelete(DeclarativeBase):
    __tablename__ = INCIDENT_DELETE_TABLE
    __table_args__ = _schema_table_args()

    # The table has no surrogate key - (IncidentID, ScenarioID) is the natural key.
    IncidentID = sa.Column(sa.Integer, sa.ForeignKey(Incident.IncidentID), primary_key=True)
    ScenarioID = sa.Column(sa.Integer, primary_key=True)
    CreatedOn = sa.Column(sa.DateTime, nullable=True)
    UserId = sa.Column(sa.String(50), nullable=False)

    incident = relationship("Incident", back_populates="deletes")


class IncidentEventType(DeclarativeBase):
    __tablename__ = INCIDENT_EVENT_TYPE_TABLE
    __table_args__ = _schema_table_args()

    EventTypeID = sa.Column(sa.Integer, primary_key=True)
    EventName = sa.Column(sa.String(50), nullable=True)
    TranslationKey = sa.Column(sa.String(200), nullable=True)

    history_entries = relationship("IncidentHistory", back_populates="event_type")


class IncidentHistory(DeclarativeBase):
    __tablename__ = INCIDENT_HISTORY_TABLE
    __table_args__ = _schema_table_args()

    IncidentHistoryID = sa.Column(sa.Integer, primary_key=True)
    IncidentID = sa.Column(sa.Integer, sa.ForeignKey(Incident.IncidentID))
    ScenarioID = sa.Column(sa.Integer, nullable=False)
    EventTypeID = sa.Column(sa.Integer, sa.ForeignKey(IncidentEventType.EventTypeID))
    DateTime = sa.Column(sa.DateTime, nullable=True)
    UserId = sa.Column(sa.String(450), nullable=True)
    LoadID = sa.Column(sa.Integer, nullable=True)
    RuleID = sa.Column(sa.String(100), nullable=True)
    Comment = sa.Column(sa.String, nullable=True)
    HideUntil = sa.Column(sa.DateTime, nullable=True)
    Values = sa.Column(sa.String, nullable=True)

    incident = relationship("Incident", back_populates="history_entries")
    event_type = relationship("IncidentEventType", back_populates="history_entries")


class IncidentComment(DeclarativeBase):
    __tablename__ = INCIDENT_COMMENT_TABLE
    __table_args__ = _schema_table_args()

    Id = sa.Column(sa.Integer, primary_key=True)
    IncidentID = sa.Column(sa.Integer, sa.ForeignKey(Incident.IncidentID))
    ScenarioID = sa.Column(sa.Integer, nullable=False)
    UserId = sa.Column(sa.String(450), nullable=True)
    Date = sa.Column(sa.DateTime, nullable=True)
    LoadId = sa.Column(sa.Integer, nullable=True)
    Comment = sa.Column(sa.String, nullable=True)
    CreatedBy = sa.Column(sa.String, nullable=True)
    CreatedOn = sa.Column(sa.DateTime, nullable=True)

    incident = relationship("Incident", back_populates="comments")