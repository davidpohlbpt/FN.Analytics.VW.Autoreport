import json
from typing import Any, Optional, Union

import pydantic

from pycore.schemas import FilterOperator
from pycore.utils.pydantic import CamelModel

from pycore.workbench.constants import GROUP_PREFIX


class WorkbenchGroupingModel(CamelModel):
    dimension: Optional[str] = None
    origin: Optional[str] = None
    value: Optional[str] = None


class WorkbenchSearchParam(CamelModel):
    field_name: str
    value: str


class WorkbenchSortingModel(CamelModel):
    active: Optional[str] = None
    direction: Optional[str] = None
    data_type: Optional[str] = None


class WorkbenchFilterItem(CamelModel):
    type: FilterOperator
    name: str
    value: Optional[Any] = None
    value2: Optional[Any] = None
    path: Optional[str] = None
    net_path: Optional[str] = None

    @pydantic.field_validator("value", mode="after")
    @classmethod
    def parse_multiselect_value(
        cls, value: Any, info: pydantic.ValidationInfo
    ) -> Any:
        if info.data.get("type") != FilterOperator.multiselect:
            return value

        if isinstance(value, str):
            payload = json.loads(value)
            if isinstance(payload, list) and payload and isinstance(payload[0], dict):
                return [str(item.get("name", "")) for item in payload]
            return payload
        return value


class WorkbenchTagProperty(CamelModel):
    name: str
    color: str
    translation_key: str


class WorkbenchTagInfo(CamelModel):
    name: str
    color: str
    translation_key: str


class WorkbenchGroupInfo(CamelModel):
    group_id: str
    description: Optional[str] = None
    tag_properties_id: Optional[int] = None


class WorkbenchDefaultFilter(CamelModel):
    filter_type: str
    filter_field: str
    filter_source: Optional[str] = None
    default_value: Any

    @pydantic.model_validator(mode="before")
    @classmethod
    def map_legacy_value_alias(cls, values: Any) -> Any:
        if not isinstance(values, dict) or "defaultValue" in values or "default_value" in values:
            return values

        lowered_keys = {str(key).lower(): key for key in values}
        actual_key = lowered_keys.get("value")
        if actual_key is not None:
            values = {**values, "defaultValue": values[actual_key]}
        return values


class ScenarioIdAliasMixin:
    @pydantic.model_validator(mode="before")
    @classmethod
    def map_legacy_scenario_alias(cls, values: Any) -> Any:
        if not isinstance(values, dict):
            return values

        lowered_keys = {str(key).lower(): key for key in values}

        # Legacy frontend/request variants for scenario id are not derivable from
        # the generated alias (`scenarioId`), so map them explicitly first.
        if "scenario_id" not in values:
            for candidate in ("scenarioid", "scenid", "scen_id"):
                actual_key = lowered_keys.get(candidate)
                if actual_key is not None:
                    values["scenario_id"] = values[actual_key]
                    break

        for field_name, field_info in cls.model_fields.items():
            if field_name in values:
                continue

            alias = field_info.alias or field_name
            actual_key = lowered_keys.get(str(alias).lower())
            if actual_key is not None:
                values[field_name] = values[actual_key]
        return values


class WorkbenchRequestBase(CamelModel, ScenarioIdAliasMixin):
    menu_item_id: int
    scenario_id: int
    entity_id: Optional[int] = None
    entity_ids: Optional[list[int]] = None
    load_id: Optional[int] = None
    load_ids: Optional[list[int]] = None
    reporting_unit_id: Optional[int] = None
    dimension_value_id: Optional[int] = None
    has_scoping: bool = False
    show_hidden: bool = False
    show_deleted: bool = False
    filters: Optional[Union[str, list[WorkbenchFilterItem]]] = None
    search_parameters: Optional[list[WorkbenchSearchParam]] = None
    grouping: Optional[WorkbenchGroupingModel] = None
    grouping_dimension: Optional[str] = None
    grouping_dimension_origin: Optional[str] = None
    is_computed_column: bool = False
    computed_occurrence_columns: list[str] = pydantic.Field(default_factory=list)
    translation_key_extension: Optional[str] = None
    cannot_see_group_tag: bool = False
    workbench_group_information: Optional[list[WorkbenchGroupInfo]] = None
    workbench_tag_properties: Optional[dict[int, WorkbenchTagProperty]] = None
    workbench_default_filters: Optional[list[WorkbenchDefaultFilter]] = None
    user_language: Optional[str] = None


class WorkbenchGroupsRequest(WorkbenchRequestBase):
    pass


class WorkbenchCountRequest(WorkbenchRequestBase):
    pass


class WorkbenchSliceRequest(WorkbenchRequestBase):
    take: int = 10
    skip: int = 0
    applied_sorting: Optional[WorkbenchSortingModel] = None


class WorkbenchParameter(CamelModel):
    name: str
    value: str


class WorkbenchExtendedViewRequest(WorkbenchSliceRequest):
    configuration_parameters: Optional[list[WorkbenchParameter]] = None


class WorkbenchSearchRequest(WorkbenchRequestBase):
    search_term: Optional[str] = None
    dimension: Optional[str] = None
    path: Optional[str] = None
    selected_values: Optional[list[str]] = None
    take: int = 100
    skip: int = 0

    @pydantic.model_validator(mode="before")
    @classmethod
    def map_legacy_search_value_alias(cls, values: Any) -> Any:
        if not isinstance(values, dict):
            return values

        if "search_term" in values or "searchTerm" in values:
            return values

        lowered_keys = {str(key).lower(): key for key in values}
        actual_key = lowered_keys.get("searchvalue")
        if actual_key is not None:
            values["search_term"] = values[actual_key]

        return values


class WorkbenchFilterMetadataRequest(WorkbenchRequestBase):
    dimension: str
    path: Optional[str] = None
    search_term: Optional[str] = None
    selected_values: Optional[list[str]] = None
    take: int = 100
    skip: int = 0


class WorkbenchFilterConfigurationRequest(WorkbenchRequestBase):
    pass


class WorkbenchDimensionGroup(CamelModel):
    title: str
    count: int
    records: int = 0
    prefix: str = GROUP_PREFIX
    description: Optional[str] = None
    extra: Optional[str] = None
    summary: Optional[str] = None
    dynamic_group_description: Optional[str] = ""
    tag: Optional[WorkbenchTagProperty] = None


class WorkbenchErrorDetail(CamelModel):
    code: str
    message: str


class WorkbenchErrorResponse(CamelModel):
    error: WorkbenchErrorDetail


class WorkbenchGroupsResponse(CamelModel):
    groups: list[WorkbenchDimensionGroup]


class WorkbenchGroupsApiResponse(CamelModel):
    result: WorkbenchGroupsResponse


class WorkbenchCountResponse(CamelModel):
    total_count: int
    filtered_count: int


class WorkbenchCountApiResponse(CamelModel):
    result: WorkbenchCountResponse


class WorkbenchIncidentModel(CamelModel):
    incident_id: int
    business_rule_id: Optional[str] = None
    status: Optional[str] = None
    age: Optional[int] = None
    incident_assigned_user: Optional[str] = None
    has_comments: bool = False
    is_hidden: Optional[bool] = None
    load_id: Optional[int] = None
    entity_id: Optional[int] = None
    reporting_unit_id: Optional[int] = None
    score_value: Optional[float] = None
    criticality_label: Optional[str] = None
    business_rule: Optional[str] = None
    dynamic_description: Optional[str] = None
    tag_info: Optional[WorkbenchTagInfo] = None


class WorkbenchSliceMeta(CamelModel):
    skip: int
    take: int
    returned: int


class WorkbenchSliceResponse(CamelModel):
    data: list[WorkbenchIncidentModel]
    count: int
    meta: WorkbenchSliceMeta


class WorkbenchSliceApiResponse(CamelModel):
    result: WorkbenchSliceResponse


class GroupingDimensionModel(CamelModel):
    id: int
    grouping_dimension: str
    value: str


class WorkbenchExtendedViewIncidentModel(CamelModel):
    incident_id: int
    business_rule_id: Optional[str] = None
    age: Optional[int] = None
    load_id: Optional[int] = None
    entity_id: Optional[int] = None
    reporting_unit_id: Optional[int] = None
    grouping_dimension_query_models: list[GroupingDimensionModel] = pydantic.Field(
        default_factory=list
    )
    fields: dict[str, str] = pydantic.Field(default_factory=dict)


class WorkbenchExtendedViewResponse(CamelModel):
    data: list[WorkbenchExtendedViewIncidentModel]
    count: int


class WorkbenchExtendedViewApiResponse(CamelModel):
    result: WorkbenchExtendedViewResponse


class RuleParameterModel(CamelModel):
    name: str = ""
    value: str = ""


class RuleEntitySpecificInformationModel(CamelModel):
    rule_parameter_query_models: list[RuleParameterModel] = pydantic.Field(
        default_factory=list
    )


class ExtendedRuleModel(CamelModel):
    id: str
    business_rule_id: str
    criticality: Optional[str] = None
    risk: Optional[str] = None
    help_text: Optional[str] = None
    scoping: Optional[str] = None
    deleted: bool = False
    assigned_user: Optional[str] = None
    business_rule: Optional[str] = None
    description: Optional[str] = None
    dynamic_description: Optional[str] = None
    applicable: bool = True
    grouping_dimension_query_models: list[GroupingDimensionModel] = pydantic.Field(
        default_factory=list
    )
    rule_entity_specific_information_query_models: list[RuleEntitySpecificInformationModel] = pydantic.Field(
        default_factory=list
    )


class DimensionWithValueModel(CamelModel):
    dimension_value_id: int
    dimension_name: str
    dimension_source: str
    dimension_value: str
    dimension_display_value: Optional[str] = None


class FnUserModel(CamelModel):
    """Subset of Identity's `FnUserQueryModel` used to resolve incident actors."""

    id: Optional[str] = None
    user_name: Optional[str] = None
    email: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    language_key: Optional[str] = None


class MenuItemModel(CamelModel):
    """Subset of Identity's `MenuItemQueryModel` used to build deep links."""

    menu_item_id: Optional[int] = pydantic.Field(default=None, alias="menuItemID")
    name: Optional[str] = None
    url: Optional[str] = pydantic.Field(default=None, alias="url")
    is_generic: bool = False

    @pydantic.model_validator(mode="before")
    @classmethod
    def map_case_insensitive_aliases(cls, values: Any) -> Any:
        # Identity serializes these as `menuItemID` and `uRL`; match them loosely.
        if not isinstance(values, dict):
            return values

        lowered = {str(key).lower(): value for key, value in values.items()}
        for field_name, alias in (("menu_item_id", "menuitemid"), ("url", "url")):
            if field_name not in values and alias in lowered:
                values[field_name] = lowered[alias]
        return values


class WorkbenchSearchResultItem(CamelModel):
    dimension: str
    column_name: str
    name: str
    value: str


class WorkbenchSearchResponse(CamelModel):
    values: list[WorkbenchSearchResultItem]


class WorkbenchSearchApiResponse(CamelModel):
    result: list[WorkbenchSearchResultItem]


class WorkbenchFilterMetadataResponse(CamelModel):
    values: list[str]


class WorkbenchFilterMetadataApiResponse(CamelModel):
    result: list[str]


class FilterConfigurationModel(CamelModel):
    name: str
    label: str
    dimension: str
    type: str
    path: str


class FilterOperatorOption(CamelModel):
    name: str
    value: str


class FilterOperatorsModel(CamelModel):
    type: str
    operators: list[FilterOperatorOption]


class WorkbenchFilterConfigurationResponse(CamelModel):
    filters: list[FilterConfigurationModel]
    operators: list[FilterOperatorsModel]


class WorkbenchFilterConfigurationApiResponse(CamelModel):
    result: WorkbenchFilterConfigurationResponse


class WorkbenchSmartlistCountModel(CamelModel):
    filter_set: Optional[str] = None
    scenario_id: Optional[int] = pydantic.Field(default=None, alias="scenID")
    item_count: int = 0
    user_subscribed: bool = False
    smartlist_group_id: Optional[int] = pydantic.Field(default=None, alias="smartlistGroupID")
    menu_item_id: int = pydantic.Field(alias="menuItemID")
    reporting_unit_id: Optional[int] = pydantic.Field(default=None, alias="reportingUnitID")
    dimension_value_id: Optional[int] = None
    disabled: Optional[bool] = None
    smartlist_id: int = pydantic.Field(alias="smartlistID")
    smartlist_name: Optional[str] = None
    description: Optional[str] = None


class WorkbenchSmartlistCountRequest(WorkbenchRequestBase):
    smartlists: list[WorkbenchSmartlistCountModel] = pydantic.Field(default_factory=list)
    incident_status_filter_for_subscription_email: Optional[str] = None


class WorkbenchSmartlistCountApiResponse(CamelModel):
    result: list[WorkbenchSmartlistCountModel]


class WorkbenchIncidentDetailsRequest(CamelModel, ScenarioIdAliasMixin):
    incident_id: int
    workbench_id: int
    menu_item_id: int
    scenario_id: int
    entity_id: int
    reporting_unit_id: int
    load_id: int
    user_default_reporting_unit_id: int
    permissions: dict[str, str] = pydantic.Field(default_factory=dict)
    user_language: Optional[str] = None


class WorkbenchIncidentDetailsApiResponse(CamelModel):
    result: dict[str, str]