import logging
import os
import sys

import dotenv
import pydantic
from pydantic_settings import BaseSettings

from pycore.enum import EnvironmentType, ResourceType

# Read settings from environment variable files
# Earlier file take precedence over later ones
_DOTENV_FILES = [".env", ".env.pipeline", ".env.global"]
for f in _DOTENV_FILES:
    if os.path.exists(f):
        dotenv.load_dotenv(f, override=False)
    elif f == ".env":
        # .env is a mandatory file
        logging.warning("No '.env' file found.")
    else:
        pass  # other files are not mandatory


class TechnicalSettings(BaseSettings):
    # ---------------------------------- Basics ---------------------------------- #

    app_name: str
    """Name of the web application. Mainly used for display and logging.
    """

    scenario_id: int | None = None
    """Scenario ID to distinguish this service's data from other results.
    """

    environment: EnvironmentType | None = None
    """Indicates whether the code is run locally or deployed.
    Is dynamically determined based on the other settings.
    """

    resource_type: ResourceType = ResourceType.MEMORY
    """Determines which type of 'easy' resources are used for data access. 
    """

    build_tag: str = "untagged"
    """Git tag of the build that is currently deployed.
    """

    commit_hash: str = "n/a"
    """Git commit hash of the build that is currently deployed.
    """

    # --------------------------------- Database --------------------------------- #

    app_db_name: str | None = None
    """Name of the database that the default 'easy' database resource connects to.
    """

    # -------------------------------- Web service ------------------------------- #

    ext_base_url: str | None = pydantic.Field(
        default=None, validation_alias="EndpointBasePath"
    )
    """Base url of the environment to be used when
    the application is outside the cluster (e.g. local)
    """


    @pydantic.field_validator("ext_base_url", mode="before")
    @classmethod
    def _strip_ext_base_url_trailing_slash(cls, value):
        if isinstance(value, str):
            return value.rstrip("/") or value
        return value

    root_path: str = pydantic.Field("", validation_alias="ROOT_PATH")
    """Root path set by the reverse proxy (e.g. /yourservice).
    """

    sf_node_ip: str | None = pydantic.Field(
        None, validation_alias="Fabric_NodeIPOrFQDN"
    )
    """Internal IP address under which the other services can be reached.
    Only used to determine the environment type.
    """

    kubernetes_port: str | None = pydantic.Field(
        None, validation_alias="KUBERNETES_PORT"
    )
    """Kubernetes port under which the other services can be reached.
    Only used to determine the environment type.
    """

    elastic_index_name: str = "pyfactorynavigator"
    """Name under which the logs are displayed in Elastic.
    """

    e2e_test: bool = False
    """Indicates whether the code is run in an end-to-end test.
    """

    offline_mode: bool = False
    """Indicates whether the application runs in offline mode.
    When True, Swagger UI is served from local static assets instead of the CDN.
    """

    # ---------------------------------- Airflow --------------------------------- #

    runs_in_airflow: int | None = pydantic.Field(
        None, validation_alias="RUNS_IN_AIRFLOW"
    )

    @staticmethod
    def _has_setting(values: dict, field_name: str, alias: str) -> bool:
        return values.get(field_name) is not None or values.get(alias) is not None

    @pydantic.model_validator(mode="before")
    @classmethod
    def determine_environment(cls, values):
        """Dynamically determines the environment the code is currently running in and sets the configuration environment accordingly.

        This mechanism cannot be manually overriden, except by setting the respective environment variables 'SF_NODE_IP' or 'KUBERNETES_PORT'.

        - If the environment variable 'SF_NODE_IP' is not null, the code is running in an Azure Service Fabric cluster.
        - If the environment variable 'KUBERNETES_PORT' is not null, the code is running in a K8 cluster.
        - Else, the code is running on a local machine.
        """
        if cls._has_setting(values, "sf_node_ip", "Fabric_NodeIPOrFQDN"):
            values["environment"] = EnvironmentType.SERVICE_FABRIC
        elif cls._has_setting(values, "runs_in_airflow", "RUNS_IN_AIRFLOW"):
            # The app runs in Airflow's Kubernetes cluster.
            values["environment"] = EnvironmentType.LOCAL
        elif cls._has_setting(values, "kubernetes_port", "KUBERNETES_PORT"):
            # The app run's as web service in our Kubernetes cluster.
            values["environment"] = EnvironmentType.KUBERNETES
        else:
            values["environment"] = EnvironmentType.LOCAL
        return values

    @property
    def debug(self) -> bool:
        """Indicates whether the code is running in debug mode.

        The code is assumed to run in debug mode if run locally.
        Deployed code can never be run in debug mode.

        Returns:
            bool: True if code runs locally, False else.
        """
        return self.environment == EnvironmentType.LOCAL

    @property
    def base_url(self) -> str:
        """Returns the base url of this and other services in the deployment environment.

        Returns:
            str: base url
        """
        if self.environment == EnvironmentType.SERVICE_FABRIC:
            # App is running in a service fabric cluster
            # Other service can be reached without leaving the cluster
            return "http://" + self.sf_node_ip + ":19081/FactoryNavigator"
        elif self.environment == EnvironmentType.KUBERNETES:
            return "http://"
        else:
            # App is running outside of service fabric cluster
            # Other services can be reached through the admin API gateway
            return self.ext_base_url


try:
    settings = TechnicalSettings()
except pydantic.ValidationError as exc:
    missing = ", ".join(["'" + e["loc"][0] + "'" for e in exc.errors()])
    logging.critical(
        f"The settings could not be loaded because the following were missing: {missing}"
    )
    logging.critical("Start-up is terminated.")
    sys.exit(1)
else:
    vals = [
        ("app_name", settings.app_name),
        ("env", settings.environment.value),
        ("resources", settings.resource_type.value),
        ("base_url", settings.base_url),
    ]
    vals = " / ".join([f"{k}={v}" for k, v in vals])
    logging.warning(f"Loaded settings with the following parameters: {vals}")
