"""This module contains configurations and diagnostics without which PyCore should not be used.

The code in this module is executed first whenever something is imported from `pycore`.
"""

import logging

import pycore.logs
from pycore import utils

# ---------------------------------------------------------------------------- #
#                                 Repositories                                 #
# ---------------------------------------------------------------------------- #
from pycore.repository.crud import CRUDRepository
from pycore.repository.data import DataRepository
from pycore.repository.hooks import HookRepository, HookType
from pycore.repository.services.base import PREFIXES, Service, ServiceType
from pycore.repository.services.batch import BatchRepository
from pycore.repository.services.masterdata import MasterDataRepository
from pycore.repository.services.monitoring import MonitoringRepository
from pycore.repository.services.rdp import ReportDataProviderRepository
from pycore.repository.services.rules_mgmt import RulesMgmtRepository
from pycore.repository.services.tracker import (
    TrackerRepository,
    tracker_service_execution,
)
from pycore.repository.services.identity import IdentityRepository
from pycore.repository.services.translation import TranslationRepository

# ---------------------------------------------------------------------------- #
#                                   Resources                                  #
# ---------------------------------------------------------------------------- #
from pycore.resources.abc import (
    BlobStorage,
    HttpSession,
    Resource,
    ResourceState,
    Secret,
    SecretValue,
    Vault,
)
from pycore.resources.env import EnvVault
from pycore.resources.file import FileStorage, TempFileStorage
from pycore.resources.http import AdminHttpSession, NoAuthHttpSession, UserHttpSession
from pycore.resources.odbc import (
    DeclarativeBase,
    OdbcDatabase,
    SqliteDatabase,
    SqlServerDatabase,
)

logging.basicConfig(level=logging.INFO, format=pycore.logs.LOG_FORMAT)
