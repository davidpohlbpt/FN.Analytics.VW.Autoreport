import enum
import logging
from functools import wraps

from pycore import MonitoringRepository
from pycore.schemas import LogData, LogMessage


def delay_to_first_completion(func):
    # Small state-aware wrapper to prevent recursive loops when logging to the Monitoring service fails
    # This way, all messages are logged, even if HTTP logging fails

    backlog = []

    class State(enum.Enum):
        INACTIVE = -1
        STARTING = 0
        ACTIVE = 1
        FAILED = 2

    @wraps(func)
    def with_delay(obj, *args, **kwargs):
        if not hasattr(obj, "__state"):
            setattr(obj, "__state", State.INACTIVE)

        if obj.__state == State.FAILED:
            return

        if obj.__state == State.STARTING:
            backlog.append((args, kwargs))
            return
        elif obj.__state == State.INACTIVE:
            obj.__state = State.STARTING

        result = func(obj, *args, **kwargs)

        if result is False:
            obj.__state = State.FAILED
        elif obj.__state == State.STARTING:
            obj.__state = State.ACTIVE
            for args, kwargs in backlog:
                func(obj, *args, **kwargs)

        return result

    return with_delay


class HttpServiceHandler(logging.StreamHandler):
    """StreamHandler to send records to the monitoring service if a valid token is passed."""

    def __init__(self, monitoring_repo: MonitoringRepository, service_name: str):
        super().__init__()
        self.service_name = service_name
        self.monitoring_repo = monitoring_repo

    @staticmethod
    def extract_extra(record: logging.LogRecord) -> dict:
        # Get info that was added by the caller
        log_record = logging.makeLogRecord({"message": "", "asctime": ""})
        extra_keys = record.__dict__.keys() - log_record.__dict__.keys()

        # Build
        extra = {}
        for key in extra_keys:
            extra[key] = record.__dict__[key]
        return extra

    @delay_to_first_completion
    def emit(self, record):
        extra = HttpServiceHandler.extract_extra(record)

        module = f"{record.filename}:{record.lineno}/{record.funcName}"
        entity_id = extra.pop("entity_id", None)
        task_id = extra.pop("task_id", None)
        load_id = extra.pop("load_id", None)
        scen_id = extra.pop("scenario_id", None) or extra.pop("scen_id", None)
        uuid = record.uuid if hasattr(record, "uuid") else None

        values_array = LogData(
            module=module,
            entity_id=entity_id,
            load_id=load_id,
            scenario_id=scen_id,
            uuid=uuid,
            data=extra,
        )

        if task_id is not None:
            values_array.task_id = task_id

        message = LogMessage(
            log_level=record.levelno,
            service=self.service_name,
            message=record.message,
            values_array=values_array,
        )

        return self.monitoring_repo.log_message(message=message)
