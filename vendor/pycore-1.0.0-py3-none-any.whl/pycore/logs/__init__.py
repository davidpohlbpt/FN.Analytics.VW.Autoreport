import contextvars
import logging
import uuid

LOG_FORMAT = (
    "%(asctime)s | %(levelname)-8s | %(message)s [%(filename)s:%(lineno)d/%(funcName)s]"
)


uuid_context = contextvars.ContextVar("uuid")
uuid_context.set(uuid.uuid4())  # constant for local executions

old = logging.getLogRecordFactory()


def new(*args, **kwargs):
    r = old(*args, **kwargs)
    r.uuid = uuid_context.get(None)
    return r


logging.setLogRecordFactory(new)


logging.basicConfig(
    format=LOG_FORMAT,
    level=logging.INFO,
)


def enable_remote_loggers(service_name: str, monitoring_repo=None):
    from pycore.logs.http_handler import HttpServiceHandler

    logger = logging.getLogger()
    if monitoring_repo is not None:
        logging.info("Sending logs to the MonitoringService.")
        http_hdlr = HttpServiceHandler(
            monitoring_repo=monitoring_repo, service_name=service_name
        )
        http_hdlr.setLevel(logging.WARNING)
        logger.addHandler(hdlr=http_hdlr)
        logging.info("Sending logs to the MonitoringService.")
