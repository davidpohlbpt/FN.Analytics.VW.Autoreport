import logging

from pycore.config import settings
from pycore.enum import EnvironmentType, ResourceType, ServiceType
from pycore.repository.data import DataRepository
from pycore.repository.hooks import HookRepository
from pycore.repository.services.batch import BatchRepository
from pycore.repository.services.email import EmailRepository
from pycore.repository.services.identity import IdentityRepository
from pycore.repository.services.masterdata import MasterDataRepository
from pycore.repository.services.monitoring import MonitoringRepository
from pycore.repository.services.rdp import ReportDataProviderRepository
from pycore.repository.services.rules_mgmt import RulesMgmtRepository
from pycore.repository.services.tracker import TrackerRepository
from pycore.repository.services.translation import TranslationRepository
from pycore.resources.azure import load_azure_resources
from pycore.resources.env import EnvVault
from pycore.resources.file import TempFileStorage
from pycore.resources.http import AdminHttpSession, NoAuthHttpSession
from pycore.resources.local import load_local_resources
from pycore.resources.odbc import DeclarativeBase, SqliteDatabase
from pycore.resources.openai import load_openai_session

# Caution: global state!
#
# This provides the PyCore users with ready-to-use resources / repositories.
# For testing, the underlying resources are mocked / exchanged with in-memory resources.
# (except for the OpenAI session, which is not mocked)
#
# Reference: https://python-patterns.guide/python/module-globals/
#
if settings.resource_type == ResourceType.AZURE:
    database, vault, storage, rdp_db, md_db, batch_api_db = load_azure_resources(
        base=DeclarativeBase
    )
    openai = load_openai_session(vault=vault)
elif settings.resource_type == ResourceType.LOCAL:
    database, vault, storage, rdp_db, md_db, batch_api_db = load_local_resources(
        base=DeclarativeBase
    )
    openai = load_openai_session(vault=vault)
elif settings.resource_type == ResourceType.MEMORY:
    database = SqliteDatabase(base=DeclarativeBase, shell=True)
    rdp_db = SqliteDatabase(shell=True)
    md_db = SqliteDatabase(shell=True)
    batch_api_db = SqliteDatabase(shell=True)
    vault = EnvVault(shell=True)
    storage = TempFileStorage(shell=True)
    openai = None
else:
    raise NotImplementedError(
        f"Resource type '{settings.resource_type.value}' is not supported yet."
    )

if settings.environment == EnvironmentType.LOCAL:
    # Go through admin API gateway
    _http_secret = vault.get_secret("IdentityClientAdmin")
    http_session = AdminHttpSession(
        base_url=settings.base_url,
        http_secret=_http_secret,
        shell=True,
    )
else:
    # Stay locally or inside the Service Fabric / Kubernetes cluster
    http_session = NoAuthHttpSession(base_url=settings.base_url, shell=True)

data_repo = DataRepository(database=database)
rdp_repo = ReportDataProviderRepository(database=rdp_db)
md_repo = MasterDataRepository(database=md_db)
tracker = TrackerRepository(http_session=http_session, env=settings.environment)
monitoring_service = MonitoringRepository(
    http_session=http_session, env=settings.environment
)
batch_service = BatchRepository(
    database=batch_api_db, http_session=http_session, env=settings.environment
)
rules_mgmt = RulesMgmtRepository(http_session=http_session, env=settings.environment)
translation = TranslationRepository(http_session=http_session, env=settings.environment)
identity = IdentityRepository(http_session=http_session, env=settings.environment)
email = EmailRepository(http_session=http_session, vault=vault, env=settings.environment)
hook_repo = HookRepository()
services = {
    ServiceType.TRACKER: tracker,
    ServiceType.MONITORING: monitoring_service,
    ServiceType.BATCH: batch_service,
    ServiceType.RULES_MGMT: rules_mgmt,
    ServiceType.TRANSLATION: translation,
    ServiceType.IDENTITY: identity,
}
logging.warning(
    f"Initialized access to easy resources of type {settings.resource_type.value}."
)
