import logging
import pathlib

import alembic
import alembic.config
import typer

from pycore import easy
from pycore.config import settings
from pycore.logs import enable_remote_loggers
from pycore.setup.utils import has_all_alembic_files

app = typer.Typer(name=settings.app_name)

SkipDbOption = typer.Option(default=False, help="Skip confirmation of DB connection.")


def assert_alembic_config():
    """Assert that alembic is configured correctly, i.e., all necessary files are present."""
    if not has_all_alembic_files():
        logging.error(
            "alembic is not configured correctly. Run 'pycore init' to setup alembic."
        )
        raise typer.Exit(code=1)


@app.command()
def run(
    host: str = typer.Option(
        default="127.0.0.1", help="IP at which the service is reachable."
    ),
    port: int = typer.Option(
        default=5000, help="Port at which the service is reachable."
    ),
):
    """Run as web service.

    This command starts a FastAPI-based web service. The service is reachable at http://<host>:<port>.

    Args:
        host (str, optional): IP at which the service is reachable. Defaults to "127.0.0.1"
        port (int, optional): Port at which the service is reachable. Defaults to 5000.
    """
    from pycore.api.web.app import run_app

    run_app(host=host, port=port)


@app.command()
def init():
    """Initialize a new PyCore-based project."""
    from pycore.setup.utils import create_files

    create_files()


@app.command()
def log_as_running(
    message: str,
    remote: str = typer.Option(
        default=True,
        help="Log to remote logging destinations (MonitoringService, ELK, ...).",
    ),
):
    """Log that the service is running.

    Args:
        message (str): Message to log.
        remote (str, optional): Log to remote logging destinations (MonitoringService, ELK, ...). Defaults to True.
    """
    if remote:
        enable_remote_loggers(
            service_name=settings.app_name, monitoring_repo=easy.monitoring_service
        )
    logging.warning(f"{settings.app_name} is running: {message}")


@app.command()
def recreate_db_models(
    skip_confirmation: bool = typer.Option(
        default=False,
        help="Skip confirmation of DB connection before dropping the tables.",
    )
):
    """Drop all tables and re-create them.

    This command is useful when the database models have changed and the database needs to be re-created.
    Only use this command in development environments.

    Args:
        skip_confirmation (bool, optional): Skip confirmation of DB connection before dropping the tables. Defaults to False.
    """
    if not skip_confirmation and not typer.confirm(
        text="Confirm database connection string where tables are dropped"
    ):
        raise typer.Exit(code=1)

    if not skip_confirmation and not typer.confirm(
        text="Confirm that all tables will be dropped and re-created. All table content is lost."
    ):
        raise typer.Exit(code=1)
    easy.database.drop_all_tables()
    easy.database.create_all_tables()


@app.command()
def upgrade_db(skip_confirmation: bool = SkipDbOption):
    """Upgrade the database to the latest version using alembic.

    This command executes the migration scripts stored under deployment/alembic/versions.

    Args:
        skip_confirmation (bool, optional): Skip confirmation of DB connection. Defaults to False.
    """

    assert_alembic_config()

    logging.warning(f"The following DB connection is used: {easy.database.uri}")
    if not skip_confirmation and not typer.confirm(
        text="Confirm database connection string where the upgrade is executed"
    ):
        raise typer.Exit(code=1)

    args = [
        "--raiseerr",
        "upgrade",
        "head",
    ]

    alembic.config.main(argv=args)


@app.command()
def create_db_version(
    msg: str = typer.Option(default="revision", help="Version description.")
):
    """Create a new database migration script using alembic.

    Execute this command before a commit that changes the database models.

    Args:
        msg (str, optional): Version description. Defaults to "revision".
    """

    assert_alembic_config()

    args = ["--raiseerr", "revision", "--autogenerate", "-m", msg]
    alembic.config.main(argv=args)


@app.command()
def reset_test_data(skip_confirmation: bool = SkipDbOption):
    """Reset the test data.

    This command executes the test data reset script stored under deployment/data/test.py.
    It is executed everytime the code is deployed to the test environment.

    Args:
        skip_confirmation (bool, optional): Skip confirmation of DB connection. Defaults to False.
    """

    logging.warning(f"The following DB connection is used: {easy.database.uri}")
    if not skip_confirmation and not typer.confirm(
        text="Confirm database connection string where the data is reset"
    ):
        raise typer.Exit(code=1)

    path = pathlib.Path("deployment") / "data" / "test.py"

    if not path.is_file():
        logging.error(f"The test data reset script is not present at {path}.")
        raise typer.Exit(code=1)

    with open(path) as f:
        logging.error(f"Executing the test data reset script at {path}.")
        exec(f.read(), {"__name__": "__main__"})


@app.command()
def upgrade_batch_service_images(
    image_name: str, image_tag: str, skip_confirmation: bool = SkipDbOption
):
    """Upgrade the images used in the Batch Service.

    This command executes the image upgrade within the deployment pipeline.

    Args:
        image_name (str): The name of the image to be upgraded.
        image_tag (str): The new tag of the image to be used.
        skip_confirmation (bool, optional): Skip confirmation of DB connection. Defaults to False.
    """
    logging.warning(f"The following DB connection is used: {easy.database.uri}")
    if not skip_confirmation and not typer.confirm(
        text="Confirm database connection string where the upgrade is executed"
    ):
        raise typer.Exit(code=1)

    easy.batch_service.upgrade_image(
        image_name=image_name,
        image_tag=image_tag,
    )
