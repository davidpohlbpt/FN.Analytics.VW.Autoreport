try:
    # Running the web service behind PyCore requires additional libraries
    import fastapi
    import uvicorn
except ImportError as e:
    raise ImportError(
        "Please install optional webapi dependencies with 'poetry install --extras webapi'"
    ) from e
