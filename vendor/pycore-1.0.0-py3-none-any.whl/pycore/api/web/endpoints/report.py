import functools
import json
import logging
from collections.abc import Iterable

import fastapi
import numpy as np
import pandas as pd
from fastapi import APIRouter
from fastapi.responses import Response
from starlette import status

from pycore import easy
from pycore.api.web.utils import (
    simplify_interaction,
    simplify_multi_query,
    simplify_single_query,
)
from pycore.schemas import (
    DataModel,
    DataQuery,
    Interaction,
    MultipleDataQuery,
    Scope,
    SingleDataQuery,
)
from pycore.utils.database import TableDoesNotExistError
from pycore.utils.pandas import df_to_jsonable_dict

router = APIRouter()


def have_identical_columns(simple_queries: list[DataQuery]) -> bool:
    unique_cols = set()
    for q in simple_queries:
        if q.columns:
            unique_cols.update(q.columns)
    if all([len(q.columns) == len(unique_cols) for q in simple_queries if q.columns]):
        return True
    else:
        return False


@router.get("/sources")
def get_hooked_in_data_sources() -> list[str]:
    """Returns a list of all available custom queries.

    Returns:
        List[str]: List of data source names.
    """
    return easy.hook_repo.get_sources()


@router.get("/interactions")
def get_hooked_in_data_interactions() -> list[str]:
    """Returns a list of all available data interactions.

    Returns:
        List[str]: List of interaction names.
    """
    return easy.hook_repo.get_interactions()


@router.post("/query")
def query_single_data_source(
    data_query: SingleDataQuery,
) -> DataModel:
    logging.warning(
        f"Execution of query on source '{data_query.data_source.name}' is requested.",
        extra={"query": data_query.model_dump()},
    )

    # Simplify the complex combination of several filter types
    data_query.scope = Scope()
    simple_query = simplify_single_query(query=data_query)

    if easy.hook_repo.is_hooked_in_source(data_query.data_source.name):
        fun = easy.hook_repo.get_source(name=data_query.data_source.name)
    else:
        fun = easy.data_repo.read_query

    try:
        # Query execution
        data = fun(query=simple_query)
    except TableDoesNotExistError:
        msg = f"Data source '{data_query.data_source.name}' does not exist and, thus, cannot be queried."
        logging.error(msg, extra={"scope": data_query.scope})
        raise fastapi.HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=msg)
    except Exception as e:
        # Actual error
        logging.error(e, extra={"scope": data_query.scope})

        # Notice of failure
        msg = f"Query on '{data_query.data_source.name}' failed."
        logging.error(msg, extra={"scope": data_query.scope})
        raise fastapi.HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=msg
        )

    if isinstance(data, Iterable):
        logging.warning(
            f"Query execution yielded {len(data)} items.",
            extra={"query": data_query.model_dump()},
        )
    else:
        logging.warning(
            "Query execution successful.", extra={"query": data_query.model_dump()}
        )

    # Make serializable
    if isinstance(data, pd.DataFrame):
        data = df_to_jsonable_dict(df=data)

    return DataModel(data_source_id=data_query.data_source.data_source_id, rows=data)


@router.post("/query/multiple")
def query_multiple_data_sources(
    data_query: MultipleDataQuery,
):
    sources = ", ".join(["'" + s.name + "'" for s in data_query.data_sources])
    logging.warning(
        f"Execution of query on sources {sources} is requested.",
        extra={"query": data_query.model_dump()},
    )

    # Simplify the complex combination of several filter type
    data_query.scope = Scope()
    simple_queries = simplify_multi_query(query=data_query)
    result = {}

    # If all queries have the same columns, it is assumed that the query is for an opening mask
    # and the distinct flag is set to True to avoid duplicates in the result
    # This assumption is fair, since different data sources typically have different columns
    # This is required, because the UI does not transfer any information as to whether the query is for an opening mask
    distinct = have_identical_columns(simple_queries)

    for simple_query, data_source in zip(simple_queries, data_query.data_sources):
        if easy.hook_repo.is_hooked_in_source(simple_query.data_source_name):
            fun = easy.hook_repo.get_source(name=simple_query.data_source_name)
        else:
            fun = functools.partial(
                easy.data_repo.read_query, jsonable=True, distinct=distinct
            )

        try:
            # Query execution
            data = fun(query=simple_query)
        except TableDoesNotExistError:
            msg = f"Data source '{simple_query.data_source_name}' does not exist and, thus, cannot be queried."
            logging.error(msg, extra={"scope": data_query.scope})
            result[data_source.data_source_id] = json.dumps(None)
        except Exception as e:
            # Actual error
            logging.error(e, extra={"scope": data_query.scope})

            # Notice of failure
            msg = f"Query on '{simple_query.data_source_name}' failed."
            logging.error(msg, extra={"scope": data_query.scope})
            result[data_source.data_source_id] = json.dumps(None)
        else:
            # Make serializable
            if isinstance(data, pd.DataFrame):
                data = data.replace(
                    {np.nan: None}
                )  # replace NaNs with None to make it JSON serializable
                # More performant than df.to_dict + json.dumps
                data = data.to_json(orient="records")
            else:
                data = json.dumps(data)

            result[data_source.data_source_id] = data

    # required because df.to_json returns a string
    result = "{" + ",".join(f'"{k}":' + v for k, v in result.items()) + "}"
    return Response(result, media_type="application/json")


@router.post("/interaction")
def execute_data_interaction(
    interaction: Interaction,
) -> dict | list | int | float | str:
    """Returns the result of a __custom data interaction__ that is offered by this business service.

    The interaction must be built in the business service and must be hooked into the pycore.
    The interaction returns either a list, an object, or a scalar value.
    If not scalar, the response can be nested and of arbitrary shape.

    A data interaction can be any sort of business logic, e.g.,
    a real-time calculation logic or retrieval of complex result
    objects which do not follow the usual tabular structure used in
    generic reports.

    Please get in touch with the responsible business team if you're
    interested in the available data interactions and their
    required inputs and returned outputs.

    Args:
        interaction (Action): The interaction to be executed.

    Returns:
        Union[Dict, List, int, float, str]: The data returned as result of the interaction.
    """
    logging.warning(
        f"Execution of interaction '{interaction.action}' is requested.",
        extra={"interaction": interaction.model_dump()},
    )

    simple_action = simplify_interaction(interaction=interaction)

    try:
        fun = easy.hook_repo.get_interaction(name=simple_action.action_name)
        result = fun(action=simple_action)
        logging.warning(
            f"Execution of interaction '{simple_action.action_name}' was completed.",
            extra={"result": result, "filters": simple_action.filters},
        )
        return result
    except NotImplementedError:
        msg = f"Action '{simple_action.action_name}' is not hooked-in and, thus, cannot be executed."
        logging.error(msg)
        raise fastapi.HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=msg)
    except Exception as e:
        # Actual error
        logging.error(e, extra={"filters": simple_action.filters})

        # Notice of failure
        msg = f"Action '{simple_action.action_name}' failed."
        logging.error(msg, extra={"filters": simple_action.filters})
        raise fastapi.HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=msg
        )
