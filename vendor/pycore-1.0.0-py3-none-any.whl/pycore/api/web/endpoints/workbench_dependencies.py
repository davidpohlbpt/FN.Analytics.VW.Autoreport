"""FastAPI dependency factories for the workbench endpoints.

Kept separate from `pycore.workbench.*` (framework-agnostic domain logic) since
these functions are specifically about wiring FastAPI's dependency injection —
they exist to be passed to `fastapi.Depends`, not to be called directly.
"""

import dataclasses
from typing import Annotated, Callable, TypeVar

import fastapi

from pycore.api.web.dependencies import BearerSession
from pycore.workbench.contracts import WorkbenchRequestBase
from pycore.workbench.dimension_scoping import append_dimension_scoping_filters
from pycore.workbench.filters import (
    RoutedFilters,
    RoutedSearchParameters,
    normalize_filters_payload,
    route_filters,
    route_search_parameters,
)

RequestT = TypeVar("RequestT", bound=WorkbenchRequestBase)


@dataclasses.dataclass(frozen=True)
class RoutedFiltersBundle:
    normalized_filters: list
    routed_filters: RoutedFilters
    routed_search_parameters: RoutedSearchParameters


def routed_filters_dependency(
    request_type: type[RequestT],
) -> Callable[..., RoutedFiltersBundle]:
    """Builds a dependency that normalizes, dimension-scopes, and routes a
    workbench request's filters/search parameters.

    `request_type` must be the concrete request model the route itself
    declares (e.g. `WorkbenchGroupsRequest`) — FastAPI shares the single
    parsed request body between the route's own `request` parameter and this
    dependency's identically-named/typed one, so the wire contract (a bare
    JSON body, not `{"request": {...}}`) is unaffected.
    """

    def dependency(
        request: request_type,
        bearer_session: Annotated[BearerSession, fastapi.Depends(BearerSession)],
    ) -> RoutedFiltersBundle:
        normalized_filters = normalize_filters_payload(request.filters)
        normalized_filters = append_dimension_scoping_filters(
            normalized_filters, request, bearer_session.token
        )
        routed_filters = route_filters(normalized_filters)
        routed_search_parameters = route_search_parameters(
            request.search_parameters, request.computed_occurrence_columns
        )
        return RoutedFiltersBundle(
            normalized_filters=normalized_filters,
            routed_filters=routed_filters,
            routed_search_parameters=routed_search_parameters,
        )

    return dependency
