import logging
from typing import Annotated

import fastapi
from pydantic import ValidationError

from pycore import easy
from pycore import schemas as s
from pycore.api.web import contracts as cntr
from pycore.api.web.dependencies import BearerSession
from pycore.api.web.utils import derive_table_identifier
from pycore.repository.table_edit import (
    TableEditRepository,
    validate_data_columns_exist,
    validate_update_data,
)
from pycore.schemas import DataAction, GenericTableColumns

router = fastapi.APIRouter()
non_editable_columns = [
    GenericTableColumns.last_edited_at,
    GenericTableColumns.last_edited_by,
    GenericTableColumns.last_transaction_id,
    GenericTableColumns.last_transaction_date,
]
EDIT_INTERACTION = "edit"


class InternalServerError(fastapi.HTTPException):

    def __init__(
        self, e: Exception, edit_step: str, data_source_name: str | s.DataTable
    ):
        if isinstance(data_source_name, s.DataTable):
            data_source_name = data_source_name.table_schema + str(
                data_source_name.table_name
            )
        msg = f"Table Edit step '{edit_step}' for data table '{data_source_name}' failed. See logs for details."
        super().__init__(
            status_code=fastapi.status.HTTP_500_INTERNAL_SERVER_ERROR, detail=msg
        )
        logging.error(msg, extra={"data_source": data_source_name})
        logging.error(e, extra={"data_source": data_source_name})


class BadRequestError(fastapi.HTTPException):

    def __init__(
        self, e: Exception, edit_step: str, data_source_name: str | s.DataTable
    ):
        if isinstance(data_source_name, s.DataTable):
            data_source_name = str(data_source_name.table_schema) + str(
                data_source_name.table_name
            )
        if isinstance(e, ValidationError):
            error_messages = " ".join([error["msg"] for error in e.errors()])
            error_message = f"{error_messages}"
        else:
            error_message = f"{str(e)}"
        msg = f"Table Edit step '{edit_step}' for data table '{data_source_name}' failed: {error_message}"
        super().__init__(status_code=fastapi.status.HTTP_400_BAD_REQUEST, detail=msg)
        logging.error(msg, extra={"data_source": data_source_name})


def get_table_edit_repo(
    bearer_session: Annotated[BearerSession, fastapi.Depends(BearerSession)],
) -> TableEditRepository:
    return TableEditRepository(database=easy.database, email=bearer_session.email)


def get_table_edit_operations(
    req: cntr.TableEditRequest,
) -> s.TableEditOperations:
    step_0 = "validate request"
    try:
        table_edit_operations = convert_edit_request_to_edit_operations(req)
        data_table_info = table_edit_operations.data_table
        data_table = easy.database.get_table(
            table=data_table_info.table_name, schema=data_table_info.table_schema
        )
        validate_data_columns_exist(
            table_edit_operations=table_edit_operations, data_table=data_table
        )
        table_edit_operations = validate_update_data(
            table_edit_operations=table_edit_operations, data_table=data_table
        )
    except ValueError as e:
        raise BadRequestError(e, step_0, req.report_data_source.table_name) from e
    except Exception as e:
        raise InternalServerError(e, step_0, req.report_data_source.table_name) from e

    return table_edit_operations


@router.post("/edit")
def perform_table_edit(
    table_edit_operations: Annotated[
        s.TableEditOperations, fastapi.Depends(get_table_edit_operations)
    ],
    table_edit_repo: Annotated[
        TableEditRepository, fastapi.Depends(get_table_edit_repo)
    ],
) -> cntr.TableEditResponse:
    """Perform insert, update, and delete operations on a table.

    If "has_audit" is true, then audit records are inserted within the same DB transaction of their respective operation (insert, update, delete).
    Each operation (insert, update, delete) can succeed independently from the others.
    Deletes are always "soft" deletes, i.e, the column "IsDeleted" is set to True.
    Before we try a value insert or update, the type compatibility is checked.

    Args:
        table_edit_operations (TableEditOperations): The operations to perform.
        table_edit_repo (TableEditRepository): The repository to perform the operations.

    Returns:
        TableEditResponse: The result of the operations.
    """
    step_1 = "set data tables"
    try:
        if easy.hook_repo.is_hooked_in_interaction(EDIT_INTERACTION):
            fun = easy.hook_repo.get_interaction(name=EDIT_INTERACTION)
            result = fun(
                DataAction(action_name=EDIT_INTERACTION, data=table_edit_operations)
            )
            logging.warning(
                "Execution of edit operation was completed.",
                extra={"result": result},
            )
            return result
        table_edit_repo.set_audit_table(has_audit=table_edit_operations.has_audit)
        table_edit_repo.set_data_table(data_table=table_edit_operations.data_table)
    except ValueError as e:
        raise BadRequestError(e, step_1, table_edit_operations.data_table) from e
    except Exception as e:
        raise InternalServerError(e, step_1, table_edit_operations.data_table) from e

    # Step 2 execute the operations (exceptions handled within functions, no HTTPExceptions are raised, but errors will logged)
    insert_result = table_edit_repo.insert_rows(
        table_insert=table_edit_operations.insert_operations,
    )
    if insert_result.details:
        logging.error(f"Insert failed: {insert_result.details}")

    update_result = table_edit_repo.update_rows(
        table_update=table_edit_operations.update_operations,
    )
    if update_result.details:
        logging.error(f"Update failed: {update_result.details}")

    delete_result = table_edit_repo.delete_rows(
        table_delete=table_edit_operations.delete_operations,
    )
    if delete_result.details:
        logging.error(f"Delete failed: {delete_result.details}")

    return cntr.TableEditResponse(
        result=cntr.TableEditResult(
            result_insert=insert_result.success,
            result_update=update_result.success,
            result_delete=delete_result.success,
        )
    )


def convert_primary_keys(
    primary_keys: list[cntr.TablePrimaryKey] | None,
) -> list[s.PrimaryKey] | None:
    if primary_keys is None:
        return None
    return [
        s.PrimaryKey(column_name=pk.column_name, value=pk.value) for pk in primary_keys
    ]


def convert_insert_model_to_insert_operation(
    insert_view_model: cntr.TableInsertModel,
) -> list[s.InsertOperation] | None:
    def convert_field_values(
        field_values: list[cntr.TableFieldValue] | None,
    ) -> list[s.FieldValue]:
        if field_values is None:
            return []
        return [
            s.FieldValue(
                column_name=fv.column_name,
                data_type=fv.data_type,
                new_value=fv.new_value,
                old_value=fv.old_value,
            )
            for fv in field_values
            if fv.column_name not in non_editable_columns
        ]

    if not insert_view_model:
        return None

    insert_operations = []
    for insert_fields in insert_view_model:
        insert_fields = convert_field_values(insert_fields)
        if not insert_fields:
            continue
        insert_operations.append(s.InsertOperation(insert_fields=insert_fields))
    if not insert_operations:
        return None
    return insert_operations


def convert_update_model_to_update_operation(
    update_view_model: cntr.TableUpdateModel,
) -> list[s.UpdateOperation] | None:
    def transform_update_value(field: s.FieldValue) -> str | None:
        if field.new_value == "":
            return None
        else:
            return field.new_value

    if not update_view_model:
        return None

    update_operations_dict = {}
    for fv in update_view_model:
        if fv.column_name in non_editable_columns:
            continue
        primary_keys = convert_primary_keys(fv.primary_keys)
        primary_keys_tuple = tuple((pk.column_name, pk.value) for pk in primary_keys)
        if primary_keys_tuple not in update_operations_dict:
            update_operations_dict[primary_keys_tuple] = s.UpdateOperation(
                primary_keys=primary_keys, update_fields=[]
            )
        update_operations_dict[primary_keys_tuple].update_fields.append(
            s.FieldValue(
                column_name=fv.column_name,
                data_type=fv.data_type,
                new_value=transform_update_value(fv),
                old_value=fv.old_value,
            )
        )
    update_operations = list(update_operations_dict.values())
    if not update_operations:
        return None
    return update_operations


def convert_delete_model_to_delete_operation(
    delete_view_model: cntr.TableDeleteModel,
) -> list[s.DeleteOperation] | None:
    delete_operations = None
    if delete_view_model:
        delete_operations = [
            s.DeleteOperation(primary_keys=convert_primary_keys(primary_keys))
            for primary_keys in delete_view_model
        ]
    return delete_operations


def convert_edit_request_to_edit_operations(
    table_edit_request: cntr.TableEditRequest,
) -> s.TableEditOperations:

    table_name, schema = derive_table_identifier(
        table_identifier=table_edit_request.report_data_source.table_name
    )
    data_table = s.DataTable(table_schema=schema, table_name=table_name)

    insert_operations = convert_insert_model_to_insert_operation(
        table_edit_request.insert_view_model
    )

    update_operations = convert_update_model_to_update_operation(
        table_edit_request.update_view_model
    )

    delete_operations = convert_delete_model_to_delete_operation(
        table_edit_request.delete_view_model
    )

    return s.TableEditOperations(
        has_audit=table_edit_request.has_audit,
        data_table=data_table,
        insert_operations=insert_operations,
        update_operations=update_operations,
        delete_operations=delete_operations,
    )
