import datetime as dt
import logging
from typing import Annotated

import fastapi
import sqlalchemy as sa
from fastapi import APIRouter

from pycore import easy
from pycore.api.web.dependencies import BearerSession
from pycore.api.web.endpoints.workbench_dependencies import (
    RoutedFiltersBundle,
    routed_filters_dependency,
)
from pycore.api.web.endpoints.workbench_helpers import (
    _WORKBENCH_ERROR_RESPONSES,
    _build_extended_view_incident,
    _build_slice_incident,
    _dedupe_search_items,
    _execute_rows,
    _execute_sql_rows,
    _fetch_extended_rules,
    _incident_details_fields,
    _merge_rule_grouping_dimensions,
    _page,
    _resolve_extended_view_rule,
    _resolve_incident_details_rule,
    _rule_detail_entries,
    _rule_filter_metadata_values,
    _rule_id_filters,
    _rule_search_items,
    _scoping_detail_value,
    _translate_rules_or_empty,
    _visible_field_entries,
    _visible_grouping_dimensions,
    _workbench_error_response,
)
from pycore.workbench import models as workbench_models
from pycore.workbench.constants import (
    CAN_SEE_SCORE,
    INCIDENT_DETAILS_PROPERTY_INCIDENT_ID_TK,
    INCIDENT_DETAILS_PROPERTY_SCOPING_TK,
    ORIGIN_FIELDS,
    ORIGIN_RULES,
    SCORE_FIELD_NAME,
    WORKBENCH_INCIDENT_STATUS_ALLOWLIST,
)
from pycore.workbench.contracts import (
    FilterConfigurationModel,
    WorkbenchCountApiResponse,
    WorkbenchCountRequest,
    WorkbenchCountResponse,
    WorkbenchDimensionGroup,
    WorkbenchExtendedViewApiResponse,
    WorkbenchExtendedViewRequest,
    WorkbenchExtendedViewResponse,
    WorkbenchFilterConfigurationApiResponse,
    WorkbenchFilterConfigurationRequest,
    WorkbenchFilterConfigurationResponse,
    WorkbenchFilterMetadataApiResponse,
    WorkbenchFilterMetadataRequest,
    WorkbenchGroupsApiResponse,
    WorkbenchGroupsRequest,
    WorkbenchGroupsResponse,
    WorkbenchIncidentDetailsApiResponse,
    WorkbenchIncidentDetailsRequest,
    WorkbenchSearchApiResponse,
    WorkbenchSearchRequest,
    WorkbenchSearchResultItem,
    WorkbenchSliceApiResponse,
    WorkbenchSliceRequest,
    WorkbenchSliceResponse,
    WorkbenchSmartlistCountApiResponse,
    WorkbenchSmartlistCountRequest,
)
from pycore.workbench.dimension_scoping import (
    entity_ids_for_request,
    resolve_dimension_value_filter_if_needed,
)
from pycore.workbench.groups_presentation import (
    apply_rule_origin_groups_post_processing,
    augment_groups,
)
from pycore.workbench.filters import normalize_filters_payload, route_filters, route_search_parameters
from pycore.workbench.permissions import is_field_valid, permission_is_true, permission_lookup
from pycore.workbench.query.count import build_count_statements
from pycore.workbench.query.extended_view import build_extended_view_statement
from pycore.workbench.query.filter_configuration import (
    OPERATORS_BY_FIELD_TYPE,
    STATIC_FILTERS,
    DynamicFieldTypesSqlParams,
    WorkbenchFilterConfigurationSqlBuilder,
    map_openjson_type,
)
from pycore.workbench.query.filter_metadata import (
    build_filter_metadata_statement,
    normalize_filter_path,
)
from pycore.workbench.query.groups import build_groups_query_plan
from pycore.workbench.query.incident_details import build_incident_details_statement
from pycore.workbench.query.search import SearchSqlParams, WorkbenchSearchSqlBuilder
from pycore.workbench.query.slice import build_slice_meta, build_slice_statement
from pycore.workbench.query.smartlist_count import build_smartlist_count_statement
from pycore.workbench.rule_matching import filter_rules
from pycore.workbench.translation_helpers import translate_search_labels_if_possible

router = APIRouter()
metadata_router = APIRouter()


def _execute_scalar(statement: sa.sql.Select) -> int:
    with easy.database.session_scope() as db:
        return int(db.execute(statement).scalar_one_or_none() or 0)


@router.post(
    "/groups", response_model=WorkbenchGroupsApiResponse, responses=_WORKBENCH_ERROR_RESPONSES
)
def get_workbench_groups(
    request: WorkbenchGroupsRequest,
    bearer_session: Annotated[BearerSession, fastapi.Depends(BearerSession)],
    routed: Annotated[
        RoutedFiltersBundle, fastapi.Depends(routed_filters_dependency(WorkbenchGroupsRequest))
    ],
):
    try:
        query_plan = build_groups_query_plan(
            request,
            routed_filters=routed.routed_filters,
            routed_search_parameters=routed.routed_search_parameters,
        )

        if query_plan.raw_sql:
            rows = _execute_sql_rows(query_plan.raw_sql, query_plan.raw_parameters)
            groups = [
                WorkbenchDimensionGroup(title=str(row[0] or ""), count=int(row[1] or 0))
                for row in rows
            ]
            groups = apply_rule_origin_groups_post_processing(
                request,
                groups,
                routed.routed_filters,
                routed.normalized_filters,
                access_token=bearer_session.token,
            )
            groups = augment_groups(groups, request.grouping_dimension or "")
            return WorkbenchGroupsApiResponse(result=WorkbenchGroupsResponse(groups=groups))

        if query_plan.orm_statement is None:
            return WorkbenchGroupsApiResponse(result=WorkbenchGroupsResponse(groups=[]))

        rows = _execute_rows(query_plan.orm_statement)
        groups = [
            WorkbenchDimensionGroup(title=str(row.title or ""), count=int(row.count or 0))
            for row in rows
        ]
        groups = apply_rule_origin_groups_post_processing(
            request,
            groups,
            routed.routed_filters,
            routed.normalized_filters,
            access_token=bearer_session.token,
        )
        groups = augment_groups(groups, request.grouping_dimension or "")
        return WorkbenchGroupsApiResponse(result=WorkbenchGroupsResponse(groups=groups))
    except Exception as exc:
        return _workbench_error_response(exc, "groups", scenario_id=request.scenario_id)


@router.post(
    "/count", response_model=WorkbenchCountApiResponse, responses=_WORKBENCH_ERROR_RESPONSES
)
def get_workbench_count(
    request: WorkbenchCountRequest,
    bearer_session: Annotated[BearerSession, fastapi.Depends(BearerSession)],
    routed: Annotated[
        RoutedFiltersBundle, fastapi.Depends(routed_filters_dependency(WorkbenchCountRequest))
    ],
):
    try:
        included_rule_ids = None
        excluded_rule_ids = None
        if routed.routed_filters.rule:
            rules = _fetch_extended_rules(request, bearer_session.token)
            included_rule_ids, excluded_rule_ids = _rule_id_filters(
                rules, routed.routed_filters.rule
            )

        count_statements = build_count_statements(
            request,
            routed_filters=routed.routed_filters,
            routed_search_parameters=routed.routed_search_parameters,
            included_rule_ids=included_rule_ids,
            excluded_rule_ids=excluded_rule_ids,
        )

        with easy.database.session_scope() as db:
            total_count = int(
                db.execute(count_statements.total_statement).scalar_one_or_none() or 0
            )
            filtered_count = int(
                db.execute(count_statements.filtered_statement).scalar_one_or_none() or 0
            )

        return WorkbenchCountApiResponse(
            result=WorkbenchCountResponse(
                total_count=total_count,
                filtered_count=filtered_count,
            )
        )
    except Exception as exc:
        return _workbench_error_response(exc, "count", scenario_id=request.scenario_id)


def _validate_incident_status_filter(incident_status: str | None) -> None:
    if incident_status is not None and incident_status not in WORKBENCH_INCIDENT_STATUS_ALLOWLIST:
        raise ValueError(
            "`incidentStatusFilterForSubscriptionEmail` must be one of "
            f"{sorted(WORKBENCH_INCIDENT_STATUS_ALLOWLIST)}."
        )


def _fetch_smartlist_rules(
    request: WorkbenchSmartlistCountRequest, access_token: str
) -> tuple[list, list[int]]:
    entity_ids = entity_ids_for_request(request)
    if not entity_ids:
        return [], []

    rules = easy.rules_mgmt.get_extended_rules_for_multiple_entities(
        entity_ids=entity_ids,
        scenario_id=request.scenario_id,
        access_token=access_token,
    )
    all_rule_ids = [rule.business_rule_id for rule in rules if rule.business_rule_id]
    return rules, all_rule_ids


def _smartlist_rule_id_filters(
    routed_filters, rules: list, all_rule_ids: list[int]
) -> tuple[list[int] | None, list[int] | None]:
    if not routed_filters.rule:
        return None, None

    filtered_rules = filter_rules(rules, routed_filters.rule)
    filtered_rule_ids = [
        rule.business_rule_id for rule in filtered_rules if rule.business_rule_id
    ]
    if filtered_rule_ids:
        return filtered_rule_ids, None
    if all_rule_ids:
        return None, all_rule_ids
    return None, None


def _apply_smartlist_item_count(
    smartlist,
    *,
    request: WorkbenchSmartlistCountRequest,
    rules: list,
    all_rule_ids: list[int],
    dimension_filters,
    incident_status: str | None,
) -> None:
    try:
        item_filters = normalize_filters_payload(smartlist.filter_set)
        if dimension_filters:
            item_filters = item_filters + normalize_filters_payload(dimension_filters)

        routed_filters = route_filters(item_filters)
        routed_search_parameters = route_search_parameters(
            request.search_parameters, request.computed_occurrence_columns
        )
        included_rule_ids, excluded_rule_ids = _smartlist_rule_id_filters(
            routed_filters, rules, all_rule_ids
        )

        statement = build_smartlist_count_statement(
            request,
            routed_filters=routed_filters,
            routed_search_parameters=routed_search_parameters,
            included_rule_ids=included_rule_ids,
            excluded_rule_ids=excluded_rule_ids,
            incident_status=incident_status,
        )
        smartlist.item_count = _execute_scalar(statement)
    except Exception:
        logging.warning(
            "Workbench smartlist count failed for one smartlist; marking disabled.",
            extra={"smartlist_id": smartlist.smartlist_id},
        )
        smartlist.disabled = True


@router.post(
    "/smartlist/count",
    response_model=WorkbenchSmartlistCountApiResponse,
    responses=_WORKBENCH_ERROR_RESPONSES,
)
def get_workbench_smartlist_count(
    request: WorkbenchSmartlistCountRequest,
    bearer_session: Annotated[BearerSession, fastapi.Depends(BearerSession)],
):
    try:
        incident_status = request.incident_status_filter_for_subscription_email
        _validate_incident_status_filter(incident_status)

        rules, all_rule_ids = _fetch_smartlist_rules(request, bearer_session.token)
        dimension_filters = resolve_dimension_value_filter_if_needed(
            request, bearer_session.token
        )

        for smartlist in request.smartlists:
            _apply_smartlist_item_count(
                smartlist,
                request=request,
                rules=rules,
                all_rule_ids=all_rule_ids,
                dimension_filters=dimension_filters,
                incident_status=incident_status,
            )

        return WorkbenchSmartlistCountApiResponse(result=request.smartlists)
    except Exception as exc:
        return _workbench_error_response(exc, "smartlist count", scenario_id=request.scenario_id)


@router.post(
    "/slice", response_model=WorkbenchSliceApiResponse, responses=_WORKBENCH_ERROR_RESPONSES
)
def get_workbench_slice(
    request: WorkbenchSliceRequest,
    bearer_session: Annotated[BearerSession, fastapi.Depends(BearerSession)],
    routed: Annotated[
        RoutedFiltersBundle, fastapi.Depends(routed_filters_dependency(WorkbenchSliceRequest))
    ],
):
    try:
        rules = _fetch_extended_rules(request, bearer_session.token)
        included_rule_ids, excluded_rule_ids = _rule_id_filters(
            rules, routed.routed_filters.rule
        )

        slice_plan = build_slice_statement(
            request,
            routed_filters=routed.routed_filters,
            routed_search_parameters=routed.routed_search_parameters,
            included_rule_ids=included_rule_ids,
            excluded_rule_ids=excluded_rule_ids,
        )

        rows = _execute_rows(slice_plan.statement)

        translations = _translate_rules_or_empty(
            rules, request.user_language, bearer_session.token, request.scenario_id
        )
        rules_by_br_id = {rule.business_rule_id: rule for rule in rules if rule.business_rule_id}
        today = dt.datetime.now(dt.UTC).date()

        data = [
            _build_slice_incident(
                row, rules_by_br_id, translations, today, request.show_hidden
            )
            for row in rows
        ]

        meta = build_slice_meta(
            skip=slice_plan.skip,
            take=slice_plan.take,
            returned=len(data),
        )
        return WorkbenchSliceApiResponse(
            result=WorkbenchSliceResponse(data=data, count=len(data), meta=meta)
        )
    except Exception as exc:
        return _workbench_error_response(exc, "slice", scenario_id=request.scenario_id)


@router.post(
    "/extendedViewIncidents",
    response_model=WorkbenchExtendedViewApiResponse,
    responses=_WORKBENCH_ERROR_RESPONSES,
)
def get_workbench_extended_view_incidents(
    request: WorkbenchExtendedViewRequest,
    bearer_session: Annotated[BearerSession, fastapi.Depends(BearerSession)],
    routed: Annotated[
        RoutedFiltersBundle,
        fastapi.Depends(routed_filters_dependency(WorkbenchExtendedViewRequest)),
    ],
):
    try:
        business_rule_id = (request.grouping.value or "").strip() if request.grouping else ""
        if not business_rule_id:
            raise ValueError(
                "grouping.value (business rule id) is required for extendedViewIncidents."
            )

        plan = build_extended_view_statement(
            request,
            business_rule_id=business_rule_id,
            routed_filters=routed.routed_filters,
            routed_search_parameters=routed.routed_search_parameters,
        )
        rows = _execute_rows(plan.statement)
        with easy.database.session_scope() as db:
            total_count = int(db.execute(plan.count_statement).scalar_one_or_none() or 0)

        rules = _fetch_extended_rules(request, bearer_session.token)
        extended_rule = _resolve_extended_view_rule(
            rules, business_rule_id, routed.routed_filters.rule
        )

        permissions = {
            parameter.name: parameter.value
            for parameter in (request.configuration_parameters or [])
        }
        visible_grouping_dimensions = _visible_grouping_dimensions(extended_rule, permissions)

        today = dt.datetime.now(dt.UTC).date()
        data = [
            _build_extended_view_incident(row, visible_grouping_dimensions, today)
            for row in rows
        ]

        return WorkbenchExtendedViewApiResponse(
            result=WorkbenchExtendedViewResponse(data=data, count=total_count)
        )
    except Exception as exc:
        return _workbench_error_response(
            exc, "extended view incidents", scenario_id=request.scenario_id
        )


@metadata_router.post(
    "/filter",
    response_model=WorkbenchFilterMetadataApiResponse,
    responses=_WORKBENCH_ERROR_RESPONSES,
)
def get_workbench_filter_metadata(
    request: WorkbenchFilterMetadataRequest,
    bearer_session: Annotated[BearerSession, fastapi.Depends(BearerSession)],
    routed: Annotated[
        RoutedFiltersBundle,
        fastapi.Depends(routed_filters_dependency(WorkbenchFilterMetadataRequest)),
    ],
):
    try:
        normalized_path = normalize_filter_path(request.path, request.dimension)
        if normalized_path == ORIGIN_RULES:
            return WorkbenchFilterMetadataApiResponse(
                result=_rule_filter_metadata_values(request, bearer_session.token)
            )

        statement = build_filter_metadata_statement(
            request,
            routed_filters=routed.routed_filters,
            routed_search_parameters=routed.routed_search_parameters,
        )
        if statement is None:
            return WorkbenchFilterMetadataApiResponse(result=[])

        rows = _execute_rows(statement)
        values = [str(row.value) for row in rows if row.value is not None]
        return WorkbenchFilterMetadataApiResponse(result=values)
    except Exception as exc:
        return _workbench_error_response(exc, "filter metadata", scenario_id=request.scenario_id)


@router.post(
    "/filters",
    response_model=WorkbenchFilterConfigurationApiResponse,
    responses=_WORKBENCH_ERROR_RESPONSES,
)
def get_workbench_filter_configuration(
    request: WorkbenchFilterConfigurationRequest,
    bearer_session: Annotated[BearerSession, fastapi.Depends(BearerSession)],
):
    try:
        sql_builder = WorkbenchFilterConfigurationSqlBuilder()
        sql, params = sql_builder.build_dynamic_field_types_query(
            DynamicFieldTypesSqlParams(
                scenario_id=request.scenario_id,
                schema=workbench_models.WORKBENCH_SCHEMA,
                load_id=request.load_id,
                load_ids=request.load_ids,
            )
        )
        rows = _execute_sql_rows(sql, params)
        dynamic_filters = [
            FilterConfigurationModel(
                name=row.key,
                label=row.key,
                dimension=row.key,
                type=map_openjson_type(row.type, row.key),
                path=ORIGIN_FIELDS,
            )
            for row in rows
        ]
        return WorkbenchFilterConfigurationApiResponse(
            result=WorkbenchFilterConfigurationResponse(
                filters=[*STATIC_FILTERS, *dynamic_filters],
                operators=OPERATORS_BY_FIELD_TYPE,
            )
        )
    except Exception as exc:
        return _workbench_error_response(exc, "filters", scenario_id=request.scenario_id)


@metadata_router.post(
    "/search", response_model=WorkbenchSearchApiResponse, responses=_WORKBENCH_ERROR_RESPONSES
)
def search_workbench_metadata(
    request: WorkbenchSearchRequest,
    bearer_session: Annotated[BearerSession, fastapi.Depends(BearerSession)],
    routed: Annotated[
        RoutedFiltersBundle, fastapi.Depends(routed_filters_dependency(WorkbenchSearchRequest))
    ],
):
    try:
        sql_builder = WorkbenchSearchSqlBuilder()
        sql, params = sql_builder.build_search_query(
            SearchSqlParams(
                scenario_id=request.scenario_id,
                schema=workbench_models.WORKBENCH_SCHEMA,
                search_term=request.search_term or "",
                take=request.take,
                skip=request.skip,
                load_id=request.load_id,
                load_ids=request.load_ids,
                entity_id=request.entity_id,
                entity_ids=request.entity_ids,
                reporting_unit_id=request.reporting_unit_id,
                show_hidden=request.show_hidden,
                show_deleted=request.show_deleted,
            )
        )

        rules = _fetch_extended_rules(request, bearer_session.token)
        search_tokens = [t.lower() for t in (request.search_term or "").split(";") if t]
        values = _rule_search_items(rules, search_tokens)

        rows = _execute_sql_rows(sql, params)
        values.extend(
            WorkbenchSearchResultItem(
                dimension=str(row[0]),
                column_name=str(row[1]),
                name=str(row[1]),
                value=str(row[2]),
            )
            for row in rows
        )

        paged = _page(_dedupe_search_items(values), request.skip, request.take)

        translations = translate_search_labels_if_possible(
            [item.name for item in paged],
            request.user_language or "",
        )

        return WorkbenchSearchApiResponse(
            result=[
                WorkbenchSearchResultItem(
                    dimension=item.dimension,
                    column_name=item.column_name,
                    name=translations.get(item.name, item.name),
                    value=item.value,
                )
                for item in paged
            ]
        )
    except Exception as exc:
        return _workbench_error_response(exc, "search", scenario_id=request.scenario_id)


@router.post(
    "/incidentDetails",
    response_model=WorkbenchIncidentDetailsApiResponse,
    responses=_WORKBENCH_ERROR_RESPONSES,
)
def get_workbench_incident_details(
    request: WorkbenchIncidentDetailsRequest,
    bearer_session: Annotated[BearerSession, fastapi.Depends(BearerSession)],
):
    try:
        statement = build_incident_details_statement(
            request.incident_id,
            request.scenario_id,
            request.reporting_unit_id,
            request.load_id,
        )
        rows = _execute_rows(statement)
        if not rows:
            raise fastapi.HTTPException(status_code=404, detail="Incident details not found.")

        row = rows[0]
        row_mapping = row._mapping if hasattr(row, "_mapping") else dict(row)
        incident_id = row_mapping.get("IncidentID") or row_mapping.get("incident_id")
        rule_id = row_mapping.get("RuleId") or row_mapping.get("rule_id")
        business_rule_id = row_mapping.get("BusinessRuleId") or row_mapping.get("business_rule_id")

        parsed_fields = _incident_details_fields(
            row_mapping.get("Fields") or row_mapping.get("fields") or "{}"
        )
        rule = _resolve_incident_details_rule(
            request, rule_id, business_rule_id, bearer_session.token
        )
        _merge_rule_grouping_dimensions(parsed_fields, rule)

        permissions = permission_lookup(request.permissions)
        result: dict[str, str] = {}

        if is_field_valid(incident_id):
            result[INCIDENT_DETAILS_PROPERTY_INCIDENT_ID_TK] = str(incident_id)

        result[str(rule.business_rule_id or rule_id or "")] = rule.business_rule or ""
        result.update(_rule_detail_entries(rule, permissions))

        scoping = _scoping_detail_value(
            rule, permissions, request.user_language, bearer_session.token
        )
        if scoping is not None:
            result[INCIDENT_DETAILS_PROPERTY_SCOPING_TK] = scoping

        if not permission_is_true(permissions, CAN_SEE_SCORE):
            parsed_fields.pop(SCORE_FIELD_NAME, None)
        result.update(_visible_field_entries(parsed_fields, permissions))

        return WorkbenchIncidentDetailsApiResponse(result=result)
    except Exception as exc:
        return _workbench_error_response(
            exc,
            "incident details",
            scenario_id=request.scenario_id,
            incident_id=request.incident_id,
        )
