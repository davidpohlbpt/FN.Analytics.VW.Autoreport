import logging
from collections.abc import Callable
from typing import Annotated

import fastapi
import pandas as pd
import sqlalchemy as sa

from pycore import easy
from pycore.api.web import contracts as cntr
from pycore.api.web import filters as conv_filters
from pycore.api.web.utils import derive_table_identifier
from pycore.repository.report import ReportDataRepository
from pycore.schemas import Filter, FilterExpression, FilterOperator, Query
from pycore.utils.database import ColumnDoesNotExistError
from pycore.utils.pandas import df_to_jsonable_dict
from pycore.utils.string import normalize_search_terms

router = fastapi.APIRouter()


class InternalServerError(fastapi.HTTPException):

    def __init__(self, e: Exception, func: Callable, data_source_name: str):
        msg = f"Processing '{func.__name__}' on '{data_source_name}' failed. See logs for details."
        super().__init__(
            status_code=fastapi.status.HTTP_500_INTERNAL_SERVER_ERROR, detail=msg
        )
        logging.error(msg, extra={"data_source": data_source_name})
        logging.error(e, extra={"data_source": data_source_name})


class BadRequestError(fastapi.HTTPException):

    def __init__(self, e: Exception, func: Callable, data_source_name: str):
        msg = f"Processing '{func.__name__}' on '{data_source_name}' failed: {e}"
        super().__init__(status_code=fastapi.status.HTTP_400_BAD_REQUEST, detail=msg)
        logging.error(msg, extra={"data_source": data_source_name})


def get_report_repo() -> ReportDataRepository:
    return ReportDataRepository(database=easy.database)


def get_filters(req: cntr.FilterContract) -> FilterExpression:

    filters = []

    if req.advanced_filters:
        adv_filter_expr = conv_filters.convert_standard_filters(req.advanced_filters)
        filters.append(adv_filter_expr)

    if req.report_filters:
        rep_filter_expr = conv_filters.convert_report_filters(req.report_filters)
        filters.append(rep_filter_expr)

    if req.quick_filters:
        quick_filter_expr = conv_filters.convert_quick_filters(req.quick_filters)
        filters.append(quick_filter_expr)

    if req.drill_through_filters:
        drill_through_expr = conv_filters.convert_drill_through_filters(
            req.drill_through_filters
        )
        filters.append(drill_through_expr)

    if req.advanced_filters_groups:
        nested_filter_expr = conv_filters.convert_nested_filter(
            req.advanced_filters_groups
        )
        filters.append(nested_filter_expr)

    return FilterExpression(
        filters=filters,
        all_must_be_met=True,
    )


def get_query(req: cntr.DataSourceContract) -> Query:
    table, schema = derive_table_identifier(
        table_identifier=req.report_data_source.table_name
    )

    is_table = easy.database.has_table(table=table, schema=schema)
    is_hooked_in = easy.hook_repo.is_hooked_in_source(req.report_data_source.table_name)

    if not (is_table or is_hooked_in):
        msg = f"Data source '{req.report_data_source.table_name}' does not exist and, thus, cannot be queried."
        logging.error(msg, extra={"data_source": req.report_data_source.table_name})
        raise fastapi.HTTPException(
            status_code=fastapi.status.HTTP_404_NOT_FOUND, detail=msg
        )

    if req.report_data_source.data_source_filters:
        ds_filters = conv_filters.convert_report_filters(
            req.report_data_source.data_source_filters
        )
        filters = ds_filters
    else:
        filters = FilterExpression(filters=[])

    return Query(
        table_name=table,
        schema_=schema,
        select=req.report_data_source.columns,
        filters=filters,
    )


def get_report_document_query(
    req: cntr.RetrieveSingleValueByPrimaryKeyRequest,
) -> Query:
    req_for_query = req.model_copy(deep=True)
    req_for_query.report_data_source.columns = [req.column_name]
    req_for_query.report_data_source.data_source_filters = [
        cntr.ReportFilter(
            filter_type=cntr.FilterType.EQUAL,
            filter_field=pk.column_name,
            default_value=pk.value,
            default_values=None,
        )
        for pk in req.primary_keys
    ]

    return get_query(req=req_for_query)


@router.post("/slice")
def get_data_slice(
    req: cntr.ReportDataSliceRequest,
    query: Annotated[Query, fastapi.Depends(get_query)],
    filters: Annotated[FilterExpression, fastapi.Depends(get_filters)],
    report_repo: Annotated[ReportDataRepository, fastapi.Depends(get_report_repo)],
) -> fastapi.responses.JSONResponse:
    """Returns a data slice for the requested data source."""
    query.filters = FilterExpression(filters=[filters, query.filters])

    query.offset = req.skip
    query.limit = req.take

    if req.applied_sorting:
        query.order_by = req.applied_sorting.columns
    elif req.skip is not None and req.take is not None:
        if query.select and len(query.select) > 0:
            query.order_by = [(query.select[0], True)]

    if easy.hook_repo.is_hooked_in_source(req.report_data_source.table_name):
        fun = easy.hook_repo.get_source(name=req.report_data_source.table_name)
    else:
        fun = report_repo.get_query_result

    try:
        data = fun(query=query)
    except ColumnDoesNotExistError as e:
        raise BadRequestError(e, fun, req.report_data_source.table_name) from e
    except Exception as e:
        raise InternalServerError(e, fun, req.report_data_source.table_name) from e

    # Make serializable
    if isinstance(data, pd.DataFrame):
        data = df_to_jsonable_dict(df=data)

    return cntr.ReportDataSliceResponse(result=data)


@router.post("/count")
def get_row_count(
    req: cntr.ReportDataCountRequest,
    query: Annotated[Query, fastapi.Depends(get_query)],
    filters: Annotated[FilterExpression, fastapi.Depends(get_filters)],
    report_repo: Annotated[ReportDataRepository, fastapi.Depends(get_report_repo)],
) -> cntr.ReportDataCountResponse:
    """Returns the row count for the requested data source."""
    query.filters = FilterExpression(filters=[filters, query.filters])

    fun = report_repo.get_query_count

    try:
        count = fun(query)
    except ColumnDoesNotExistError as e:
        raise BadRequestError(e, fun, req.report_data_source.table_name) from e
    except Exception as e:
        raise InternalServerError(e, fun, req.report_data_source.table_name) from e

    return cntr.ReportDataCountResponse(
        result=cntr.ReportDataCountResult(total_count=count)
    )


@router.post("/filters/metadata")
def get_filter_metadata(
    req: cntr.FilterMetadataRequest,
    filters: Annotated[FilterExpression, fastapi.Depends(get_filters)],
    report_repo: Annotated[ReportDataRepository, fastapi.Depends(get_report_repo)],
) -> cntr.FilterMetadataResponse:
    if req.search_term:
        _apply_search_term_filter(filters, req.filter_column, req.search_term)

    metadata_queries = _build_filter_metadata_queries(
        data_sources=req.data_sources,
        filter_column=req.filter_column,
        filters=filters,
        report_repo=report_repo,
    )
    if not metadata_queries:
        return []

    union_query = _to_distinct_select(metadata_queries, req.filter_column, ordered=True)
    if req.skip is not None and req.take is not None and req.take > 0:
        union_query = union_query.offset(req.skip).limit(req.take)

    with report_repo.database.engine.connect() as conn:
        distinct_values = [str(row[0]) for row in conn.execute(union_query).fetchall()]

    if not req.selected_values:
        return distinct_values

    # Fetch selected values separately and merge with the paged results
    selected_filter = Filter(
        name=req.filter_column,
        type=FilterOperator.multiselect,
        value=req.selected_values,
    )
    selected_queries = _build_filter_metadata_queries(
        data_sources=req.data_sources,
        filter_column=req.filter_column,
        filters=filters,
        report_repo=report_repo,
        additional_filter=selected_filter,
    )
    if not selected_queries:
        return distinct_values

    selected_union = _to_distinct_select(selected_queries, req.filter_column)
    with report_repo.database.engine.connect() as conn:
        selected_values = [
            str(row[0]) for row in conn.execute(selected_union).fetchall()
        ]

    return list(set(distinct_values + selected_values))


@router.post("/kpi")
def get_kpi(
    req: cntr.ReportKpiRequest,
    query: Annotated[Query, fastapi.Depends(get_query)],
    filters: Annotated[FilterExpression, fastapi.Depends(get_filters)],
    report_repo: Annotated[ReportDataRepository, fastapi.Depends(get_report_repo)],
) -> cntr.ReportKpiResponse:
    query.filters = FilterExpression(filters=[filters, query.filters])

    fun = report_repo.get_raw_query_result

    try:
        value = fun(query, raw_sql=req.kpi_query)
    except ColumnDoesNotExistError as e:
        raise BadRequestError(e, fun, req.report_data_source.table_name) from e
    except sa.exc.OperationalError as e:
        msg = f"The KPI query is invalid or cannot be executed for other reasons: {req.kpi_query}"
        logging.error(msg, extra={"data_source": req.report_data_source.table_name})
        logging.error(e, extra={"data_source": req.report_data_source.table_name})
        raise fastapi.HTTPException(
            status_code=fastapi.status.HTTP_400_BAD_REQUEST,
            detail=msg,
        ) from e
    except Exception as e:
        raise InternalServerError(e, fun, req.report_data_source.table_name) from e

    if len(value) != 1 or len(value[0]) != 1:
        raise fastapi.HTTPException(
            status_code=fastapi.status.HTTP_400_BAD_REQUEST,
            detail="The KPI query must return exactly 1 row & 1 column.",
        )

    return cntr.ReportKpiResponse(result=cntr.ReportKpiResult(value=value[0][0]))


@router.post("/chart")
def get_chart_data(
    req: cntr.ReportChartRequest,
    query: Annotated[Query, fastapi.Depends(get_query)],
    filters: Annotated[FilterExpression, fastapi.Depends(get_filters)],
    report_repo: Annotated[ReportDataRepository, fastapi.Depends(get_report_repo)],
) -> cntr.ReportChartResponse:

    if req.chart_filters:
        chart_filter_expr, minmax_filter = conv_filters.convert_chart_filters(
            req.chart_filters
        )
        query.minmax_filter = minmax_filter
        filters = FilterExpression(filters=[chart_filter_expr, filters])

    query.filters = FilterExpression(filters=[filters, query.filters])

    results = []
    fun = report_repo.get_query_result

    for geom in req.chart_geometries:

        query.groupby = list(
            set(aes.dimension for aes in geom.aesthetics if not aes.aggregation)
        )
        query.aggregation = {
            aes.dimension: aes.aggregation for aes in geom.aesthetics if aes.aggregation
        }
        query.select = query.groupby + list(set(query.aggregation.keys()))

        if req.applied_sorting:
            query.order_by = [
                col for col in req.applied_sorting.columns if col[0] in query.select
            ]

        try:
            data = fun(query)
        except ColumnDoesNotExistError as e:
            raise BadRequestError(e, fun, req.report_data_source.table_name) from e
        except Exception as e:
            raise InternalServerError(e, fun, req.report_data_source.table_name) from e

        data = df_to_jsonable_dict(df=data)
        result = cntr.ReportChartResult(geometry_id=geom.geom_id, geometry_data=data)
        results.append(result)

    return cntr.ReportChartResponse(result=results)


def _apply_search_term_filter(
    filters: FilterExpression, column: str, search_term: str
) -> None:
    terms = normalize_search_terms(search_term)
    if len(terms) == 1:
        filters.filters.append(
            Filter(name=column, type=FilterOperator.fuzzy_search, value=terms[0])
        )
    elif len(terms) > 1:
        filters.filters.append(
            FilterExpression(
                all_must_be_met=False,
                filters=[
                    Filter(name=column, type=FilterOperator.fuzzy_search, value=t)
                    for t in terms
                ],
            )
        )


def _to_distinct_select(
    queries: list, column: str, *, ordered: bool = False
) -> sa.sql.Select:
    base = queries[0] if len(queries) == 1 else sa.union_all(*queries)
    base = base.subquery()
    q = sa.select(sa.distinct(base.c[column]))
    if ordered:
        q = q.order_by(base.c[column])
    return q


def _build_filter_metadata_queries(
    data_sources: list,
    filter_column: str,
    filters: FilterExpression,
    report_repo: ReportDataRepository,
    additional_filter: Filter | None = None,
) -> list:
    """Build union queries for filter metadata from multiple data sources."""
    return _build_union_queries(
        data_sources=data_sources,
        select_columns=[filter_column],
        filters=filters,
        report_repo=report_repo,
        additional_filter=additional_filter,
    )


def _build_union_queries(
    data_sources: list,
    select_columns: list[str],
    filters: FilterExpression,
    report_repo: ReportDataRepository,
    additional_filter: Filter | None = None,
) -> list:
    """Build union queries for multiple columns from multiple data sources."""
    union_queries = []

    for data_source in data_sources:
        try:
            query = get_query(
                req=cntr.DataSourceContract(report_data_source=data_source)
            )
            query.distinct = True
            query.select = select_columns

            # Build filters list
            filters_list = [filters, query.filters]
            if additional_filter:
                filters_list.append(FilterExpression(filters=[additional_filter]))

            query.filters = FilterExpression(filters=filters_list)

            # Get the SQL query for this data source
            sql_query = report_repo._get_sql_query(query=query)
            union_queries.append(sql_query)

        except Exception:
            # Log warning but continue with other data sources
            logging.warning(
                f"Could not build query for columns {select_columns} on table '{data_source.table_name}'."
            )

    return union_queries


@router.post("/dataSource/columns")
def get_datasource_columns(
    req: cntr.DataSourceColumnsRequest,
    filters: Annotated[FilterExpression, fastapi.Depends(get_filters)],
    report_repo: Annotated[ReportDataRepository, fastapi.Depends(get_report_repo)],
) -> cntr.DataSourceColumnsResponse:
    """Returns distinct values for multiple columns from the requested data sources."""

    # Build union queries for all data sources
    column_queries = _build_union_queries(
        data_sources=req.data_sources,
        select_columns=req.filter_columns,
        filters=filters,
        report_repo=report_repo,
    )

    if not column_queries:
        return cntr.DataSourceColumnsResponse(result=[])

    if len(column_queries) == 1:
        column_union_query = column_queries[0]
    else:
        column_union_query = sa.union_all(*column_queries)

    # Create a subquery to properly reference columns
    subquery = column_union_query.subquery()

    # Apply distinct - for multiple columns, distinct applies to the combination
    column_union_query = sa.select(
        *[subquery.c[col] for col in req.filter_columns]
    ).distinct()

    # Order by first column
    if req.filter_columns:
        column_union_query = column_union_query.order_by(
            subquery.c[req.filter_columns[0]]
        )

    # Apply pagination
    if req.skip is not None and req.take is not None and req.take > 0:
        column_union_query = column_union_query.offset(req.skip)
        column_union_query = column_union_query.limit(req.take)

    with report_repo.database.engine.connect() as conn:
        result = conn.execute(column_union_query)
        column_values = [dict(row._mapping) for row in result.fetchall()]

    return cntr.DataSourceColumnsResponse(result=column_values)


@router.post("/reportDocument")
def retrieve_document(
    req: cntr.RetrieveSingleValueByPrimaryKeyRequest,
    query: Annotated[Query, fastapi.Depends(get_report_document_query)],
    report_repo: Annotated[ReportDataRepository, fastapi.Depends(get_report_repo)],
) -> fastapi.responses.Response:
    """Resolves a blob path via primary key lookup and streams the file from Azure Blob Storage."""
    import mimetypes

    try:
        df = report_repo.get_query_result(query)
    except ColumnDoesNotExistError as e:
        raise BadRequestError(
            e, report_repo.get_query_result, req.report_data_source.table_name
        ) from e
    except Exception as e:
        raise InternalServerError(
            e, report_repo.get_query_result, req.report_data_source.table_name
        ) from e

    if df is None or df.empty:
        raise fastapi.HTTPException(
            status_code=fastapi.status.HTTP_404_NOT_FOUND,
            detail="Document not found.",
        )

    blob_file_path = str(df.iloc[0, 0])
    container, path = blob_file_path.split("/", 1)

    file_bytes = easy.storage.read_blob(container, path, decode=False)

    file_name = path.rsplit("/", 1)[-1]
    content_type, _ = mimetypes.guess_type(file_name)
    content_type = content_type or "application/octet-stream"

    return fastapi.responses.Response(
        content=file_bytes,
        media_type=content_type,
        headers={
            "Content-Disposition": f'attachment; filename="{file_name}"',
            "Access-Control-Expose-Headers": "Content-Disposition",
        },
    )
