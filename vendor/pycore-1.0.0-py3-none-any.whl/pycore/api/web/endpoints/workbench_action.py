"""FastAPI surface for `/api/v1/workbenchAction`.

Mirrors the .NET `WorkbenchActionController`. Handlers stay orchestration-only:
they validate the request contract, delegate, and map the result into the
`ApiResponse`-style `{"result": ...}` envelope the FnApiGateway expects.
"""

from typing import Annotated, Any, Callable

import fastapi
from fastapi import APIRouter
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session

from pycore import easy
from pycore.api.web.dependencies import BearerSession
from pycore.config import settings
from pycore.workbench.actions.constants import (
    ERROR_CODE_OPERATION_NOT_ALLOWED,
    ERROR_MESSAGE_INVALID_USER_EMAIL,
    ROUTE_ASSIGN,
    ROUTE_COMMENT,
    ROUTE_COMMENTS,
    ROUTE_DELETE,
    ROUTE_GROUP_ACTION,
    ROUTE_GROUP_COMMENTS,
    ROUTE_HIDE,
    ROUTE_HIDE_EXPIRED,
    ROUTE_HISTORY,
    ROUTE_RESOLVE,
    ROUTE_RESTORE,
    ROUTE_SHOW,
    ROUTE_UNASSIGN,
)
from pycore.workbench.actions.contracts import (
    EditIncidentRequest,
    GroupAction,
    WorkbenchActionBoolApiResponse,
    WorkbenchAssignUserRequest,
    WorkbenchCommentIncidentsRequest,
    WorkbenchCommentsApiResponse,
    WorkbenchDeleteIncidentsRequest,
    WorkbenchGroupActionApiResponse,
    WorkbenchGroupActionRequest,
    WorkbenchHideIncidentsRequest,
    WorkbenchHistoryApiResponse,
    WorkbenchResolveIncidentsRequest,
    WorkbenchRestoreIncidentsRequest,
)
from pycore.workbench.actions.email import (
    DEFAULT_LANGUAGE_KEY,
    AssignedIncident,
    build_assigned_incidents,
    send_assign_email,
)
from pycore.workbench.actions.group_action import guard_group_action, perform_group_action
from pycore.workbench.actions.group_resolution import resolve_group_incidents
from pycore.workbench.actions.exceptions import (
    EventTypeNotFoundError,
    IncidentNotFoundError,
    OperationNotAllowedError,
)
from pycore.workbench.actions.service import (
    assign_incidents,
    comment_incidents,
    get_incident_business_rules,
    get_incident_comments,
    get_incident_history,
    hide_incidents,
    mark_incidents_as_deleted,
    resolve_incidents,
    restore_incidents,
    show_incidents,
    unassign_incidents,
    unhide_expired_incidents,
)
from pycore.workbench.actions.users import UserDirectory
from pycore.workbench.constants import (
    ERROR_CODE_DIMENSION_VALUE_NOT_FOUND,
    ERROR_CODE_INTERNAL_ERROR,
)
from pycore.workbench.contracts import WorkbenchErrorDetail, WorkbenchErrorResponse

router = APIRouter()

_ACTION_ERROR_RESPONSES: dict[int, dict[str, Any]] = {
    400: {"model": WorkbenchErrorResponse},
    404: {"model": WorkbenchErrorResponse},
    422: {"model": WorkbenchErrorResponse},
    500: {"model": WorkbenchErrorResponse},
}

AuthenticatedSession = Annotated[BearerSession, fastapi.Depends(BearerSession)]


def action_error_response(status_code: int, code: str, message: str) -> JSONResponse:
    payload = WorkbenchErrorResponse(error=WorkbenchErrorDetail(code=code, message=message))
    return JSONResponse(status_code=status_code, content=payload.model_dump(by_alias=True))


def _user_directory(access_token: str) -> UserDirectory:
    return UserDirectory.from_users(easy.identity.get_all_users(access_token=access_token))


def _run_mutation(mutate: Callable[[Session], bool]):
    """Runs a mutation in one transaction and maps domain errors to the envelope."""
    try:
        with easy.database.session_scope() as db:
            result = mutate(db)
    except OperationNotAllowedError as error:
        return action_error_response(
            status_code=400,
            code=ERROR_CODE_OPERATION_NOT_ALLOWED,
            message=str(error),
        )
    except IncidentNotFoundError as error:
        return action_error_response(
            status_code=404,
            code=ERROR_CODE_DIMENSION_VALUE_NOT_FOUND,
            message=str(error),
        )
    except EventTypeNotFoundError as error:
        return action_error_response(
            status_code=500,
            code=ERROR_CODE_INTERNAL_ERROR,
            message=str(error),
        )

    return WorkbenchActionBoolApiResponse(result=result)


@router.get(
    ROUTE_HISTORY,
    response_model=WorkbenchHistoryApiResponse,
    responses=_ACTION_ERROR_RESPONSES,
)
def get_incident_history_endpoint(
    incident_id: int,
    scenario_id: int,
    bearer_session: AuthenticatedSession,
):
    directory = _user_directory(bearer_session.token)

    try:
        with easy.database.session_scope() as db:
            history = get_incident_history(db, incident_id, scenario_id, directory)
    except IncidentNotFoundError as error:
        return action_error_response(
            status_code=404,
            code=ERROR_CODE_DIMENSION_VALUE_NOT_FOUND,
            message=str(error),
        )

    return WorkbenchHistoryApiResponse(result=history)


@router.post(
    ROUTE_ASSIGN,
    response_model=WorkbenchActionBoolApiResponse,
    responses=_ACTION_ERROR_RESPONSES,
)
def assign_users_to_incidents(
    request: WorkbenchAssignUserRequest,
    bearer_session: AuthenticatedSession,
):
    assigned_user = easy.identity.get_user_by_id(
        request.user_id, access_token=bearer_session.token
    )
    if assigned_user is None or not assigned_user.email:
        return action_error_response(
            status_code=400,
            code=ERROR_CODE_OPERATION_NOT_ALLOWED,
            message=ERROR_MESSAGE_INVALID_USER_EMAIL,
        )

    try:
        with easy.database.session_scope() as db:
            assign_incidents(
                db, request.incident_ids, request.scenario_id, assigned_user.email
            )
            business_rules = get_incident_business_rules(
                db,
                request.incident_ids,
                request.scenario_id,
                entity_ids=[
                    incident.entity_id for incident in request.assigned_incidents
                ],
            )

        _dispatch_assign_email(request, assigned_user, business_rules, bearer_session)
    except OperationNotAllowedError as error:
        return action_error_response(
            status_code=400,
            code=ERROR_CODE_OPERATION_NOT_ALLOWED,
            message=str(error),
        )
    except IncidentNotFoundError as error:
        return action_error_response(
            status_code=404,
            code=ERROR_CODE_DIMENSION_VALUE_NOT_FOUND,
            message=str(error),
        )
    except EventTypeNotFoundError as error:
        return action_error_response(
            status_code=500,
            code=ERROR_CODE_INTERNAL_ERROR,
            message=str(error),
        )

    return WorkbenchActionBoolApiResponse(result=True)


def _dispatch_assign_email(
    request: WorkbenchAssignUserRequest,
    assigned_user,
    business_rules: dict[int, str],
    bearer_session: BearerSession,
) -> None:
    language_key = assigned_user.language_key or DEFAULT_LANGUAGE_KEY
    incidents = build_assigned_incidents(
        business_rules_by_incident=business_rules,
        scenario_id=request.scenario_id,
        entity_ids=[incident.entity_id for incident in request.assigned_incidents],
        language_key=language_key,
        access_token=bearer_session.token,
    )
    send_assign_email(
        incidents=incidents,
        assigned_user=assigned_user,
        current_user_email=bearer_session.email,
        menu_item_id=request.menu_item_id,
        dimension_value_id=request.dimension_value_id,
        comment=request.comment,
        ui_base_url=settings.ext_base_url or "",
        access_token=bearer_session.token,
    )


@router.post(
    ROUTE_UNASSIGN,
    response_model=WorkbenchActionBoolApiResponse,
    responses=_ACTION_ERROR_RESPONSES,
)
def unassign_incidents_from_users(
    request: EditIncidentRequest,
    bearer_session: AuthenticatedSession,
):
    return _run_mutation(
        lambda db: unassign_incidents(db, request.incident_ids, request.scenario_id)
    )


@router.post(
    ROUTE_SHOW,
    response_model=WorkbenchActionBoolApiResponse,
    responses=_ACTION_ERROR_RESPONSES,
)
def show_incidents_endpoint(
    request: EditIncidentRequest,
    bearer_session: AuthenticatedSession,
):
    return _run_mutation(
        lambda db: show_incidents(
            db, request.incident_ids, request.scenario_id, bearer_session.email
        )
    )


@router.post(
    ROUTE_HIDE,
    response_model=WorkbenchActionBoolApiResponse,
    responses=_ACTION_ERROR_RESPONSES,
)
def hide_incidents_endpoint(
    request: WorkbenchHideIncidentsRequest,
    bearer_session: AuthenticatedSession,
):
    return _run_mutation(
        lambda db: hide_incidents(
            db,
            request.incidents,
            request.scenario_id,
            bearer_session.id,
            bearer_session.email,
            request.hide_until,
        )
    )


@router.post(
    ROUTE_HIDE_EXPIRED,
    response_model=WorkbenchActionBoolApiResponse,
    responses=_ACTION_ERROR_RESPONSES,
)
def log_expired_hide_events(bearer_session: AuthenticatedSession):
    return _run_mutation(unhide_expired_incidents)


@router.post(
    ROUTE_RESOLVE,
    response_model=WorkbenchActionBoolApiResponse,
    responses=_ACTION_ERROR_RESPONSES,
)
def resolve_incidents_endpoint(
    request: WorkbenchResolveIncidentsRequest,
    bearer_session: AuthenticatedSession,
):
    return _run_mutation(
        lambda db: resolve_incidents(
            db,
            request.incidents,
            request.scenario_id,
            bearer_session.id,
            bearer_session.email,
        )
    )


@router.post(
    ROUTE_DELETE,
    response_model=WorkbenchActionBoolApiResponse,
    responses=_ACTION_ERROR_RESPONSES,
)
def mark_incidents_as_deleted_endpoint(
    request: WorkbenchDeleteIncidentsRequest,
    bearer_session: AuthenticatedSession,
):
    return _run_mutation(
        lambda db: mark_incidents_as_deleted(
            db, request.incidents, request.scenario_id, bearer_session.id
        )
    )


@router.post(
    ROUTE_RESTORE,
    response_model=WorkbenchActionBoolApiResponse,
    responses=_ACTION_ERROR_RESPONSES,
)
def restore_incidents_endpoint(
    request: WorkbenchRestoreIncidentsRequest,
    bearer_session: AuthenticatedSession,
):
    return _run_mutation(
        lambda db: restore_incidents(
            db,
            request.incident_ids,
            request.scenario_id,
            bearer_session.id,
            request.load_id,
        )
    )


@router.post(
    ROUTE_GROUP_ACTION,
    response_model=WorkbenchGroupActionApiResponse,
    responses=_ACTION_ERROR_RESPONSES,
)
def perform_group_action_endpoint(
    request: WorkbenchGroupActionRequest,
    bearer_session: AuthenticatedSession,
):
    try:
        guard_group_action(request)

        assigned_user = None
        if request.action is GroupAction.assign and request.user_id:
            assigned_user = easy.identity.get_user_by_id(
                request.user_id, access_token=bearer_session.token
            )

        with easy.database.session_scope() as db:
            incidents = resolve_group_incidents(db, request, bearer_session.token)
            perform_group_action(
                db,
                request,
                incidents,
                current_user_id=bearer_session.id,
                current_user_email=bearer_session.email,
                assigned_user_email=assigned_user.email if assigned_user else None,
            )

        if request.action is GroupAction.assign and assigned_user and incidents:
            _send_group_assign_email(request, assigned_user, incidents, bearer_session)
    except OperationNotAllowedError as error:
        return action_error_response(
            status_code=400,
            code=ERROR_CODE_OPERATION_NOT_ALLOWED,
            message=str(error),
        )
    except IncidentNotFoundError as error:
        return action_error_response(
            status_code=404,
            code=ERROR_CODE_DIMENSION_VALUE_NOT_FOUND,
            message=str(error),
        )
    except EventTypeNotFoundError as error:
        return action_error_response(
            status_code=500,
            code=ERROR_CODE_INTERNAL_ERROR,
            message=str(error),
        )

    return WorkbenchGroupActionApiResponse(result=incidents)


def _send_group_assign_email(
    request: WorkbenchGroupActionRequest,
    assigned_user,
    incidents: list,
    bearer_session: BearerSession,
) -> None:
    send_assign_email(
        incidents=[
            AssignedIncident(
                incident_id=incident.incident_id,
                business_rule_id=incident.business_rule_id,
                rule_definition=incident.rule_definition,
            )
            for incident in incidents
        ],
        assigned_user=assigned_user,
        current_user_email=bearer_session.email,
        menu_item_id=request.menu_item_id,
        dimension_value_id=request.dimension_value_id,
        comment=request.comment,
        ui_base_url=settings.ext_base_url or "",
        access_token=bearer_session.token,
    )


@router.post(
    ROUTE_COMMENTS,
    response_model=WorkbenchCommentsApiResponse,
    responses=_ACTION_ERROR_RESPONSES,
)
def get_incident_comments_endpoint(
    request: EditIncidentRequest,
    bearer_session: AuthenticatedSession,
):
    directory = _user_directory(bearer_session.token)

    with easy.database.session_scope() as db:
        comments = get_incident_comments(
            db, request.incident_ids, request.scenario_id, directory
        )

    return WorkbenchCommentsApiResponse(result=comments)


@router.post(
    ROUTE_GROUP_COMMENTS,
    response_model=WorkbenchCommentsApiResponse,
    responses=_ACTION_ERROR_RESPONSES,
)
def get_group_incident_comments(
    request: WorkbenchGroupActionRequest,
    bearer_session: AuthenticatedSession,
):
    directory = _user_directory(bearer_session.token)

    with easy.database.session_scope() as db:
        incidents = resolve_group_incidents(db, request, bearer_session.token)
        comments = get_incident_comments(
            db,
            [incident.incident_id for incident in incidents],
            request.scenario_id,
            directory,
        )

    return WorkbenchCommentsApiResponse(result=comments)


@router.post(
    ROUTE_COMMENT,
    response_model=WorkbenchActionBoolApiResponse,
    responses=_ACTION_ERROR_RESPONSES,
)
def comment_incidents_endpoint(
    request: WorkbenchCommentIncidentsRequest,
    bearer_session: AuthenticatedSession,
):
    return _run_mutation(
        lambda db: comment_incidents(
            db,
            request.incidents or [],
            request.scenario_id,
            request.comment,
            bearer_session.id,
            bearer_session.email,
        )
    )
