from typing import Annotated, Any

import fastapi
import pydantic
from fastapi import APIRouter
from starlette import status

from pycore.api.web import dependencies as deps
from pycore.repository.settings import SettingsRepository
from pycore.schemas import ApiResponse

router = APIRouter()


@router.get("/defaults")
def get_default_settings(
    settings_repo: Annotated[
        SettingsRepository, fastapi.Depends(deps.get_settings_repo)
    ],
) -> dict[str, Any]:
    try:
        return settings_repo.get_defaults().model_dump()
    except pydantic.ValidationError as e:
        raise fastapi.HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=e.errors()
        )


@router.get("/entities/{entity_id}")
def get_entity_settings(
    entity_id: int,
    settings_repo: Annotated[
        SettingsRepository, fastapi.Depends(deps.get_settings_repo)
    ],
) -> dict[str, Any]:
    try:
        return settings_repo.get_entity(entity_id=entity_id).model_dump()
    except pydantic.ValidationError as e:
        raise fastapi.HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=e.errors()
        )


@router.patch("/defaults")
def update_default_settings(
    settings: dict,
    settings_repo: Annotated[
        SettingsRepository, fastapi.Depends(deps.get_settings_repo)
    ],
) -> ApiResponse:
    try:
        settings = settings_repo.update_model.model_validate(
            settings
        )  # validate settings
        settings_repo.save_defaults(settings=settings)
        return ApiResponse(message="Default settings were updated.")
    except pydantic.ValidationError as e:
        raise fastapi.HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=e.errors()
        )


@router.patch("/entities/{entity_id}")
def update_entity_settings(
    entity_id: int,
    settings: dict,
    settings_repo: Annotated[
        SettingsRepository, fastapi.Depends(deps.get_settings_repo)
    ],
) -> ApiResponse:
    try:
        settings = settings_repo.model.model_validate(settings)  # validate settings
        settings_repo.save_entity(settings=settings, entity_id=entity_id)
        return ApiResponse(message=f"Settings for entity_id={entity_id} were updated.")
    except pydantic.ValidationError as e:
        raise fastapi.HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=e.errors()
        )


@router.delete("/entities/{entity_id}")
def delete_entity_settings(
    entity_id: int,
    settings_repo: Annotated[
        SettingsRepository, fastapi.Depends(deps.get_settings_repo)
    ],
    db: Annotated[Any, fastapi.Depends(deps.get_db)],
) -> ApiResponse:
    nr_settings = settings_repo.setting_repo.count_all_where(db, entity_id=entity_id)
    settings_repo.setting_repo.remove_all_where(db, entity_id=entity_id)
    return ApiResponse(
        message=f"Deleted {nr_settings} settings for entity_id={entity_id}"
    )
