import logging
from warnings import warn

import fastapi
import pydantic
from fastapi import APIRouter
from starlette import status

from pycore import easy
from pycore.schemas import ApiResponse

router = APIRouter()


def execute_tracker_call(process_name: str, load_id: int, query_params: dict[str, str]):
    extra = {"load_id": load_id}
    try:
        load_info = easy.tracker.get_load_information(load_id=load_id)
    except pydantic.ValidationError:
        msg = f"The Load info for load {load_id} could not be retrieved because the received Tracker information is not valid."
        logging.error(msg, extra=extra)
        raise fastapi.HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=msg)
    if load_info is None:
        msg = f"The Load info for load {load_id} could not be retrieved because the Tracker Service request was not successful."
        logging.error(msg, extra=extra)
        raise fastapi.HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=msg
        )
    else:
        logging.warning(
            f"Load information was successfully retrieved for load {load_id}.",
            extra=extra,
        )
    try:
        fun = easy.hook_repo.get_process(name=process_name)
        with easy.tracker.service_execution(
            process_id=process_name, load_info=load_info
        ):
            if "params" not in fun.__annotations__:
                warn(
                    f"The Tracker process {process_name} does not accept any parameters. Please add `params: dict[str, str]` to the function signature."
                )
                fun(load_info)
            else:
                param_cls = fun.__annotations__["params"]
                params = param_cls(**query_params)
                fun(load_info, params)  # catches any exception
        logging.warning(
            f"Execution of process '{process_name}' was completed for load {load_id}."
        )
    except NotImplementedError:
        msg = (
            f"process '{process_name}' is not hooked-in and, thus, cannot be executed."
        )
        logging.error(msg, extra=extra)
        raise fastapi.HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=msg)
    except Exception as e:
        msg = f"The execution failed for process '{process_name}' and load {load_id}. Error: {e}."
        logging.error(msg, extra=extra)
        raise fastapi.HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=msg)


@router.get("/processes")
def get_processes() -> list[str]:
    """Returns a list of all available processes.

    Returns:
        List[str]: List of process names.
    """
    return easy.hook_repo.get_processes()


@router.get("/processes/{process_name}/loads/{load_id}/execute")
def execute_process(
    process_name: str,
    load_id: str,
    req: fastapi.Request,
    background_tasks: fastapi.BackgroundTasks,
) -> ApiResponse:
    """Executes of a __custom process__ that is offered by this business service.

    The process must be built in the business service and must be hooked into the pycore.
    The process does not return anything but sets its status to success in the tracker.

    A process can be any sort of business logic that knows how to retrieve its inputs
    and persists their outputs, e.g., in a database or blob storage.

    Please get in touch with the responsible business team if you're
    interested in the available process and their logic.

    Args:
        process_name (str): Name of the process to be executed. Must match the tracker process ID.
        load_id (int): Load for which the process should be executed.
    """
    logging.warning(
        f"Execution of process '{process_name}' is requested for load {load_id}."
    )
    background_tasks.add_task(
        execute_tracker_call, process_name, load_id, req.query_params
    )

    return ApiResponse(message="Load execution was started in the background.")
