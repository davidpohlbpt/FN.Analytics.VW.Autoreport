"""Non-route helper logic for the workbench endpoints in `workbench.py`.

Keeps `workbench.py` focused on request/response orchestration: validation,
delegating to query builders, and shaping the typed API envelope. Everything
here is response formatting, permission/translation glue, or shared
error-response plumbing reused across multiple routes.
"""

import datetime as dt
import json
import logging
from typing import Any

import fastapi
import sqlalchemy as sa
from fastapi.responses import JSONResponse

from pycore import easy
from pycore.workbench.constants import (
    CAN_SEE_CRITICALITY,
    CAN_SEE_DESCRIPTION,
    CAN_SEE_HELPTEXT,
    CAN_SEE_RISK,
    CAN_SEE_SCOPING,
    ERROR_CODE_DIMENSION_VALUE_NOT_FOUND,
    ERROR_CODE_HTTP_ERROR,
    ERROR_CODE_INTERNAL_ERROR,
    ERROR_CODE_INVALID_REQUEST,
    ERROR_CODE_UPSTREAM_ERROR,
    ERROR_CODE_VALIDATION_ERROR,
    INCIDENT_DETAILS_PROPERTY_CRITICALITY_TK,
    INCIDENT_DETAILS_PROPERTY_DESCRIPTION_TK,
    INCIDENT_DETAILS_PROPERTY_HELPTEXT_TK,
    INCIDENT_DETAILS_PROPERTY_RISK_TK,
    ORIGIN_RULES,
    SCORE_FIELD_NAME,
    WORKBENCH_INCIDENT_STATUS_ALLOWLIST,
)
from pycore.workbench.contracts import (
    ExtendedRuleModel,
    GroupingDimensionModel,
    WorkbenchErrorDetail,
    WorkbenchErrorResponse,
    WorkbenchExtendedViewIncidentModel,
    WorkbenchFilterMetadataRequest,
    WorkbenchIncidentDetailsRequest,
    WorkbenchIncidentModel,
    WorkbenchRequestBase,
    WorkbenchSearchResultItem,
    WorkbenchSmartlistCountModel,
)
from pycore.workbench.dimension_scoping import entity_ids_for_request
from pycore.workbench.filters import normalize_filters_payload, route_filters, route_search_parameters
from pycore.workbench.occurrence_fields import parse_database_value
from pycore.workbench.permissions import (
    bool_grouping_value,
    can_see_grouping_dimension,
    is_field_valid,
    permission_is_true,
)
from pycore.workbench.query.filter_metadata import extract_rule_distinct_values
from pycore.workbench.query.smartlist_count import build_smartlist_count_statement
from pycore.workbench.rule_matching import filter_rules, get_rule_property_value
from pycore.workbench.templating import replace_description_params, replace_rule_param_tokens
from pycore.workbench.translation_helpers import translate_rule_texts_if_possible

_WORKBENCH_ERROR_RESPONSES: dict[int, dict[str, Any]] = {
    404: {"model": WorkbenchErrorResponse},
    422: {"model": WorkbenchErrorResponse},
    500: {"model": WorkbenchErrorResponse},
    502: {"model": WorkbenchErrorResponse},
}


def _error_response(status_code: int, code: str, message: str) -> JSONResponse:
    payload = WorkbenchErrorResponse(error=WorkbenchErrorDetail(code=code, message=message))
    return JSONResponse(status_code=status_code, content=payload.model_dump(by_alias=True))


def _http_error_code(status_code: int) -> str:
    if status_code == 404:
        return ERROR_CODE_DIMENSION_VALUE_NOT_FOUND
    if status_code == 502:
        return ERROR_CODE_UPSTREAM_ERROR
    if status_code == 422:
        return ERROR_CODE_VALIDATION_ERROR
    return ERROR_CODE_HTTP_ERROR


def _workbench_error_response(exc: Exception, operation: str, **extra: Any) -> JSONResponse:
    """Maps an exception raised by a workbench route to its error envelope.

    Shared by every route's `except Exception as exc` clause so the
    ValueError->422 / HTTPException->mapped / other->500+logged mapping is
    defined once instead of repeated per route.
    """
    if isinstance(exc, ValueError):
        return _error_response(422, ERROR_CODE_INVALID_REQUEST, str(exc))
    if isinstance(exc, fastapi.HTTPException):
        return _error_response(exc.status_code, _http_error_code(exc.status_code), str(exc.detail))
    logging.exception(f"Unexpected workbench {operation} error.", extra=extra)
    return _error_response(
        500, ERROR_CODE_INTERNAL_ERROR, f"Unexpected workbench {operation} error."
    )


_LARGE_RESULT_SET_WARNING_THRESHOLD = 10_000


def _warn_if_large_result_set(rows: list[Any], source: str) -> None:
    if len(rows) > _LARGE_RESULT_SET_WARNING_THRESHOLD:
        logging.warning(
            "Workbench query returned an unusually large result set.",
            extra={"source": source, "row_count": len(rows)},
        )


def _execute_rows(statement: sa.sql.Select) -> list[Any]:
    with easy.database.session_scope() as db:
        rows = list(db.execute(statement).fetchall())
    _warn_if_large_result_set(rows, "orm")
    return rows


def _execute_sql_rows(sql: str, params: dict[str, Any]) -> list[Any]:
    with easy.database.session_scope() as db:
        rows = list(db.execute(sa.text(sql), params).fetchall())
    _warn_if_large_result_set(rows, "raw_sql")
    return rows


def _fetch_extended_rules(
    request: WorkbenchRequestBase, access_token: str | None
) -> list[ExtendedRuleModel]:
    entity_ids = entity_ids_for_request(request)
    if not entity_ids:
        return []
    return easy.rules_mgmt.get_extended_rules_for_multiple_entities(
        entity_ids=entity_ids,
        scenario_id=request.scenario_id,
        access_token=access_token,
    )


def _rule_id_filters(
    rules: list[ExtendedRuleModel], rule_filter: Any
) -> tuple[list[str] | None, list[str] | None]:
    """Returns the (included, excluded) business rule ids for a rule filter."""
    if not rule_filter:
        return None, None

    included = [
        rule.business_rule_id
        for rule in filter_rules(rules, rule_filter)
        if rule.business_rule_id
    ]
    if included:
        return included, None

    excluded = [rule.business_rule_id for rule in rules if rule.business_rule_id]
    return None, excluded or None


def _translate_rules_or_empty(
    rules: list[ExtendedRuleModel],
    user_language: Any,
    access_token: str | None,
    scenario_id: Any,
) -> dict[str, str]:
    try:
        return translate_rule_texts_if_possible(
            rules, user_language, access_token=access_token
        )
    except Exception:
        logging.exception(
            "Workbench rule translation lookup failed.",
            extra={"scenario_id": scenario_id},
        )
        return {}


def _parse_occurrence_fields(raw_fields: Any, incident_id: Any) -> dict[str, Any]:
    if not raw_fields:
        return {}
    try:
        return json.loads(raw_fields)
    except Exception:
        logging.exception(
            "Failed to parse workbench occurrence fields JSON.",
            extra={"incident_id": incident_id},
        )
        return {}


def _translated(text: str | None, translations: dict[str, str]) -> str | None:
    if text and text in translations:
        return translations[text]
    return text


def _incident_age_days(created: Any, today: dt.date) -> int | None:
    if created is None:
        return None
    return max((today - created.date()).days, 0)


def _build_slice_incident(
    row: Any,
    rules_by_br_id: dict[str, ExtendedRuleModel],
    translations: dict[str, str],
    today: dt.date,
    show_hidden: bool,
) -> WorkbenchIncidentModel:
    row_data = row._mapping
    rule = rules_by_br_id.get(row_data["business_rule_id"])
    fields_dict = _parse_occurrence_fields(row_data["fields"], row_data["incident_id"])

    age = _incident_age_days(row_data["created"], today)

    dynamic_description = replace_description_params(
        fields_dict,
        _translated(rule.dynamic_description if rule else None, translations) or "",
    )

    return WorkbenchIncidentModel(
        incident_id=row_data["incident_id"],
        business_rule_id=row_data["business_rule_id"],
        status=row_data["status"],
        age=age,
        incident_assigned_user=row_data["assigned_user"],
        has_comments=bool(row_data["has_comments"]),
        is_hidden=show_hidden,
        load_id=row_data["load_id"],
        entity_id=row_data["entity_id"],
        reporting_unit_id=row_data["reporting_unit_id"],
        score_value=fields_dict.get(SCORE_FIELD_NAME),
        criticality_label=rule.criticality if rule else None,
        business_rule=_translated(rule.business_rule if rule else None, translations),
        dynamic_description=dynamic_description,
    )


def _resolve_extended_view_rule(
    rules: list[ExtendedRuleModel], business_rule_id: str, rule_filter: Any
) -> ExtendedRuleModel | None:
    candidate = next(
        (rule for rule in rules if rule.business_rule_id == business_rule_id), None
    )
    if candidate is None:
        return None
    matched = filter_rules([candidate], rule_filter)
    return matched[0] if matched else None


def _visible_grouping_dimensions(
    extended_rule: ExtendedRuleModel | None, permissions: dict[str, Any]
) -> list[GroupingDimensionModel]:
    groupings = extended_rule.grouping_dimension_query_models if extended_rule else []
    return [
        GroupingDimensionModel(
            id=grouping.id,
            grouping_dimension=grouping.grouping_dimension,
            value=grouping.value,
        )
        for grouping in groupings
        if can_see_grouping_dimension(grouping.grouping_dimension, permissions)
    ]


def _build_extended_view_incident(
    row: Any,
    visible_grouping_dimensions: list[GroupingDimensionModel],
    today: dt.date,
) -> WorkbenchExtendedViewIncidentModel:
    row_data = row._mapping
    raw_fields = _parse_occurrence_fields(row_data["fields"], row_data["incident_id"])
    fields = {
        str(key): parse_database_value(str(value)) for key, value in raw_fields.items()
    }

    return WorkbenchExtendedViewIncidentModel(
        incident_id=row_data["incident_id"],
        business_rule_id=row_data["business_rule_id"],
        age=_incident_age_days(row_data["created"], today),
        load_id=row_data["load_id"],
        entity_id=row_data["entity_id"],
        reporting_unit_id=row_data["reporting_unit_id"],
        grouping_dimension_query_models=visible_grouping_dimensions,
        fields=fields,
    )


def _page(items: list[Any], skip: int, take: int) -> list[Any]:
    """Applies skip/take paging; a non-positive take means "everything after skip"."""
    return items[skip:] if take <= 0 else items[skip : skip + take]


def _rule_filter_metadata_values(
    request: WorkbenchFilterMetadataRequest, access_token: str | None
) -> list[str]:
    rules = _fetch_extended_rules(request, access_token)
    if request.search_term:
        search_term = request.search_term.lower()
        rules = [
            rule
            for rule in rules
            if search_term in get_rule_property_value(rule, request.dimension).lower()
        ]

    values = extract_rule_distinct_values(request.dimension, rules)
    return _page(values, request.skip, request.take)


def _rule_search_items(
    rules: list[ExtendedRuleModel], search_tokens: list[str]
) -> list[WorkbenchSearchResultItem]:
    items: list[WorkbenchSearchResultItem] = []
    for rule in rules:
        if not rule.applicable:
            continue
        for grouping_dimension in rule.grouping_dimension_query_models:
            name = grouping_dimension.grouping_dimension
            value = grouping_dimension.value
            if name:
                value = bool_grouping_value(str(name), value)
            if search_tokens and not any(
                token in str(value).lower() for token in search_tokens
            ):
                continue
            items.append(
                WorkbenchSearchResultItem(
                    dimension=ORIGIN_RULES,
                    column_name=str(name),
                    name=str(name),
                    value=str(value),
                )
            )
    return items


def _dedupe_search_items(
    items: list[WorkbenchSearchResultItem],
) -> list[WorkbenchSearchResultItem]:
    unique: dict[tuple[str, str], WorkbenchSearchResultItem] = {}
    for item in items:
        unique.setdefault((item.column_name, item.value), item)
    return list(unique.values())


# (permission, translation key, rule attribute) for the pass-through detail properties.
_RULE_DETAIL_PROPERTIES = (
    (CAN_SEE_CRITICALITY, INCIDENT_DETAILS_PROPERTY_CRITICALITY_TK, "criticality"),
    (CAN_SEE_DESCRIPTION, INCIDENT_DETAILS_PROPERTY_DESCRIPTION_TK, "description"),
    (CAN_SEE_HELPTEXT, INCIDENT_DETAILS_PROPERTY_HELPTEXT_TK, "help_text"),
    (CAN_SEE_RISK, INCIDENT_DETAILS_PROPERTY_RISK_TK, "risk"),
)


def _incident_details_fields(raw_fields: Any) -> dict[str, Any]:
    if isinstance(raw_fields, str):
        parsed = json.loads(raw_fields) if raw_fields else {}
    else:
        parsed = raw_fields
    return parsed if isinstance(parsed, dict) else {}


def _resolve_incident_details_rule(
    request: WorkbenchIncidentDetailsRequest,
    rule_id: Any,
    business_rule_id: Any,
    access_token: str | None,
) -> ExtendedRuleModel:
    rule = easy.rules_mgmt.get_extended_rule(
        rule_id=str(rule_id or ""),
        entity_id=request.entity_id,
        scenario_id=request.scenario_id,
        access_token=access_token,
    )
    if rule is not None:
        return rule
    return ExtendedRuleModel(
        id="",
        business_rule_id=str(business_rule_id or rule_id or ""),
        business_rule="",
    )


def _merge_rule_grouping_dimensions(
    parsed_fields: dict[str, Any], rule: ExtendedRuleModel
) -> None:
    for grouping in rule.grouping_dimension_query_models or []:
        if grouping.grouping_dimension:
            parsed_fields[str(grouping.grouping_dimension).strip()] = grouping.value


def _rule_detail_entries(
    rule: ExtendedRuleModel, permissions: dict[str, Any]
) -> dict[str, str]:
    entries: dict[str, str] = {}
    for permission, key, attribute in _RULE_DETAIL_PROPERTIES:
        value = getattr(rule, attribute, None)
        if permission_is_true(permissions, permission) and value and is_field_valid(value):
            entries[key] = str(value)
    return entries


def _scoping_detail_value(
    rule: ExtendedRuleModel,
    permissions: dict[str, Any],
    user_language: str | None,
    access_token: str | None,
) -> str | None:
    if not permission_is_true(permissions, CAN_SEE_SCOPING) or not rule.scoping:
        return None

    scoping = rule.scoping
    if user_language:
        translations = easy.translation.get_translation_values(
            language_id=user_language,
            translation_keys=[scoping],
            access_token=access_token,
        )
        scoping = translations.get(scoping, scoping)
    return str(replace_rule_param_tokens(scoping, rule))


def _visible_field_entries(
    parsed_fields: dict[str, Any], permissions: dict[str, Any]
) -> dict[str, str]:
    return {
        str(key): str(bool_grouping_value(str(key), value))
        for key, value in parsed_fields.items()
        if can_see_grouping_dimension(str(key), permissions) and is_field_valid(value)
    }
