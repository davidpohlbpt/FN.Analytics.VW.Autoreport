import fastapi

from pycore.api.web.endpoints.report import router as report_router
from pycore.api.web.endpoints.settings import router as settings_router
from pycore.api.web.endpoints.smart import router as smart_router
from pycore.api.web.endpoints.table_edit import router as table_edit_router
from pycore.api.web.endpoints.tracker import router as tracker_router
from pycore.api.web.endpoints import workbench as workbench_data
from pycore.api.web.endpoints.workbench import router as workbench_router
from pycore.api.web.endpoints.workbench_action import router as workbench_action_router
from pycore.workbench.actions.constants import WORKBENCH_ACTION_PREFIX

REPORTS_DATA_PREFIX = "/reports/data"
TRACKER_PREFIX = "/tracker"
SETTINGS_PREFIX = "/settings"
WORKBENCH_PREFIX = "/api/v1/workbenchData"
WORKBENCH_METADATA_PREFIX = "/api/v1/workbenchMetadata"

router = fastapi.APIRouter()
router.include_router(
    table_edit_router, prefix=REPORTS_DATA_PREFIX, tags=["Table Edit"]
)
router.include_router(smart_router, prefix=REPORTS_DATA_PREFIX, tags=["Smart"])
router.include_router(report_router, prefix=REPORTS_DATA_PREFIX, tags=["Reports"])
router.include_router(
    tracker_router, prefix=TRACKER_PREFIX, tags=["Tracker Integration"]
)
router.include_router(settings_router, prefix=SETTINGS_PREFIX, tags=["Settings"])
router.include_router(
    workbench_router,
    prefix=WORKBENCH_PREFIX,
    tags=["Workbench"],
)
router.include_router(
    workbench_data.metadata_router,
    prefix=WORKBENCH_METADATA_PREFIX,
    tags=["Workbench"],
)
router.include_router(
    workbench_action_router,
    prefix=WORKBENCH_ACTION_PREFIX,
    tags=["Workbench"],
)
