from fastapi.openapi.models import OAuthFlowClientCredentials
from fastapi.security import HTTPBearer, OAuth2

from pycore.config import settings

# Write an OAuth2 client credentials dependency for FastAPI
oauth_client_creds_scheme = OAuth2(
    flows={
        "clientCredentials": OAuthFlowClientCredentials(
            refreshUrl=f"{settings.ext_base_url}/identity/refresh/token",
            tokenUrl=f"{settings.ext_base_url}/identity/connect/token",
            scopes={"factory-navigator-admin-api": "Factory Navigator Admin API"},
        ),
    },
    auto_error=False,
)

http_bearer_scheme = HTTPBearer(auto_error=False)
