import logging
from collections.abc import Sequence

from pycore.api.web import contracts
from pycore.schemas import (
    Filter,
    FilterExpression,
    FilterOperator,
    QuickFilterModel,
    QuickFilterOperator,
    QuickFilterType,
)

# Dictionary mapping QuickFilter tye to their corresponding FilterOperator
quick_filter_type_to_operator = {
    QuickFilterOperator.CONTAINS: FilterOperator.fuzzy_search,
    QuickFilterOperator.NOT_CONTAINS: FilterOperator.not_fuzzy_search,
    QuickFilterOperator.EQUALS: FilterOperator.equal,
    QuickFilterOperator.NOT_EQUAL: FilterOperator.not_equal,
    QuickFilterOperator.STARTS_WITH: FilterOperator.begins_with,
    QuickFilterOperator.ENDS_WITH: FilterOperator.ends_with,
    QuickFilterOperator.BLANK: FilterOperator.is_null_or_empty,
    QuickFilterOperator.NOT_BLANK: FilterOperator.is_not_null_or_empty,
    QuickFilterOperator.GREATER_THAN: FilterOperator.greater,
    QuickFilterOperator.GREATER_THAN_OR_EQUAL: FilterOperator.greater_or_equal,
    QuickFilterOperator.LESS_THAN: FilterOperator.less,
    QuickFilterOperator.LESS_THAN_OR_EQUAL: FilterOperator.less_or_equal,
    QuickFilterOperator.IN_RANGE: FilterOperator.between,
}


def convert_report_filters(
    rep_filters: list[contracts.ReportFilter],
    all_must_be_met: bool = True,
) -> FilterExpression:
    filters = []
    for rep_filter in rep_filters:
        filters.append(
            Filter(
                type=(
                    FilterOperator.multiselect
                    if rep_filter.filter_type == contracts.FilterType.IN
                    else FilterOperator.equal
                ),
                name=rep_filter.filter_field,
                value=rep_filter.default_value,
                value2=None,
            )
        )

    return FilterExpression(filters=filters, all_must_be_met=all_must_be_met)


def _convert_standard_filter(
    adv_filter: contracts.StandardFilter,
) -> Filter:
    if adv_filter.filter_type == FilterOperator.multiselect:
        v, v2 = [
            value["name"] if isinstance(value, dict) else value
            for value in adv_filter.value
        ], None
    else:
        v, v2 = adv_filter.value, adv_filter.value2

    return Filter(
        name=adv_filter.name,
        type=adv_filter.filter_type,
        value=v,
        value2=v2,
    )


def convert_standard_filters(
    adv_filters: list[contracts.StandardFilter],
    all_must_be_met: bool = True,
) -> FilterExpression:
    filters = []
    for adv_filter in adv_filters:
        filters.append(_convert_standard_filter(adv_filter))

    return FilterExpression(filters=filters, all_must_be_met=all_must_be_met)


def convert_quick_filters(
    quick_filters: dict[str, contracts.QuickFilter],
    all_must_be_met: bool = True,
) -> FilterExpression:
    filters = []
    for name, quick_filter in quick_filters.items():
        if quick_filter.filter_type == QuickFilterType.MULTI:
            for filter in quick_filter.filter_models:
                if filter is not None:
                    filters.append(create_quick_filter(name, filter))
        else:
            filters.append(create_quick_filter(name, quick_filter))

    return FilterExpression(filters=filters, all_must_be_met=all_must_be_met)


def create_quick_filter(name: str, quick_filter: QuickFilterModel):
    if quick_filter.filter_type == QuickFilterType.SET:
        return Filter(
            type=(
                FilterOperator.multiselect_or_blank
                if None in quick_filter.values
                else FilterOperator.multiselect
            ),
            name=name,
            value=[v for v in quick_filter.values if v is not None],
            value2=None,
        )
    return Filter(
        type=(
            FilterOperator.date_equal
            if quick_filter.filter_type == QuickFilterType.DATE
            else quick_filter_type_to_operator[quick_filter.type]
        ),
        name=name,
        value=(
            quick_filter.date_from
            if quick_filter.filter_type == QuickFilterType.DATE
            else quick_filter.filter
        ),
        value2=quick_filter.filter_to,
    )


def _convert_nested_filter_group(nested_filter: contracts.NestedFilterGroup):
    filters = []
    or_filter_group = []
    for filter_ in nested_filter.filters:
        or_filter_group.append(convert_nested_filter(filter_))
        if filter_.group_operator != contracts.GroupOperator.OR:
            if len(or_filter_group) == 1:
                filters.append(or_filter_group[0])
            else:
                filters.append(
                    FilterExpression(filters=or_filter_group, all_must_be_met=False)
                )
            or_filter_group = []
    if len(filters) == 1:
        return filters[0]
    else:
        return FilterExpression(filters=filters, all_must_be_met=True)


def _convert_nested_filter_leaf(nested_filter_group: contracts.NestedFilterGroup):
    filters = []
    all_must_be_met = (
        nested_filter_group.filters[0].operator != contracts.GroupOperator.OR
    )
    for nested_filter_leaf in nested_filter_group.filters:
        filters.append(_convert_standard_filter(nested_filter_leaf.filter))
    return FilterExpression(filters=filters, all_must_be_met=all_must_be_met)


def convert_nested_filter(
    nested_filter_group: contracts.NestedFilterGroup,
) -> FilterExpression:
    if not nested_filter_group.filters:
        return FilterExpression(filters=[])
    elif isinstance(nested_filter_group.filters[0], contracts.NestedFilterGroup):
        return _convert_nested_filter_group(nested_filter_group)
    elif isinstance(nested_filter_group.filters[0], contracts.NestedFilterLeaf):
        return _convert_nested_filter_leaf(nested_filter_group)
    else:
        raise RuntimeError(
            "Nested filter must contain either NestedFilterGroup or NestedFilterLeaf type filters"
        )


def convert_drill_through_filters(
    drill_through_filters: list[Sequence[contracts.DrillThroughFilter]],
) -> FilterExpression:
    expressions = []
    for drill_through_filter in drill_through_filters:
        filters = []
        for filter_ in drill_through_filter:
            filters.append(
                Filter(
                    type=FilterOperator.equal,
                    name=filter_.column_name,
                    value=filter_.value,
                    value2=None,
                )
            )
        # Logical AND
        expressions.append(
            FilterExpression(
                filters=filters,
                all_must_be_met=True,
            )
        )

    # Logical OR
    return FilterExpression(filters=expressions, all_must_be_met=False)


def convert_chart_filters(
    chart_filters: list[contracts.ChartFilter],
) -> tuple[FilterExpression, Filter]:
    filters = []

    minmax_filter = None

    for chart_filter in chart_filters:
        filter_ = convert_chart_filter(chart_filter)
        if filter_ is None:  # invalid filter type
            continue
        if filter_.type not in [FilterOperator.is_max, FilterOperator.is_min]:
            filters.append(filter_)
        else:
            if minmax_filter is not None:
                raise RuntimeError("Only one min/max filter is allowed")
            minmax_filter = filter_

    return FilterExpression(filters=filters, all_must_be_met=True), minmax_filter


def convert_chart_filter(chart_filter: contracts.ChartFilter) -> Filter:
    if chart_filter.filter_type == contracts.ChartFilterType.MultiSelect:
        return Filter(
            type=FilterOperator.multiselect,
            name=chart_filter.column_name,
            value=chart_filter.values,
        )
    elif chart_filter.filter_type == contracts.ChartFilterType.ExactValue:
        if len(chart_filter.values) != 1:
            raise RuntimeError("ExactValue filter must have exactly one value")
        return Filter(
            type=FilterOperator.equal,
            name=chart_filter.column_name,
            value=chart_filter.values[0],
        )
    elif chart_filter.filter_type == contracts.ChartFilterType.NotEmpty:
        return Filter(
            type=FilterOperator.is_not_null_or_empty,
            name=chart_filter.column_name,
        )
    elif chart_filter.filter_type == contracts.ChartFilterType.TimestampMax:
        return Filter(
            type=FilterOperator.is_max,
            name=chart_filter.column_name,
        )
    elif chart_filter.filter_type == contracts.ChartFilterType.TimestampMin:
        return Filter(
            type=FilterOperator.is_min,
            name=chart_filter.column_name,
        )
    else:
        logging.error(f"Unknown chart filter type: {chart_filter.filter_type}")
