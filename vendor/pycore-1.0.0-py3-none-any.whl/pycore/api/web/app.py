"""This module allows to run PyCore as web service exposing APIs.

PyCore offers several generic APIs for data retrieval.
In addition, custom data retrieval and interaction functions can be 'hooked-in' by developers.
They are secured in the same way as the generic APIs.

We use [FastAPI](https://fastapi.tiangolo.com/) as web service framework.
FastAPI is written in a very Pythonic way and easy to use, even for beginners.
It relies heavily on type annotations and [Pydantic](https://docs.pydantic.dev/) to specify APIs.
"""

import logging
import pathlib
from contextlib import asynccontextmanager
from typing import Annotated

import fastapi
import fastapi.security
import pydantic
import requests
import uvicorn
from fastapi.openapi.docs import get_swagger_ui_html
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from starlette import status

from pycore import ResourceState, easy
from pycore.api.web import endpoints
from pycore.api.web.security import http_bearer_scheme, oauth_client_creds_scheme
from pycore.api.web.utils import log_failed_request_validations, set_uuid_as_contextvar
from pycore.config import settings
from pycore.enum import EnvironmentType, ResourceType
from pycore.logs import LOG_FORMAT, enable_remote_loggers

# Align format with standard PyCore format
log_config = uvicorn.config.LOGGING_CONFIG
log_config["formatters"]["access"]["fmt"] = LOG_FORMAT
log_config["formatters"]["default"]["fmt"] = LOG_FORMAT


def get_servers() -> list[dict[str, str]]:
    if settings.environment == EnvironmentType.LOCAL:
        # Locally, requests to deployed services are not allowed due to security reasons (CORS).
        return []
    else:
        # When deployed, requests can be routed through the API gateway.
        app_suffix = settings.root_path.split("/")[
            -1
        ]  # e.g. get "inaservice" out of /adminapigw/inaservice
        return [
            {
                "url": f"{settings.ext_base_url}/apigw/{app_suffix}",
                "description": "User API Gateway",
            }
        ]


servers = get_servers()


@asynccontextmanager
async def lifespan(app: fastapi.FastAPI):
    """Executed when the web service is started."""
    logger = logging.getLogger("uvicorn")
    formatter = logging.Formatter(LOG_FORMAT)
    for handler in logger.handlers:
        handler.setFormatter(formatter)
    if settings.environment != EnvironmentType.LOCAL:
        enable_remote_loggers(
            service_name=settings.app_name, monitoring_repo=easy.monitoring_service
        )
    elif settings.resource_type == ResourceType.MEMORY:
        # Make sure DB models are created in in-memory DB
        logging.info("Creating DB tables in in-memory DB.")

    # Hook-ins are supposed to be added before the service is started
    # It must be prevented that hook-ins depend on some sort of business logic
    # and are created in the context of individual requests.
    easy.hook_repo.close()
    yield


# The actual web service object should not be interacted with
# by PyCore users developers for security reasons.
# Endpoints can be added by calling add_secure_router().
# Currently, no security scheme is actually used but this might
# change in the future.
app = fastapi.FastAPI(
    title=settings.app_name,
    version=settings.build_tag,
    debug=settings.debug,
    root_path=settings.root_path,
    servers=servers,
    lifespan=lifespan,
    docs_url=None,  # Disable default /docs to serve Swagger UI manually (supports offline mode)
    dependencies=[
        fastapi.Depends(oauth_client_creds_scheme),
        fastapi.Depends(http_bearer_scheme),
    ],
)
app.include_router(router=endpoints.router)

log_failed_request_validations(app)
set_uuid_as_contextvar(app)


def add_secure_router(router):
    app.include_router(router=router)


# Mount local Swagger UI static assets for offline mode
_STATIC_DIR = pathlib.Path(__file__).parent / "static"
app.mount("/static/swagger-ui", StaticFiles(directory=_STATIC_DIR), name="swagger-ui-static")


class AppHealth(pydantic.BaseModel):
    app_name: str
    build_tag: str
    commit_hash: str
    resources: dict[str, ResourceState]


@app.get("/", include_in_schema=False)
async def docs_redirect() -> RedirectResponse:
    """Redirects to the Swagger UI if no specific route is provided."""
    return RedirectResponse(url="/docs")


_SWAGGER_CDN = "https://cdn.jsdelivr.net/npm/swagger-ui-dist@5.9.0"


def _prefix(path: str) -> str:
    """Prepend root_path to a URL path, avoiding double slashes."""
    root = settings.root_path.rstrip("/") if settings.root_path else ""
    return f"{root}{path}"


def _build_offline_swagger_html(title: str) -> str:
    """Returns a self-contained Swagger UI HTML page that loads assets from local static files."""
    return f"""<!DOCTYPE html>
<html>
  <head>
    <title>{title}</title>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="{_prefix('/static/swagger-ui/swagger-ui.css')}">
  </head>
  <body>
    <div id="swagger-ui"></div>
    <script src="{_prefix('/static/swagger-ui/swagger-ui-bundle.js')}"></script>
    <script src="{_prefix('/static/swagger-ui/swagger-ui-standalone-preset.js')}"></script>
    <script>
      window.onload = function() {{
        SwaggerUIBundle({{
          url: "{_prefix('/openapi.json')}",
          dom_id: '#swagger-ui',
          presets: [SwaggerUIBundle.presets.apis, SwaggerUIStandalonePreset],
          layout: "StandaloneLayout"
        }})
      }}
    </script>
  </body>
</html>"""


@app.get("/docs", include_in_schema=False)
async def custom_swagger_ui() -> HTMLResponse:
    """Serves the Swagger UI.

    When ``offline_mode`` is enabled the JS/CSS assets are loaded from locally
    mounted static files so that the UI works without internet access.
    Otherwise the standard CDN URLs are used.
    """
    title = f"{settings.app_name} - Swagger UI"
    if settings.offline_mode:
        return HTMLResponse(_build_offline_swagger_html(title))
    return get_swagger_ui_html(
        openapi_url=_prefix("/openapi.json"),
        title=title,
        swagger_js_url=f"{_SWAGGER_CDN}/swagger-ui-bundle.js",
        swagger_css_url=f"{_SWAGGER_CDN}/swagger-ui.css",
    )


@app.get("/health", tags=["Admin"])
async def get_app_health() -> AppHealth:
    """Provides general information about the app, its configuration and its connected resources."""
    resource_state = {
        "storage": easy.storage.state,
        "vault": easy.vault.state,
        "database": easy.database.state,
        "http_session": easy.http_session.state,
    }

    return AppHealth(
        app_name=settings.app_name,
        build_tag=settings.build_tag,
        commit_hash=settings.commit_hash,
        resources=resource_state,
    )


@app.get("/health/readiness", tags=["Admin"])
async def get_app_readiness() -> dict[str, bool]:
    """Provides readiness information about the app by checking whether the key vault can be reached."""
    if easy.vault.is_active:
        return {"ready": True}
    else:
        raise fastapi.HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="No connection to key vault.",
        )


@app.get("/health/liveness", tags=["Admin"])
async def get_app_liveness() -> dict[str, bool]:
    """Provides liveness information about the app."""
    return {"alive": True}


basic_security = fastapi.security.HTTPBasic(
    description="Used to retrieve a user token from the IdentityService."
)


@app.post("/token", tags=["Admin"])
def get_user_token(
    credentials: Annotated[
        fastapi.security.HTTPBasicCredentials, fastapi.Depends(basic_security)
    ]
) -> str:
    """Retrieves a user token from the IdentityService.

    Enter your personal DQN username and password as basic auth credentials (see lock symbol on the right in Swagger UI).
    """
    url = f"{settings.ext_base_url}/api/login"
    body = {"username": credentials.username, "password": credentials.password}
    response = requests.post(url, json=body)

    if response.status_code == fastapi.status.HTTP_200_OK:
        return response.json()["value"]["accessToken"]
    else:
        raise fastapi.HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password.",
        )
