import logging
import uuid

import fastapi
from fastapi.exception_handlers import request_validation_exception_handler
from fastapi.exceptions import RequestValidationError

from pycore.api.web.filters import convert_quick_filters
from pycore.logs import uuid_context
from pycore.schemas import (
    DataAction,
    DataQuery,
    Filter,
    FilterOperator,
    Interaction,
    MultipleDataQuery,
    QuickFilter,
    ReportFilter,
    Scope,
    SingleDataQuery,
    convert_report_to_adv_filters,
)


def derive_table_identifier(table_identifier: str) -> tuple[str, str | None]:
    """Process the data source name to extract schema and table names.

    Args:
        table_identifier (str): The table identifier in the format "schema.table" or "table".

    Returns:
        tuple[str, Optional[str]]: A tuple containing the table name and schema name.
    """
    parts = table_identifier.split(".")
    if len(parts) == 1:
        return parts[0], None
    elif len(parts) == 2 and parts[1] != "":
        return parts[1], parts[0]
    else:
        raise ValueError(f"Invalid data source name: '{table_identifier}'.")


def simplify_single_query(query: SingleDataQuery | Interaction) -> DataQuery:
    table, schema = derive_table_identifier(table_identifier=query.data_source.name)

    # Get columns
    if query.data_source.data_source_columns:
        columns = [c.column_name for c in query.data_source.data_source_columns]
    else:
        columns = None

    filters = merge_filters(
        adv_filters=query.advanced_filters,
        rep_filters=query.filters,
        def_filters=query.data_source.default_filters,
        scope=query.scope,
        quick_filters=query.quick_filters,
    )

    return DataQuery(
        table=table,
        schema_=schema,
        columns=columns,
        drill_through_filters=query.drill_through_filters,
        filters=filters,
        nested_filters=query.nested_filters,
        properties={"data_source_id": query.data_source.data_source_id},
    )


def simplify_multi_query(query: MultipleDataQuery) -> list[DataQuery]:
    queries = []
    for data_source in query.data_sources:
        single_query = SingleDataQuery(
            filters=query.filters,
            advanced_filters=query.advanced_filters,
            scope=query.scope,
            data_source=data_source,
            quick_filters=query.quick_filters,
            drill_through_filters=query.drill_through_filters,
            nested_filters=query.nested_filters,
        )
        simple_single_query = simplify_single_query(query=single_query)
        queries.append(simple_single_query)
    return queries


def simplify_interaction(interaction: Interaction) -> DataAction:
    filters = merge_filters(
        adv_filters=interaction.advanced_filters,
        rep_filters=interaction.filters,
        def_filters=interaction.data_source.default_filters,
        scope=interaction.scope,
    )

    return DataAction(
        action_name=interaction.action,
        filters=filters,
        data=interaction.data,
        data_source=interaction.data_source,
        drill_through_filters=interaction.drill_through_filters,
        properties={"data_source_id": interaction.data_source.data_source_id},
    )


def merge_filters(
    adv_filters: list[Filter],
    rep_filters: list[ReportFilter],
    def_filters: list[ReportFilter],
    scope: Scope,
    quick_filters: dict[str, QuickFilter] | None = None,
) -> list[Filter]:
    # Advanced filters are kept "as is"
    filters = adv_filters

    # Simplify report filters
    filters += convert_report_to_adv_filters(rep_filters=rep_filters)

    if scope.entity_id is not None:
        filters.append(
            Filter(type=FilterOperator.equal, name="entity_id", value=scope.entity_id)
        )

    if scope.load_id is not None:
        filters.append(
            Filter(type=FilterOperator.equal, name="load_id", value=scope.load_id)
        )

    if scope.reporting_unit_id is not None:
        filters.append(
            Filter(
                type=FilterOperator.equal,
                name="reporting_unit_id",
                value=scope.reporting_unit_id,
            )
        )

    # Default filters are "independent" from report filters
    # They must not be combined in a single multiselect
    filters += convert_report_to_adv_filters(rep_filters=def_filters)

    if quick_filters:
        filters += convert_quick_filters(quick_filters).filters

    return filters


def log_failed_request_validations(app):
    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(
        request: fastapi.Request, exc: RequestValidationError
    ):
        logging.error(f"{exc}")
        return await request_validation_exception_handler(request, exc)


def set_uuid_as_contextvar(app):
    @app.middleware("http")
    async def set_uuid(request: fastapi.Request, call_next):
        current_uuid = uuid.uuid4()
        uuid_context.set(current_uuid)
        response = await call_next(request)
        return response
