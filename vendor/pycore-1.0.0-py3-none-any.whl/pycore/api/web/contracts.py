"""The models in this module represent the contract with the ReportDataProvider / API gateway.

ANY change must be aligned beforehand. Ideally, they are generated via the library datamodel-code-generator
from the provided OpenAPI specification.
"""

import enum
import json
import logging
from collections.abc import Sequence
from enum import Enum
from typing import Any

from pydantic import (
    BaseModel,
    Field,
    NonNegativeInt,
    PositiveInt,
    computed_field,
    field_validator,
    model_validator,
)

from pycore.schemas import AggregationFunction, FilterOperator, QuickFilter
from pycore.utils.pydantic import CamelModel, CaseInsensitiveEnum


class GroupOperator(str, Enum):
    AND = "AND"
    OR = "OR"


class FilterType(CaseInsensitiveEnum):
    IN = "IN"
    EQUAL = "EQUAL"
    EQUALS = "="


class SortingDirection(str, Enum):
    ASC = "asc"
    DESC = "desc"


class StandardFilter(CamelModel):

    filter_type: FilterOperator | None = None
    name: str | None = None
    value: Any | None = None
    value2: str | None = None

    @model_validator(mode="after")
    def parse_list_of_values(self):
        if self.filter_type != FilterOperator.multiselect:
            return self

        if isinstance(self.value, str):
            try:
                self.value = json.loads(self.value)
            except json.JSONDecodeError as exc:
                raise ValueError(
                    f"Invalid JSON for multiselect filter value: {self.value!r}"
                ) from exc
        return self


class ReportDataSorting(CamelModel):

    active: str | None = None
    direction: str | None = None

    @model_validator(mode="after")
    def validate_sort_order(self):
        cols = self.active.split(",")
        dirs = self.direction.split(",")

        if len(cols) != len(dirs):
            raise ValueError(
                f"Number of columns ({len(cols)}) must match sort order ({len(dirs)})"
            )

        is_valid_order = [
            d.lower() in (SortingDirection.ASC, SortingDirection.DESC) for d in dirs
        ]

        if not all(is_valid_order):
            raise ValueError(
                "Sorting direction must be either 'ASC' or 'DESC' (case-insensitive)"
            )

        return self

    @computed_field
    @property
    def columns(self) -> list[tuple[str, bool]]:
        cols = self.active.split(",")
        dirs = self.direction.split(",")
        return [(c, SortingDirection.ASC == d.lower()) for c, d in zip(cols, dirs)]


class DrillThroughFilter(CamelModel):

    column_name: str | None = None
    value: str | None = None


class NestedFilterLeaf(CamelModel):
    filter: StandardFilter
    index: int | None = None
    operator: GroupOperator | None = None


NestedFilterList = list[NestedFilterLeaf]


class NestedFilterGroup(CamelModel):

    index: int | None = None
    group_operator: GroupOperator | None = None
    filters: NestedFilterList | list["NestedFilterGroup"]


class MaskFilter(CamelModel):

    id: int | None = None
    value: str | None = None


class ReportFilter(CamelModel):
    filter_type: FilterType
    filter_field: str
    default_values: Any | None = None
    default_value: Any | None = None

    # If the filter is of type IN, the default value might be a comma separated list of values
    # This adjusts the input to match a FilterOperator.multiselect e.g. "test" => '[{ "name": "test"}]'
    @model_validator(mode="after")
    def convert_default_values_if_filter_type_in(self):
        if self.filter_type != FilterType.IN:
            return self
        if isinstance(self.default_value, str):
            if self.default_value.startswith('[{"name":'):
                return self
            array_representation = [
                {"name": item.strip()} for item in self.default_value.split(",")
            ]
            self.default_value = json.dumps(array_representation)
            return self
        if (
            isinstance(self.default_values, list)
            and self.default_values
            and isinstance(self.default_values[0], str)
        ):
            array_representation = [
                {"name": item.strip()} for item in self.default_values
            ]
            self.default_value = json.dumps(array_representation)
        return self


class ChartFilterType(str, Enum):
    NotEmpty = "NotEmpty"
    MultiSelect = "MultiSelect"
    ExactValue = "ExactValue"
    TimestampMax = "TimestampMax"
    TimestampMin = "TimestampMin"


class ChartFilter(CamelModel):
    column_name: str
    filter_type: ChartFilterType
    values: list[str] | None = None

    @field_validator("values", mode="before", check_fields=False)
    def trim_strings(cls, values):
        if isinstance(values, list):
            return [v.strip() if isinstance(v, str) else v for v in values]
        if isinstance(values, str):
            return values.strip()
        return values


class DataSource(CamelModel):
    table_name: str
    columns: list[str] | None = None
    data_source_filters: list[ReportFilter] | None = Field(default_factory=list)


class DataSourceContract(CamelModel):
    report_data_source: DataSource


class FilterContract(CamelModel):
    report_filters: list[ReportFilter] | None = Field(default_factory=list)
    drill_through_filters: list[Sequence[DrillThroughFilter]] | None = Field(
        default_factory=list
    )
    advanced_filters: list[StandardFilter] | None = Field(default_factory=list)
    advanced_filters_groups: NestedFilterGroup | None = None
    quick_filters: dict[str, QuickFilter] | None = None


class ReportDataSliceRequest(DataSourceContract, FilterContract):

    take: PositiveInt | None = None
    skip: NonNegativeInt | None = None
    applied_sorting: ReportDataSorting | None = None


class ReportDataSliceResponse(CamelModel):

    result: list[dict[str, Any]]


class ReportDataCountRequest(DataSourceContract, FilterContract):
    pass


class ReportDataCountResult(CamelModel):
    total_count: int


class ReportDataCountResponse(CamelModel):

    result: ReportDataCountResult


class FilterMetadataRequest(FilterContract):
    data_sources: list[DataSource]
    filter_column: str
    take: NonNegativeInt | None = None
    skip: NonNegativeInt | None = None
    search_term: str | None = None
    selected_values: list[str] | None = None


FilterMetadataResponse = list[str]


class DataSourceColumnsRequest(FilterContract):
    data_sources: list[DataSource]
    filter_columns: list[str]
    take: NonNegativeInt | None = None
    skip: NonNegativeInt | None = None


class DataSourceColumnsResponse(CamelModel):
    result: list[dict[str, Any]]


class ReportKpiRequest(DataSourceContract, FilterContract):
    kpi_query: str

    @field_validator("kpi_query", mode="before")
    def replace_double_quotes(cls, value):
        if value is None:
            raise ValueError("kpi_query must not be None")
        if '"' in value:
            logging.warning(
                "Double quotes found in `kpi_query`, replacing with single quotes.",
                extra={"query": value},
            )
            value = value.replace('"', "'")
        return value


class ReportKpiResult(CamelModel):
    value: float | str | None = None
    delta_value: float | None = None


class ReportKpiResponse(CamelModel):
    result: ReportKpiResult


class ReportChartAesthetic(CamelModel):
    dimension: str
    aggregation: AggregationFunction | None = None


class ReportChartGeometry(CamelModel):
    geom_id: int
    aesthetics: list[ReportChartAesthetic]


class ReportChartRequest(DataSourceContract, FilterContract):
    chart_geometries: list[ReportChartGeometry]
    applied_sorting: ReportDataSorting | None = None
    chart_filters: list[ChartFilter] | None = None


class ReportChartResult(CamelModel):
    geometry_id: int
    geometry_data: list[dict[str, Any]]


class ReportChartResponse(CamelModel):
    result: list[ReportChartResult]


class TableColumnType(str, enum.Enum):
    NUMERIC = "numeric"
    BOOLEAN = "boolean"
    RESTRICTED_BOOLEAN = "restrictedboolean"
    DROPDOWN = "dropdown"
    JSON = "JSON"
    DATETIME = "datetime"
    DATE = "date"
    STRING = "string"


class TablePrimaryKey(CamelModel):
    column_name: str
    value: str


class TableFieldValue(CamelModel):
    column_name: str
    data_type: TableColumnType | None = None
    new_value: str | None = None
    old_value: str | None = None
    primary_keys: list[TablePrimaryKey] | None = None


TableInsertModel = list[list[TableFieldValue]]
TableUpdateModel = list[TableFieldValue]
TableDeleteModel = list[list[TablePrimaryKey]]


class TableEditRequest(CamelModel):
    has_audit: bool
    report_data_source: DataSource
    insert_view_model: TableInsertModel | None = None
    update_view_model: TableUpdateModel | None = None
    delete_view_model: TableDeleteModel | None = None


class TableEditResult(CamelModel):
    result_insert: bool
    result_update: bool
    result_delete: bool


class TableEditResponse(CamelModel):
    result: TableEditResult


class RetrieveSingleValueByPrimaryKeyRequest(DataSourceContract):
    tile_id: int
    column_name: str
    primary_keys: list[TablePrimaryKey]
