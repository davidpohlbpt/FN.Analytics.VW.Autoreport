import logging
from collections.abc import Generator

import fastapi
import jwt
import pydantic
import sqlalchemy as sa
from fastapi import Security
from fastapi.security import HTTPAuthorizationCredentials
from starlette import status

from pycore import easy
from pycore.api.web.security import http_bearer_scheme
from pycore.repository.settings import SettingsRepository


def get_db() -> Generator:
    """Yields a DB session to be used in the context of a web request, i.e., as single transaction.

    The session is closed directly before the response is returned to the client.
    This means, that all (uncommitted) changes are committed.

    Yields:
        Generator: DB session object
    """
    # No exception handling can be done here since the response is returned to the client
    # before the code after 'yield' is executed.
    # See: https://fastapi.tiangolo.com/uk/tutorial/dependencies/dependencies-with-yield/
    try:
        with easy.database.session_scope() as session:
            yield session
    except sa.exc.DBAPIError as e:
        logging.exception(f"Database transaction failed: {e}")
        raise fastapi.HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Database error: {e}",
        )


def get_settings_repo():
    if not easy.hook_repo.has_hooked_settings():
        raise fastapi.HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="No settings are hooked-in.",
        )

    return easy.hook_repo.get_hooked_in_settings()


class BearerSession:
    def __init__(
        self, auth_creds: HTTPAuthorizationCredentials = Security(http_bearer_scheme)
    ):
        """Verifies and decodes a JWT passed in the auth header as bearer token."""
        try:
            self.token = auth_creds.credentials
            self.payload = jwt.decode(self.token, options={"verify_signature": False})
            self.id = self.payload.get("sub")
            self.email = self.payload.get("email")
            self.full_name = self.payload.get("full_name")
        except Exception as e:
            raise fastapi.HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=f"Invalid token ({e}).",
            )
