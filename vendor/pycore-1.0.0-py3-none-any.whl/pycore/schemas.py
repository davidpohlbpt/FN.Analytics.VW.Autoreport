import datetime
import datetime as dt
import enum
import json
import re
from collections.abc import Sequence
from enum import Enum
from itertools import groupby
from typing import Any, Union
from uuid import UUID

import pydantic
from pydantic import ConfigDict, Field, field_validator, model_validator

from pycore.enum import FilterType, ProcessState, TaskStatus
from pycore.utils.collections import create_json_from_str
from pycore.utils.pydantic import CamelModel, CaseInsensitiveEnum


class ApiResponse(pydantic.BaseModel):
    message: str


class ReportFilter(CamelModel):
    filter_type: FilterType
    """ The type of filter to be applied,
    currently supporting only 'IN' and 'EQUAL'
    Different from the advanced filters type
    """
    filter_field: str
    """ The column name on which the filter should be applied
    """
    value: str
    """ The value to be compared when applying the filter
    """


class DefaultReportFilter(CamelModel):
    """This class exists to match the default filters format coming from apigw"""

    filter_type: FilterType
    filter_field: str
    default_value: str


class DataSourceColumn(CamelModel):
    column_name: str


class DataSource(CamelModel):
    data_source_id: int | None = None
    name: str
    data_source_columns: list[DataSourceColumn] | None = None
    default_filters: list[DefaultReportFilter] | None = []


class QuickFilterType(str, Enum):
    TEXT = "text"
    DATE = "date"
    MULTI = "multi"
    NUMBER = "number"
    SET = "set"


class QuickFilterModel(CamelModel):
    filter: str | None = None
    filter_to: str | None = None
    filter_type: QuickFilterType | None = None
    date_from: str | None = None
    date_to: str | None = None
    type: str | None = None
    values: list[Any] | None = None


class QuickFilter(QuickFilterModel):

    filter_models: list[QuickFilterModel | None] | None = None


class Scope(CamelModel):
    entity_id: int | None = None
    load_id: int | None = None
    reporting_unit_id: int | None = None
    user_id: str | None = None


class QuickFilterOperator(CaseInsensitiveEnum):
    CONTAINS = "contains"
    NOT_CONTAINS = "notContains"
    EQUALS = "equals"
    NOT_EQUAL = "notEqual"
    STARTS_WITH = "startsWith"
    ENDS_WITH = "endsWith"
    BLANK = "blank"
    NOT_BLANK = "notBlank"
    GREATER_THAN = "greaterThan"
    GREATER_THAN_OR_EQUAL = "greaterThanOrEqual"
    LESS_THAN = "lessThan"
    LESS_THAN_OR_EQUAL = "lessThanOrEqual"
    IN_RANGE = "inRange"


class FilterOperator(CaseInsensitiveEnum):
    greater = "higher"
    greater_or_equal = "higherorequal"
    less = "lower"
    less_or_equal = "lowerorequal"
    equal = "equal"
    not_equal = "notequal"
    between = "between"
    date_before = "datebefore"
    date_strictly_before = "datestrictlybefore"
    date_after = "dateafter"
    date_strictly_after = "datestrictlyafter"
    date_equal = "dateequal"
    date_not_equal = "datenotequal"
    date_between = "datebetween"
    fuzzy_search = "fuzzysearch"
    not_fuzzy_search = "notfuzzysearch"
    exact_search = "exactsearch"
    multiselect = "multiselect"
    multiselect_or_blank = "multiselectblanks"
    yes_no = "yesno"
    is_null = "isnull"
    is_null_or_empty = "isnullorempty"
    is_not_null = "isnotnull"
    is_not_null_or_empty = "isnotnullorempty"
    is_max = "ismax"
    is_min = "ismin"
    begins_with = "beginswith"
    ends_with = "endswith"


class GroupOperator(str, Enum):
    AND = "AND"
    OR = "OR"


class GenericTableColumns(str, Enum):
    last_edited_at = "LastEditedAt"
    last_edited_by = "LastEditedBy"
    last_transaction_id = "LastTransactionID"
    last_transaction_date = "LastTransactionDate"
    is_deleted = "IsDeleted"


class IndexOperator(int, Enum):
    LEFT = 0
    RIGHT = 1


class Filter(CamelModel):
    type: FilterOperator
    """ The type of filter to be applied
    """
    name: str
    """ The column name on which the filter should be applied
    """
    value: Any | None = None
    """ The value to be compared when applying the filter
    """
    value2: Any | None = None
    """ The second value to be compared to for range filters, optional
    """

    @field_validator("value", mode="after")
    def parse_list_of_values(cls, v, values):
        if values.data.get("type") != FilterOperator.multiselect:
            return v

        if isinstance(v, str):
            values_list = json.loads(v)
            return [
                value["name"] if isinstance(value, dict) else value
                for value in values_list
            ]
        elif isinstance(v, list):
            return [value["name"] if isinstance(value, dict) else value for value in v]
        else:
            return v


class FilterExpression(pydantic.BaseModel):
    all_must_be_met: bool = True
    """Indicates if filters are combined with AND or OR
    """

    filters: list[Union["FilterExpression", Filter]]
    """Flat or nested filters to be applied
    """


FilterExpression.model_rebuild()


class ColumnType(str, enum.Enum):
    NUMERIC = "numeric"
    BOOLEAN = "boolean"
    RESTRICTED_BOOLEAN = "restrictedboolean"
    DROPDOWN = "dropdown"
    JSON = "JSON"
    DATETIME = "datetime"
    DATE = "date"
    STRING = "string"


class PrimaryKey(pydantic.BaseModel):
    column_name: str
    value: str


class FieldValue(pydantic.BaseModel):
    column_name: str
    data_type: ColumnType | None = None
    new_value: str | None = None
    old_value: str | None = None


class InsertOperation(pydantic.BaseModel):
    insert_fields: list[FieldValue]


class UpdateOperation(pydantic.BaseModel):
    primary_keys: list[PrimaryKey]
    update_fields: list[FieldValue]


class DeleteOperation(pydantic.BaseModel):
    primary_keys: list[PrimaryKey]


class DataTable(pydantic.BaseModel):
    table_schema: str | None = None
    table_name: str


class TableEditOperations(pydantic.BaseModel):
    has_audit: bool
    data_table: DataTable
    insert_operations: list[InsertOperation] | None = None
    update_operations: list[UpdateOperation] | None = None
    delete_operations: list[DeleteOperation] | None = None

    @model_validator(mode="before")
    @classmethod
    def check_at_least_one_view_model(cls, values):
        if (
            not values.get("insert_operations")
            and not values.get("update_operations")
            and not values.get("delete_operations")
        ):
            raise ValueError(
                "At least one of insert_operations, update_operations, or delete_operations must be provided within table edit request."
            )
        return values

    def validate(self):
        # Explicitly call the root_validator logic
        values = self.model_dump()
        validated_values = self.__class__.check_at_least_one_view_model(values)
        return self.__class__.model_validate(validated_values)

    def remove_field_from_update(
        self, update_operation: UpdateOperation, field: FieldValue
    ):
        update_operation.update_fields.remove(field)
        if not update_operation.update_fields:
            self.update_operations.remove(update_operation)


class AggregationFunction(CaseInsensitiveEnum):
    AVG = "AVG"
    COUNT = "COUNT"
    MIN = "MIN"
    MAX = "MAX"
    SUM = "SUM"


class Query(pydantic.BaseModel):

    table_name: str
    """ The name of the database table.
    """

    schema_: str | None = None
    """The name of the schema in which the table is located.
    """

    select: list[str] | None = None
    """The columns to be retrieved when querying the table.
    """

    distinct: bool | None = False
    """Indicates if the results should be distinct.
    """

    aggregation: dict[str, AggregationFunction] | None = {}
    """The aggregation functions to be applied when querying the table.
    """

    filters: FilterExpression | None = None
    """The filters to be applied when querying the table.
    """

    minmax_filter: Filter | None = None
    """Filter to return only rows having its min/max value (e.g. only latest load ID)
    """

    groupby: list[str] | None = None
    """The columns to be used for grouping the results.
    """

    order_by: list[tuple[str, bool]] | None = None
    """The columns to be used for sorting the results, 
    either ascending (True) or descending (False).
    """

    offset: int | None = None
    """The number of rows to skip before returning the results.
    """

    limit: int | None = None
    """The maximum number of rows to return.
    """


class NestedFilter(CamelModel):
    filter_type: FilterOperator
    """ The type of filter to be applied
    """
    name: str
    """ The column name on which the filter should be applied
    """
    value: Any = None
    """ The value to be compared when applying the filter
    """
    value2: Any = None
    """ The second value to be compared to for range filters, optional
    """

    @field_validator("value", mode="after")
    def parse_list_of_values(cls, v, values):
        if values.data.get("filter_type") != FilterOperator.multiselect:
            return v

        if isinstance(v, str):
            v = json.loads(v)
        return [value["name"] if isinstance(value, dict) else value for value in v]


class NestedFilterLeaf(CamelModel):
    filter: NestedFilter
    index: IndexOperator
    operator: GroupOperator | None = None


NestedFilterList = list[NestedFilterLeaf]


class NestedFilterGroup(CamelModel):
    filters: NestedFilterList | list["NestedFilterGroup"]
    index: IndexOperator
    group_operator: GroupOperator | None = None


class DrillTroughFilter(CamelModel):
    column_name: str
    value: str


class BaseRequest(CamelModel):
    filters: list[ReportFilter] = []
    advanced_filters: list[Filter] = []
    drill_through_filters: list[list[DrillTroughFilter]] | None = None
    scope: Scope
    nested_filters: NestedFilterGroup | None = None
    quick_filters: dict[str, QuickFilter] | None = None

    @field_validator("filters", "advanced_filters", mode="before")
    @classmethod
    def _coerce_none_filters_to_empty_list(cls, value):
        # Clients may send an explicit ``null`` for these collections. Normalize
        # them to empty lists so downstream code (e.g. ``merge_filters``) can rely
        # on always receiving a list instead of guarding against ``None``.
        return [] if value is None else value

    @model_validator(mode="before")
    @classmethod
    def normalize_nested_filters_aliases(cls, values):
        if values is None:
            return values

        nested_filters = values.get("nested_filters")
        nested_filters_alias = values.get("nestedFilters")
        legacy_alias = values.get("advancedFiltersGroups")
        legacy_name = values.get("advanced_filters_groups")

        if nested_filters is None and nested_filters_alias is None:
            if legacy_alias is not None:
                values["nestedFilters"] = legacy_alias
            elif legacy_name is not None:
                values["nestedFilters"] = legacy_name

        return values

    @model_validator(mode="after")
    def unify_filters(self):
        if self.filters:
            converted = convert_report_to_adv_filters(self.filters)
            self.advanced_filters += converted
            self.filters = []
        return self


class MultipleDataQuery(BaseRequest):
    data_sources: list[DataSource]


class SingleDataQuery(BaseRequest):
    data_source: DataSource


class Interaction(BaseRequest):
    action: str
    data: list | dict
    data_source: DataSource


class DataModel(CamelModel):
    data_source_id: int | None = None
    rows: list[dict] | None = None


MultiDataModel = dict[int, list[dict] | None]


class HookObject(pydantic.BaseModel):
    filters: list[Filter] = []
    nested_filters: NestedFilterGroup | None = None
    properties: dict[str, str | int | float] = {}

    @model_validator(mode="after")
    def create_properties(self):
        props = {}
        for filter_ in self.filters:
            if filter_.type == FilterOperator.equal:
                props[filter_.name] = filter_.value
            elif filter_.type == FilterOperator.multiselect and len(filter_.value) == 1:
                props[filter_.name] = filter_.value[0]
        self.properties = props
        return self


class DataQuery(HookObject):
    schema_: str | None = None
    drill_through_filters: list[Sequence[DrillTroughFilter]] | None = None
    table: str
    columns: list[str] | None = None

    @property
    def data_source_name(self):
        if self.schema_:
            return self.schema_ + "." + self.table
        else:
            return self.table


class DataAction(HookObject):
    action_name: str
    data: Any | None = None
    data_source: DataSource | None = None
    drill_through_filters: list[Sequence[DrillTroughFilter]] | None = None


class BatchTask(CamelModel):
    load_id: int = Field(..., alias="loadId")
    scenario_id: int = Field(..., alias="scenarioId")
    task_type_id: int = Field(..., alias="taskTypeId")
    task_status: TaskStatus = Field(TaskStatus.NEW, alias="taskStatus")
    parameters: str = Field(..., alias="parameters")


class BatchTaskList(CamelModel):
    tasks: list[BatchTask] = Field(..., alias="fnTasks")


class TrackerLoadInformation(CamelModel):
    load_id: int = Field(..., alias="loadID")
    entity_id: int = Field(..., alias="entityID")
    scen_id: int = Field(..., alias="scenID")
    timestamp_started: datetime.datetime | None = None
    timestamp_finished: datetime.datetime | None = None
    status: ProcessState


class LoadInformation(pydantic.BaseModel):
    load_id: int
    entity_id: int
    scen_id: int
    load_date: dt.date
    reporting_unit_id: int | None = None


class TrackerEntityInformation(CamelModel):
    entity_id: int = Field(..., alias="entityID")
    system_id: str = Field(..., alias="systemID")
    system_type: str = Field(..., alias="systemType")
    reporting_unit_id: int | None = Field(None, alias="reportingUnitID")


class ProcessStateUpdate(CamelModel):
    entity_id: int = Field(..., alias="entityID")
    scen_id: str = Field(..., alias="scenID")
    load_id: int = Field(..., alias="loadID")
    process_id: str = Field(..., alias="processID")
    process_state: ProcessState


class DevRule(CamelModel):
    rule_id: str = Field(..., alias="ruleId")
    query: str | None = Field(None, alias="masterDataQuery")


class LogData(pydantic.BaseModel):
    module: str
    entity_id: int | None = None
    task_id: str | None = None
    load_id: int | None = None
    scenario_id: int | None = None
    data: dict
    uuid: UUID | None = None


class LogMessage(CamelModel):
    log_level: int | str = Field(..., alias="logLevel")
    timestamp: str | None = None
    service: str | None = None
    message: str
    values_array: LogData | None = None
    value: Any | None = None


class IncidentStatus(str, enum.Enum):
    NEW = "new"
    ONGOING = "ongoing"
    SOLVED = "solved"
    REOCCURED = "reoccurence"
    SOLVED_CURR = "solvedCurr"


class Incident(pydantic.BaseModel):
    scenario_id: int = pydantic.Field(alias="ScenarioID")
    incident_id: int = pydantic.Field(alias="IncidentID")
    entity_id: int | None = pydantic.Field(None, alias="EntityID")
    reporting_unit_id: int | None = pydantic.Field(None, alias="ReportingUnitID")
    technical_rule_id: str = pydantic.Field(alias="RuleID")
    business_rule_id: str = pydantic.Field(alias="BusinessRuleID")
    identifiers: dict[str, Any] = pydantic.Field(alias="Identifier")
    loads: dict[str, list[int]] | None = pydantic.Field(None, alias="Loads")
    status: IncidentStatus = pydantic.Field(alias="Status")
    created_on: dt.datetime | None = pydantic.Field(None, alias="Created")
    assigned_user: str | None = pydantic.Field(None, alias="AssignedUser")

    @pydantic.field_validator("loads", mode="before")
    def create_loads_dict(cls, v):
        return create_json_from_str(v)

    @pydantic.field_validator("identifiers", mode="before")
    def create_identifiers_dict(cls, v):
        return create_json_from_str(v)

    model_config = ConfigDict(populate_by_name=True)


class IncidentEvent(pydantic.BaseModel):
    scenario_id: int = pydantic.Field(alias="ScenarioID")
    incident_id: int = pydantic.Field(alias="IncidentID")
    event_type_id: int = pydantic.Field(alias="EventTypeID")
    date_time: dt.datetime = pydantic.Field(alias="DateTime")
    user_id: str | None = pydantic.Field(None, alias="UserId")
    comment: str = pydantic.Field(alias="Comment")
    hide_until: dt.datetime | None = pydantic.Field(None, alias="HideUntil")
    model_config = ConfigDict(populate_by_name=True)


class GroupInformation(pydantic.BaseModel):
    grouping_dimension_id: int = pydantic.Field(alias="GroupingDimensionID")
    group_id: str = pydantic.Field(alias="GroupID")
    scenario_id: int = pydantic.Field(alias="ScenarioID")
    description: str | None = pydantic.Field(None, alias="Description")
    tag_properties_id: int | None = pydantic.Field(None, alias="TagPropertiesID")
    changed_on: dt.datetime | None = pydantic.Field(None, alias="ChangedOn")
    changed_by: str | None = pydantic.Field(None, alias="ChangedBy")
    model_config = ConfigDict(populate_by_name=True)


class IncidentTag(pydantic.BaseModel):
    incident_id: int = pydantic.Field(alias="IncidentID")
    scenario_id: int = pydantic.Field(alias="ScenarioID")
    tag_properties_id: int | None = pydantic.Field(None, alias="TagPropertiesID")
    changed_on: dt.datetime | None = pydantic.Field(None, alias="ChangedOn")
    changed_by: str | None = pydantic.Field(None, alias="ChangedBy")
    model_config = ConfigDict(populate_by_name=True)


class Occurence(pydantic.BaseModel):
    scenario_id: int = pydantic.Field(alias="ScenarioID")
    occurence_id: int = pydantic.Field(alias="OccurenceID")
    incident_id: int = pydantic.Field(alias="IncidentID")
    technical_rule_id: str = pydantic.Field(alias="RuleID")
    business_rule_id: str = pydantic.Field(alias="BusinessRuleID")
    load_id: int = pydantic.Field(alias="LoadID")
    entity_id: int = pydantic.Field(alias="EntityID")
    reporting_unit_id: int = pydantic.Field(alias="ReportingUnitID")
    fields: dict[str, Any] = pydantic.Field(alias="Fields")

    @pydantic.field_validator("fields", mode="before")
    def create_identifiers_dict(cls, v):
        return create_json_from_str(v)

    model_config = ConfigDict(populate_by_name=True)


class IncidentComment(pydantic.BaseModel):
    comment_id: int = pydantic.Field(alias="Id")
    scenario_id: int = pydantic.Field(alias="ScenarioID")
    incident_id: int = pydantic.Field(alias="IncidentID")
    user_id: str = pydantic.Field(alias="UserId")
    date: dt.datetime | None = pydantic.Field(None, alias="Date")
    comment: str = pydantic.Field(None, alias="Comment")
    created_by: dt.datetime | None = pydantic.Field(None, alias="CreatedBy")
    created_on: dt.datetime | None = pydantic.Field(None, alias="CreatedOn")


def convert_report_to_adv_filters(
    rep_filters: list[DefaultReportFilter | ReportFilter],
) -> list[Filter]:
    if not rep_filters:
        return []

    adv_filters = []
    # Without sorting, the groupby is not reliable
    rep_filters = sorted(rep_filters, key=lambda f: f.filter_field)

    # Condense filters on the same field to a single multi-select filter
    for field, field_filters in groupby(rep_filters, key=lambda f: f.filter_field):
        values = [v for f in field_filters for v in get_filter_values(f)]
        adv_filters.append(
            Filter(type=FilterOperator.multiselect, name=field, value=values)
        )

    return adv_filters


def get_filter_values(filter: DefaultReportFilter | ReportFilter):
    if isinstance(filter, DefaultReportFilter):
        value = filter.default_value
    else:
        value = filter.value

    if filter.filter_type == FilterType.IN:
        return value.split(",")
    else:
        return [value]
