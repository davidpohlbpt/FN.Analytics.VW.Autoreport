from .api.cli.commands import app

app()
